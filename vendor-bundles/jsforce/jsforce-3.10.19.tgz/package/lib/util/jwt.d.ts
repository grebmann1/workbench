/**
 * Checks if a given access token is a JWT.
 *
 * @param {string} accessToken - The access token to check
 * @returns {boolean} True if the token is a valid JWT token, false otherwise.
 */
export declare function isJWTToken(accessToken: string): boolean;
