declare const _default: "3.10.19";
export default _default;
