import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof _Symbol && _getIteratorMethod(r) || r["@@iterator"]; if (!t) { if (_Array$isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { var _context2; if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = _sliceInstanceProperty(_context2 = {}.toString.call(r)).call(_context2, 8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? _Array$from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.to-string.js";
import { Duplex, PassThrough, Writable } from 'stream';
import { getLogger } from './logger';
var logger = getLogger('stream');
export function createLazyStream() {
  var ins = new PassThrough();
  var outs = new PassThrough();
  var stream = concatStreamsAsDuplex(ins, outs);
  var piped = false;
  var setStream = function setStream(str) {
    if (piped) {
      throw new Error('stream is already piped to actual stream');
    }
    piped = true;
    ins.pipe(str).pipe(outs);
  };
  return {
    stream: stream,
    setStream: setStream
  };
}
var MemoryWriteStream = /*#__PURE__*/function (_Writable) {
  function MemoryWriteStream() {
    var _this;
    _classCallCheck(this, MemoryWriteStream);
    _this = _callSuper(this, MemoryWriteStream);
    _this._chunks = [];
    _this._totalBytes = 0;
    return _this;
  }
  _inherits(MemoryWriteStream, _Writable);
  return _createClass(MemoryWriteStream, [{
    key: "_write",
    value: function _write(chunk, encoding, callback) {
      this._chunks.push(chunk);
      this._totalBytes += chunk.length;
      callback();
    }
  }, {
    key: "_writev",
    value: function _writev(data, callback) {
      var _iterator = _createForOfIteratorHelper(data),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var chunk = _step.value.chunk;
          this._chunks.push(chunk);
          this._totalBytes += chunk.length;
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      callback();
    }
  }, {
    key: "toString",
    value: function toString() {
      var encoding = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'utf-8';
      return _concatInstanceProperty(Buffer).call(Buffer, this._chunks).toString(encoding);
    }
  }]);
}(Writable);
export function readAll(_x) {
  return _readAll.apply(this, arguments);
}
function _readAll() {
  _readAll = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(rs) {
    var encoding,
      start,
      _args = arguments;
    return _regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          encoding = _args.length > 1 && _args[1] !== undefined ? _args[1] : 'utf-8';
          logger.debug('readAll: starting to read stream');
          start = _Date$now();
          return _context.abrupt("return", new _Promise(function (resolve, reject) {
            var ws = new MemoryWriteStream();
            rs.on('error', function (err) {
              logger.error("readAll: stream error: ".concat(err.message));
              reject(err);
            }).pipe(ws).on('finish', function () {
              logger.debug("readAll: stream finished in ".concat(_Date$now() - start, "ms"));
              resolve(ws.toString(encoding));
            });
          }));
        case 4:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
  return _readAll.apply(this, arguments);
}
var DuplexifiedStream = /*#__PURE__*/function (_Duplex) {
  function DuplexifiedStream(ws, rs) {
    var _opts$writableObjectM, _opts$readableObjectM;
    var _this2;
    var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    _classCallCheck(this, DuplexifiedStream);
    _this2 = _callSuper(this, DuplexifiedStream, [{
      writableObjectMode: (_opts$writableObjectM = opts.writableObjectMode) !== null && _opts$writableObjectM !== void 0 ? _opts$writableObjectM : ws.writableObjectMode,
      readableObjectMode: (_opts$readableObjectM = opts.readableObjectMode) !== null && _opts$readableObjectM !== void 0 ? _opts$readableObjectM : rs.readableObjectMode
    }]);
    _this2._writable = ws;
    _this2._readable = rs;
    ws.once('finish', function () {
      _this2.end();
    });
    _this2.once('finish', function () {
      ws.end();
    });
    rs.on('readable', function () {
      _this2._readStream();
    });
    rs.once('end', function () {
      _this2.push(null);
    });
    ws.on('error', function (err) {
      return _this2.emit('error', err);
    });
    rs.on('error', function (err) {
      return _this2.emit('error', err);
    });
    return _this2;
  }
  _inherits(DuplexifiedStream, _Duplex);
  return _createClass(DuplexifiedStream, [{
    key: "_write",
    value: function _write(chunk, encoding, callback) {
      this._writable.write(chunk, encoding, callback);
    }
  }, {
    key: "_read",
    value: function _read(n) {
      this._readStream(n);
    }
  }, {
    key: "_readStream",
    value: function _readStream(n) {
      var data;
      while ((data = this._readable.read(n)) !== null) {
        this.push(data);
      }
    }
  }]);
}(Duplex);
export function concatStreamsAsDuplex(ws, rs, opts) {
  return new DuplexifiedStream(ws, rs, opts);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJEdXBsZXgiLCJQYXNzVGhyb3VnaCIsIldyaXRhYmxlIiwiZ2V0TG9nZ2VyIiwibG9nZ2VyIiwiY3JlYXRlTGF6eVN0cmVhbSIsImlucyIsIm91dHMiLCJzdHJlYW0iLCJjb25jYXRTdHJlYW1zQXNEdXBsZXgiLCJwaXBlZCIsInNldFN0cmVhbSIsInN0ciIsIkVycm9yIiwicGlwZSIsIk1lbW9yeVdyaXRlU3RyZWFtIiwiX1dyaXRhYmxlIiwiX3RoaXMiLCJfY2xhc3NDYWxsQ2hlY2siLCJfY2FsbFN1cGVyIiwiX2NodW5rcyIsIl90b3RhbEJ5dGVzIiwiX2luaGVyaXRzIiwiX2NyZWF0ZUNsYXNzIiwia2V5IiwidmFsdWUiLCJfd3JpdGUiLCJjaHVuayIsImVuY29kaW5nIiwiY2FsbGJhY2siLCJwdXNoIiwibGVuZ3RoIiwiX3dyaXRldiIsImRhdGEiLCJfaXRlcmF0b3IiLCJfY3JlYXRlRm9yT2ZJdGVyYXRvckhlbHBlciIsIl9zdGVwIiwicyIsIm4iLCJkb25lIiwiZXJyIiwiZSIsImYiLCJ0b1N0cmluZyIsImFyZ3VtZW50cyIsInVuZGVmaW5lZCIsIl9jb25jYXRJbnN0YW5jZVByb3BlcnR5IiwiQnVmZmVyIiwiY2FsbCIsInJlYWRBbGwiLCJfeCIsIl9yZWFkQWxsIiwiYXBwbHkiLCJfYXN5bmNUb0dlbmVyYXRvciIsIl9yZWdlbmVyYXRvclJ1bnRpbWUiLCJtYXJrIiwiX2NhbGxlZSIsInJzIiwic3RhcnQiLCJfYXJncyIsIndyYXAiLCJfY2FsbGVlJCIsIl9jb250ZXh0IiwicHJldiIsIm5leHQiLCJkZWJ1ZyIsIl9EYXRlJG5vdyIsImFicnVwdCIsIl9Qcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsIndzIiwib24iLCJlcnJvciIsImNvbmNhdCIsIm1lc3NhZ2UiLCJzdG9wIiwiRHVwbGV4aWZpZWRTdHJlYW0iLCJfRHVwbGV4IiwiX29wdHMkd3JpdGFibGVPYmplY3RNIiwiX29wdHMkcmVhZGFibGVPYmplY3RNIiwiX3RoaXMyIiwib3B0cyIsIndyaXRhYmxlT2JqZWN0TW9kZSIsInJlYWRhYmxlT2JqZWN0TW9kZSIsIl93cml0YWJsZSIsIl9yZWFkYWJsZSIsIm9uY2UiLCJlbmQiLCJfcmVhZFN0cmVhbSIsImVtaXQiLCJ3cml0ZSIsIl9yZWFkIiwicmVhZCJdLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy91dGlsL3N0cmVhbS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEdXBsZXgsIFBhc3NUaHJvdWdoLCBSZWFkYWJsZSwgV3JpdGFibGUgfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IHsgZ2V0TG9nZ2VyIH0gZnJvbSAnLi9sb2dnZXInO1xuXG5jb25zdCBsb2dnZXIgPSBnZXRMb2dnZXIoJ3N0cmVhbScpO1xuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlTGF6eVN0cmVhbSgpIHtcbiAgY29uc3QgaW5zID0gbmV3IFBhc3NUaHJvdWdoKCk7XG4gIGNvbnN0IG91dHMgPSBuZXcgUGFzc1Rocm91Z2goKTtcbiAgY29uc3Qgc3RyZWFtID0gY29uY2F0U3RyZWFtc0FzRHVwbGV4KGlucywgb3V0cyk7XG4gIGxldCBwaXBlZCA9IGZhbHNlO1xuICBjb25zdCBzZXRTdHJlYW0gPSAoc3RyOiBEdXBsZXgpID0+IHtcbiAgICBpZiAocGlwZWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignc3RyZWFtIGlzIGFscmVhZHkgcGlwZWQgdG8gYWN0dWFsIHN0cmVhbScpO1xuICAgIH1cbiAgICBwaXBlZCA9IHRydWU7XG4gICAgaW5zLnBpcGUoc3RyKS5waXBlKG91dHMpO1xuICB9O1xuICByZXR1cm4geyBzdHJlYW0sIHNldFN0cmVhbSB9O1xufVxuXG5jbGFzcyBNZW1vcnlXcml0ZVN0cmVhbSBleHRlbmRzIFdyaXRhYmxlIHtcbiAgX2NodW5rczogQnVmZmVyW107XG4gIF90b3RhbEJ5dGVzOiBudW1iZXI7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLl9jaHVua3MgPSBbXTtcbiAgICB0aGlzLl90b3RhbEJ5dGVzID0gMDtcbiAgfVxuXG4gIF93cml0ZShjaHVuazogQnVmZmVyLCBlbmNvZGluZzogc3RyaW5nLCBjYWxsYmFjazogRnVuY3Rpb24pIHtcbiAgICB0aGlzLl9jaHVua3MucHVzaChjaHVuayk7XG4gICAgdGhpcy5fdG90YWxCeXRlcyArPSBjaHVuay5sZW5ndGg7XG4gICAgY2FsbGJhY2soKTtcbiAgfVxuXG4gIF93cml0ZXYoXG4gICAgZGF0YTogQXJyYXk8eyBjaHVuazogQnVmZmVyOyBlbmNvZGluZzogc3RyaW5nIH0+LFxuICAgIGNhbGxiYWNrOiBGdW5jdGlvbixcbiAgKSB7XG4gICAgZm9yIChjb25zdCB7IGNodW5rIH0gb2YgZGF0YSkge1xuICAgICAgdGhpcy5fY2h1bmtzLnB1c2goY2h1bmspO1xuICAgICAgdGhpcy5fdG90YWxCeXRlcyArPSBjaHVuay5sZW5ndGg7XG4gICAgfVxuICAgIGNhbGxiYWNrKCk7XG4gIH1cblxuICB0b1N0cmluZyhlbmNvZGluZzogQnVmZmVyRW5jb2RpbmcgPSAndXRmLTgnKSB7XG4gICAgcmV0dXJuIEJ1ZmZlci5jb25jYXQodGhpcy5fY2h1bmtzKS50b1N0cmluZyhlbmNvZGluZyk7XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlYWRBbGwoXG4gIHJzOiBSZWFkYWJsZSxcbiAgZW5jb2Rpbmc6IEJ1ZmZlckVuY29kaW5nID0gJ3V0Zi04Jyxcbikge1xuICBsb2dnZXIuZGVidWcoJ3JlYWRBbGw6IHN0YXJ0aW5nIHRvIHJlYWQgc3RyZWFtJyk7XG4gIGNvbnN0IHN0YXJ0ID0gRGF0ZS5ub3coKTtcblxuICByZXR1cm4gbmV3IFByb21pc2U8c3RyaW5nPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgY29uc3Qgd3MgPSBuZXcgTWVtb3J5V3JpdGVTdHJlYW0oKTtcbiAgICBycy5vbignZXJyb3InLCAoZXJyKSA9PiB7XG4gICAgICBsb2dnZXIuZXJyb3IoYHJlYWRBbGw6IHN0cmVhbSBlcnJvcjogJHsoZXJyKS5tZXNzYWdlfWApO1xuICAgICAgcmVqZWN0KGVycik7XG4gICAgfSlcbiAgICAgIC5waXBlKHdzKVxuICAgICAgLm9uKCdmaW5pc2gnLCAoKSA9PiB7XG4gICAgICAgIGxvZ2dlci5kZWJ1ZyhgcmVhZEFsbDogc3RyZWFtIGZpbmlzaGVkIGluICR7RGF0ZS5ub3coKSAtIHN0YXJ0fW1zYCk7XG4gICAgICAgIHJlc29sdmUod3MudG9TdHJpbmcoZW5jb2RpbmcpKTtcbiAgICAgIH0pO1xuICB9KTtcbn1cblxuY2xhc3MgRHVwbGV4aWZpZWRTdHJlYW0gZXh0ZW5kcyBEdXBsZXgge1xuICBfd3JpdGFibGU6IFdyaXRhYmxlO1xuICBfcmVhZGFibGU6IFJlYWRhYmxlO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHdzOiBXcml0YWJsZSxcbiAgICByczogUmVhZGFibGUsXG4gICAgb3B0czogeyB3cml0YWJsZU9iamVjdE1vZGU/OiBib29sZWFuOyByZWFkYWJsZU9iamVjdE1vZGU/OiBib29sZWFuIH0gPSB7fSxcbiAgKSB7XG4gICAgc3VwZXIoe1xuICAgICAgd3JpdGFibGVPYmplY3RNb2RlOiBvcHRzLndyaXRhYmxlT2JqZWN0TW9kZSA/PyB3cy53cml0YWJsZU9iamVjdE1vZGUsXG4gICAgICByZWFkYWJsZU9iamVjdE1vZGU6IG9wdHMucmVhZGFibGVPYmplY3RNb2RlID8/IHJzLnJlYWRhYmxlT2JqZWN0TW9kZSxcbiAgICB9KTtcbiAgICB0aGlzLl93cml0YWJsZSA9IHdzO1xuICAgIHRoaXMuX3JlYWRhYmxlID0gcnM7XG4gICAgd3Mub25jZSgnZmluaXNoJywgKCkgPT4ge1xuICAgICAgdGhpcy5lbmQoKTtcbiAgICB9KTtcbiAgICB0aGlzLm9uY2UoJ2ZpbmlzaCcsICgpID0+IHtcbiAgICAgIHdzLmVuZCgpO1xuICAgIH0pO1xuICAgIHJzLm9uKCdyZWFkYWJsZScsICgpID0+IHtcbiAgICAgIHRoaXMuX3JlYWRTdHJlYW0oKTtcbiAgICB9KTtcbiAgICBycy5vbmNlKCdlbmQnLCAoKSA9PiB7XG4gICAgICB0aGlzLnB1c2gobnVsbCk7XG4gICAgfSk7XG4gICAgd3Mub24oJ2Vycm9yJywgKGVycikgPT4gdGhpcy5lbWl0KCdlcnJvcicsIGVycikpO1xuICAgIHJzLm9uKCdlcnJvcicsIChlcnIpID0+IHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpKTtcbiAgfVxuXG4gIF93cml0ZShjaHVuazogYW55LCBlbmNvZGluZzogYW55LCBjYWxsYmFjazogYW55KSB7XG4gICAgdGhpcy5fd3JpdGFibGUud3JpdGUoY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjayk7XG4gIH1cblxuICBfcmVhZChuOiBudW1iZXIpIHtcbiAgICB0aGlzLl9yZWFkU3RyZWFtKG4pO1xuICB9XG5cbiAgX3JlYWRTdHJlYW0obj86IG51bWJlcikge1xuICAgIGxldCBkYXRhO1xuICAgIHdoaWxlICgoZGF0YSA9IHRoaXMuX3JlYWRhYmxlLnJlYWQobikpICE9PSBudWxsKSB7XG4gICAgICB0aGlzLnB1c2goZGF0YSk7XG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjb25jYXRTdHJlYW1zQXNEdXBsZXgoXG4gIHdzOiBXcml0YWJsZSxcbiAgcnM6IFJlYWRhYmxlLFxuICBvcHRzPzogeyB3cml0YWJsZU9iamVjdE1vZGU/OiBib29sZWFuOyByZWFkYWJsZU9iamVjdE1vZGU/OiBib29sZWFuIH0sXG4pOiBEdXBsZXgge1xuICByZXR1cm4gbmV3IER1cGxleGlmaWVkU3RyZWFtKHdzLCBycywgb3B0cyk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTQSxNQUFNLEVBQUVDLFdBQVcsRUFBWUMsUUFBUSxRQUFRLFFBQVE7QUFDaEUsU0FBU0MsU0FBUyxRQUFRLFVBQVU7QUFFcEMsSUFBTUMsTUFBTSxHQUFHRCxTQUFTLENBQUMsUUFBUSxDQUFDO0FBRWxDLE9BQU8sU0FBU0UsZ0JBQWdCQSxDQUFBLEVBQUc7RUFDakMsSUFBTUMsR0FBRyxHQUFHLElBQUlMLFdBQVcsQ0FBQyxDQUFDO0VBQzdCLElBQU1NLElBQUksR0FBRyxJQUFJTixXQUFXLENBQUMsQ0FBQztFQUM5QixJQUFNTyxNQUFNLEdBQUdDLHFCQUFxQixDQUFDSCxHQUFHLEVBQUVDLElBQUksQ0FBQztFQUMvQyxJQUFJRyxLQUFLLEdBQUcsS0FBSztFQUNqQixJQUFNQyxTQUFTLEdBQUcsU0FBWkEsU0FBU0EsQ0FBSUMsR0FBVyxFQUFLO0lBQ2pDLElBQUlGLEtBQUssRUFBRTtNQUNULE1BQU0sSUFBSUcsS0FBSyxDQUFDLDBDQUEwQyxDQUFDO0lBQzdEO0lBQ0FILEtBQUssR0FBRyxJQUFJO0lBQ1pKLEdBQUcsQ0FBQ1EsSUFBSSxDQUFDRixHQUFHLENBQUMsQ0FBQ0UsSUFBSSxDQUFDUCxJQUFJLENBQUM7RUFDMUIsQ0FBQztFQUNELE9BQU87SUFBRUMsTUFBTSxFQUFOQSxNQUFNO0lBQUVHLFNBQVMsRUFBVEE7RUFBVSxDQUFDO0FBQzlCO0FBQUMsSUFFS0ksaUJBQWlCLDBCQUFBQyxTQUFBO0VBSXJCLFNBQUFELGtCQUFBLEVBQWM7SUFBQSxJQUFBRSxLQUFBO0lBQUFDLGVBQUEsT0FBQUgsaUJBQUE7SUFDWkUsS0FBQSxHQUFBRSxVQUFBLE9BQUFKLGlCQUFBO0lBQ0FFLEtBQUEsQ0FBS0csT0FBTyxHQUFHLEVBQUU7SUFDakJILEtBQUEsQ0FBS0ksV0FBVyxHQUFHLENBQUM7SUFBQyxPQUFBSixLQUFBO0VBQ3ZCO0VBQUNLLFNBQUEsQ0FBQVAsaUJBQUEsRUFBQUMsU0FBQTtFQUFBLE9BQUFPLFlBQUEsQ0FBQVIsaUJBQUE7SUFBQVMsR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQUMsTUFBTUEsQ0FBQ0MsS0FBYSxFQUFFQyxRQUFnQixFQUFFQyxRQUFrQixFQUFFO01BQzFELElBQUksQ0FBQ1QsT0FBTyxDQUFDVSxJQUFJLENBQUNILEtBQUssQ0FBQztNQUN4QixJQUFJLENBQUNOLFdBQVcsSUFBSU0sS0FBSyxDQUFDSSxNQUFNO01BQ2hDRixRQUFRLENBQUMsQ0FBQztJQUNaO0VBQUM7SUFBQUwsR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQU8sT0FBT0EsQ0FDTEMsSUFBZ0QsRUFDaERKLFFBQWtCLEVBQ2xCO01BQUEsSUFBQUssU0FBQSxHQUFBQywwQkFBQSxDQUN3QkYsSUFBSTtRQUFBRyxLQUFBO01BQUE7UUFBNUIsS0FBQUYsU0FBQSxDQUFBRyxDQUFBLE1BQUFELEtBQUEsR0FBQUYsU0FBQSxDQUFBSSxDQUFBLElBQUFDLElBQUEsR0FBOEI7VUFBQSxJQUFqQlosS0FBSyxHQUFBUyxLQUFBLENBQUFYLEtBQUEsQ0FBTEUsS0FBSztVQUNoQixJQUFJLENBQUNQLE9BQU8sQ0FBQ1UsSUFBSSxDQUFDSCxLQUFLLENBQUM7VUFDeEIsSUFBSSxDQUFDTixXQUFXLElBQUlNLEtBQUssQ0FBQ0ksTUFBTTtRQUNsQztNQUFDLFNBQUFTLEdBQUE7UUFBQU4sU0FBQSxDQUFBTyxDQUFBLENBQUFELEdBQUE7TUFBQTtRQUFBTixTQUFBLENBQUFRLENBQUE7TUFBQTtNQUNEYixRQUFRLENBQUMsQ0FBQztJQUNaO0VBQUM7SUFBQUwsR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQWtCLFFBQVFBLENBQUEsRUFBcUM7TUFBQSxJQUFwQ2YsUUFBd0IsR0FBQWdCLFNBQUEsQ0FBQWIsTUFBQSxRQUFBYSxTQUFBLFFBQUFDLFNBQUEsR0FBQUQsU0FBQSxNQUFHLE9BQU87TUFDekMsT0FBT0UsdUJBQUEsQ0FBQUMsTUFBTSxFQUFBQyxJQUFBLENBQU5ELE1BQU0sRUFBUSxJQUFJLENBQUMzQixPQUFPLENBQUMsQ0FBQ3VCLFFBQVEsQ0FBQ2YsUUFBUSxDQUFDO0lBQ3ZEO0VBQUM7QUFBQSxFQTdCNkIxQixRQUFRO0FBZ0N4QyxnQkFBc0IrQyxPQUFPQSxDQUFBQyxFQUFBO0VBQUEsT0FBQUMsUUFBQSxDQUFBQyxLQUFBLE9BQUFSLFNBQUE7QUFBQTtBQW1CNUIsU0FBQU8sU0FBQTtFQUFBQSxRQUFBLEdBQUFFLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FuQk0sU0FBQUMsUUFDTEMsRUFBWTtJQUFBLElBQUE3QixRQUFBO01BQUE4QixLQUFBO01BQUFDLEtBQUEsR0FBQWYsU0FBQTtJQUFBLE9BQUFVLG1CQUFBLENBQUFNLElBQUEsVUFBQUMsU0FBQUMsUUFBQTtNQUFBLGtCQUFBQSxRQUFBLENBQUFDLElBQUEsR0FBQUQsUUFBQSxDQUFBRSxJQUFBO1FBQUE7VUFDWnBDLFFBQXdCLEdBQUErQixLQUFBLENBQUE1QixNQUFBLFFBQUE0QixLQUFBLFFBQUFkLFNBQUEsR0FBQWMsS0FBQSxNQUFHLE9BQU87VUFFbEN2RCxNQUFNLENBQUM2RCxLQUFLLENBQUMsa0NBQWtDLENBQUM7VUFDMUNQLEtBQUssR0FBR1EsU0FBQSxDQUFTLENBQUM7VUFBQSxPQUFBSixRQUFBLENBQUFLLE1BQUEsV0FFakIsSUFBQUMsUUFBQSxDQUFvQixVQUFDQyxPQUFPLEVBQUVDLE1BQU0sRUFBSztZQUM5QyxJQUFNQyxFQUFFLEdBQUcsSUFBSXhELGlCQUFpQixDQUFDLENBQUM7WUFDbEMwQyxFQUFFLENBQUNlLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBQ2hDLEdBQUcsRUFBSztjQUN0QnBDLE1BQU0sQ0FBQ3FFLEtBQUssMkJBQUFDLE1BQUEsQ0FBNEJsQyxHQUFHLENBQUVtQyxPQUFPLENBQUUsQ0FBQztjQUN2REwsTUFBTSxDQUFDOUIsR0FBRyxDQUFDO1lBQ2IsQ0FBQyxDQUFDLENBQ0MxQixJQUFJLENBQUN5RCxFQUFFLENBQUMsQ0FDUkMsRUFBRSxDQUFDLFFBQVEsRUFBRSxZQUFNO2NBQ2xCcEUsTUFBTSxDQUFDNkQsS0FBSyxnQ0FBQVMsTUFBQSxDQUFnQ1IsU0FBQSxDQUFTLENBQUMsR0FBR1IsS0FBSyxPQUFJLENBQUM7Y0FDbkVXLE9BQU8sQ0FBQ0UsRUFBRSxDQUFDNUIsUUFBUSxDQUFDZixRQUFRLENBQUMsQ0FBQztZQUNoQyxDQUFDLENBQUM7VUFDTixDQUFDLENBQUM7UUFBQTtRQUFBO1VBQUEsT0FBQWtDLFFBQUEsQ0FBQWMsSUFBQTtNQUFBO0lBQUEsR0FBQXBCLE9BQUE7RUFBQSxDQUNIO0VBQUEsT0FBQUwsUUFBQSxDQUFBQyxLQUFBLE9BQUFSLFNBQUE7QUFBQTtBQUFBLElBRUtpQyxpQkFBaUIsMEJBQUFDLE9BQUE7RUFJckIsU0FBQUQsa0JBQ0VOLEVBQVksRUFDWmQsRUFBWSxFQUVaO0lBQUEsSUFBQXNCLHFCQUFBLEVBQUFDLHFCQUFBO0lBQUEsSUFBQUMsTUFBQTtJQUFBLElBREFDLElBQW9FLEdBQUF0QyxTQUFBLENBQUFiLE1BQUEsUUFBQWEsU0FBQSxRQUFBQyxTQUFBLEdBQUFELFNBQUEsTUFBRyxDQUFDLENBQUM7SUFBQTFCLGVBQUEsT0FBQTJELGlCQUFBO0lBRXpFSSxNQUFBLEdBQUE5RCxVQUFBLE9BQUEwRCxpQkFBQSxHQUFNO01BQ0pNLGtCQUFrQixHQUFBSixxQkFBQSxHQUFFRyxJQUFJLENBQUNDLGtCQUFrQixjQUFBSixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJUixFQUFFLENBQUNZLGtCQUFrQjtNQUNwRUMsa0JBQWtCLEdBQUFKLHFCQUFBLEdBQUVFLElBQUksQ0FBQ0Usa0JBQWtCLGNBQUFKLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUl2QixFQUFFLENBQUMyQjtJQUNwRCxDQUFDO0lBQ0RILE1BQUEsQ0FBS0ksU0FBUyxHQUFHZCxFQUFFO0lBQ25CVSxNQUFBLENBQUtLLFNBQVMsR0FBRzdCLEVBQUU7SUFDbkJjLEVBQUUsQ0FBQ2dCLElBQUksQ0FBQyxRQUFRLEVBQUUsWUFBTTtNQUN0Qk4sTUFBQSxDQUFLTyxHQUFHLENBQUMsQ0FBQztJQUNaLENBQUMsQ0FBQztJQUNGUCxNQUFBLENBQUtNLElBQUksQ0FBQyxRQUFRLEVBQUUsWUFBTTtNQUN4QmhCLEVBQUUsQ0FBQ2lCLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsQ0FBQyxDQUFDO0lBQ0YvQixFQUFFLENBQUNlLEVBQUUsQ0FBQyxVQUFVLEVBQUUsWUFBTTtNQUN0QlMsTUFBQSxDQUFLUSxXQUFXLENBQUMsQ0FBQztJQUNwQixDQUFDLENBQUM7SUFDRmhDLEVBQUUsQ0FBQzhCLElBQUksQ0FBQyxLQUFLLEVBQUUsWUFBTTtNQUNuQk4sTUFBQSxDQUFLbkQsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNqQixDQUFDLENBQUM7SUFDRnlDLEVBQUUsQ0FBQ0MsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFDaEMsR0FBRztNQUFBLE9BQUt5QyxNQUFBLENBQUtTLElBQUksQ0FBQyxPQUFPLEVBQUVsRCxHQUFHLENBQUM7SUFBQSxFQUFDO0lBQ2hEaUIsRUFBRSxDQUFDZSxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQUNoQyxHQUFHO01BQUEsT0FBS3lDLE1BQUEsQ0FBS1MsSUFBSSxDQUFDLE9BQU8sRUFBRWxELEdBQUcsQ0FBQztJQUFBLEVBQUM7SUFBQyxPQUFBeUMsTUFBQTtFQUNuRDtFQUFDM0QsU0FBQSxDQUFBdUQsaUJBQUEsRUFBQUMsT0FBQTtFQUFBLE9BQUF2RCxZQUFBLENBQUFzRCxpQkFBQTtJQUFBckQsR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQUMsTUFBTUEsQ0FBQ0MsS0FBVSxFQUFFQyxRQUFhLEVBQUVDLFFBQWEsRUFBRTtNQUMvQyxJQUFJLENBQUN3RCxTQUFTLENBQUNNLEtBQUssQ0FBQ2hFLEtBQUssRUFBRUMsUUFBUSxFQUFFQyxRQUFRLENBQUM7SUFDakQ7RUFBQztJQUFBTCxHQUFBO0lBQUFDLEtBQUEsRUFFRCxTQUFBbUUsS0FBS0EsQ0FBQ3RELENBQVMsRUFBRTtNQUNmLElBQUksQ0FBQ21ELFdBQVcsQ0FBQ25ELENBQUMsQ0FBQztJQUNyQjtFQUFDO0lBQUFkLEdBQUE7SUFBQUMsS0FBQSxFQUVELFNBQUFnRSxXQUFXQSxDQUFDbkQsQ0FBVSxFQUFFO01BQ3RCLElBQUlMLElBQUk7TUFDUixPQUFPLENBQUNBLElBQUksR0FBRyxJQUFJLENBQUNxRCxTQUFTLENBQUNPLElBQUksQ0FBQ3ZELENBQUMsQ0FBQyxNQUFNLElBQUksRUFBRTtRQUMvQyxJQUFJLENBQUNSLElBQUksQ0FBQ0csSUFBSSxDQUFDO01BQ2pCO0lBQ0Y7RUFBQztBQUFBLEVBNUM2QmpDLE1BQU07QUErQ3RDLE9BQU8sU0FBU1MscUJBQXFCQSxDQUNuQzhELEVBQVksRUFDWmQsRUFBWSxFQUNaeUIsSUFBcUUsRUFDN0Q7RUFDUixPQUFPLElBQUlMLGlCQUFpQixDQUFDTixFQUFFLEVBQUVkLEVBQUUsRUFBRXlCLElBQUksQ0FBQztBQUM1QyIsImlnbm9yZUxpc3QiOltdfQ==