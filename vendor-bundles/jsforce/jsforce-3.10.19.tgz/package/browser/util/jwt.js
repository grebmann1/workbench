import "core-js/modules/es.object.keys.js";
import "core-js/modules/web.atob.js";
import "core-js/modules/web.dom-exception.constructor.js";
import "core-js/modules/web.dom-exception.stack.js";
import "core-js/modules/web.dom-exception.to-string-tag.js";
/**
 * Checks if a given access token is a JWT.
 *
 * @param {string} accessToken - The access token to check
 * @returns {boolean} True if the token is a valid JWT token, false otherwise.
 */
export function isJWTToken(accessToken) {
  var parts = accessToken.split('.');
  if (parts.length !== 3) return false;
  var header = parts[0];
  try {
    JSON.parse(atob(header));
    return true;
  } catch (err) {
    return false;
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJpc0pXVFRva2VuIiwiYWNjZXNzVG9rZW4iLCJwYXJ0cyIsInNwbGl0IiwibGVuZ3RoIiwiaGVhZGVyIiwiSlNPTiIsInBhcnNlIiwiYXRvYiIsImVyciJdLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy91dGlsL2p3dC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIENoZWNrcyBpZiBhIGdpdmVuIGFjY2VzcyB0b2tlbiBpcyBhIEpXVC5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gYWNjZXNzVG9rZW4gLSBUaGUgYWNjZXNzIHRva2VuIHRvIGNoZWNrXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgdG9rZW4gaXMgYSB2YWxpZCBKV1QgdG9rZW4sIGZhbHNlIG90aGVyd2lzZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzSldUVG9rZW4oYWNjZXNzVG9rZW46IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCBwYXJ0cyA9IGFjY2Vzc1Rva2VuLnNwbGl0KCcuJyk7XG4gIGlmIChwYXJ0cy5sZW5ndGggIT09IDMpIHJldHVybiBmYWxzZTtcblxuICBjb25zdCBoZWFkZXIgPSBwYXJ0c1swXTtcbiAgdHJ5IHtcbiAgICBKU09OLnBhcnNlKGF0b2IoaGVhZGVyKSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sU0FBU0EsVUFBVUEsQ0FBQ0MsV0FBbUIsRUFBVztFQUN2RCxJQUFNQyxLQUFLLEdBQUdELFdBQVcsQ0FBQ0UsS0FBSyxDQUFDLEdBQUcsQ0FBQztFQUNwQyxJQUFJRCxLQUFLLENBQUNFLE1BQU0sS0FBSyxDQUFDLEVBQUUsT0FBTyxLQUFLO0VBRXBDLElBQU1DLE1BQU0sR0FBR0gsS0FBSyxDQUFDLENBQUMsQ0FBQztFQUN2QixJQUFJO0lBQ0ZJLElBQUksQ0FBQ0MsS0FBSyxDQUFDQyxJQUFJLENBQUNILE1BQU0sQ0FBQyxDQUFDO0lBQ3hCLE9BQU8sSUFBSTtFQUNiLENBQUMsQ0FBQyxPQUFPSSxHQUFHLEVBQUU7SUFDWixPQUFPLEtBQUs7RUFDZDtBQUNGIiwiaWdub3JlTGlzdCI6W119