import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context3, _context4; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context3 = ownKeys(Object(t), !0)).call(_context3, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context4 = ownKeys(Object(t))).call(_context4, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.number.to-fixed.js";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _Set from "@babel/runtime-corejs3/core-js-stable/set";
import { PassThrough } from 'stream';
import { concatStreamsAsDuplex, readAll } from './util/stream';
import FormData from 'form-data';
import { getLogger } from './util/logger';
var logger = getLogger('request-helper');

/**
 *
 */
export function createHttpRequestHandlerStreams(req) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var reqBody = req.body;
  var input = new PassThrough();
  var output = new PassThrough();
  var duplex = concatStreamsAsDuplex(input, output);
  if (typeof reqBody !== 'undefined') {
    _setTimeout(function () {
      if (reqBody instanceof FormData) {
        duplex.end(reqBody.getBuffer());
      } else {
        duplex.end(reqBody, 'utf8');
      }
    }, 0);
  }
  duplex.on('response', /*#__PURE__*/function () {
    var _ref = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(res) {
      var start, resBody;
      return _regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            if (!(duplex.listenerCount('complete') > 0)) {
              _context.next = 8;
              break;
            }
            logger.debug('Processing response');
            start = _Date$now();
            _context.next = 5;
            return readAll(duplex, options.encoding);
          case 5:
            resBody = _context.sent;
            logger.debug("Response body read: ".concat((resBody.length / 1024 / 1024).toFixed(1), "MB ") + "in ".concat(_Date$now() - start, "ms"));
            duplex.emit('complete', _objectSpread(_objectSpread({}, res), {}, {
              body: resBody
            }));
          case 8:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return function (_x) {
      return _ref.apply(this, arguments);
    };
  }());
  return {
    input: input,
    output: output,
    stream: duplex
  };
}
var redirectStatuses = new _Set([301, 302, 303, 307, 308]);

/**
 *
 */
export function isRedirect(status) {
  return redirectStatuses.has(status);
}

/**
 *
 */
var MAX_REDIRECT_COUNT = 10;

/**
 *
 */
export function performRedirectRequest(req, res, followRedirect, counter, redirectCallback) {
  if (counter >= MAX_REDIRECT_COUNT) {
    throw new Error('Reached to maximum redirect count');
  }
  var redirectUrl = res.headers['location'];
  if (!redirectUrl) {
    throw new Error('No redirect URI found');
  }
  var getRedirectRequest = typeof followRedirect === 'function' ? followRedirect : function () {
    return {
      method: 'GET',
      url: redirectUrl,
      headers: req.headers
    };
  };
  var nextReqParams = getRedirectRequest(redirectUrl);
  if (!nextReqParams) {
    throw new Error('Cannot handle redirect for ' + redirectUrl);
  }
  redirectCallback(nextReqParams);
}

/**
 *
 */
export function executeWithTimeout(_x2, _x3, _x4) {
  return _executeWithTimeout.apply(this, arguments);
}
function _executeWithTimeout() {
  _executeWithTimeout = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(execFn, msec, cancelCallback) {
    var timeout, pid, res;
    return _regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          timeout = false;
          pid = msec != null ? _setTimeout(function () {
            timeout = true;
            cancelCallback === null || cancelCallback === void 0 || cancelCallback();
          }, msec) : undefined;
          _context2.prev = 2;
          _context2.next = 5;
          return execFn();
        case 5:
          res = _context2.sent;
        case 6:
          _context2.prev = 6;
          if (pid) {
            clearTimeout(pid);
          }
          return _context2.finish(6);
        case 9:
          if (!timeout) {
            _context2.next = 11;
            break;
          }
          throw new Error('Request Timeout');
        case 11:
          return _context2.abrupt("return", res);
        case 12:
        case "end":
          return _context2.stop();
      }
    }, _callee2, null, [[2,, 6, 9]]);
  }));
  return _executeWithTimeout.apply(this, arguments);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQYXNzVGhyb3VnaCIsImNvbmNhdFN0cmVhbXNBc0R1cGxleCIsInJlYWRBbGwiLCJGb3JtRGF0YSIsImdldExvZ2dlciIsImxvZ2dlciIsImNyZWF0ZUh0dHBSZXF1ZXN0SGFuZGxlclN0cmVhbXMiLCJyZXEiLCJvcHRpb25zIiwiYXJndW1lbnRzIiwibGVuZ3RoIiwidW5kZWZpbmVkIiwicmVxQm9keSIsImJvZHkiLCJpbnB1dCIsIm91dHB1dCIsImR1cGxleCIsIl9zZXRUaW1lb3V0IiwiZW5kIiwiZ2V0QnVmZmVyIiwib24iLCJfcmVmIiwiX2FzeW5jVG9HZW5lcmF0b3IiLCJfcmVnZW5lcmF0b3JSdW50aW1lIiwibWFyayIsIl9jYWxsZWUiLCJyZXMiLCJzdGFydCIsInJlc0JvZHkiLCJ3cmFwIiwiX2NhbGxlZSQiLCJfY29udGV4dCIsInByZXYiLCJuZXh0IiwibGlzdGVuZXJDb3VudCIsImRlYnVnIiwiX0RhdGUkbm93IiwiZW5jb2RpbmciLCJzZW50IiwiY29uY2F0IiwidG9GaXhlZCIsImVtaXQiLCJfb2JqZWN0U3ByZWFkIiwic3RvcCIsIl94IiwiYXBwbHkiLCJzdHJlYW0iLCJyZWRpcmVjdFN0YXR1c2VzIiwiX1NldCIsImlzUmVkaXJlY3QiLCJzdGF0dXMiLCJoYXMiLCJNQVhfUkVESVJFQ1RfQ09VTlQiLCJwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0IiwiZm9sbG93UmVkaXJlY3QiLCJjb3VudGVyIiwicmVkaXJlY3RDYWxsYmFjayIsIkVycm9yIiwicmVkaXJlY3RVcmwiLCJoZWFkZXJzIiwiZ2V0UmVkaXJlY3RSZXF1ZXN0IiwibWV0aG9kIiwidXJsIiwibmV4dFJlcVBhcmFtcyIsImV4ZWN1dGVXaXRoVGltZW91dCIsIl94MiIsIl94MyIsIl94NCIsIl9leGVjdXRlV2l0aFRpbWVvdXQiLCJfY2FsbGVlMiIsImV4ZWNGbiIsIm1zZWMiLCJjYW5jZWxDYWxsYmFjayIsInRpbWVvdXQiLCJwaWQiLCJfY2FsbGVlMiQiLCJfY29udGV4dDIiLCJjbGVhclRpbWVvdXQiLCJmaW5pc2giLCJhYnJ1cHQiXSwic291cmNlcyI6WyIuLi9zcmMvcmVxdWVzdC1oZWxwZXIudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFzc1Rocm91Z2ggfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IHsgY29uY2F0U3RyZWFtc0FzRHVwbGV4LCByZWFkQWxsIH0gZnJvbSAnLi91dGlsL3N0cmVhbSc7XG5pbXBvcnQgeyBIdHRwUmVxdWVzdCwgSHR0cFJlcXVlc3RPcHRpb25zLCBIdHRwUmVzcG9uc2UgfSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCBGb3JtRGF0YSBmcm9tICdmb3JtLWRhdGEnO1xuaW1wb3J0IHsgZ2V0TG9nZ2VyIH0gZnJvbSAnLi91dGlsL2xvZ2dlcic7XG5cbmNvbnN0IGxvZ2dlciA9IGdldExvZ2dlcigncmVxdWVzdC1oZWxwZXInKTtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyhcbiAgcmVxOiBIdHRwUmVxdWVzdCxcbiAgb3B0aW9uczogSHR0cFJlcXVlc3RPcHRpb25zID0ge30sXG4pIHtcbiAgY29uc3QgeyBib2R5OiByZXFCb2R5IH0gPSByZXE7XG4gIGNvbnN0IGlucHV0ID0gbmV3IFBhc3NUaHJvdWdoKCk7XG4gIGNvbnN0IG91dHB1dCA9IG5ldyBQYXNzVGhyb3VnaCgpO1xuICBjb25zdCBkdXBsZXggPSBjb25jYXRTdHJlYW1zQXNEdXBsZXgoaW5wdXQsIG91dHB1dCk7XG5cbiAgaWYgKHR5cGVvZiByZXFCb2R5ICE9PSAndW5kZWZpbmVkJykge1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgaWYgKHJlcUJvZHkgaW5zdGFuY2VvZiBGb3JtRGF0YSkge1xuICAgICAgICBkdXBsZXguZW5kKHJlcUJvZHkuZ2V0QnVmZmVyKCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZHVwbGV4LmVuZChyZXFCb2R5LCAndXRmOCcpO1xuICAgICAgfVxuICAgIH0sIDApO1xuICB9XG4gIGR1cGxleC5vbigncmVzcG9uc2UnLCBhc3luYyAocmVzKSA9PiB7XG4gICAgaWYgKGR1cGxleC5saXN0ZW5lckNvdW50KCdjb21wbGV0ZScpID4gMCkge1xuICAgICAgbG9nZ2VyLmRlYnVnKCdQcm9jZXNzaW5nIHJlc3BvbnNlJyk7XG4gICAgICBjb25zdCBzdGFydCA9IERhdGUubm93KCk7XG5cbiAgICAgIGNvbnN0IHJlc0JvZHkgPSBhd2FpdCByZWFkQWxsKGR1cGxleCwgb3B0aW9ucy5lbmNvZGluZyk7XG5cbiAgICAgIGxvZ2dlci5kZWJ1ZyhcbiAgICAgICAgYFJlc3BvbnNlIGJvZHkgcmVhZDogJHsocmVzQm9keS5sZW5ndGggLyAxMDI0IC8gMTAyNCkudG9GaXhlZCgxKX1NQiBgICtcbiAgICAgICAgICBgaW4gJHtEYXRlLm5vdygpIC0gc3RhcnR9bXNgLFxuICAgICAgKTtcblxuICAgICAgZHVwbGV4LmVtaXQoJ2NvbXBsZXRlJywge1xuICAgICAgICAuLi5yZXMsXG4gICAgICAgIGJvZHk6IHJlc0JvZHksXG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4geyBpbnB1dCwgb3V0cHV0LCBzdHJlYW06IGR1cGxleCB9O1xufVxuXG5jb25zdCByZWRpcmVjdFN0YXR1c2VzID0gbmV3IFNldChbMzAxLCAzMDIsIDMwMywgMzA3LCAzMDhdKTtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNSZWRpcmVjdChzdGF0dXM6IG51bWJlcikge1xuICByZXR1cm4gcmVkaXJlY3RTdGF0dXNlcy5oYXMoc3RhdHVzKTtcbn1cblxuLyoqXG4gKlxuICovXG5jb25zdCBNQVhfUkVESVJFQ1RfQ09VTlQgPSAxMDtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGVyZm9ybVJlZGlyZWN0UmVxdWVzdChcbiAgcmVxOiBIdHRwUmVxdWVzdCxcbiAgcmVzOiBPbWl0PEh0dHBSZXNwb25zZSwgJ2JvZHknPixcbiAgZm9sbG93UmVkaXJlY3Q6IE5vbk51bGxhYmxlPEh0dHBSZXF1ZXN0T3B0aW9uc1snZm9sbG93UmVkaXJlY3QnXT4sXG4gIGNvdW50ZXI6IG51bWJlcixcbiAgcmVkaXJlY3RDYWxsYmFjazogKHJlcTogSHR0cFJlcXVlc3QpID0+IHZvaWQsXG4pIHtcbiAgaWYgKGNvdW50ZXIgPj0gTUFYX1JFRElSRUNUX0NPVU5UKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdSZWFjaGVkIHRvIG1heGltdW0gcmVkaXJlY3QgY291bnQnKTtcbiAgfVxuICBjb25zdCByZWRpcmVjdFVybCA9IHJlcy5oZWFkZXJzWydsb2NhdGlvbiddO1xuICBpZiAoIXJlZGlyZWN0VXJsKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdObyByZWRpcmVjdCBVUkkgZm91bmQnKTtcbiAgfVxuICBjb25zdCBnZXRSZWRpcmVjdFJlcXVlc3QgPVxuICAgIHR5cGVvZiBmb2xsb3dSZWRpcmVjdCA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgPyBmb2xsb3dSZWRpcmVjdFxuICAgICAgOiAoKSA9PiAoe1xuICAgICAgICAgIG1ldGhvZDogJ0dFVCcgYXMgY29uc3QsXG4gICAgICAgICAgdXJsOiByZWRpcmVjdFVybCxcbiAgICAgICAgICBoZWFkZXJzOiByZXEuaGVhZGVycyxcbiAgICAgICAgfSk7XG4gIGNvbnN0IG5leHRSZXFQYXJhbXMgPSBnZXRSZWRpcmVjdFJlcXVlc3QocmVkaXJlY3RVcmwpO1xuICBpZiAoIW5leHRSZXFQYXJhbXMpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBoYW5kbGUgcmVkaXJlY3QgZm9yICcgKyByZWRpcmVjdFVybCk7XG4gIH1cbiAgcmVkaXJlY3RDYWxsYmFjayhuZXh0UmVxUGFyYW1zKTtcbn1cblxuLyoqXG4gKlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZXhlY3V0ZVdpdGhUaW1lb3V0PFQ+KFxuICBleGVjRm46ICgpID0+IFByb21pc2U8VD4sXG4gIG1zZWM6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgY2FuY2VsQ2FsbGJhY2s/OiAoKSA9PiB2b2lkLFxuKTogUHJvbWlzZTxUPiB7XG4gIGxldCB0aW1lb3V0ID0gZmFsc2U7XG4gIGNvbnN0IHBpZCA9XG4gICAgbXNlYyAhPSBudWxsXG4gICAgICA/IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHRpbWVvdXQgPSB0cnVlO1xuICAgICAgICAgIGNhbmNlbENhbGxiYWNrPy4oKTtcbiAgICAgICAgfSwgbXNlYylcbiAgICAgIDogdW5kZWZpbmVkO1xuICBsZXQgcmVzO1xuICB0cnkge1xuICAgIHJlcyA9IGF3YWl0IGV4ZWNGbigpO1xuICB9IGZpbmFsbHkge1xuICAgIGlmIChwaWQpIHtcbiAgICAgIGNsZWFyVGltZW91dChwaWQpO1xuICAgIH1cbiAgfVxuICBpZiAodGltZW91dCkge1xuICAgIHRocm93IG5ldyBFcnJvcignUmVxdWVzdCBUaW1lb3V0Jyk7XG4gIH1cbiAgcmV0dXJuIHJlcztcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVNBLFdBQVcsUUFBUSxRQUFRO0FBQ3BDLFNBQVNDLHFCQUFxQixFQUFFQyxPQUFPLFFBQVEsZUFBZTtBQUU5RCxPQUFPQyxRQUFRLE1BQU0sV0FBVztBQUNoQyxTQUFTQyxTQUFTLFFBQVEsZUFBZTtBQUV6QyxJQUFNQyxNQUFNLEdBQUdELFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQzs7QUFFMUM7QUFDQTtBQUNBO0FBQ0EsT0FBTyxTQUFTRSwrQkFBK0JBLENBQzdDQyxHQUFnQixFQUVoQjtFQUFBLElBREFDLE9BQTJCLEdBQUFDLFNBQUEsQ0FBQUMsTUFBQSxRQUFBRCxTQUFBLFFBQUFFLFNBQUEsR0FBQUYsU0FBQSxNQUFHLENBQUMsQ0FBQztFQUVoQyxJQUFjRyxPQUFPLEdBQUtMLEdBQUcsQ0FBckJNLElBQUk7RUFDWixJQUFNQyxLQUFLLEdBQUcsSUFBSWQsV0FBVyxDQUFDLENBQUM7RUFDL0IsSUFBTWUsTUFBTSxHQUFHLElBQUlmLFdBQVcsQ0FBQyxDQUFDO0VBQ2hDLElBQU1nQixNQUFNLEdBQUdmLHFCQUFxQixDQUFDYSxLQUFLLEVBQUVDLE1BQU0sQ0FBQztFQUVuRCxJQUFJLE9BQU9ILE9BQU8sS0FBSyxXQUFXLEVBQUU7SUFDbENLLFdBQUEsQ0FBVyxZQUFNO01BQ2YsSUFBSUwsT0FBTyxZQUFZVCxRQUFRLEVBQUU7UUFDL0JhLE1BQU0sQ0FBQ0UsR0FBRyxDQUFDTixPQUFPLENBQUNPLFNBQVMsQ0FBQyxDQUFDLENBQUM7TUFDakMsQ0FBQyxNQUFNO1FBQ0xILE1BQU0sQ0FBQ0UsR0FBRyxDQUFDTixPQUFPLEVBQUUsTUFBTSxDQUFDO01BQzdCO0lBQ0YsQ0FBQyxFQUFFLENBQUMsQ0FBQztFQUNQO0VBQ0FJLE1BQU0sQ0FBQ0ksRUFBRSxDQUFDLFVBQVU7SUFBQSxJQUFBQyxJQUFBLEdBQUFDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FBRSxTQUFBQyxRQUFPQyxHQUFHO01BQUEsSUFBQUMsS0FBQSxFQUFBQyxPQUFBO01BQUEsT0FBQUwsbUJBQUEsQ0FBQU0sSUFBQSxVQUFBQyxTQUFBQyxRQUFBO1FBQUEsa0JBQUFBLFFBQUEsQ0FBQUMsSUFBQSxHQUFBRCxRQUFBLENBQUFFLElBQUE7VUFBQTtZQUFBLE1BQzFCakIsTUFBTSxDQUFDa0IsYUFBYSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7Y0FBQUgsUUFBQSxDQUFBRSxJQUFBO2NBQUE7WUFBQTtZQUN0QzVCLE1BQU0sQ0FBQzhCLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztZQUM3QlIsS0FBSyxHQUFHUyxTQUFBLENBQVMsQ0FBQztZQUFBTCxRQUFBLENBQUFFLElBQUE7WUFBQSxPQUVGL0IsT0FBTyxDQUFDYyxNQUFNLEVBQUVSLE9BQU8sQ0FBQzZCLFFBQVEsQ0FBQztVQUFBO1lBQWpEVCxPQUFPLEdBQUFHLFFBQUEsQ0FBQU8sSUFBQTtZQUViakMsTUFBTSxDQUFDOEIsS0FBSyxDQUNWLHVCQUFBSSxNQUFBLENBQXVCLENBQUNYLE9BQU8sQ0FBQ2xCLE1BQU0sR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFOEIsT0FBTyxDQUFDLENBQUMsQ0FBQyxpQkFBQUQsTUFBQSxDQUN4REgsU0FBQSxDQUFTLENBQUMsR0FBR1QsS0FBSyxPQUM1QixDQUFDO1lBRURYLE1BQU0sQ0FBQ3lCLElBQUksQ0FBQyxVQUFVLEVBQUFDLGFBQUEsQ0FBQUEsYUFBQSxLQUNqQmhCLEdBQUc7Y0FDTmIsSUFBSSxFQUFFZTtZQUFPLEVBQ2QsQ0FBQztVQUFDO1VBQUE7WUFBQSxPQUFBRyxRQUFBLENBQUFZLElBQUE7UUFBQTtNQUFBLEdBQUFsQixPQUFBO0lBQUEsQ0FFTjtJQUFBLGlCQUFBbUIsRUFBQTtNQUFBLE9BQUF2QixJQUFBLENBQUF3QixLQUFBLE9BQUFwQyxTQUFBO0lBQUE7RUFBQSxJQUFDO0VBQ0YsT0FBTztJQUFFSyxLQUFLLEVBQUxBLEtBQUs7SUFBRUMsTUFBTSxFQUFOQSxNQUFNO0lBQUUrQixNQUFNLEVBQUU5QjtFQUFPLENBQUM7QUFDMUM7QUFFQSxJQUFNK0IsZ0JBQWdCLEdBQUcsSUFBQUMsSUFBQSxDQUFRLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDOztBQUUzRDtBQUNBO0FBQ0E7QUFDQSxPQUFPLFNBQVNDLFVBQVVBLENBQUNDLE1BQWMsRUFBRTtFQUN6QyxPQUFPSCxnQkFBZ0IsQ0FBQ0ksR0FBRyxDQUFDRCxNQUFNLENBQUM7QUFDckM7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsSUFBTUUsa0JBQWtCLEdBQUcsRUFBRTs7QUFFN0I7QUFDQTtBQUNBO0FBQ0EsT0FBTyxTQUFTQyxzQkFBc0JBLENBQ3BDOUMsR0FBZ0IsRUFDaEJtQixHQUErQixFQUMvQjRCLGNBQWlFLEVBQ2pFQyxPQUFlLEVBQ2ZDLGdCQUE0QyxFQUM1QztFQUNBLElBQUlELE9BQU8sSUFBSUgsa0JBQWtCLEVBQUU7SUFDakMsTUFBTSxJQUFJSyxLQUFLLENBQUMsbUNBQW1DLENBQUM7RUFDdEQ7RUFDQSxJQUFNQyxXQUFXLEdBQUdoQyxHQUFHLENBQUNpQyxPQUFPLENBQUMsVUFBVSxDQUFDO0VBQzNDLElBQUksQ0FBQ0QsV0FBVyxFQUFFO0lBQ2hCLE1BQU0sSUFBSUQsS0FBSyxDQUFDLHVCQUF1QixDQUFDO0VBQzFDO0VBQ0EsSUFBTUcsa0JBQWtCLEdBQ3RCLE9BQU9OLGNBQWMsS0FBSyxVQUFVLEdBQ2hDQSxjQUFjLEdBQ2Q7SUFBQSxPQUFPO01BQ0xPLE1BQU0sRUFBRSxLQUFjO01BQ3RCQyxHQUFHLEVBQUVKLFdBQVc7TUFDaEJDLE9BQU8sRUFBRXBELEdBQUcsQ0FBQ29EO0lBQ2YsQ0FBQztFQUFBLENBQUM7RUFDUixJQUFNSSxhQUFhLEdBQUdILGtCQUFrQixDQUFDRixXQUFXLENBQUM7RUFDckQsSUFBSSxDQUFDSyxhQUFhLEVBQUU7SUFDbEIsTUFBTSxJQUFJTixLQUFLLENBQUMsNkJBQTZCLEdBQUdDLFdBQVcsQ0FBQztFQUM5RDtFQUNBRixnQkFBZ0IsQ0FBQ08sYUFBYSxDQUFDO0FBQ2pDOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGdCQUFzQkMsa0JBQWtCQSxDQUFBQyxHQUFBLEVBQUFDLEdBQUEsRUFBQUMsR0FBQTtFQUFBLE9BQUFDLG1CQUFBLENBQUF2QixLQUFBLE9BQUFwQyxTQUFBO0FBQUE7QUF5QnZDLFNBQUEyRCxvQkFBQTtFQUFBQSxtQkFBQSxHQUFBOUMsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQXpCTSxTQUFBNkMsU0FDTEMsTUFBd0IsRUFDeEJDLElBQXdCLEVBQ3hCQyxjQUEyQjtJQUFBLElBQUFDLE9BQUEsRUFBQUMsR0FBQSxFQUFBaEQsR0FBQTtJQUFBLE9BQUFILG1CQUFBLENBQUFNLElBQUEsVUFBQThDLFVBQUFDLFNBQUE7TUFBQSxrQkFBQUEsU0FBQSxDQUFBNUMsSUFBQSxHQUFBNEMsU0FBQSxDQUFBM0MsSUFBQTtRQUFBO1VBRXZCd0MsT0FBTyxHQUFHLEtBQUs7VUFDYkMsR0FBRyxHQUNQSCxJQUFJLElBQUksSUFBSSxHQUNSdEQsV0FBQSxDQUFXLFlBQU07WUFDZndELE9BQU8sR0FBRyxJQUFJO1lBQ2RELGNBQWMsYUFBZEEsY0FBYyxlQUFkQSxjQUFjLENBQUcsQ0FBQztVQUNwQixDQUFDLEVBQUVELElBQUksQ0FBQyxHQUNSNUQsU0FBUztVQUFBaUUsU0FBQSxDQUFBNUMsSUFBQTtVQUFBNEMsU0FBQSxDQUFBM0MsSUFBQTtVQUFBLE9BR0RxQyxNQUFNLENBQUMsQ0FBQztRQUFBO1VBQXBCNUMsR0FBRyxHQUFBa0QsU0FBQSxDQUFBdEMsSUFBQTtRQUFBO1VBQUFzQyxTQUFBLENBQUE1QyxJQUFBO1VBRUgsSUFBSTBDLEdBQUcsRUFBRTtZQUNQRyxZQUFZLENBQUNILEdBQUcsQ0FBQztVQUNuQjtVQUFDLE9BQUFFLFNBQUEsQ0FBQUUsTUFBQTtRQUFBO1VBQUEsS0FFQ0wsT0FBTztZQUFBRyxTQUFBLENBQUEzQyxJQUFBO1lBQUE7VUFBQTtVQUFBLE1BQ0gsSUFBSXdCLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztRQUFBO1VBQUEsT0FBQW1CLFNBQUEsQ0FBQUcsTUFBQSxXQUU3QnJELEdBQUc7UUFBQTtRQUFBO1VBQUEsT0FBQWtELFNBQUEsQ0FBQWpDLElBQUE7TUFBQTtJQUFBLEdBQUEwQixRQUFBO0VBQUEsQ0FDWDtFQUFBLE9BQUFELG1CQUFBLENBQUF2QixLQUFBLE9BQUFwQyxTQUFBO0FBQUEiLCJpZ25vcmVMaXN0IjpbXX0=