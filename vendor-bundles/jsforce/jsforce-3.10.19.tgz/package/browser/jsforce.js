import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
import { EventEmitter } from 'events';
import VERSION from './VERSION';
import Connection from './connection';
import OAuth2 from './oauth2';
import SfDate from './date';
import registry from './registry';
import client, { BrowserClient } from './browser/client';

/**
 *
 */
var JSforce = /*#__PURE__*/function (_EventEmitter) {
  function JSforce() {
    var _context;
    var _this;
    _classCallCheck(this, JSforce);
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    _this = _callSuper(this, JSforce, _concatInstanceProperty(_context = []).call(_context, args));
    _defineProperty(_this, "VERSION", VERSION);
    _defineProperty(_this, "Connection", Connection);
    _defineProperty(_this, "OAuth2", OAuth2);
    _defineProperty(_this, "SfDate", SfDate);
    _defineProperty(_this, "Date", SfDate);
    _defineProperty(_this, "BrowserClient", BrowserClient);
    _defineProperty(_this, "registry", registry);
    _defineProperty(_this, "browser", client);
    return _this;
  }
  _inherits(JSforce, _EventEmitter);
  return _createClass(JSforce);
}(EventEmitter);
export function registerModule(name, factory) {
  jsforce.on('connection:new', function (conn) {
    var obj = undefined;
    _Object$defineProperty(conn, name, {
      get: function get() {
        obj = obj !== null && obj !== void 0 ? obj : factory(conn);
        return obj;
      },
      enumerable: true,
      configurable: true
    });
  });
}
var jsforce = new JSforce();
export default jsforce;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJWRVJTSU9OIiwiQ29ubmVjdGlvbiIsIk9BdXRoMiIsIlNmRGF0ZSIsInJlZ2lzdHJ5IiwiY2xpZW50IiwiQnJvd3NlckNsaWVudCIsIkpTZm9yY2UiLCJfRXZlbnRFbWl0dGVyIiwiX2NvbnRleHQiLCJfdGhpcyIsIl9jbGFzc0NhbGxDaGVjayIsIl9sZW4iLCJhcmd1bWVudHMiLCJsZW5ndGgiLCJhcmdzIiwiQXJyYXkiLCJfa2V5IiwiX2NhbGxTdXBlciIsIl9jb25jYXRJbnN0YW5jZVByb3BlcnR5IiwiY2FsbCIsIl9kZWZpbmVQcm9wZXJ0eSIsIl9pbmhlcml0cyIsIl9jcmVhdGVDbGFzcyIsInJlZ2lzdGVyTW9kdWxlIiwibmFtZSIsImZhY3RvcnkiLCJqc2ZvcmNlIiwib24iLCJjb25uIiwib2JqIiwidW5kZWZpbmVkIiwiX09iamVjdCRkZWZpbmVQcm9wZXJ0eSIsImdldCIsImVudW1lcmFibGUiLCJjb25maWd1cmFibGUiXSwic291cmNlcyI6WyIuLi9zcmMvanNmb3JjZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IFZFUlNJT04gZnJvbSAnLi9WRVJTSU9OJztcbmltcG9ydCBDb25uZWN0aW9uIGZyb20gJy4vY29ubmVjdGlvbic7XG5pbXBvcnQgT0F1dGgyIGZyb20gJy4vb2F1dGgyJztcbmltcG9ydCBTZkRhdGUgZnJvbSAnLi9kYXRlJztcbmltcG9ydCByZWdpc3RyeSwgeyBSZWdpc3RyeSB9IGZyb20gJy4vcmVnaXN0cnknO1xuaW1wb3J0IGNsaWVudCwgeyBCcm93c2VyQ2xpZW50IH0gZnJvbSAnLi9icm93c2VyL2NsaWVudCc7XG5cbi8qKlxuICpcbiAqL1xuY2xhc3MgSlNmb3JjZSBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIFZFUlNJT046IHR5cGVvZiBWRVJTSU9OID0gVkVSU0lPTjtcbiAgQ29ubmVjdGlvbjogdHlwZW9mIENvbm5lY3Rpb24gPSBDb25uZWN0aW9uO1xuICBPQXV0aDI6IHR5cGVvZiBPQXV0aDIgPSBPQXV0aDI7XG4gIFNmRGF0ZTogdHlwZW9mIFNmRGF0ZSA9IFNmRGF0ZTtcbiAgRGF0ZTogdHlwZW9mIFNmRGF0ZSA9IFNmRGF0ZTtcbiAgQnJvd3NlckNsaWVudDogdHlwZW9mIEJyb3dzZXJDbGllbnQgPSBCcm93c2VyQ2xpZW50O1xuICByZWdpc3RyeTogUmVnaXN0cnkgPSByZWdpc3RyeTtcbiAgYnJvd3NlcjogQnJvd3NlckNsaWVudCA9IGNsaWVudDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlZ2lzdGVyTW9kdWxlKFxuICBuYW1lOiBzdHJpbmcsXG4gIGZhY3Rvcnk6IChjb25uOiBDb25uZWN0aW9uKSA9PiBhbnksXG4pIHtcbiAganNmb3JjZS5vbignY29ubmVjdGlvbjpuZXcnLCAoY29ubjogQ29ubmVjdGlvbikgPT4ge1xuICAgIGxldCBvYmo6IGFueSA9IHVuZGVmaW5lZDtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY29ubiwgbmFtZSwge1xuICAgICAgZ2V0KCkge1xuICAgICAgICBvYmogPSBvYmogPz8gZmFjdG9yeShjb25uKTtcbiAgICAgICAgcmV0dXJuIG9iajtcbiAgICAgIH0sXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgIH0pO1xuICB9KTtcbn1cblxuY29uc3QganNmb3JjZSA9IG5ldyBKU2ZvcmNlKCk7XG5leHBvcnQgZGVmYXVsdCBqc2ZvcmNlO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBLFNBQVNBLFlBQVksUUFBUSxRQUFRO0FBQ3JDLE9BQU9DLE9BQU8sTUFBTSxXQUFXO0FBQy9CLE9BQU9DLFVBQVUsTUFBTSxjQUFjO0FBQ3JDLE9BQU9DLE1BQU0sTUFBTSxVQUFVO0FBQzdCLE9BQU9DLE1BQU0sTUFBTSxRQUFRO0FBQzNCLE9BQU9DLFFBQVEsTUFBb0IsWUFBWTtBQUMvQyxPQUFPQyxNQUFNLElBQUlDLGFBQWEsUUFBUSxrQkFBa0I7O0FBRXhEO0FBQ0E7QUFDQTtBQUZBLElBR01DLE9BQU8sMEJBQUFDLGFBQUE7RUFBQSxTQUFBRCxRQUFBO0lBQUEsSUFBQUUsUUFBQTtJQUFBLElBQUFDLEtBQUE7SUFBQUMsZUFBQSxPQUFBSixPQUFBO0lBQUEsU0FBQUssSUFBQSxHQUFBQyxTQUFBLENBQUFDLE1BQUEsRUFBQUMsSUFBQSxPQUFBQyxLQUFBLENBQUFKLElBQUEsR0FBQUssSUFBQSxNQUFBQSxJQUFBLEdBQUFMLElBQUEsRUFBQUssSUFBQTtNQUFBRixJQUFBLENBQUFFLElBQUEsSUFBQUosU0FBQSxDQUFBSSxJQUFBO0lBQUE7SUFBQVAsS0FBQSxHQUFBUSxVQUFBLE9BQUFYLE9BQUEsRUFBQVksdUJBQUEsQ0FBQVYsUUFBQSxPQUFBVyxJQUFBLENBQUFYLFFBQUEsRUFBQU0sSUFBQTtJQUFBTSxlQUFBLENBQUFYLEtBQUEsYUFDZVYsT0FBTztJQUFBcUIsZUFBQSxDQUFBWCxLQUFBLGdCQUNEVCxVQUFVO0lBQUFvQixlQUFBLENBQUFYLEtBQUEsWUFDbEJSLE1BQU07SUFBQW1CLGVBQUEsQ0FBQVgsS0FBQSxZQUNOUCxNQUFNO0lBQUFrQixlQUFBLENBQUFYLEtBQUEsVUFDUlAsTUFBTTtJQUFBa0IsZUFBQSxDQUFBWCxLQUFBLG1CQUNVSixhQUFhO0lBQUFlLGVBQUEsQ0FBQVgsS0FBQSxjQUM5Qk4sUUFBUTtJQUFBaUIsZUFBQSxDQUFBWCxLQUFBLGFBQ0pMLE1BQU07SUFBQSxPQUFBSyxLQUFBO0VBQUE7RUFBQVksU0FBQSxDQUFBZixPQUFBLEVBQUFDLGFBQUE7RUFBQSxPQUFBZSxZQUFBLENBQUFoQixPQUFBO0FBQUEsRUFSWFIsWUFBWTtBQVdsQyxPQUFPLFNBQVN5QixjQUFjQSxDQUM1QkMsSUFBWSxFQUNaQyxPQUFrQyxFQUNsQztFQUNBQyxPQUFPLENBQUNDLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxVQUFDQyxJQUFnQixFQUFLO0lBQ2pELElBQUlDLEdBQVEsR0FBR0MsU0FBUztJQUN4QkMsc0JBQUEsQ0FBc0JILElBQUksRUFBRUosSUFBSSxFQUFFO01BQ2hDUSxHQUFHLFdBQUhBLEdBQUdBLENBQUEsRUFBRztRQUNKSCxHQUFHLEdBQUdBLEdBQUcsYUFBSEEsR0FBRyxjQUFIQSxHQUFHLEdBQUlKLE9BQU8sQ0FBQ0csSUFBSSxDQUFDO1FBQzFCLE9BQU9DLEdBQUc7TUFDWixDQUFDO01BQ0RJLFVBQVUsRUFBRSxJQUFJO01BQ2hCQyxZQUFZLEVBQUU7SUFDaEIsQ0FBQyxDQUFDO0VBQ0osQ0FBQyxDQUFDO0FBQ0o7QUFFQSxJQUFNUixPQUFPLEdBQUcsSUFBSXBCLE9BQU8sQ0FBQyxDQUFDO0FBQzdCLGVBQWVvQixPQUFPIiwiaWdub3JlTGlzdCI6W119