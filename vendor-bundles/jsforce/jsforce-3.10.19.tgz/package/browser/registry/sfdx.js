import _toConsumableArray from "@babel/runtime-corejs3/helpers/toConsumableArray";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.join.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.object.keys.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.to-string.js";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import { exec } from 'child_process';
import { stripVTControlCharacters } from 'util';
import Connection from '../connection';
function isNotNullOrUndefined(v) {
  return v != null;
}

/**
 *
 */
export var SfdxRegistry = /*#__PURE__*/function () {
  function SfdxRegistry(_ref) {
    var cliPath = _ref.cliPath;
    _classCallCheck(this, SfdxRegistry);
    _defineProperty(this, "_orgInfoMap", {});
    this._cliPath = cliPath;
  }
  return _createClass(SfdxRegistry, [{
    key: "_createCommand",
    value: function _createCommand(command) {
      var _context, _context2, _context3, _context4;
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var args = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
      return _concatInstanceProperty(_context = _concatInstanceProperty(_context2 = _concatInstanceProperty(_context3 = "".concat(this._cliPath ? this._cliPath + '/' : '', "sfdx ")).call(_context3, command, " ")).call(_context2, _mapInstanceProperty(_context4 = _Object$keys(options)).call(_context4, function (option) {
        var _context5, _context6;
        return _concatInstanceProperty(_context5 = _concatInstanceProperty(_context6 = "".concat(option.length > 1 ? '--' : '-')).call(_context6, option)).call(_context5, options[option] != null ? ' ' + options[option] : '');
      }).join(' '), " --json ")).call(_context, args.join(' '));
    }
  }, {
    key: "_execCommand",
    value: function () {
      var _execCommand2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(command) {
        var options,
          args,
          cmd,
          buf,
          body,
          ret,
          err,
          _args = arguments;
        return _regeneratorRuntime.wrap(function _callee$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              options = _args.length > 1 && _args[1] !== undefined ? _args[1] : {};
              args = _args.length > 2 && _args[2] !== undefined ? _args[2] : [];
              cmd = this._createCommand(command, options, args);
              _context7.next = 5;
              return new _Promise(function (resolve, reject) {
                exec(cmd, function (err, ret) {
                  if (err && !ret) {
                    reject(err);
                  } else {
                    resolve(ret);
                  }
                });
              });
            case 5:
              buf = _context7.sent;
              body = stripVTControlCharacters(buf.toString());
              _context7.prev = 7;
              ret = JSON.parse(body);
              _context7.next = 14;
              break;
            case 11:
              _context7.prev = 11;
              _context7.t0 = _context7["catch"](7);
              throw new Error("Unexpectedd output from Sfdx cli: ".concat(body));
            case 14:
              if (!(ret.status === 0 && ret.result)) {
                _context7.next = 18;
                break;
              }
              return _context7.abrupt("return", ret.result);
            case 18:
              err = new Error(ret.message);
              err.name = ret.name;
              throw err;
            case 21:
            case "end":
              return _context7.stop();
          }
        }, _callee, this, [[7, 11]]);
      }));
      function _execCommand(_x) {
        return _execCommand2.apply(this, arguments);
      }
      return _execCommand;
    }()
  }, {
    key: "_getOrgList",
    value: function () {
      var _getOrgList2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2() {
        return _regeneratorRuntime.wrap(function _callee2$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              if (!this._orgList) {
                this._orgList = this._execCommand('force:org:list');
              }
              return _context8.abrupt("return", this._orgList);
            case 2:
            case "end":
              return _context8.stop();
          }
        }, _callee2, this);
      }));
      function _getOrgList() {
        return _getOrgList2.apply(this, arguments);
      }
      return _getOrgList;
    }()
  }, {
    key: "getConnectionNames",
    value: function () {
      var _getConnectionNames = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3() {
        var _context9, _context10, _context11;
        var _yield$this$_getOrgLi, nonScratchOrgs, scratchOrgs;
        return _regeneratorRuntime.wrap(function _callee3$(_context12) {
          while (1) switch (_context12.prev = _context12.next) {
            case 0:
              _context12.next = 2;
              return this._getOrgList();
            case 2:
              _yield$this$_getOrgLi = _context12.sent;
              nonScratchOrgs = _yield$this$_getOrgLi.nonScratchOrgs;
              scratchOrgs = _yield$this$_getOrgLi.scratchOrgs;
              return _context12.abrupt("return", _concatInstanceProperty(_context9 = []).call(_context9, _toConsumableArray(_filterInstanceProperty(_context10 = _mapInstanceProperty(nonScratchOrgs).call(nonScratchOrgs, function (o) {
                return o.alias;
              })).call(_context10, isNotNullOrUndefined)), _toConsumableArray(_filterInstanceProperty(_context11 = _mapInstanceProperty(scratchOrgs).call(scratchOrgs, function (o) {
                return o.alias;
              })).call(_context11, isNotNullOrUndefined)), _toConsumableArray(_mapInstanceProperty(nonScratchOrgs).call(nonScratchOrgs, function (o) {
                return o.username;
              })), _toConsumableArray(_mapInstanceProperty(scratchOrgs).call(scratchOrgs, function (o) {
                return o.username;
              }))));
            case 6:
            case "end":
              return _context12.stop();
          }
        }, _callee3, this);
      }));
      function getConnectionNames() {
        return _getConnectionNames.apply(this, arguments);
      }
      return getConnectionNames;
    }()
  }, {
    key: "getConnection",
    value: function () {
      var _getConnection = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4(name) {
        var config;
        return _regeneratorRuntime.wrap(function _callee4$(_context13) {
          while (1) switch (_context13.prev = _context13.next) {
            case 0:
              _context13.next = 2;
              return this.getConnectionConfig(name);
            case 2:
              config = _context13.sent;
              return _context13.abrupt("return", config ? new Connection(config) : null);
            case 4:
            case "end":
              return _context13.stop();
          }
        }, _callee4, this);
      }));
      function getConnection(_x2) {
        return _getConnection.apply(this, arguments);
      }
      return getConnection;
    }()
  }, {
    key: "_getOrgInfo",
    value: function () {
      var _getOrgInfo2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee5(username) {
        var options, pOrgInfo, orgInfo;
        return _regeneratorRuntime.wrap(function _callee5$(_context14) {
          while (1) switch (_context14.prev = _context14.next) {
            case 0:
              options = username ? {
                u: username
              } : {};
              if (!username || !this._orgInfoMap[username]) {
                pOrgInfo = this._execCommand('force:org:display', options);
                this._memoOrgInfo(pOrgInfo, username);
              }
              orgInfo = username ? this._orgInfoMap[username] : this._defaultOrgInfo;
              if (orgInfo) {
                _context14.next = 5;
                break;
              }
              throw new Error('no orginfo found');
            case 5:
              return _context14.abrupt("return", orgInfo);
            case 6:
            case "end":
              return _context14.stop();
          }
        }, _callee5, this);
      }));
      function _getOrgInfo(_x3) {
        return _getOrgInfo2.apply(this, arguments);
      }
      return _getOrgInfo;
    }()
  }, {
    key: "_memoOrgInfo",
    value: function _memoOrgInfo(pOrgInfo, username) {
      var _this = this;
      var pOrgInfo_ = pOrgInfo.then(function (orgInfo) {
        _this._orgInfoMap[orgInfo.username] = pOrgInfo_;
        if (orgInfo.alias) {
          _this._orgInfoMap[orgInfo.alias] = pOrgInfo_;
        }
        return orgInfo;
      });
      if (username) {
        this._orgInfoMap[username] = pOrgInfo_;
      } else {
        this._defaultOrgInfo = pOrgInfo_;
      }
    }
  }, {
    key: "getConnectionConfig",
    value: function () {
      var _getConnectionConfig = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee6(name) {
        var orgInfo, accessToken, instanceUrl, loginUrl;
        return _regeneratorRuntime.wrap(function _callee6$(_context15) {
          while (1) switch (_context15.prev = _context15.next) {
            case 0:
              _context15.next = 2;
              return this._getOrgInfo(name);
            case 2:
              orgInfo = _context15.sent;
              if (orgInfo) {
                _context15.next = 5;
                break;
              }
              return _context15.abrupt("return", null);
            case 5:
              accessToken = orgInfo.accessToken, instanceUrl = orgInfo.instanceUrl, loginUrl = orgInfo.loginUrl;
              return _context15.abrupt("return", {
                accessToken: accessToken,
                instanceUrl: instanceUrl,
                loginUrl: loginUrl
              });
            case 7:
            case "end":
              return _context15.stop();
          }
        }, _callee6, this);
      }));
      function getConnectionConfig(_x4) {
        return _getConnectionConfig.apply(this, arguments);
      }
      return getConnectionConfig;
    }()
  }, {
    key: "saveConnectionConfig",
    value: function () {
      var _saveConnectionConfig = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee7(_name, _connConfig) {
        return _regeneratorRuntime.wrap(function _callee7$(_context16) {
          while (1) switch (_context16.prev = _context16.next) {
            case 0:
            case "end":
              return _context16.stop();
          }
        }, _callee7);
      }));
      function saveConnectionConfig(_x5, _x6) {
        return _saveConnectionConfig.apply(this, arguments);
      }
      return saveConnectionConfig;
    }()
  }, {
    key: "setDefaultConnection",
    value: function () {
      var _setDefaultConnection = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee8(_name) {
        return _regeneratorRuntime.wrap(function _callee8$(_context17) {
          while (1) switch (_context17.prev = _context17.next) {
            case 0:
            case "end":
              return _context17.stop();
          }
        }, _callee8);
      }));
      function setDefaultConnection(_x7) {
        return _setDefaultConnection.apply(this, arguments);
      }
      return setDefaultConnection;
    }()
  }, {
    key: "removeConnectionConfig",
    value: function () {
      var _removeConnectionConfig = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee9(name) {
        return _regeneratorRuntime.wrap(function _callee9$(_context18) {
          while (1) switch (_context18.prev = _context18.next) {
            case 0:
              _context18.next = 2;
              return this._execCommand('force:org:delete', {
                u: name
              });
            case 2:
            case "end":
              return _context18.stop();
          }
        }, _callee9, this);
      }));
      function removeConnectionConfig(_x8) {
        return _removeConnectionConfig.apply(this, arguments);
      }
      return removeConnectionConfig;
    }() // eslint-disable-next-line @typescript-eslint/require-await
  }, {
    key: "getClientConfig",
    value: function () {
      var _getClientConfig = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee10(_name) {
        return _regeneratorRuntime.wrap(function _callee10$(_context19) {
          while (1) switch (_context19.prev = _context19.next) {
            case 0:
              return _context19.abrupt("return", null);
            case 1:
            case "end":
              return _context19.stop();
          }
        }, _callee10);
      }));
      function getClientConfig(_x9) {
        return _getClientConfig.apply(this, arguments);
      }
      return getClientConfig;
    }() // eslint-disable-next-line @typescript-eslint/require-await
  }, {
    key: "getClientNames",
    value: function () {
      var _getClientNames = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee11() {
        return _regeneratorRuntime.wrap(function _callee11$(_context20) {
          while (1) switch (_context20.prev = _context20.next) {
            case 0:
              return _context20.abrupt("return", []);
            case 1:
            case "end":
              return _context20.stop();
          }
        }, _callee11);
      }));
      function getClientNames() {
        return _getClientNames.apply(this, arguments);
      }
      return getClientNames;
    }()
  }, {
    key: "registerClientConfig",
    value: function () {
      var _registerClientConfig = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee12(_name, _clientConfig) {
        return _regeneratorRuntime.wrap(function _callee12$(_context21) {
          while (1) switch (_context21.prev = _context21.next) {
            case 0:
            case "end":
              return _context21.stop();
          }
        }, _callee12);
      }));
      function registerClientConfig(_x10, _x11) {
        return _registerClientConfig.apply(this, arguments);
      }
      return registerClientConfig;
    }()
  }]);
}();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJleGVjIiwic3RyaXBWVENvbnRyb2xDaGFyYWN0ZXJzIiwiQ29ubmVjdGlvbiIsImlzTm90TnVsbE9yVW5kZWZpbmVkIiwidiIsIlNmZHhSZWdpc3RyeSIsIl9yZWYiLCJjbGlQYXRoIiwiX2NsYXNzQ2FsbENoZWNrIiwiX2RlZmluZVByb3BlcnR5IiwiX2NsaVBhdGgiLCJfY3JlYXRlQ2xhc3MiLCJrZXkiLCJ2YWx1ZSIsIl9jcmVhdGVDb21tYW5kIiwiY29tbWFuZCIsIl9jb250ZXh0IiwiX2NvbnRleHQyIiwiX2NvbnRleHQzIiwiX2NvbnRleHQ0Iiwib3B0aW9ucyIsImFyZ3VtZW50cyIsImxlbmd0aCIsInVuZGVmaW5lZCIsImFyZ3MiLCJfY29uY2F0SW5zdGFuY2VQcm9wZXJ0eSIsImNvbmNhdCIsImNhbGwiLCJfbWFwSW5zdGFuY2VQcm9wZXJ0eSIsIl9PYmplY3Qka2V5cyIsIm9wdGlvbiIsIl9jb250ZXh0NSIsIl9jb250ZXh0NiIsImpvaW4iLCJfZXhlY0NvbW1hbmQyIiwiX2FzeW5jVG9HZW5lcmF0b3IiLCJfcmVnZW5lcmF0b3JSdW50aW1lIiwibWFyayIsIl9jYWxsZWUiLCJjbWQiLCJidWYiLCJib2R5IiwicmV0IiwiZXJyIiwiX2FyZ3MiLCJ3cmFwIiwiX2NhbGxlZSQiLCJfY29udGV4dDciLCJwcmV2IiwibmV4dCIsIl9Qcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsInNlbnQiLCJ0b1N0cmluZyIsIkpTT04iLCJwYXJzZSIsInQwIiwiRXJyb3IiLCJzdGF0dXMiLCJyZXN1bHQiLCJhYnJ1cHQiLCJtZXNzYWdlIiwibmFtZSIsInN0b3AiLCJfZXhlY0NvbW1hbmQiLCJfeCIsImFwcGx5IiwiX2dldE9yZ0xpc3QyIiwiX2NhbGxlZTIiLCJfY2FsbGVlMiQiLCJfY29udGV4dDgiLCJfb3JnTGlzdCIsIl9nZXRPcmdMaXN0IiwiX2dldENvbm5lY3Rpb25OYW1lcyIsIl9jYWxsZWUzIiwiX2NvbnRleHQ5IiwiX2NvbnRleHQxMCIsIl9jb250ZXh0MTEiLCJfeWllbGQkdGhpcyRfZ2V0T3JnTGkiLCJub25TY3JhdGNoT3JncyIsInNjcmF0Y2hPcmdzIiwiX2NhbGxlZTMkIiwiX2NvbnRleHQxMiIsIl90b0NvbnN1bWFibGVBcnJheSIsIl9maWx0ZXJJbnN0YW5jZVByb3BlcnR5IiwibyIsImFsaWFzIiwidXNlcm5hbWUiLCJnZXRDb25uZWN0aW9uTmFtZXMiLCJfZ2V0Q29ubmVjdGlvbiIsIl9jYWxsZWU0IiwiY29uZmlnIiwiX2NhbGxlZTQkIiwiX2NvbnRleHQxMyIsImdldENvbm5lY3Rpb25Db25maWciLCJnZXRDb25uZWN0aW9uIiwiX3gyIiwiX2dldE9yZ0luZm8yIiwiX2NhbGxlZTUiLCJwT3JnSW5mbyIsIm9yZ0luZm8iLCJfY2FsbGVlNSQiLCJfY29udGV4dDE0IiwidSIsIl9vcmdJbmZvTWFwIiwiX21lbW9PcmdJbmZvIiwiX2RlZmF1bHRPcmdJbmZvIiwiX2dldE9yZ0luZm8iLCJfeDMiLCJfdGhpcyIsInBPcmdJbmZvXyIsInRoZW4iLCJfZ2V0Q29ubmVjdGlvbkNvbmZpZyIsIl9jYWxsZWU2IiwiYWNjZXNzVG9rZW4iLCJpbnN0YW5jZVVybCIsImxvZ2luVXJsIiwiX2NhbGxlZTYkIiwiX2NvbnRleHQxNSIsIl94NCIsIl9zYXZlQ29ubmVjdGlvbkNvbmZpZyIsIl9jYWxsZWU3IiwiX25hbWUiLCJfY29ubkNvbmZpZyIsIl9jYWxsZWU3JCIsIl9jb250ZXh0MTYiLCJzYXZlQ29ubmVjdGlvbkNvbmZpZyIsIl94NSIsIl94NiIsIl9zZXREZWZhdWx0Q29ubmVjdGlvbiIsIl9jYWxsZWU4IiwiX2NhbGxlZTgkIiwiX2NvbnRleHQxNyIsInNldERlZmF1bHRDb25uZWN0aW9uIiwiX3g3IiwiX3JlbW92ZUNvbm5lY3Rpb25Db25maWciLCJfY2FsbGVlOSIsIl9jYWxsZWU5JCIsIl9jb250ZXh0MTgiLCJyZW1vdmVDb25uZWN0aW9uQ29uZmlnIiwiX3g4IiwiX2dldENsaWVudENvbmZpZyIsIl9jYWxsZWUxMCIsIl9jYWxsZWUxMCQiLCJfY29udGV4dDE5IiwiZ2V0Q2xpZW50Q29uZmlnIiwiX3g5IiwiX2dldENsaWVudE5hbWVzIiwiX2NhbGxlZTExIiwiX2NhbGxlZTExJCIsIl9jb250ZXh0MjAiLCJnZXRDbGllbnROYW1lcyIsIl9yZWdpc3RlckNsaWVudENvbmZpZyIsIl9jYWxsZWUxMiIsIl9jbGllbnRDb25maWciLCJfY2FsbGVlMTIkIiwiX2NvbnRleHQyMSIsInJlZ2lzdGVyQ2xpZW50Q29uZmlnIiwiX3gxMCIsIl94MTEiXSwic291cmNlcyI6WyIuLi8uLi9zcmMvcmVnaXN0cnkvc2ZkeC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBleGVjIH0gZnJvbSAnY2hpbGRfcHJvY2Vzcyc7XG5pbXBvcnQgeyBzdHJpcFZUQ29udHJvbENoYXJhY3RlcnMgfSBmcm9tICd1dGlsJztcbmltcG9ydCBDb25uZWN0aW9uIGZyb20gJy4uL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHsgUmVnaXN0cnksIENvbm5lY3Rpb25Db25maWcsIENsaWVudENvbmZpZyB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgU2NoZW1hIH0gZnJvbSAnLi4vdHlwZXMnO1xuXG50eXBlIFNmZHhDb21tYW5kT3V0cHV0ID0ge1xuICBzdGF0dXM6IG51bWJlcjtcbiAgbmFtZT86IHN0cmluZztcbiAgbWVzc2FnZT86IHN0cmluZztcbiAgcmVzdWx0PzogYW55O1xufTtcblxudHlwZSBTZmR4T3JnTGlzdCA9IHtcbiAgbm9uU2NyYXRjaE9yZ3M6IFNmZHhPcmdJbmZvW107XG4gIHNjcmF0Y2hPcmdzOiBTZmR4T3JnSW5mb1tdO1xufTtcblxudHlwZSBTZmR4T3JnSW5mbyA9IHtcbiAgb3JnSWQ6IHN0cmluZztcbiAgYWNjZXNzVG9rZW46IHN0cmluZztcbiAgaW5zdGFuY2VVcmw6IHN0cmluZztcbiAgbG9naW5Vcmw6IHN0cmluZztcbiAgdXNlcm5hbWU6IHN0cmluZztcbiAgY2xpZW50SWQ6IHN0cmluZztcbiAgaXNEZXZIdWI6IGJvb2xlYW47XG4gIGNvbm5lY3RlZFN0YXR1czogc3RyaW5nO1xuICBsYXN0VXNlZDogc3RyaW5nO1xuICBhbGlhcz86IHN0cmluZztcbn07XG5cbmZ1bmN0aW9uIGlzTm90TnVsbE9yVW5kZWZpbmVkPFQ+KHY6IFQgfCBudWxsIHwgdW5kZWZpbmVkKTogdiBpcyBUIHtcbiAgcmV0dXJuIHYgIT0gbnVsbDtcbn1cblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgU2ZkeFJlZ2lzdHJ5IGltcGxlbWVudHMgUmVnaXN0cnkge1xuICBfY2xpUGF0aDogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICBfb3JnTGlzdDogUHJvbWlzZTxTZmR4T3JnTGlzdD4gfCB1bmRlZmluZWQ7XG4gIF9vcmdJbmZvTWFwOiB7IFtuYW1lOiBzdHJpbmddOiBQcm9taXNlPFNmZHhPcmdJbmZvPiB9ID0ge307XG4gIF9kZWZhdWx0T3JnSW5mbzogUHJvbWlzZTxTZmR4T3JnSW5mbz4gfCB1bmRlZmluZWQ7XG5cbiAgY29uc3RydWN0b3IoeyBjbGlQYXRoIH06IHsgY2xpUGF0aD86IHN0cmluZyB9KSB7XG4gICAgdGhpcy5fY2xpUGF0aCA9IGNsaVBhdGg7XG4gIH1cblxuICBfY3JlYXRlQ29tbWFuZChcbiAgICBjb21tYW5kOiBzdHJpbmcsXG4gICAgb3B0aW9uczogeyBbb3B0aW9uOiBzdHJpbmddOiBhbnkgfSA9IHt9LFxuICAgIGFyZ3M6IHN0cmluZ1tdID0gW10sXG4gICkge1xuICAgIHJldHVybiBgJHtcbiAgICAgIHRoaXMuX2NsaVBhdGggPyB0aGlzLl9jbGlQYXRoICsgJy8nIDogJydcbiAgICB9c2ZkeCAke2NvbW1hbmR9ICR7T2JqZWN0LmtleXMob3B0aW9ucylcbiAgICAgIC5tYXAoXG4gICAgICAgIChvcHRpb24pID0+XG4gICAgICAgICAgYCR7b3B0aW9uLmxlbmd0aCA+IDEgPyAnLS0nIDogJy0nfSR7b3B0aW9ufSR7XG4gICAgICAgICAgICBvcHRpb25zW29wdGlvbl0gIT0gbnVsbCA/ICcgJyArIG9wdGlvbnNbb3B0aW9uXSA6ICcnXG4gICAgICAgICAgfWAsXG4gICAgICApXG4gICAgICAuam9pbignICcpfSAtLWpzb24gJHthcmdzLmpvaW4oJyAnKX1gO1xuICB9XG5cbiAgYXN5bmMgX2V4ZWNDb21tYW5kPFQ+KFxuICAgIGNvbW1hbmQ6IHN0cmluZyxcbiAgICBvcHRpb25zOiB7IFtvcHRpb246IHN0cmluZ106IGFueSB9ID0ge30sXG4gICAgYXJnczogc3RyaW5nW10gPSBbXSxcbiAgKSB7XG4gICAgY29uc3QgY21kID0gdGhpcy5fY3JlYXRlQ29tbWFuZChjb21tYW5kLCBvcHRpb25zLCBhcmdzKTtcbiAgICBjb25zdCBidWYgPSBhd2FpdCBuZXcgUHJvbWlzZTxzdHJpbmc+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGV4ZWMoY21kLCAoZXJyLCByZXQpID0+IHtcbiAgICAgICAgaWYgKGVyciAmJiAhcmV0KSB7XG4gICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzb2x2ZShyZXQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICBjb25zdCBib2R5ID0gc3RyaXBWVENvbnRyb2xDaGFyYWN0ZXJzKGJ1Zi50b1N0cmluZygpKTtcbiAgICBsZXQgcmV0OiBTZmR4Q29tbWFuZE91dHB1dDtcbiAgICB0cnkge1xuICAgICAgcmV0ID0gSlNPTi5wYXJzZShib2R5KSBhcyBTZmR4Q29tbWFuZE91dHB1dDtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuZXhwZWN0ZWRkIG91dHB1dCBmcm9tIFNmZHggY2xpOiAke2JvZHl9YCk7XG4gICAgfVxuICAgIGlmIChyZXQuc3RhdHVzID09PSAwICYmIHJldC5yZXN1bHQpIHtcbiAgICAgIHJldHVybiByZXQucmVzdWx0IGFzIFQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcihyZXQubWVzc2FnZSBhcyBzdHJpbmcpO1xuICAgICAgZXJyLm5hbWUgPSByZXQubmFtZSBhcyBzdHJpbmc7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgX2dldE9yZ0xpc3QoKSB7XG4gICAgaWYgKCF0aGlzLl9vcmdMaXN0KSB7XG4gICAgICB0aGlzLl9vcmdMaXN0ID0gdGhpcy5fZXhlY0NvbW1hbmQ8U2ZkeE9yZ0xpc3Q+KCdmb3JjZTpvcmc6bGlzdCcpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fb3JnTGlzdDtcbiAgfVxuXG4gIGFzeW5jIGdldENvbm5lY3Rpb25OYW1lcygpIHtcbiAgICBjb25zdCB7IG5vblNjcmF0Y2hPcmdzLCBzY3JhdGNoT3JncyB9ID0gYXdhaXQgdGhpcy5fZ2V0T3JnTGlzdCgpO1xuICAgIHJldHVybiBbXG4gICAgICAuLi5ub25TY3JhdGNoT3Jncy5tYXAoKG8pID0+IG8uYWxpYXMpLmZpbHRlcihpc05vdE51bGxPclVuZGVmaW5lZCksXG4gICAgICAuLi5zY3JhdGNoT3Jncy5tYXAoKG8pID0+IG8uYWxpYXMpLmZpbHRlcihpc05vdE51bGxPclVuZGVmaW5lZCksXG4gICAgICAuLi5ub25TY3JhdGNoT3Jncy5tYXAoKG8pID0+IG8udXNlcm5hbWUpLFxuICAgICAgLi4uc2NyYXRjaE9yZ3MubWFwKChvKSA9PiBvLnVzZXJuYW1lKSxcbiAgICBdO1xuICB9XG5cbiAgYXN5bmMgZ2V0Q29ubmVjdGlvbjxTIGV4dGVuZHMgU2NoZW1hID0gU2NoZW1hPihuYW1lPzogc3RyaW5nKSB7XG4gICAgY29uc3QgY29uZmlnID0gYXdhaXQgdGhpcy5nZXRDb25uZWN0aW9uQ29uZmlnKG5hbWUpO1xuICAgIHJldHVybiBjb25maWcgPyBuZXcgQ29ubmVjdGlvbjxTPihjb25maWcpIDogbnVsbDtcbiAgfVxuXG4gIGFzeW5jIF9nZXRPcmdJbmZvKHVzZXJuYW1lPzogc3RyaW5nKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHVzZXJuYW1lID8geyB1OiB1c2VybmFtZSB9IDoge307XG4gICAgaWYgKCF1c2VybmFtZSB8fCAhdGhpcy5fb3JnSW5mb01hcFt1c2VybmFtZV0pIHtcbiAgICAgIGNvbnN0IHBPcmdJbmZvID0gdGhpcy5fZXhlY0NvbW1hbmQ8U2ZkeE9yZ0luZm8+KFxuICAgICAgICAnZm9yY2U6b3JnOmRpc3BsYXknLFxuICAgICAgICBvcHRpb25zLFxuICAgICAgKTtcbiAgICAgIHRoaXMuX21lbW9PcmdJbmZvKHBPcmdJbmZvLCB1c2VybmFtZSk7XG4gICAgfVxuICAgIGNvbnN0IG9yZ0luZm8gPSB1c2VybmFtZVxuICAgICAgPyB0aGlzLl9vcmdJbmZvTWFwW3VzZXJuYW1lXVxuICAgICAgOiB0aGlzLl9kZWZhdWx0T3JnSW5mbztcbiAgICBpZiAoIW9yZ0luZm8pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignbm8gb3JnaW5mbyBmb3VuZCcpO1xuICAgIH1cbiAgICByZXR1cm4gb3JnSW5mbztcbiAgfVxuXG4gIF9tZW1vT3JnSW5mbyhwT3JnSW5mbzogUHJvbWlzZTxTZmR4T3JnSW5mbz4sIHVzZXJuYW1lPzogc3RyaW5nKSB7XG4gICAgY29uc3QgcE9yZ0luZm9fID0gcE9yZ0luZm8udGhlbigob3JnSW5mbykgPT4ge1xuICAgICAgdGhpcy5fb3JnSW5mb01hcFtvcmdJbmZvLnVzZXJuYW1lXSA9IHBPcmdJbmZvXztcbiAgICAgIGlmIChvcmdJbmZvLmFsaWFzKSB7XG4gICAgICAgIHRoaXMuX29yZ0luZm9NYXBbb3JnSW5mby5hbGlhc10gPSBwT3JnSW5mb187XG4gICAgICB9XG4gICAgICByZXR1cm4gb3JnSW5mbztcbiAgICB9KTtcbiAgICBpZiAodXNlcm5hbWUpIHtcbiAgICAgIHRoaXMuX29yZ0luZm9NYXBbdXNlcm5hbWVdID0gcE9yZ0luZm9fO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9kZWZhdWx0T3JnSW5mbyA9IHBPcmdJbmZvXztcbiAgICB9XG4gIH1cblxuICBhc3luYyBnZXRDb25uZWN0aW9uQ29uZmlnKG5hbWU/OiBzdHJpbmcpIHtcbiAgICBjb25zdCBvcmdJbmZvID0gYXdhaXQgdGhpcy5fZ2V0T3JnSW5mbyhuYW1lKTtcbiAgICBpZiAoIW9yZ0luZm8pIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCB7IGFjY2Vzc1Rva2VuLCBpbnN0YW5jZVVybCwgbG9naW5VcmwgfSA9IG9yZ0luZm87XG4gICAgcmV0dXJuIHsgYWNjZXNzVG9rZW4sIGluc3RhbmNlVXJsLCBsb2dpblVybCB9O1xuICB9XG5cbiAgYXN5bmMgc2F2ZUNvbm5lY3Rpb25Db25maWcoX25hbWU6IHN0cmluZywgX2Nvbm5Db25maWc6IENvbm5lY3Rpb25Db25maWcpIHtcbiAgICAvLyBub3RoaW5nIHRvIGRvXG4gIH1cblxuICBhc3luYyBzZXREZWZhdWx0Q29ubmVjdGlvbihfbmFtZTogc3RyaW5nKSB7XG4gICAgLy8gbm90aGluZyB0byBkb1xuICB9XG5cbiAgYXN5bmMgcmVtb3ZlQ29ubmVjdGlvbkNvbmZpZyhuYW1lOiBzdHJpbmcpIHtcbiAgICBhd2FpdCB0aGlzLl9leGVjQ29tbWFuZCgnZm9yY2U6b3JnOmRlbGV0ZScsIHsgdTogbmFtZSB9KTtcbiAgfVxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L3JlcXVpcmUtYXdhaXRcbiAgYXN5bmMgZ2V0Q2xpZW50Q29uZmlnKF9uYW1lOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvcmVxdWlyZS1hd2FpdFxuICBhc3luYyBnZXRDbGllbnROYW1lcygpIHtcbiAgICByZXR1cm4gW107XG4gIH1cblxuICBhc3luYyByZWdpc3RlckNsaWVudENvbmZpZyhfbmFtZTogc3RyaW5nLCBfY2xpZW50Q29uZmlnOiBDbGllbnRDb25maWcpIHtcbiAgICAvLyBub3RoaW5nIHRvIGRvXG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxTQUFTQSxJQUFJLFFBQVEsZUFBZTtBQUNwQyxTQUFTQyx3QkFBd0IsUUFBUSxNQUFNO0FBQy9DLE9BQU9DLFVBQVUsTUFBTSxlQUFlO0FBNkJ0QyxTQUFTQyxvQkFBb0JBLENBQUlDLENBQXVCLEVBQVU7RUFDaEUsT0FBT0EsQ0FBQyxJQUFJLElBQUk7QUFDbEI7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBYUMsWUFBWTtFQU12QixTQUFBQSxhQUFBQyxJQUFBLEVBQStDO0lBQUEsSUFBakNDLE9BQU8sR0FBQUQsSUFBQSxDQUFQQyxPQUFPO0lBQUFDLGVBQUEsT0FBQUgsWUFBQTtJQUFBSSxlQUFBLHNCQUhtQyxDQUFDLENBQUM7SUFJeEQsSUFBSSxDQUFDQyxRQUFRLEdBQUdILE9BQU87RUFDekI7RUFBQyxPQUFBSSxZQUFBLENBQUFOLFlBQUE7SUFBQU8sR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQUMsY0FBY0EsQ0FDWkMsT0FBZSxFQUdmO01BQUEsSUFBQUMsUUFBQSxFQUFBQyxTQUFBLEVBQUFDLFNBQUEsRUFBQUMsU0FBQTtNQUFBLElBRkFDLE9BQWtDLEdBQUFDLFNBQUEsQ0FBQUMsTUFBQSxRQUFBRCxTQUFBLFFBQUFFLFNBQUEsR0FBQUYsU0FBQSxNQUFHLENBQUMsQ0FBQztNQUFBLElBQ3ZDRyxJQUFjLEdBQUFILFNBQUEsQ0FBQUMsTUFBQSxRQUFBRCxTQUFBLFFBQUFFLFNBQUEsR0FBQUYsU0FBQSxNQUFHLEVBQUU7TUFFbkIsT0FBQUksdUJBQUEsQ0FBQVQsUUFBQSxHQUFBUyx1QkFBQSxDQUFBUixTQUFBLEdBQUFRLHVCQUFBLENBQUFQLFNBQUEsTUFBQVEsTUFBQSxDQUNFLElBQUksQ0FBQ2hCLFFBQVEsR0FBRyxJQUFJLENBQUNBLFFBQVEsR0FBRyxHQUFHLEdBQUcsRUFBRSxZQUFBaUIsSUFBQSxDQUFBVCxTQUFBLEVBQ2xDSCxPQUFPLFFBQUFZLElBQUEsQ0FBQVYsU0FBQSxFQUFJVyxvQkFBQSxDQUFBVCxTQUFBLEdBQUFVLFlBQUEsQ0FBWVQsT0FBTyxDQUFDLEVBQUFPLElBQUEsQ0FBQVIsU0FBQSxFQUVuQyxVQUFDVyxNQUFNO1FBQUEsSUFBQUMsU0FBQSxFQUFBQyxTQUFBO1FBQUEsT0FBQVAsdUJBQUEsQ0FBQU0sU0FBQSxHQUFBTix1QkFBQSxDQUFBTyxTQUFBLE1BQUFOLE1BQUEsQ0FDRkksTUFBTSxDQUFDUixNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxHQUFHLEdBQUFLLElBQUEsQ0FBQUssU0FBQSxFQUFHRixNQUFNLEdBQUFILElBQUEsQ0FBQUksU0FBQSxFQUN4Q1gsT0FBTyxDQUFDVSxNQUFNLENBQUMsSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHVixPQUFPLENBQUNVLE1BQU0sQ0FBQyxHQUFHLEVBQUU7TUFBQSxDQUUxRCxDQUFDLENBQ0FHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBQU4sSUFBQSxDQUFBWCxRQUFBLEVBQVdRLElBQUksQ0FBQ1MsSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUN2QztFQUFDO0lBQUFyQixHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBcUIsYUFBQSxHQUFBQyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBRUQsU0FBQUMsUUFDRXZCLE9BQWU7UUFBQSxJQUFBSyxPQUFBO1VBQUFJLElBQUE7VUFBQWUsR0FBQTtVQUFBQyxHQUFBO1VBQUFDLElBQUE7VUFBQUMsR0FBQTtVQUFBQyxHQUFBO1VBQUFDLEtBQUEsR0FBQXZCLFNBQUE7UUFBQSxPQUFBZSxtQkFBQSxDQUFBUyxJQUFBLFVBQUFDLFNBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBQyxJQUFBLEdBQUFELFNBQUEsQ0FBQUUsSUFBQTtZQUFBO2NBQ2Y3QixPQUFrQyxHQUFBd0IsS0FBQSxDQUFBdEIsTUFBQSxRQUFBc0IsS0FBQSxRQUFBckIsU0FBQSxHQUFBcUIsS0FBQSxNQUFHLENBQUMsQ0FBQztjQUN2Q3BCLElBQWMsR0FBQW9CLEtBQUEsQ0FBQXRCLE1BQUEsUUFBQXNCLEtBQUEsUUFBQXJCLFNBQUEsR0FBQXFCLEtBQUEsTUFBRyxFQUFFO2NBRWJMLEdBQUcsR0FBRyxJQUFJLENBQUN6QixjQUFjLENBQUNDLE9BQU8sRUFBRUssT0FBTyxFQUFFSSxJQUFJLENBQUM7Y0FBQXVCLFNBQUEsQ0FBQUUsSUFBQTtjQUFBLE9BQ3JDLElBQUFDLFFBQUEsQ0FBb0IsVUFBQ0MsT0FBTyxFQUFFQyxNQUFNLEVBQUs7Z0JBQ3pEcEQsSUFBSSxDQUFDdUMsR0FBRyxFQUFFLFVBQUNJLEdBQUcsRUFBRUQsR0FBRyxFQUFLO2tCQUN0QixJQUFJQyxHQUFHLElBQUksQ0FBQ0QsR0FBRyxFQUFFO29CQUNmVSxNQUFNLENBQUNULEdBQUcsQ0FBQztrQkFDYixDQUFDLE1BQU07b0JBQ0xRLE9BQU8sQ0FBQ1QsR0FBRyxDQUFDO2tCQUNkO2dCQUNGLENBQUMsQ0FBQztjQUNKLENBQUMsQ0FBQztZQUFBO2NBUklGLEdBQUcsR0FBQU8sU0FBQSxDQUFBTSxJQUFBO2NBU0haLElBQUksR0FBR3hDLHdCQUF3QixDQUFDdUMsR0FBRyxDQUFDYyxRQUFRLENBQUMsQ0FBQyxDQUFDO2NBQUFQLFNBQUEsQ0FBQUMsSUFBQTtjQUduRE4sR0FBRyxHQUFHYSxJQUFJLENBQUNDLEtBQUssQ0FBQ2YsSUFBSSxDQUFzQjtjQUFDTSxTQUFBLENBQUFFLElBQUE7Y0FBQTtZQUFBO2NBQUFGLFNBQUEsQ0FBQUMsSUFBQTtjQUFBRCxTQUFBLENBQUFVLEVBQUEsR0FBQVYsU0FBQTtjQUFBLE1BRXRDLElBQUlXLEtBQUssc0NBQUFoQyxNQUFBLENBQXNDZSxJQUFJLENBQUUsQ0FBQztZQUFBO2NBQUEsTUFFMURDLEdBQUcsQ0FBQ2lCLE1BQU0sS0FBSyxDQUFDLElBQUlqQixHQUFHLENBQUNrQixNQUFNO2dCQUFBYixTQUFBLENBQUFFLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE9BQUFGLFNBQUEsQ0FBQWMsTUFBQSxXQUN6Qm5CLEdBQUcsQ0FBQ2tCLE1BQU07WUFBQTtjQUVYakIsR0FBRyxHQUFHLElBQUllLEtBQUssQ0FBQ2hCLEdBQUcsQ0FBQ29CLE9BQWlCLENBQUM7Y0FDNUNuQixHQUFHLENBQUNvQixJQUFJLEdBQUdyQixHQUFHLENBQUNxQixJQUFjO2NBQUMsTUFDeEJwQixHQUFHO1lBQUE7WUFBQTtjQUFBLE9BQUFJLFNBQUEsQ0FBQWlCLElBQUE7VUFBQTtRQUFBLEdBQUExQixPQUFBO01BQUEsQ0FFWjtNQUFBLFNBN0JLMkIsWUFBWUEsQ0FBQUMsRUFBQTtRQUFBLE9BQUFoQyxhQUFBLENBQUFpQyxLQUFBLE9BQUE5QyxTQUFBO01BQUE7TUFBQSxPQUFaNEMsWUFBWTtJQUFBO0VBQUE7SUFBQXJELEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUF1RCxZQUFBLEdBQUFqQyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBK0JsQixTQUFBZ0MsU0FBQTtRQUFBLE9BQUFqQyxtQkFBQSxDQUFBUyxJQUFBLFVBQUF5QixVQUFBQyxTQUFBO1VBQUEsa0JBQUFBLFNBQUEsQ0FBQXZCLElBQUEsR0FBQXVCLFNBQUEsQ0FBQXRCLElBQUE7WUFBQTtjQUNFLElBQUksQ0FBQyxJQUFJLENBQUN1QixRQUFRLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQ0EsUUFBUSxHQUFHLElBQUksQ0FBQ1AsWUFBWSxDQUFjLGdCQUFnQixDQUFDO2NBQ2xFO2NBQUMsT0FBQU0sU0FBQSxDQUFBVixNQUFBLFdBQ00sSUFBSSxDQUFDVyxRQUFRO1lBQUE7WUFBQTtjQUFBLE9BQUFELFNBQUEsQ0FBQVAsSUFBQTtVQUFBO1FBQUEsR0FBQUssUUFBQTtNQUFBLENBQ3JCO01BQUEsU0FMS0ksV0FBV0EsQ0FBQTtRQUFBLE9BQUFMLFlBQUEsQ0FBQUQsS0FBQSxPQUFBOUMsU0FBQTtNQUFBO01BQUEsT0FBWG9ELFdBQVc7SUFBQTtFQUFBO0lBQUE3RCxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBNkQsbUJBQUEsR0FBQXZDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FPakIsU0FBQXNDLFNBQUE7UUFBQSxJQUFBQyxTQUFBLEVBQUFDLFVBQUEsRUFBQUMsVUFBQTtRQUFBLElBQUFDLHFCQUFBLEVBQUFDLGNBQUEsRUFBQUMsV0FBQTtRQUFBLE9BQUE3QyxtQkFBQSxDQUFBUyxJQUFBLFVBQUFxQyxVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQW5DLElBQUEsR0FBQW1DLFVBQUEsQ0FBQWxDLElBQUE7WUFBQTtjQUFBa0MsVUFBQSxDQUFBbEMsSUFBQTtjQUFBLE9BQ2dELElBQUksQ0FBQ3dCLFdBQVcsQ0FBQyxDQUFDO1lBQUE7Y0FBQU0scUJBQUEsR0FBQUksVUFBQSxDQUFBOUIsSUFBQTtjQUF4RDJCLGNBQWMsR0FBQUQscUJBQUEsQ0FBZEMsY0FBYztjQUFFQyxXQUFXLEdBQUFGLHFCQUFBLENBQVhFLFdBQVc7Y0FBQSxPQUFBRSxVQUFBLENBQUF0QixNQUFBLFdBQUFwQyx1QkFBQSxDQUFBbUQsU0FBQSxPQUFBakQsSUFBQSxDQUFBaUQsU0FBQSxFQUFBUSxrQkFBQSxDQUU5QkMsdUJBQUEsQ0FBQVIsVUFBQSxHQUFBakQsb0JBQUEsQ0FBQW9ELGNBQWMsRUFBQXJELElBQUEsQ0FBZHFELGNBQWMsRUFBSyxVQUFDTSxDQUFDO2dCQUFBLE9BQUtBLENBQUMsQ0FBQ0MsS0FBSztjQUFBLEVBQUMsRUFBQTVELElBQUEsQ0FBQWtELFVBQUEsRUFBUTFFLG9CQUFvQixDQUFDLEdBQUFpRixrQkFBQSxDQUMvREMsdUJBQUEsQ0FBQVAsVUFBQSxHQUFBbEQsb0JBQUEsQ0FBQXFELFdBQVcsRUFBQXRELElBQUEsQ0FBWHNELFdBQVcsRUFBSyxVQUFDSyxDQUFDO2dCQUFBLE9BQUtBLENBQUMsQ0FBQ0MsS0FBSztjQUFBLEVBQUMsRUFBQTVELElBQUEsQ0FBQW1ELFVBQUEsRUFBUTNFLG9CQUFvQixDQUFDLEdBQUFpRixrQkFBQSxDQUM1RHhELG9CQUFBLENBQUFvRCxjQUFjLEVBQUFyRCxJQUFBLENBQWRxRCxjQUFjLEVBQUssVUFBQ00sQ0FBQztnQkFBQSxPQUFLQSxDQUFDLENBQUNFLFFBQVE7Y0FBQSxFQUFDLEdBQUFKLGtCQUFBLENBQ3JDeEQsb0JBQUEsQ0FBQXFELFdBQVcsRUFBQXRELElBQUEsQ0FBWHNELFdBQVcsRUFBSyxVQUFDSyxDQUFDO2dCQUFBLE9BQUtBLENBQUMsQ0FBQ0UsUUFBUTtjQUFBLEVBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQUwsVUFBQSxDQUFBbkIsSUFBQTtVQUFBO1FBQUEsR0FBQVcsUUFBQTtNQUFBLENBRXhDO01BQUEsU0FSS2Msa0JBQWtCQSxDQUFBO1FBQUEsT0FBQWYsbUJBQUEsQ0FBQVAsS0FBQSxPQUFBOUMsU0FBQTtNQUFBO01BQUEsT0FBbEJvRSxrQkFBa0I7SUFBQTtFQUFBO0lBQUE3RSxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBNkUsY0FBQSxHQUFBdkQsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQVV4QixTQUFBc0QsU0FBK0M1QixJQUFhO1FBQUEsSUFBQTZCLE1BQUE7UUFBQSxPQUFBeEQsbUJBQUEsQ0FBQVMsSUFBQSxVQUFBZ0QsVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUE5QyxJQUFBLEdBQUE4QyxVQUFBLENBQUE3QyxJQUFBO1lBQUE7Y0FBQTZDLFVBQUEsQ0FBQTdDLElBQUE7Y0FBQSxPQUNyQyxJQUFJLENBQUM4QyxtQkFBbUIsQ0FBQ2hDLElBQUksQ0FBQztZQUFBO2NBQTdDNkIsTUFBTSxHQUFBRSxVQUFBLENBQUF6QyxJQUFBO2NBQUEsT0FBQXlDLFVBQUEsQ0FBQWpDLE1BQUEsV0FDTCtCLE1BQU0sR0FBRyxJQUFJMUYsVUFBVSxDQUFJMEYsTUFBTSxDQUFDLEdBQUcsSUFBSTtZQUFBO1lBQUE7Y0FBQSxPQUFBRSxVQUFBLENBQUE5QixJQUFBO1VBQUE7UUFBQSxHQUFBMkIsUUFBQTtNQUFBLENBQ2pEO01BQUEsU0FIS0ssYUFBYUEsQ0FBQUMsR0FBQTtRQUFBLE9BQUFQLGNBQUEsQ0FBQXZCLEtBQUEsT0FBQTlDLFNBQUE7TUFBQTtNQUFBLE9BQWIyRSxhQUFhO0lBQUE7RUFBQTtJQUFBcEYsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQXFGLFlBQUEsR0FBQS9ELGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FLbkIsU0FBQThELFNBQWtCWCxRQUFpQjtRQUFBLElBQUFwRSxPQUFBLEVBQUFnRixRQUFBLEVBQUFDLE9BQUE7UUFBQSxPQUFBakUsbUJBQUEsQ0FBQVMsSUFBQSxVQUFBeUQsVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUF2RCxJQUFBLEdBQUF1RCxVQUFBLENBQUF0RCxJQUFBO1lBQUE7Y0FDM0I3QixPQUFPLEdBQUdvRSxRQUFRLEdBQUc7Z0JBQUVnQixDQUFDLEVBQUVoQjtjQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7Y0FDL0MsSUFBSSxDQUFDQSxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUNpQixXQUFXLENBQUNqQixRQUFRLENBQUMsRUFBRTtnQkFDdENZLFFBQVEsR0FBRyxJQUFJLENBQUNuQyxZQUFZLENBQ2hDLG1CQUFtQixFQUNuQjdDLE9BQ0YsQ0FBQztnQkFDRCxJQUFJLENBQUNzRixZQUFZLENBQUNOLFFBQVEsRUFBRVosUUFBUSxDQUFDO2NBQ3ZDO2NBQ01hLE9BQU8sR0FBR2IsUUFBUSxHQUNwQixJQUFJLENBQUNpQixXQUFXLENBQUNqQixRQUFRLENBQUMsR0FDMUIsSUFBSSxDQUFDbUIsZUFBZTtjQUFBLElBQ25CTixPQUFPO2dCQUFBRSxVQUFBLENBQUF0RCxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUNKLElBQUlTLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQztZQUFBO2NBQUEsT0FBQTZDLFVBQUEsQ0FBQTFDLE1BQUEsV0FFOUJ3QyxPQUFPO1lBQUE7WUFBQTtjQUFBLE9BQUFFLFVBQUEsQ0FBQXZDLElBQUE7VUFBQTtRQUFBLEdBQUFtQyxRQUFBO01BQUEsQ0FDZjtNQUFBLFNBaEJLUyxXQUFXQSxDQUFBQyxHQUFBO1FBQUEsT0FBQVgsWUFBQSxDQUFBL0IsS0FBQSxPQUFBOUMsU0FBQTtNQUFBO01BQUEsT0FBWHVGLFdBQVc7SUFBQTtFQUFBO0lBQUFoRyxHQUFBO0lBQUFDLEtBQUEsRUFrQmpCLFNBQUE2RixZQUFZQSxDQUFDTixRQUE4QixFQUFFWixRQUFpQixFQUFFO01BQUEsSUFBQXNCLEtBQUE7TUFDOUQsSUFBTUMsU0FBUyxHQUFHWCxRQUFRLENBQUNZLElBQUksQ0FBQyxVQUFDWCxPQUFPLEVBQUs7UUFDM0NTLEtBQUksQ0FBQ0wsV0FBVyxDQUFDSixPQUFPLENBQUNiLFFBQVEsQ0FBQyxHQUFHdUIsU0FBUztRQUM5QyxJQUFJVixPQUFPLENBQUNkLEtBQUssRUFBRTtVQUNqQnVCLEtBQUksQ0FBQ0wsV0FBVyxDQUFDSixPQUFPLENBQUNkLEtBQUssQ0FBQyxHQUFHd0IsU0FBUztRQUM3QztRQUNBLE9BQU9WLE9BQU87TUFDaEIsQ0FBQyxDQUFDO01BQ0YsSUFBSWIsUUFBUSxFQUFFO1FBQ1osSUFBSSxDQUFDaUIsV0FBVyxDQUFDakIsUUFBUSxDQUFDLEdBQUd1QixTQUFTO01BQ3hDLENBQUMsTUFBTTtRQUNMLElBQUksQ0FBQ0osZUFBZSxHQUFHSSxTQUFTO01BQ2xDO0lBQ0Y7RUFBQztJQUFBbkcsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQW9HLG9CQUFBLEdBQUE5RSxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBRUQsU0FBQTZFLFNBQTBCbkQsSUFBYTtRQUFBLElBQUFzQyxPQUFBLEVBQUFjLFdBQUEsRUFBQUMsV0FBQSxFQUFBQyxRQUFBO1FBQUEsT0FBQWpGLG1CQUFBLENBQUFTLElBQUEsVUFBQXlFLFVBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBdkUsSUFBQSxHQUFBdUUsVUFBQSxDQUFBdEUsSUFBQTtZQUFBO2NBQUFzRSxVQUFBLENBQUF0RSxJQUFBO2NBQUEsT0FDZixJQUFJLENBQUMyRCxXQUFXLENBQUM3QyxJQUFJLENBQUM7WUFBQTtjQUF0Q3NDLE9BQU8sR0FBQWtCLFVBQUEsQ0FBQWxFLElBQUE7Y0FBQSxJQUNSZ0QsT0FBTztnQkFBQWtCLFVBQUEsQ0FBQXRFLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE9BQUFzRSxVQUFBLENBQUExRCxNQUFBLFdBQ0gsSUFBSTtZQUFBO2NBRUxzRCxXQUFXLEdBQTRCZCxPQUFPLENBQTlDYyxXQUFXLEVBQUVDLFdBQVcsR0FBZWYsT0FBTyxDQUFqQ2UsV0FBVyxFQUFFQyxRQUFRLEdBQUtoQixPQUFPLENBQXBCZ0IsUUFBUTtjQUFBLE9BQUFFLFVBQUEsQ0FBQTFELE1BQUEsV0FDbkM7Z0JBQUVzRCxXQUFXLEVBQVhBLFdBQVc7Z0JBQUVDLFdBQVcsRUFBWEEsV0FBVztnQkFBRUMsUUFBUSxFQUFSQTtjQUFTLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQUUsVUFBQSxDQUFBdkQsSUFBQTtVQUFBO1FBQUEsR0FBQWtELFFBQUE7TUFBQSxDQUM5QztNQUFBLFNBUEtuQixtQkFBbUJBLENBQUF5QixHQUFBO1FBQUEsT0FBQVAsb0JBQUEsQ0FBQTlDLEtBQUEsT0FBQTlDLFNBQUE7TUFBQTtNQUFBLE9BQW5CMEUsbUJBQW1CO0lBQUE7RUFBQTtJQUFBbkYsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQTRHLHFCQUFBLEdBQUF0RixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBU3pCLFNBQUFxRixTQUEyQkMsS0FBYSxFQUFFQyxXQUE2QjtRQUFBLE9BQUF4RixtQkFBQSxDQUFBUyxJQUFBLFVBQUFnRixVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTlFLElBQUEsR0FBQThFLFVBQUEsQ0FBQTdFLElBQUE7WUFBQTtZQUFBO2NBQUEsT0FBQTZFLFVBQUEsQ0FBQTlELElBQUE7VUFBQTtRQUFBLEdBQUEwRCxRQUFBO01BQUEsQ0FFdEU7TUFBQSxTQUZLSyxvQkFBb0JBLENBQUFDLEdBQUEsRUFBQUMsR0FBQTtRQUFBLE9BQUFSLHFCQUFBLENBQUF0RCxLQUFBLE9BQUE5QyxTQUFBO01BQUE7TUFBQSxPQUFwQjBHLG9CQUFvQjtJQUFBO0VBQUE7SUFBQW5ILEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFxSCxxQkFBQSxHQUFBL0YsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUkxQixTQUFBOEYsU0FBMkJSLEtBQWE7UUFBQSxPQUFBdkYsbUJBQUEsQ0FBQVMsSUFBQSxVQUFBdUYsVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUFyRixJQUFBLEdBQUFxRixVQUFBLENBQUFwRixJQUFBO1lBQUE7WUFBQTtjQUFBLE9BQUFvRixVQUFBLENBQUFyRSxJQUFBO1VBQUE7UUFBQSxHQUFBbUUsUUFBQTtNQUFBLENBRXZDO01BQUEsU0FGS0csb0JBQW9CQSxDQUFBQyxHQUFBO1FBQUEsT0FBQUwscUJBQUEsQ0FBQS9ELEtBQUEsT0FBQTlDLFNBQUE7TUFBQTtNQUFBLE9BQXBCaUgsb0JBQW9CO0lBQUE7RUFBQTtJQUFBMUgsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQTJILHVCQUFBLEdBQUFyRyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBSTFCLFNBQUFvRyxTQUE2QjFFLElBQVk7UUFBQSxPQUFBM0IsbUJBQUEsQ0FBQVMsSUFBQSxVQUFBNkYsVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUEzRixJQUFBLEdBQUEyRixVQUFBLENBQUExRixJQUFBO1lBQUE7Y0FBQTBGLFVBQUEsQ0FBQTFGLElBQUE7Y0FBQSxPQUNqQyxJQUFJLENBQUNnQixZQUFZLENBQUMsa0JBQWtCLEVBQUU7Z0JBQUV1QyxDQUFDLEVBQUV6QztjQUFLLENBQUMsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBNEUsVUFBQSxDQUFBM0UsSUFBQTtVQUFBO1FBQUEsR0FBQXlFLFFBQUE7TUFBQSxDQUN6RDtNQUFBLFNBRktHLHNCQUFzQkEsQ0FBQUMsR0FBQTtRQUFBLE9BQUFMLHVCQUFBLENBQUFyRSxLQUFBLE9BQUE5QyxTQUFBO01BQUE7TUFBQSxPQUF0QnVILHNCQUFzQjtJQUFBLElBRzVCO0VBQUE7SUFBQWhJLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFpSSxnQkFBQSxHQUFBM0csaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUNBLFNBQUEwRyxVQUFzQnBCLEtBQWE7UUFBQSxPQUFBdkYsbUJBQUEsQ0FBQVMsSUFBQSxVQUFBbUcsV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUFqRyxJQUFBLEdBQUFpRyxVQUFBLENBQUFoRyxJQUFBO1lBQUE7Y0FBQSxPQUFBZ0csVUFBQSxDQUFBcEYsTUFBQSxXQUMxQixJQUFJO1lBQUE7WUFBQTtjQUFBLE9BQUFvRixVQUFBLENBQUFqRixJQUFBO1VBQUE7UUFBQSxHQUFBK0UsU0FBQTtNQUFBLENBQ1o7TUFBQSxTQUZLRyxlQUFlQSxDQUFBQyxHQUFBO1FBQUEsT0FBQUwsZ0JBQUEsQ0FBQTNFLEtBQUEsT0FBQTlDLFNBQUE7TUFBQTtNQUFBLE9BQWY2SCxlQUFlO0lBQUEsSUFJckI7RUFBQTtJQUFBdEksR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQXVJLGVBQUEsR0FBQWpILGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FDQSxTQUFBZ0gsVUFBQTtRQUFBLE9BQUFqSCxtQkFBQSxDQUFBUyxJQUFBLFVBQUF5RyxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXZHLElBQUEsR0FBQXVHLFVBQUEsQ0FBQXRHLElBQUE7WUFBQTtjQUFBLE9BQUFzRyxVQUFBLENBQUExRixNQUFBLFdBQ1MsRUFBRTtZQUFBO1lBQUE7Y0FBQSxPQUFBMEYsVUFBQSxDQUFBdkYsSUFBQTtVQUFBO1FBQUEsR0FBQXFGLFNBQUE7TUFBQSxDQUNWO01BQUEsU0FGS0csY0FBY0EsQ0FBQTtRQUFBLE9BQUFKLGVBQUEsQ0FBQWpGLEtBQUEsT0FBQTlDLFNBQUE7TUFBQTtNQUFBLE9BQWRtSSxjQUFjO0lBQUE7RUFBQTtJQUFBNUksR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQTRJLHFCQUFBLEdBQUF0SCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBSXBCLFNBQUFxSCxVQUEyQi9CLEtBQWEsRUFBRWdDLGFBQTJCO1FBQUEsT0FBQXZILG1CQUFBLENBQUFTLElBQUEsVUFBQStHLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBN0csSUFBQSxHQUFBNkcsVUFBQSxDQUFBNUcsSUFBQTtZQUFBO1lBQUE7Y0FBQSxPQUFBNEcsVUFBQSxDQUFBN0YsSUFBQTtVQUFBO1FBQUEsR0FBQTBGLFNBQUE7TUFBQSxDQUVwRTtNQUFBLFNBRktJLG9CQUFvQkEsQ0FBQUMsSUFBQSxFQUFBQyxJQUFBO1FBQUEsT0FBQVAscUJBQUEsQ0FBQXRGLEtBQUEsT0FBQTlDLFNBQUE7TUFBQTtNQUFBLE9BQXBCeUksb0JBQW9CO0lBQUE7RUFBQTtBQUFBIiwiaWdub3JlTGlzdCI6W119