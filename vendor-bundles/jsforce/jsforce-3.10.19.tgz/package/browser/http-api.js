import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _wrapNativeSuper from "@babel/runtime-corejs3/helpers/wrapNativeSuper";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
import _Number$isFinite from "@babel/runtime-corejs3/core-js-stable/number/is-finite";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _Object$keys2 from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _includesInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/includes";
import _globalThis from "@babel/runtime-corejs3/core-js/global-this";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.join.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.number.constructor.js";
import "core-js/modules/es.object.keys.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/web.self.js";
/**
 *
 */
import { EventEmitter } from 'events';
import xml2js from 'xml2js';
import { getLogger } from './util/logger';
import { StreamPromise } from './util/promise';
import { parseCSV } from './csv';
import { createLazyStream } from './util/stream';
import { getBodySize } from './util/get-body-size';

/** @private */
function parseJSON(str) {
  return JSON.parse(str);
}

/** @private */
function parseXML(_x) {
  return _parseXML.apply(this, arguments);
}
/** @private */
function _parseXML() {
  _parseXML = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee5(str) {
    return _regeneratorRuntime.wrap(function _callee5$(_context12) {
      while (1) switch (_context12.prev = _context12.next) {
        case 0:
          return _context12.abrupt("return", xml2js.parseStringPromise(str, {
            explicitArray: false
          }));
        case 1:
        case "end":
          return _context12.stop();
      }
    }, _callee5);
  }));
  return _parseXML.apply(this, arguments);
}
function parseText(str) {
  return str;
}

/**
 * Maximum number of times a single request will be retried after a session-expired
 * response, even when the refresh delegate reports success. Without this cap, a
 * refresh that keeps returning a token the server still rejects (e.g. a persistently
 * broken connected app) would recurse via `HttpApi#request` forever.
 *
 * A connection may override this with `_maxSessionRefreshRetries` (jsforce 1/2
 * leftover that 3.x previously ignored). `0` means fail on the first expired
 * response without calling the refresh delegate.
 * @private
 */
var MAX_SESSION_REFRESH_RETRIES = 3;
function resolveMaxSessionRefreshRetries(conn) {
  var configured = Number(conn === null || conn === void 0 ? void 0 : conn._maxSessionRefreshRetries);
  return _Number$isFinite(configured) ? configured : MAX_SESSION_REFRESH_RETRIES;
}

/**
 * HTTP based API class with authorization hook
 */
export var HttpApi = /*#__PURE__*/function (_EventEmitter) {
  function HttpApi(conn, options) {
    var _this;
    _classCallCheck(this, HttpApi);
    _this = _callSuper(this, HttpApi);
    _this._conn = conn;
    _this._logger = conn._logLevel ? HttpApi._logger.createInstance(conn._logLevel) : HttpApi._logger;
    _this._responseType = options.responseType;
    _this._transport = options.transport || conn._transport;
    _this._noContentResponse = options.noContentResponse;
    _this._options = options;
    return _this;
  }

  /**
   * Callout to API endpoint using http
   */
  _inherits(HttpApi, _EventEmitter);
  return _createClass(HttpApi, [{
    key: "request",
    value: function request(_request) {
      var _this2 = this;
      var sessionRefreshCount = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      return StreamPromise.create(function () {
        var _createLazyStream = createLazyStream(),
          stream = _createLazyStream.stream,
          setStream = _createLazyStream.setStream;
        var promise = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
          var _context, _context2;
          var refreshDelegate, bodyPromise, _body2, requestTime, requestPromise, response, responseTime, maxRetries, err, _err, body;
          return _regeneratorRuntime.wrap(function _callee$(_context3) {
            while (1) switch (_context3.prev = _context3.next) {
              case 0:
                refreshDelegate = _this2.getRefreshDelegate();
                /* TODO decide remove or not this section */
                /*
                // remember previous instance url in case it changes after a refresh
                const lastInstanceUrl = conn.instanceUrl;
                 // check to see if the token refresh has changed the instance url
                if(lastInstanceUrl !== conn.instanceUrl){
                  // if the instance url has changed
                  // then replace the current request urls instance url fragment
                  // with the updated instance url
                  request.url = request.url.replace(lastInstanceUrl,conn.instanceUrl);
                }
                */
                if (!(refreshDelegate && refreshDelegate.isRefreshing())) {
                  _context3.next = 10;
                  break;
                }
                _context3.next = 4;
                return refreshDelegate.waitRefresh();
              case 4:
                bodyPromise = _this2.request(_request, sessionRefreshCount);
                setStream(bodyPromise.stream());
                _context3.next = 8;
                return bodyPromise;
              case 8:
                _body2 = _context3.sent;
                return _context3.abrupt("return", _body2);
              case 10:
                // hook before sending
                _this2.beforeSend(_request);
                _this2.emit('request', _request);
                _this2._logger.debug(_concatInstanceProperty(_context = "<request> method=".concat(_request.method, ", url=")).call(_context, _request.url));
                requestTime = _Date$now();
                requestPromise = _this2._transport.httpRequest(_request, _this2._options);
                setStream(requestPromise.stream());
                _context3.prev = 16;
                _context3.next = 19;
                return requestPromise;
              case 19:
                response = _context3.sent;
                _context3.next = 26;
                break;
              case 22:
                _context3.prev = 22;
                _context3.t0 = _context3["catch"](16);
                _this2._logger.error(_context3.t0);
                throw _context3.t0;
              case 26:
                _context3.prev = 26;
                responseTime = _Date$now();
                _this2._logger.debug("elapsed time: ".concat(responseTime - requestTime, " msec"));
                return _context3.finish(26);
              case 30:
                if (response) {
                  _context3.next = 32;
                  break;
                }
                return _context3.abrupt("return");
              case 32:
                _this2._logger.debug(_concatInstanceProperty(_context2 = "<response> status=".concat(String(response.statusCode), ", url=")).call(_context2, _request.url));
                _this2.emit('response', response);
                // Refresh token if session has been expired and requires authentication
                // when session refresh delegate is available
                if (!(_this2.isSessionExpired(response) && refreshDelegate)) {
                  _context3.next = 46;
                  break;
                }
                maxRetries = resolveMaxSessionRefreshRetries(_this2._conn);
                if (!(sessionRefreshCount >= maxRetries)) {
                  _context3.next = 42;
                  break;
                }
                _this2._logger.error("Session still expired after ".concat(sessionRefreshCount, " refresh attempts, giving up."));
                _context3.next = 40;
                return _this2.getError(response);
              case 40:
                err = _context3.sent;
                throw err;
              case 42:
                _context3.next = 44;
                return refreshDelegate.refresh(requestTime);
              case 44:
                /* remove the `content-length` header after token refresh
                 *
                 * SOAP requests include the access token their the body,
                 * if the first req had an invalid token and jsforce successfully
                 * refreshed it we need to remove the `content-length` header
                 * so that it get's re-calculated again with the new body.
                 *
                 * REST request aren't affected by this because the access token
                 * is sent via HTTP headers
                 *
                 * `_message` is only present in SOAP requests
                 */
                if ('_message' in _request && _request.headers && 'content-length' in _request.headers) {
                  delete _request.headers['content-length'];
                }
                return _context3.abrupt("return", _this2.request(_request, sessionRefreshCount + 1));
              case 46:
                if (!_this2.isErrorResponse(response)) {
                  _context3.next = 51;
                  break;
                }
                _context3.next = 49;
                return _this2.getError(response);
              case 49:
                _err = _context3.sent;
                throw _err;
              case 51:
                _context3.next = 53;
                return _this2.getResponseBody(response);
              case 53:
                body = _context3.sent;
                return _context3.abrupt("return", body);
              case 55:
              case "end":
                return _context3.stop();
            }
          }, _callee, null, [[16, 22, 26, 30]]);
        }))();
        return {
          stream: stream,
          promise: promise
        };
      });
    }

    /**
     * @protected
     */
  }, {
    key: "getRefreshDelegate",
    value: function getRefreshDelegate() {
      return this._conn._refreshDelegate;
    }

    /**
     * @protected
     */
  }, {
    key: "beforeSend",
    value: function beforeSend(request) {
      var _context5;
      /* eslint-disable no-param-reassign */
      var headers = request.headers || {};
      if (this._conn.accessToken) {
        headers.Authorization = "Bearer ".concat(this._conn.accessToken);
      }
      if (this._conn._callOptions) {
        var callOptions = [];
        for (var _i = 0, _Object$keys = _Object$keys2(this._conn._callOptions); _i < _Object$keys.length; _i++) {
          var _context4;
          var name = _Object$keys[_i];
          callOptions.push(_concatInstanceProperty(_context4 = "".concat(name, "=")).call(_context4, this._conn._callOptions[name]));
        }
        headers['Sforce-Call-Options'] = callOptions.join(', ');
      }
      var bodySize = getBodySize(request.body, headers);
      var cannotHaveBody = _includesInstanceProperty(_context5 = ['GET', 'HEAD', 'OPTIONS']).call(_context5, request.method);

      // Don't set content-length in browsers as it's not allowed
      var isBrowser = 'window' in _globalThis || 'self' in _globalThis;
      if (!isBrowser &&
      // Don't set content-length in browsers as it's not allowed
      !cannotHaveBody && !!request.body && !('transfer-encoding' in headers) && !('content-length' in headers) && !!bodySize) {
        this._logger.debug("missing 'content-length' header, setting it to: ".concat(bodySize));
        headers['content-length'] = String(bodySize);
      }
      request.headers = headers;
    }

    /**
     * Detect response content mime-type
     * @protected
     */
  }, {
    key: "getResponseContentType",
    value: function getResponseContentType(response) {
      return this._responseType || response.headers && response.headers['content-type'];
    }

    /**
     * @private
     */
    // eslint-disable-next-line @typescript-eslint/require-await
  }, {
    key: "parseResponseBody",
    value: (function () {
      var _parseResponseBody = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(response) {
        var contentType, parseBody, _context6;
        return _regeneratorRuntime.wrap(function _callee2$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              contentType = this.getResponseContentType(response) || '';
              parseBody = /^(text|application)\/xml(;|$)/.test(contentType) ? parseXML : /^application\/json(;|$)/.test(contentType) ? parseJSON : /^text\/csv(;|$)/.test(contentType) ? parseCSV : parseText;
              _context7.prev = 2;
              return _context7.abrupt("return", parseBody(response.body));
            case 6:
              _context7.prev = 6;
              _context7.t0 = _context7["catch"](2);
              // TODO(next major): we could throw a new "invalid response body" error instead.
              this._logger.debug(_concatInstanceProperty(_context6 = "Failed to parse body of content-type: ".concat(contentType, ". Error: ")).call(_context6, _context7.t0.message));
              return _context7.abrupt("return", response.body);
            case 10:
            case "end":
              return _context7.stop();
          }
        }, _callee2, this, [[2, 6]]);
      }));
      function parseResponseBody(_x2) {
        return _parseResponseBody.apply(this, arguments);
      }
      return parseResponseBody;
    }()
    /**
     * Get response body
     * @protected
     */
    )
  }, {
    key: "getResponseBody",
    value: (function () {
      var _getResponseBody = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3(response) {
        var body, err;
        return _regeneratorRuntime.wrap(function _callee3$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              if (!(response.statusCode === 204)) {
                _context8.next = 2;
                break;
              }
              return _context8.abrupt("return", this._noContentResponse);
            case 2:
              _context8.next = 4;
              return this.parseResponseBody(response);
            case 4:
              body = _context8.sent;
              if (!this.hasErrorInResponseBody(body)) {
                _context8.next = 10;
                break;
              }
              _context8.next = 8;
              return this.getError(response, body);
            case 8:
              err = _context8.sent;
              throw err;
            case 10:
              if (!(response.statusCode === 300)) {
                _context8.next = 12;
                break;
              }
              throw new HttpApiError('Multiple records found', 'MULTIPLE_CHOICES', body);
            case 12:
              return _context8.abrupt("return", body);
            case 13:
            case "end":
              return _context8.stop();
          }
        }, _callee3, this);
      }));
      function getResponseBody(_x3) {
        return _getResponseBody.apply(this, arguments);
      }
      return getResponseBody;
    }()
    /**
     * Detect session expiry
     * @protected
     */
    )
  }, {
    key: "isSessionExpired",
    value: function isSessionExpired(response) {
      // REST API status codes: https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/errorcodes.htm
      //
      // "401 - The session ID or OAuth token used has expired or is invalid. The response body contains the message and errorCode."
      if (response.statusCode === 401) {
        // Known list of 401 responses that shouldn't be considered as "session expired".
        //
        // These usualy come from an CA/ECA, OAuth, IP restriction change in the org that block connections, we need to skip these
        // org jsforce will enter into an infinite loop trying to get a valid token.
        var responsesToSkip = ['Connected app is not attached to Agent', 'This session is not valid for use with the REST API', 'BlackTab users cannot perform API operations'];
        for (var _i2 = 0, _responsesToSkip = responsesToSkip; _i2 < _responsesToSkip.length; _i2++) {
          var _context9;
          var p = _responsesToSkip[_i2];
          if (_includesInstanceProperty(_context9 = response.body).call(_context9, p)) return false;
        }
        return true;
      }
      return false;
    }

    /**
     * Detect error response
     * @protected
     */
  }, {
    key: "isErrorResponse",
    value: function isErrorResponse(response) {
      return response.statusCode >= 400;
    }

    /**
     * Detect error in response body
     * @protected
     */
  }, {
    key: "hasErrorInResponseBody",
    value: function hasErrorInResponseBody(_body) {
      return false;
    }

    /**
     * Parsing error message in response
     * @protected
     */
  }, {
    key: "parseError",
    value: function parseError(body) {
      var errors = body;

      // XML response
      if (errors.Errors) {
        return errors.Errors.Error;
      }
      return errors;
    }

    /**
     * Get error message in response
     * @protected
     */
  }, {
    key: "getError",
    value: (function () {
      var _getError = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4(response, body) {
        var _context10;
        var error;
        return _regeneratorRuntime.wrap(function _callee4$(_context11) {
          while (1) switch (_context11.prev = _context11.next) {
            case 0:
              _context11.prev = 0;
              _context11.t0 = this;
              _context11.t1 = body;
              if (_context11.t1) {
                _context11.next = 7;
                break;
              }
              _context11.next = 6;
              return this.parseResponseBody(response);
            case 6:
              _context11.t1 = _context11.sent;
            case 7:
              _context11.t2 = _context11.t1;
              error = _context11.t0.parseError.call(_context11.t0, _context11.t2);
              _context11.next = 13;
              break;
            case 11:
              _context11.prev = 11;
              _context11.t3 = _context11["catch"](0);
            case 13:
              if (!_Array$isArray(error)) {
                _context11.next = 19;
                break;
              }
              if (!(error.length === 1)) {
                _context11.next = 18;
                break;
              }
              error = error[0];
              _context11.next = 19;
              break;
            case 18:
              return _context11.abrupt("return", new HttpApiError("Multiple errors returned.\n  Check `error.data` for the error details", 'MULTIPLE_API_ERRORS', error));
            case 19:
              error = _typeof(error) === 'object' && error !== null && typeof error.message === 'string' ? error : {
                errorCode: "ERROR_HTTP_".concat(response.statusCode),
                message: response.body
              };
              if (!(response.headers['content-type'] != null && _includesInstanceProperty(_context10 = response.headers['content-type']).call(_context10, 'text/html'))) {
                _context11.next = 23;
                break;
              }
              this._logger.debug("html response.body: ".concat(response.body));
              return _context11.abrupt("return", new HttpApiError("HTTP response contains html content.\nCheck that the org exists and can be reached.\n\nHTTP status code: ".concat(response.statusCode, ".\nREST API Status Codes and Error Responses:\nhttps://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/errorcodes.htm\n\nSee `error.data` for the full html response."), error.errorCode, error.message));
            case 23:
              return _context11.abrupt("return", error instanceof HttpApiError ? error : new HttpApiError(error.message, error.errorCode, error));
            case 24:
            case "end":
              return _context11.stop();
          }
        }, _callee4, this, [[0, 11]]);
      }));
      function getError(_x4, _x5) {
        return _getError.apply(this, arguments);
      }
      return getError;
    }())
  }]);
}(EventEmitter);

/**
 *
 */
_defineProperty(HttpApi, "_logger", getLogger('http-api'));
var HttpApiError = /*#__PURE__*/function (_Error) {
  /**
   * This contains error-specific details, usually returned from the API.
   */

  function HttpApiError(message, errorCode, data) {
    var _this3;
    _classCallCheck(this, HttpApiError);
    _this3 = _callSuper(this, HttpApiError, [message]);
    _this3.name = errorCode || _this3.name;
    _this3.errorCode = _this3.name;
    _this3.data = data;
    return _this3;
  }

  /**
   * This will be removed in the next major (v4)
   *
   * @deprecated use `error.data` instead
   */
  _inherits(HttpApiError, _Error);
  return _createClass(HttpApiError, [{
    key: "content",
    get: function get() {
      return this.data;
    }
  }]);
}(/*#__PURE__*/_wrapNativeSuper(Error));
export default HttpApi;
export var isBrowser = 'window' in _globalThis || 'self' in _globalThis;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJ4bWwyanMiLCJnZXRMb2dnZXIiLCJTdHJlYW1Qcm9taXNlIiwicGFyc2VDU1YiLCJjcmVhdGVMYXp5U3RyZWFtIiwiZ2V0Qm9keVNpemUiLCJwYXJzZUpTT04iLCJzdHIiLCJKU09OIiwicGFyc2UiLCJwYXJzZVhNTCIsIl94IiwiX3BhcnNlWE1MIiwiYXBwbHkiLCJhcmd1bWVudHMiLCJfYXN5bmNUb0dlbmVyYXRvciIsIl9yZWdlbmVyYXRvclJ1bnRpbWUiLCJtYXJrIiwiX2NhbGxlZTUiLCJ3cmFwIiwiX2NhbGxlZTUkIiwiX2NvbnRleHQxMiIsInByZXYiLCJuZXh0IiwiYWJydXB0IiwicGFyc2VTdHJpbmdQcm9taXNlIiwiZXhwbGljaXRBcnJheSIsInN0b3AiLCJwYXJzZVRleHQiLCJNQVhfU0VTU0lPTl9SRUZSRVNIX1JFVFJJRVMiLCJyZXNvbHZlTWF4U2Vzc2lvblJlZnJlc2hSZXRyaWVzIiwiY29ubiIsImNvbmZpZ3VyZWQiLCJOdW1iZXIiLCJfbWF4U2Vzc2lvblJlZnJlc2hSZXRyaWVzIiwiX051bWJlciRpc0Zpbml0ZSIsIkh0dHBBcGkiLCJfRXZlbnRFbWl0dGVyIiwib3B0aW9ucyIsIl90aGlzIiwiX2NsYXNzQ2FsbENoZWNrIiwiX2NhbGxTdXBlciIsIl9jb25uIiwiX2xvZ2dlciIsIl9sb2dMZXZlbCIsImNyZWF0ZUluc3RhbmNlIiwiX3Jlc3BvbnNlVHlwZSIsInJlc3BvbnNlVHlwZSIsIl90cmFuc3BvcnQiLCJ0cmFuc3BvcnQiLCJfbm9Db250ZW50UmVzcG9uc2UiLCJub0NvbnRlbnRSZXNwb25zZSIsIl9vcHRpb25zIiwiX2luaGVyaXRzIiwiX2NyZWF0ZUNsYXNzIiwia2V5IiwidmFsdWUiLCJyZXF1ZXN0IiwiX3RoaXMyIiwic2Vzc2lvblJlZnJlc2hDb3VudCIsImxlbmd0aCIsInVuZGVmaW5lZCIsImNyZWF0ZSIsIl9jcmVhdGVMYXp5U3RyZWFtIiwic3RyZWFtIiwic2V0U3RyZWFtIiwicHJvbWlzZSIsIl9jYWxsZWUiLCJfY29udGV4dCIsIl9jb250ZXh0MiIsInJlZnJlc2hEZWxlZ2F0ZSIsImJvZHlQcm9taXNlIiwiX2JvZHkyIiwicmVxdWVzdFRpbWUiLCJyZXF1ZXN0UHJvbWlzZSIsInJlc3BvbnNlIiwicmVzcG9uc2VUaW1lIiwibWF4UmV0cmllcyIsImVyciIsIl9lcnIiLCJib2R5IiwiX2NhbGxlZSQiLCJfY29udGV4dDMiLCJnZXRSZWZyZXNoRGVsZWdhdGUiLCJpc1JlZnJlc2hpbmciLCJ3YWl0UmVmcmVzaCIsInNlbnQiLCJiZWZvcmVTZW5kIiwiZW1pdCIsImRlYnVnIiwiX2NvbmNhdEluc3RhbmNlUHJvcGVydHkiLCJjb25jYXQiLCJtZXRob2QiLCJjYWxsIiwidXJsIiwiX0RhdGUkbm93IiwiaHR0cFJlcXVlc3QiLCJ0MCIsImVycm9yIiwiZmluaXNoIiwiU3RyaW5nIiwic3RhdHVzQ29kZSIsImlzU2Vzc2lvbkV4cGlyZWQiLCJnZXRFcnJvciIsInJlZnJlc2giLCJoZWFkZXJzIiwiaXNFcnJvclJlc3BvbnNlIiwiZ2V0UmVzcG9uc2VCb2R5IiwiX3JlZnJlc2hEZWxlZ2F0ZSIsIl9jb250ZXh0NSIsImFjY2Vzc1Rva2VuIiwiQXV0aG9yaXphdGlvbiIsIl9jYWxsT3B0aW9ucyIsImNhbGxPcHRpb25zIiwiX2kiLCJfT2JqZWN0JGtleXMiLCJfT2JqZWN0JGtleXMyIiwiX2NvbnRleHQ0IiwibmFtZSIsInB1c2giLCJqb2luIiwiYm9keVNpemUiLCJjYW5ub3RIYXZlQm9keSIsIl9pbmNsdWRlc0luc3RhbmNlUHJvcGVydHkiLCJpc0Jyb3dzZXIiLCJfZ2xvYmFsVGhpcyIsImdldFJlc3BvbnNlQ29udGVudFR5cGUiLCJfcGFyc2VSZXNwb25zZUJvZHkiLCJfY2FsbGVlMiIsImNvbnRlbnRUeXBlIiwicGFyc2VCb2R5IiwiX2NvbnRleHQ2IiwiX2NhbGxlZTIkIiwiX2NvbnRleHQ3IiwidGVzdCIsIm1lc3NhZ2UiLCJwYXJzZVJlc3BvbnNlQm9keSIsIl94MiIsIl9nZXRSZXNwb25zZUJvZHkiLCJfY2FsbGVlMyIsIl9jYWxsZWUzJCIsIl9jb250ZXh0OCIsImhhc0Vycm9ySW5SZXNwb25zZUJvZHkiLCJIdHRwQXBpRXJyb3IiLCJfeDMiLCJyZXNwb25zZXNUb1NraXAiLCJfaTIiLCJfcmVzcG9uc2VzVG9Ta2lwIiwiX2NvbnRleHQ5IiwicCIsIl9ib2R5IiwicGFyc2VFcnJvciIsImVycm9ycyIsIkVycm9ycyIsIkVycm9yIiwiX2dldEVycm9yIiwiX2NhbGxlZTQiLCJfY29udGV4dDEwIiwiX2NhbGxlZTQkIiwiX2NvbnRleHQxMSIsInQxIiwidDIiLCJ0MyIsIl9BcnJheSRpc0FycmF5IiwiX3R5cGVvZiIsImVycm9yQ29kZSIsIl94NCIsIl94NSIsIl9kZWZpbmVQcm9wZXJ0eSIsIl9FcnJvciIsImRhdGEiLCJfdGhpczMiLCJnZXQiLCJfd3JhcE5hdGl2ZVN1cGVyIl0sInNvdXJjZXMiOlsiLi4vc3JjL2h0dHAtYXBpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICpcbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJztcbmltcG9ydCB4bWwyanMgZnJvbSAneG1sMmpzJztcbmltcG9ydCB7IExvZ2dlciwgZ2V0TG9nZ2VyIH0gZnJvbSAnLi91dGlsL2xvZ2dlcic7XG5pbXBvcnQgeyBTdHJlYW1Qcm9taXNlIH0gZnJvbSAnLi91dGlsL3Byb21pc2UnO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi9jb25uZWN0aW9uJztcbmltcG9ydCBUcmFuc3BvcnQgZnJvbSAnLi90cmFuc3BvcnQnO1xuaW1wb3J0IHsgcGFyc2VDU1YgfSBmcm9tICcuL2Nzdic7XG5pbXBvcnQge1xuICBIdHRwUmVxdWVzdCxcbiAgSHR0cFJlcXVlc3RPcHRpb25zLFxuICBIdHRwUmVzcG9uc2UsXG4gIE9wdGlvbmFsLFxuICBTY2hlbWEsXG59IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgY3JlYXRlTGF6eVN0cmVhbSB9IGZyb20gJy4vdXRpbC9zdHJlYW0nO1xuaW1wb3J0IHsgZ2V0Qm9keVNpemUgfSBmcm9tICcuL3V0aWwvZ2V0LWJvZHktc2l6ZSc7XG5cbi8qKiBAcHJpdmF0ZSAqL1xuZnVuY3Rpb24gcGFyc2VKU09OKHN0cjogc3RyaW5nKSB7XG4gIHJldHVybiBKU09OLnBhcnNlKHN0cik7XG59XG5cbi8qKiBAcHJpdmF0ZSAqL1xuYXN5bmMgZnVuY3Rpb24gcGFyc2VYTUwoc3RyOiBzdHJpbmcpIHtcbiAgcmV0dXJuIHhtbDJqcy5wYXJzZVN0cmluZ1Byb21pc2Uoc3RyLCB7IGV4cGxpY2l0QXJyYXk6IGZhbHNlIH0pO1xufVxuXG4vKiogQHByaXZhdGUgKi9cbmZ1bmN0aW9uIHBhcnNlVGV4dChzdHI6IHN0cmluZykge1xuICByZXR1cm4gc3RyO1xufVxuXG4vKipcbiAqIE1heGltdW0gbnVtYmVyIG9mIHRpbWVzIGEgc2luZ2xlIHJlcXVlc3Qgd2lsbCBiZSByZXRyaWVkIGFmdGVyIGEgc2Vzc2lvbi1leHBpcmVkXG4gKiByZXNwb25zZSwgZXZlbiB3aGVuIHRoZSByZWZyZXNoIGRlbGVnYXRlIHJlcG9ydHMgc3VjY2Vzcy4gV2l0aG91dCB0aGlzIGNhcCwgYVxuICogcmVmcmVzaCB0aGF0IGtlZXBzIHJldHVybmluZyBhIHRva2VuIHRoZSBzZXJ2ZXIgc3RpbGwgcmVqZWN0cyAoZS5nLiBhIHBlcnNpc3RlbnRseVxuICogYnJva2VuIGNvbm5lY3RlZCBhcHApIHdvdWxkIHJlY3Vyc2UgdmlhIGBIdHRwQXBpI3JlcXVlc3RgIGZvcmV2ZXIuXG4gKlxuICogQSBjb25uZWN0aW9uIG1heSBvdmVycmlkZSB0aGlzIHdpdGggYF9tYXhTZXNzaW9uUmVmcmVzaFJldHJpZXNgIChqc2ZvcmNlIDEvMlxuICogbGVmdG92ZXIgdGhhdCAzLnggcHJldmlvdXNseSBpZ25vcmVkKS4gYDBgIG1lYW5zIGZhaWwgb24gdGhlIGZpcnN0IGV4cGlyZWRcbiAqIHJlc3BvbnNlIHdpdGhvdXQgY2FsbGluZyB0aGUgcmVmcmVzaCBkZWxlZ2F0ZS5cbiAqIEBwcml2YXRlXG4gKi9cbmNvbnN0IE1BWF9TRVNTSU9OX1JFRlJFU0hfUkVUUklFUyA9IDM7XG5cbmZ1bmN0aW9uIHJlc29sdmVNYXhTZXNzaW9uUmVmcmVzaFJldHJpZXMoY29ubjoge1xuICBfbWF4U2Vzc2lvblJlZnJlc2hSZXRyaWVzPzogdW5rbm93bjtcbn0pOiBudW1iZXIge1xuICBjb25zdCBjb25maWd1cmVkID0gTnVtYmVyKGNvbm4/Ll9tYXhTZXNzaW9uUmVmcmVzaFJldHJpZXMpO1xuICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKGNvbmZpZ3VyZWQpXG4gICAgPyBjb25maWd1cmVkXG4gICAgOiBNQVhfU0VTU0lPTl9SRUZSRVNIX1JFVFJJRVM7XG59XG5cbi8qKlxuICogSFRUUCBiYXNlZCBBUEkgY2xhc3Mgd2l0aCBhdXRob3JpemF0aW9uIGhvb2tcbiAqL1xuZXhwb3J0IGNsYXNzIEh0dHBBcGk8UyBleHRlbmRzIFNjaGVtYT4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBzdGF0aWMgX2xvZ2dlciA9IGdldExvZ2dlcignaHR0cC1hcGknKTtcblxuICBfY29ubjogQ29ubmVjdGlvbjxTPjtcbiAgX2xvZ2dlcjogTG9nZ2VyO1xuICBfdHJhbnNwb3J0OiBUcmFuc3BvcnQ7XG4gIF9yZXNwb25zZVR5cGU6IHN0cmluZyB8IHZvaWQ7XG4gIF9ub0NvbnRlbnRSZXNwb25zZTogc3RyaW5nIHwgdm9pZDtcbiAgX29wdGlvbnM6IEh0dHBSZXF1ZXN0T3B0aW9ucztcblxuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+LCBvcHRpb25zOiBhbnkpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICAgIHRoaXMuX2xvZ2dlciA9IGNvbm4uX2xvZ0xldmVsXG4gICAgICA/IEh0dHBBcGkuX2xvZ2dlci5jcmVhdGVJbnN0YW5jZShjb25uLl9sb2dMZXZlbClcbiAgICAgIDogSHR0cEFwaS5fbG9nZ2VyO1xuICAgIHRoaXMuX3Jlc3BvbnNlVHlwZSA9IG9wdGlvbnMucmVzcG9uc2VUeXBlO1xuICAgIHRoaXMuX3RyYW5zcG9ydCA9IG9wdGlvbnMudHJhbnNwb3J0IHx8IGNvbm4uX3RyYW5zcG9ydDtcbiAgICB0aGlzLl9ub0NvbnRlbnRSZXNwb25zZSA9IG9wdGlvbnMubm9Db250ZW50UmVzcG9uc2U7XG4gICAgdGhpcy5fb3B0aW9ucyA9IG9wdGlvbnM7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbG91dCB0byBBUEkgZW5kcG9pbnQgdXNpbmcgaHR0cFxuICAgKi9cbiAgcmVxdWVzdDxSID0gdW5rbm93bj4oXG4gICAgcmVxdWVzdDogSHR0cFJlcXVlc3QsXG4gICAgc2Vzc2lvblJlZnJlc2hDb3VudCA9IDAsXG4gICk6IFN0cmVhbVByb21pc2U8Uj4ge1xuICAgIHJldHVybiBTdHJlYW1Qcm9taXNlLmNyZWF0ZTxSPigoKSA9PiB7XG4gICAgICBjb25zdCB7IHN0cmVhbSwgc2V0U3RyZWFtIH0gPSBjcmVhdGVMYXp5U3RyZWFtKCk7XG4gICAgICBjb25zdCBwcm9taXNlID0gKGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgcmVmcmVzaERlbGVnYXRlID0gdGhpcy5nZXRSZWZyZXNoRGVsZWdhdGUoKTtcbiAgICAgICAgLyogVE9ETyBkZWNpZGUgcmVtb3ZlIG9yIG5vdCB0aGlzIHNlY3Rpb24gKi9cbiAgICAgICAgLypcbiAgICAgICAgLy8gcmVtZW1iZXIgcHJldmlvdXMgaW5zdGFuY2UgdXJsIGluIGNhc2UgaXQgY2hhbmdlcyBhZnRlciBhIHJlZnJlc2hcbiAgICAgICAgY29uc3QgbGFzdEluc3RhbmNlVXJsID0gY29ubi5pbnN0YW5jZVVybDtcblxuICAgICAgICAvLyBjaGVjayB0byBzZWUgaWYgdGhlIHRva2VuIHJlZnJlc2ggaGFzIGNoYW5nZWQgdGhlIGluc3RhbmNlIHVybFxuICAgICAgICBpZihsYXN0SW5zdGFuY2VVcmwgIT09IGNvbm4uaW5zdGFuY2VVcmwpe1xuICAgICAgICAgIC8vIGlmIHRoZSBpbnN0YW5jZSB1cmwgaGFzIGNoYW5nZWRcbiAgICAgICAgICAvLyB0aGVuIHJlcGxhY2UgdGhlIGN1cnJlbnQgcmVxdWVzdCB1cmxzIGluc3RhbmNlIHVybCBmcmFnbWVudFxuICAgICAgICAgIC8vIHdpdGggdGhlIHVwZGF0ZWQgaW5zdGFuY2UgdXJsXG4gICAgICAgICAgcmVxdWVzdC51cmwgPSByZXF1ZXN0LnVybC5yZXBsYWNlKGxhc3RJbnN0YW5jZVVybCxjb25uLmluc3RhbmNlVXJsKTtcbiAgICAgICAgfVxuICAgICAgICAqL1xuICAgICAgICBpZiAocmVmcmVzaERlbGVnYXRlICYmIHJlZnJlc2hEZWxlZ2F0ZS5pc1JlZnJlc2hpbmcoKSkge1xuICAgICAgICAgIGF3YWl0IHJlZnJlc2hEZWxlZ2F0ZS53YWl0UmVmcmVzaCgpO1xuICAgICAgICAgIGNvbnN0IGJvZHlQcm9taXNlID0gdGhpcy5yZXF1ZXN0KHJlcXVlc3QsIHNlc3Npb25SZWZyZXNoQ291bnQpO1xuICAgICAgICAgIHNldFN0cmVhbShib2R5UHJvbWlzZS5zdHJlYW0oKSk7XG4gICAgICAgICAgY29uc3QgYm9keSA9IGF3YWl0IGJvZHlQcm9taXNlO1xuICAgICAgICAgIHJldHVybiBib2R5O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gaG9vayBiZWZvcmUgc2VuZGluZ1xuICAgICAgICB0aGlzLmJlZm9yZVNlbmQocmVxdWVzdCk7XG5cbiAgICAgICAgdGhpcy5lbWl0KCdyZXF1ZXN0JywgcmVxdWVzdCk7XG4gICAgICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgICAgICBgPHJlcXVlc3Q+IG1ldGhvZD0ke3JlcXVlc3QubWV0aG9kfSwgdXJsPSR7cmVxdWVzdC51cmx9YCxcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgcmVxdWVzdFRpbWUgPSBEYXRlLm5vdygpO1xuICAgICAgICBjb25zdCByZXF1ZXN0UHJvbWlzZSA9IHRoaXMuX3RyYW5zcG9ydC5odHRwUmVxdWVzdChcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgIHRoaXMuX29wdGlvbnMsXG4gICAgICAgICk7XG5cbiAgICAgICAgc2V0U3RyZWFtKHJlcXVlc3RQcm9taXNlLnN0cmVhbSgpKTtcblxuICAgICAgICBsZXQgcmVzcG9uc2U6IEh0dHBSZXNwb25zZSB8IHZvaWQ7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzcG9uc2UgPSBhd2FpdCByZXF1ZXN0UHJvbWlzZTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgdGhpcy5fbG9nZ2VyLmVycm9yKGVycik7XG4gICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlVGltZSA9IERhdGUubm93KCk7XG4gICAgICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKFxuICAgICAgICAgICAgYGVsYXBzZWQgdGltZTogJHtyZXNwb25zZVRpbWUgLSByZXF1ZXN0VGltZX0gbXNlY2AsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXJlc3BvbnNlKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgICAgICBgPHJlc3BvbnNlPiBzdGF0dXM9JHtTdHJpbmcocmVzcG9uc2Uuc3RhdHVzQ29kZSl9LCB1cmw9JHtcbiAgICAgICAgICAgIHJlcXVlc3QudXJsXG4gICAgICAgICAgfWAsXG4gICAgICAgICk7XG4gICAgICAgIHRoaXMuZW1pdCgncmVzcG9uc2UnLCByZXNwb25zZSk7XG4gICAgICAgIC8vIFJlZnJlc2ggdG9rZW4gaWYgc2Vzc2lvbiBoYXMgYmVlbiBleHBpcmVkIGFuZCByZXF1aXJlcyBhdXRoZW50aWNhdGlvblxuICAgICAgICAvLyB3aGVuIHNlc3Npb24gcmVmcmVzaCBkZWxlZ2F0ZSBpcyBhdmFpbGFibGVcbiAgICAgICAgaWYgKHRoaXMuaXNTZXNzaW9uRXhwaXJlZChyZXNwb25zZSkgJiYgcmVmcmVzaERlbGVnYXRlKSB7XG4gICAgICAgICAgY29uc3QgbWF4UmV0cmllcyA9IHJlc29sdmVNYXhTZXNzaW9uUmVmcmVzaFJldHJpZXModGhpcy5fY29ubik7XG4gICAgICAgICAgaWYgKHNlc3Npb25SZWZyZXNoQ291bnQgPj0gbWF4UmV0cmllcykge1xuICAgICAgICAgICAgdGhpcy5fbG9nZ2VyLmVycm9yKFxuICAgICAgICAgICAgICBgU2Vzc2lvbiBzdGlsbCBleHBpcmVkIGFmdGVyICR7c2Vzc2lvblJlZnJlc2hDb3VudH0gcmVmcmVzaCBhdHRlbXB0cywgZ2l2aW5nIHVwLmAsXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY29uc3QgZXJyID0gYXdhaXQgdGhpcy5nZXRFcnJvcihyZXNwb25zZSk7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfVxuICAgICAgICAgIGF3YWl0IHJlZnJlc2hEZWxlZ2F0ZS5yZWZyZXNoKHJlcXVlc3RUaW1lKTtcbiAgICAgICAgICAvKiByZW1vdmUgdGhlIGBjb250ZW50LWxlbmd0aGAgaGVhZGVyIGFmdGVyIHRva2VuIHJlZnJlc2hcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIFNPQVAgcmVxdWVzdHMgaW5jbHVkZSB0aGUgYWNjZXNzIHRva2VuIHRoZWlyIHRoZSBib2R5LFxuICAgICAgICAgICAqIGlmIHRoZSBmaXJzdCByZXEgaGFkIGFuIGludmFsaWQgdG9rZW4gYW5kIGpzZm9yY2Ugc3VjY2Vzc2Z1bGx5XG4gICAgICAgICAgICogcmVmcmVzaGVkIGl0IHdlIG5lZWQgdG8gcmVtb3ZlIHRoZSBgY29udGVudC1sZW5ndGhgIGhlYWRlclxuICAgICAgICAgICAqIHNvIHRoYXQgaXQgZ2V0J3MgcmUtY2FsY3VsYXRlZCBhZ2FpbiB3aXRoIHRoZSBuZXcgYm9keS5cbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIFJFU1QgcmVxdWVzdCBhcmVuJ3QgYWZmZWN0ZWQgYnkgdGhpcyBiZWNhdXNlIHRoZSBhY2Nlc3MgdG9rZW5cbiAgICAgICAgICAgKiBpcyBzZW50IHZpYSBIVFRQIGhlYWRlcnNcbiAgICAgICAgICAgKlxuICAgICAgICAgICAqIGBfbWVzc2FnZWAgaXMgb25seSBwcmVzZW50IGluIFNPQVAgcmVxdWVzdHNcbiAgICAgICAgICAgKi9cbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAnX21lc3NhZ2UnIGluIHJlcXVlc3QgJiZcbiAgICAgICAgICAgIHJlcXVlc3QuaGVhZGVycyAmJlxuICAgICAgICAgICAgJ2NvbnRlbnQtbGVuZ3RoJyBpbiByZXF1ZXN0LmhlYWRlcnNcbiAgICAgICAgICApIHtcbiAgICAgICAgICAgIGRlbGV0ZSByZXF1ZXN0LmhlYWRlcnNbJ2NvbnRlbnQtbGVuZ3RoJ107XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QocmVxdWVzdCwgc2Vzc2lvblJlZnJlc2hDb3VudCArIDEpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmlzRXJyb3JSZXNwb25zZShyZXNwb25zZSkpIHtcbiAgICAgICAgICBjb25zdCBlcnIgPSBhd2FpdCB0aGlzLmdldEVycm9yKHJlc3BvbnNlKTtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMuZ2V0UmVzcG9uc2VCb2R5KHJlc3BvbnNlKTtcbiAgICAgICAgcmV0dXJuIGJvZHk7XG4gICAgICB9KSgpO1xuICAgICAgcmV0dXJuIHsgc3RyZWFtLCBwcm9taXNlIH07XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgZ2V0UmVmcmVzaERlbGVnYXRlKCkge1xuICAgIHJldHVybiB0aGlzLl9jb25uLl9yZWZyZXNoRGVsZWdhdGU7XG4gIH1cblxuICAvKipcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgYmVmb3JlU2VuZChyZXF1ZXN0OiBIdHRwUmVxdWVzdCkge1xuICAgIC8qIGVzbGludC1kaXNhYmxlIG5vLXBhcmFtLXJlYXNzaWduICovXG4gICAgY29uc3QgaGVhZGVycyA9IHJlcXVlc3QuaGVhZGVycyB8fCB7fTtcbiAgICBpZiAodGhpcy5fY29ubi5hY2Nlc3NUb2tlbikge1xuICAgICAgaGVhZGVycy5BdXRob3JpemF0aW9uID0gYEJlYXJlciAke3RoaXMuX2Nvbm4uYWNjZXNzVG9rZW59YDtcbiAgICB9XG4gICAgaWYgKHRoaXMuX2Nvbm4uX2NhbGxPcHRpb25zKSB7XG4gICAgICBjb25zdCBjYWxsT3B0aW9ucyA9IFtdO1xuICAgICAgZm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKHRoaXMuX2Nvbm4uX2NhbGxPcHRpb25zKSkge1xuICAgICAgICBjYWxsT3B0aW9ucy5wdXNoKGAke25hbWV9PSR7dGhpcy5fY29ubi5fY2FsbE9wdGlvbnNbbmFtZV19YCk7XG4gICAgICB9XG4gICAgICBoZWFkZXJzWydTZm9yY2UtQ2FsbC1PcHRpb25zJ10gPSBjYWxsT3B0aW9ucy5qb2luKCcsICcpO1xuICAgIH1cblxuICAgIGNvbnN0IGJvZHlTaXplID0gZ2V0Qm9keVNpemUocmVxdWVzdC5ib2R5LCBoZWFkZXJzKTtcblxuICAgIGNvbnN0IGNhbm5vdEhhdmVCb2R5ID0gWydHRVQnLCAnSEVBRCcsICdPUFRJT05TJ10uaW5jbHVkZXMocmVxdWVzdC5tZXRob2QpO1xuXG4gICAgLy8gRG9uJ3Qgc2V0IGNvbnRlbnQtbGVuZ3RoIGluIGJyb3dzZXJzIGFzIGl0J3Mgbm90IGFsbG93ZWRcbiAgICBjb25zdCBpc0Jyb3dzZXIgPSAnd2luZG93JyBpbiBnbG9iYWxUaGlzIHx8ICdzZWxmJyBpbiBnbG9iYWxUaGlzO1xuXG4gICAgaWYgKFxuICAgICAgIWlzQnJvd3NlciAmJiAvLyBEb24ndCBzZXQgY29udGVudC1sZW5ndGggaW4gYnJvd3NlcnMgYXMgaXQncyBub3QgYWxsb3dlZFxuICAgICAgIWNhbm5vdEhhdmVCb2R5ICYmXG4gICAgICAhIXJlcXVlc3QuYm9keSAmJlxuICAgICAgISgndHJhbnNmZXItZW5jb2RpbmcnIGluIGhlYWRlcnMpICYmXG4gICAgICAhKCdjb250ZW50LWxlbmd0aCcgaW4gaGVhZGVycykgJiZcbiAgICAgICEhYm9keVNpemVcbiAgICApIHtcbiAgICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgICAgYG1pc3NpbmcgJ2NvbnRlbnQtbGVuZ3RoJyBoZWFkZXIsIHNldHRpbmcgaXQgdG86ICR7Ym9keVNpemV9YCxcbiAgICAgICk7XG4gICAgICBoZWFkZXJzWydjb250ZW50LWxlbmd0aCddID0gU3RyaW5nKGJvZHlTaXplKTtcbiAgICB9XG4gICAgcmVxdWVzdC5oZWFkZXJzID0gaGVhZGVycztcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlY3QgcmVzcG9uc2UgY29udGVudCBtaW1lLXR5cGVcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgZ2V0UmVzcG9uc2VDb250ZW50VHlwZShyZXNwb25zZTogSHR0cFJlc3BvbnNlKTogT3B0aW9uYWw8c3RyaW5nPiB7XG4gICAgcmV0dXJuIChcbiAgICAgIHRoaXMuX3Jlc3BvbnNlVHlwZSB8fFxuICAgICAgKHJlc3BvbnNlLmhlYWRlcnMgJiYgcmVzcG9uc2UuaGVhZGVyc1snY29udGVudC10eXBlJ10pXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9yZXF1aXJlLWF3YWl0XG4gIGFzeW5jIHBhcnNlUmVzcG9uc2VCb2R5KHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpIHtcbiAgICBjb25zdCBjb250ZW50VHlwZSA9IHRoaXMuZ2V0UmVzcG9uc2VDb250ZW50VHlwZShyZXNwb25zZSkgfHwgJyc7XG4gICAgY29uc3QgcGFyc2VCb2R5ID0gL14odGV4dHxhcHBsaWNhdGlvbilcXC94bWwoO3wkKS8udGVzdChjb250ZW50VHlwZSlcbiAgICAgID8gcGFyc2VYTUxcbiAgICAgIDogL15hcHBsaWNhdGlvblxcL2pzb24oO3wkKS8udGVzdChjb250ZW50VHlwZSlcbiAgICAgID8gcGFyc2VKU09OXG4gICAgICA6IC9edGV4dFxcL2Nzdig7fCQpLy50ZXN0KGNvbnRlbnRUeXBlKVxuICAgICAgPyBwYXJzZUNTVlxuICAgICAgOiBwYXJzZVRleHQ7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBwYXJzZUJvZHkocmVzcG9uc2UuYm9keSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gVE9ETyhuZXh0IG1ham9yKTogd2UgY291bGQgdGhyb3cgYSBuZXcgXCJpbnZhbGlkIHJlc3BvbnNlIGJvZHlcIiBlcnJvciBpbnN0ZWFkLlxuICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKFxuICAgICAgICBgRmFpbGVkIHRvIHBhcnNlIGJvZHkgb2YgY29udGVudC10eXBlOiAke2NvbnRlbnRUeXBlfS4gRXJyb3I6ICR7XG4gICAgICAgICAgKGUgYXMgRXJyb3IpLm1lc3NhZ2VcbiAgICAgICAgfWAsXG4gICAgICApO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLmJvZHk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldCByZXNwb25zZSBib2R5XG4gICAqIEBwcm90ZWN0ZWRcbiAgICovXG4gIGFzeW5jIGdldFJlc3BvbnNlQm9keShyZXNwb25zZTogSHR0cFJlc3BvbnNlKSB7XG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT09IDIwNCkge1xuICAgICAgLy8gTm8gQ29udGVudFxuICAgICAgcmV0dXJuIHRoaXMuX25vQ29udGVudFJlc3BvbnNlO1xuICAgIH1cbiAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5wYXJzZVJlc3BvbnNlQm9keShyZXNwb25zZSk7XG4gICAgbGV0IGVycjtcbiAgICBpZiAodGhpcy5oYXNFcnJvckluUmVzcG9uc2VCb2R5KGJvZHkpKSB7XG4gICAgICBlcnIgPSBhd2FpdCB0aGlzLmdldEVycm9yKHJlc3BvbnNlLCBib2R5KTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT09IDMwMCkge1xuICAgICAgLy8gTXVsdGlwbGUgQ2hvaWNlc1xuICAgICAgdGhyb3cgbmV3IEh0dHBBcGlFcnJvcihcbiAgICAgICAgJ011bHRpcGxlIHJlY29yZHMgZm91bmQnLFxuICAgICAgICAnTVVMVElQTEVfQ0hPSUNFUycsXG4gICAgICAgIGJvZHksXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gYm9keTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlY3Qgc2Vzc2lvbiBleHBpcnlcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgaXNTZXNzaW9uRXhwaXJlZChyZXNwb25zZTogSHR0cFJlc3BvbnNlKSB7XG4gICAgLy8gUkVTVCBBUEkgc3RhdHVzIGNvZGVzOiBodHRwczovL2RldmVsb3Blci5zYWxlc2ZvcmNlLmNvbS9kb2NzL2F0bGFzLmVuLXVzLmFwaV9yZXN0Lm1ldGEvYXBpX3Jlc3QvZXJyb3Jjb2Rlcy5odG1cbiAgICAvL1xuICAgIC8vIFwiNDAxIC0gVGhlIHNlc3Npb24gSUQgb3IgT0F1dGggdG9rZW4gdXNlZCBoYXMgZXhwaXJlZCBvciBpcyBpbnZhbGlkLiBUaGUgcmVzcG9uc2UgYm9keSBjb250YWlucyB0aGUgbWVzc2FnZSBhbmQgZXJyb3JDb2RlLlwiXG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT09IDQwMSkge1xuICAgICAgLy8gS25vd24gbGlzdCBvZiA0MDEgcmVzcG9uc2VzIHRoYXQgc2hvdWxkbid0IGJlIGNvbnNpZGVyZWQgYXMgXCJzZXNzaW9uIGV4cGlyZWRcIi5cbiAgICAgIC8vXG4gICAgICAvLyBUaGVzZSB1c3VhbHkgY29tZSBmcm9tIGFuIENBL0VDQSwgT0F1dGgsIElQIHJlc3RyaWN0aW9uIGNoYW5nZSBpbiB0aGUgb3JnIHRoYXQgYmxvY2sgY29ubmVjdGlvbnMsIHdlIG5lZWQgdG8gc2tpcCB0aGVzZVxuICAgICAgLy8gb3JnIGpzZm9yY2Ugd2lsbCBlbnRlciBpbnRvIGFuIGluZmluaXRlIGxvb3AgdHJ5aW5nIHRvIGdldCBhIHZhbGlkIHRva2VuLlxuICAgICAgY29uc3QgcmVzcG9uc2VzVG9Ta2lwID0gW1xuICAgICAgICAnQ29ubmVjdGVkIGFwcCBpcyBub3QgYXR0YWNoZWQgdG8gQWdlbnQnLFxuICAgICAgICAnVGhpcyBzZXNzaW9uIGlzIG5vdCB2YWxpZCBmb3IgdXNlIHdpdGggdGhlIFJFU1QgQVBJJyxcbiAgICAgICAgJ0JsYWNrVGFiIHVzZXJzIGNhbm5vdCBwZXJmb3JtIEFQSSBvcGVyYXRpb25zJyxcbiAgICAgIF07XG4gICAgICBmb3IgKGNvbnN0IHAgb2YgcmVzcG9uc2VzVG9Ta2lwKSB7XG4gICAgICAgIGlmIChyZXNwb25zZS5ib2R5LmluY2x1ZGVzKHApKSByZXR1cm4gZmFsc2VcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlY3QgZXJyb3IgcmVzcG9uc2VcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgaXNFcnJvclJlc3BvbnNlKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpIHtcbiAgICByZXR1cm4gcmVzcG9uc2Uuc3RhdHVzQ29kZSA+PSA0MDA7XG4gIH1cblxuICAvKipcbiAgICogRGV0ZWN0IGVycm9yIGluIHJlc3BvbnNlIGJvZHlcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgaGFzRXJyb3JJblJlc3BvbnNlQm9keShfYm9keTogT3B0aW9uYWw8c3RyaW5nPikge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQYXJzaW5nIGVycm9yIG1lc3NhZ2UgaW4gcmVzcG9uc2VcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgcGFyc2VFcnJvcihib2R5OiBhbnkpIHtcbiAgICBjb25zdCBlcnJvcnMgPSBib2R5O1xuXG4gICAgLy8gWE1MIHJlc3BvbnNlXG4gICAgaWYgKGVycm9ycy5FcnJvcnMpIHtcbiAgICAgIHJldHVybiBlcnJvcnMuRXJyb3JzLkVycm9yO1xuICAgIH1cblxuICAgIHJldHVybiBlcnJvcnM7XG4gIH1cblxuICAvKipcbiAgICogR2V0IGVycm9yIG1lc3NhZ2UgaW4gcmVzcG9uc2VcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgYXN5bmMgZ2V0RXJyb3IocmVzcG9uc2U6IEh0dHBSZXNwb25zZSwgYm9keT86IGFueSk6IFByb21pc2U8RXJyb3I+IHtcbiAgICBsZXQgZXJyb3I7XG4gICAgdHJ5IHtcbiAgICAgIGVycm9yID0gdGhpcy5wYXJzZUVycm9yKGJvZHkgfHwgKGF3YWl0IHRoaXMucGFyc2VSZXNwb25zZUJvZHkocmVzcG9uc2UpKSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUgbm8tZW1wdHlcbiAgICB9XG5cbiAgICBpZiAoQXJyYXkuaXNBcnJheShlcnJvcikpIHtcbiAgICAgIGlmIChlcnJvci5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgZXJyb3IgPSBlcnJvclswXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBuZXcgSHR0cEFwaUVycm9yKFxuICAgICAgICAgIGBNdWx0aXBsZSBlcnJvcnMgcmV0dXJuZWQuXG4gIENoZWNrIFxcYGVycm9yLmRhdGFcXGAgZm9yIHRoZSBlcnJvciBkZXRhaWxzYCxcbiAgICAgICAgICAnTVVMVElQTEVfQVBJX0VSUk9SUycsXG4gICAgICAgICAgZXJyb3IsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgZXJyb3IgPVxuICAgICAgdHlwZW9mIGVycm9yID09PSAnb2JqZWN0JyAmJlxuICAgICAgZXJyb3IgIT09IG51bGwgJiZcbiAgICAgIHR5cGVvZiBlcnJvci5tZXNzYWdlID09PSAnc3RyaW5nJ1xuICAgICAgICA/IGVycm9yXG4gICAgICAgIDoge1xuICAgICAgICAgICAgZXJyb3JDb2RlOiBgRVJST1JfSFRUUF8ke3Jlc3BvbnNlLnN0YXR1c0NvZGV9YCxcbiAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3BvbnNlLmJvZHksXG4gICAgICAgICAgfTtcblxuICAgIGlmIChyZXNwb25zZS5oZWFkZXJzWydjb250ZW50LXR5cGUnXSAhPSBudWxsICYmIHJlc3BvbnNlLmhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddLmluY2x1ZGVzKCd0ZXh0L2h0bWwnKSkge1xuICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKGBodG1sIHJlc3BvbnNlLmJvZHk6ICR7cmVzcG9uc2UuYm9keX1gKTtcbiAgICAgIHJldHVybiBuZXcgSHR0cEFwaUVycm9yKFxuICAgICAgICBgSFRUUCByZXNwb25zZSBjb250YWlucyBodG1sIGNvbnRlbnQuXG5DaGVjayB0aGF0IHRoZSBvcmcgZXhpc3RzIGFuZCBjYW4gYmUgcmVhY2hlZC5cblxuSFRUUCBzdGF0dXMgY29kZTogJHtyZXNwb25zZS5zdGF0dXNDb2RlfS5cblJFU1QgQVBJIFN0YXR1cyBDb2RlcyBhbmQgRXJyb3IgUmVzcG9uc2VzOlxuaHR0cHM6Ly9kZXZlbG9wZXIuc2FsZXNmb3JjZS5jb20vZG9jcy9hdGxhcy5lbi11cy5hcGlfcmVzdC5tZXRhL2FwaV9yZXN0L2Vycm9yY29kZXMuaHRtXG5cblNlZSBcXGBlcnJvci5kYXRhXFxgIGZvciB0aGUgZnVsbCBodG1sIHJlc3BvbnNlLmAsXG4gICAgICAgIGVycm9yLmVycm9yQ29kZSxcbiAgICAgICAgZXJyb3IubWVzc2FnZSxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGVycm9yIGluc3RhbmNlb2YgSHR0cEFwaUVycm9yXG4gICAgICA/IGVycm9yXG4gICAgICA6IG5ldyBIdHRwQXBpRXJyb3IoZXJyb3IubWVzc2FnZSwgZXJyb3IuZXJyb3JDb2RlLCBlcnJvcik7XG4gIH1cbn1cblxuLyoqXG4gKlxuICovXG5jbGFzcyBIdHRwQXBpRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIC8qKlxuICAgKiBUaGlzIGNvbnRhaW5zIGVycm9yLXNwZWNpZmljIGRldGFpbHMsIHVzdWFsbHkgcmV0dXJuZWQgZnJvbSB0aGUgQVBJLlxuICAgKi9cbiAgZGF0YTogYW55O1xuICBlcnJvckNvZGU6IHN0cmluZztcblxuICBjb25zdHJ1Y3RvcihtZXNzYWdlOiBzdHJpbmcsIGVycm9yQ29kZT86IHN0cmluZyB8IHVuZGVmaW5lZCwgZGF0YT86IGFueSkge1xuICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgIHRoaXMubmFtZSA9IGVycm9yQ29kZSB8fCB0aGlzLm5hbWU7XG4gICAgdGhpcy5lcnJvckNvZGUgPSB0aGlzLm5hbWU7XG4gICAgdGhpcy5kYXRhID0gZGF0YTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmV4dCBtYWpvciAodjQpXG4gICAqXG4gICAqIEBkZXByZWNhdGVkIHVzZSBgZXJyb3IuZGF0YWAgaW5zdGVhZFxuICAgKi9cbiAgZ2V0IGNvbnRlbnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZGF0YTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBIdHRwQXBpO1xuZXhwb3J0IGNvbnN0IGlzQnJvd3NlciA9ICd3aW5kb3cnIGluIGdsb2JhbFRoaXMgfHwgJ3NlbGYnIGluIGdsb2JhbFRoaXM7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsWUFBWSxRQUFRLFFBQVE7QUFDckMsT0FBT0MsTUFBTSxNQUFNLFFBQVE7QUFDM0IsU0FBaUJDLFNBQVMsUUFBUSxlQUFlO0FBQ2pELFNBQVNDLGFBQWEsUUFBUSxnQkFBZ0I7QUFHOUMsU0FBU0MsUUFBUSxRQUFRLE9BQU87QUFRaEMsU0FBU0MsZ0JBQWdCLFFBQVEsZUFBZTtBQUNoRCxTQUFTQyxXQUFXLFFBQVEsc0JBQXNCOztBQUVsRDtBQUNBLFNBQVNDLFNBQVNBLENBQUNDLEdBQVcsRUFBRTtFQUM5QixPQUFPQyxJQUFJLENBQUNDLEtBQUssQ0FBQ0YsR0FBRyxDQUFDO0FBQ3hCOztBQUVBO0FBQUEsU0FDZUcsUUFBUUEsQ0FBQUMsRUFBQTtFQUFBLE9BQUFDLFNBQUEsQ0FBQUMsS0FBQSxPQUFBQyxTQUFBO0FBQUE7QUFJdkI7QUFBQSxTQUFBRixVQUFBO0VBQUFBLFNBQUEsR0FBQUcsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUpBLFNBQUFDLFNBQXdCWCxHQUFXO0lBQUEsT0FBQVMsbUJBQUEsQ0FBQUcsSUFBQSxVQUFBQyxVQUFBQyxVQUFBO01BQUEsa0JBQUFBLFVBQUEsQ0FBQUMsSUFBQSxHQUFBRCxVQUFBLENBQUFFLElBQUE7UUFBQTtVQUFBLE9BQUFGLFVBQUEsQ0FBQUcsTUFBQSxXQUMxQnhCLE1BQU0sQ0FBQ3lCLGtCQUFrQixDQUFDbEIsR0FBRyxFQUFFO1lBQUVtQixhQUFhLEVBQUU7VUFBTSxDQUFDLENBQUM7UUFBQTtRQUFBO1VBQUEsT0FBQUwsVUFBQSxDQUFBTSxJQUFBO01BQUE7SUFBQSxHQUFBVCxRQUFBO0VBQUEsQ0FDaEU7RUFBQSxPQUFBTixTQUFBLENBQUFDLEtBQUEsT0FBQUMsU0FBQTtBQUFBO0FBR0QsU0FBU2MsU0FBU0EsQ0FBQ3JCLEdBQVcsRUFBRTtFQUM5QixPQUFPQSxHQUFHO0FBQ1o7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1zQiwyQkFBMkIsR0FBRyxDQUFDO0FBRXJDLFNBQVNDLCtCQUErQkEsQ0FBQ0MsSUFFeEMsRUFBVTtFQUNULElBQU1DLFVBQVUsR0FBR0MsTUFBTSxDQUFDRixJQUFJLGFBQUpBLElBQUksdUJBQUpBLElBQUksQ0FBRUcseUJBQXlCLENBQUM7RUFDMUQsT0FBT0MsZ0JBQUEsQ0FBZ0JILFVBQVUsQ0FBQyxHQUM5QkEsVUFBVSxHQUNWSCwyQkFBMkI7QUFDakM7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBYU8sT0FBTywwQkFBQUMsYUFBQTtFQVVsQixTQUFBRCxRQUFZTCxJQUFtQixFQUFFTyxPQUFZLEVBQUU7SUFBQSxJQUFBQyxLQUFBO0lBQUFDLGVBQUEsT0FBQUosT0FBQTtJQUM3Q0csS0FBQSxHQUFBRSxVQUFBLE9BQUFMLE9BQUE7SUFDQUcsS0FBQSxDQUFLRyxLQUFLLEdBQUdYLElBQUk7SUFDakJRLEtBQUEsQ0FBS0ksT0FBTyxHQUFHWixJQUFJLENBQUNhLFNBQVMsR0FDekJSLE9BQU8sQ0FBQ08sT0FBTyxDQUFDRSxjQUFjLENBQUNkLElBQUksQ0FBQ2EsU0FBUyxDQUFDLEdBQzlDUixPQUFPLENBQUNPLE9BQU87SUFDbkJKLEtBQUEsQ0FBS08sYUFBYSxHQUFHUixPQUFPLENBQUNTLFlBQVk7SUFDekNSLEtBQUEsQ0FBS1MsVUFBVSxHQUFHVixPQUFPLENBQUNXLFNBQVMsSUFBSWxCLElBQUksQ0FBQ2lCLFVBQVU7SUFDdERULEtBQUEsQ0FBS1csa0JBQWtCLEdBQUdaLE9BQU8sQ0FBQ2EsaUJBQWlCO0lBQ25EWixLQUFBLENBQUthLFFBQVEsR0FBR2QsT0FBTztJQUFDLE9BQUFDLEtBQUE7RUFDMUI7O0VBRUE7QUFDRjtBQUNBO0VBRkVjLFNBQUEsQ0FBQWpCLE9BQUEsRUFBQUMsYUFBQTtFQUFBLE9BQUFpQixZQUFBLENBQUFsQixPQUFBO0lBQUFtQixHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBQyxPQUFPQSxDQUNMQSxRQUFvQixFQUVGO01BQUEsSUFBQUMsTUFBQTtNQUFBLElBRGxCQyxtQkFBbUIsR0FBQTdDLFNBQUEsQ0FBQThDLE1BQUEsUUFBQTlDLFNBQUEsUUFBQStDLFNBQUEsR0FBQS9DLFNBQUEsTUFBRyxDQUFDO01BRXZCLE9BQU9aLGFBQWEsQ0FBQzRELE1BQU0sQ0FBSSxZQUFNO1FBQ25DLElBQUFDLGlCQUFBLEdBQThCM0QsZ0JBQWdCLENBQUMsQ0FBQztVQUF4QzRELE1BQU0sR0FBQUQsaUJBQUEsQ0FBTkMsTUFBTTtVQUFFQyxTQUFTLEdBQUFGLGlCQUFBLENBQVRFLFNBQVM7UUFDekIsSUFBTUMsT0FBTyxHQUFHbkQsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUFDLFNBQUFrRCxRQUFBO1VBQUEsSUFBQUMsUUFBQSxFQUFBQyxTQUFBO1VBQUEsSUFBQUMsZUFBQSxFQUFBQyxXQUFBLEVBQUFDLE1BQUEsRUFBQUMsV0FBQSxFQUFBQyxjQUFBLEVBQUFDLFFBQUEsRUFBQUMsWUFBQSxFQUFBQyxVQUFBLEVBQUFDLEdBQUEsRUFBQUMsSUFBQSxFQUFBQyxJQUFBO1VBQUEsT0FBQWhFLG1CQUFBLENBQUFHLElBQUEsVUFBQThELFNBQUFDLFNBQUE7WUFBQSxrQkFBQUEsU0FBQSxDQUFBNUQsSUFBQSxHQUFBNEQsU0FBQSxDQUFBM0QsSUFBQTtjQUFBO2dCQUNUK0MsZUFBZSxHQUFHWixNQUFJLENBQUN5QixrQkFBa0IsQ0FBQyxDQUFDO2dCQUNqRDtnQkFDQTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO2dCQVZRLE1BWUliLGVBQWUsSUFBSUEsZUFBZSxDQUFDYyxZQUFZLENBQUMsQ0FBQztrQkFBQUYsU0FBQSxDQUFBM0QsSUFBQTtrQkFBQTtnQkFBQTtnQkFBQTJELFNBQUEsQ0FBQTNELElBQUE7Z0JBQUEsT0FDN0MrQyxlQUFlLENBQUNlLFdBQVcsQ0FBQyxDQUFDO2NBQUE7Z0JBQzdCZCxXQUFXLEdBQUdiLE1BQUksQ0FBQ0QsT0FBTyxDQUFDQSxRQUFPLEVBQUVFLG1CQUFtQixDQUFDO2dCQUM5RE0sU0FBUyxDQUFDTSxXQUFXLENBQUNQLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQUNrQixTQUFBLENBQUEzRCxJQUFBO2dCQUFBLE9BQ2JnRCxXQUFXO2NBQUE7Z0JBQXhCUyxNQUFJLEdBQUFFLFNBQUEsQ0FBQUksSUFBQTtnQkFBQSxPQUFBSixTQUFBLENBQUExRCxNQUFBLFdBQ0h3RCxNQUFJO2NBQUE7Z0JBR2I7Z0JBQ0F0QixNQUFJLENBQUM2QixVQUFVLENBQUM5QixRQUFPLENBQUM7Z0JBRXhCQyxNQUFJLENBQUM4QixJQUFJLENBQUMsU0FBUyxFQUFFL0IsUUFBTyxDQUFDO2dCQUM3QkMsTUFBSSxDQUFDZixPQUFPLENBQUM4QyxLQUFLLENBQUFDLHVCQUFBLENBQUF0QixRQUFBLHVCQUFBdUIsTUFBQSxDQUNJbEMsUUFBTyxDQUFDbUMsTUFBTSxhQUFBQyxJQUFBLENBQUF6QixRQUFBLEVBQVNYLFFBQU8sQ0FBQ3FDLEdBQUcsQ0FDeEQsQ0FBQztnQkFDS3JCLFdBQVcsR0FBR3NCLFNBQUEsQ0FBUyxDQUFDO2dCQUN4QnJCLGNBQWMsR0FBR2hCLE1BQUksQ0FBQ1YsVUFBVSxDQUFDZ0QsV0FBVyxDQUNoRHZDLFFBQU8sRUFDUEMsTUFBSSxDQUFDTixRQUNQLENBQUM7Z0JBRURhLFNBQVMsQ0FBQ1MsY0FBYyxDQUFDVixNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUFDa0IsU0FBQSxDQUFBNUQsSUFBQTtnQkFBQTRELFNBQUEsQ0FBQTNELElBQUE7Z0JBQUEsT0FJaEJtRCxjQUFjO2NBQUE7Z0JBQS9CQyxRQUFRLEdBQUFPLFNBQUEsQ0FBQUksSUFBQTtnQkFBQUosU0FBQSxDQUFBM0QsSUFBQTtnQkFBQTtjQUFBO2dCQUFBMkQsU0FBQSxDQUFBNUQsSUFBQTtnQkFBQTRELFNBQUEsQ0FBQWUsRUFBQSxHQUFBZixTQUFBO2dCQUVSeEIsTUFBSSxDQUFDZixPQUFPLENBQUN1RCxLQUFLLENBQUFoQixTQUFBLENBQUFlLEVBQUksQ0FBQztnQkFBQyxNQUFBZixTQUFBLENBQUFlLEVBQUE7Y0FBQTtnQkFBQWYsU0FBQSxDQUFBNUQsSUFBQTtnQkFHbEJzRCxZQUFZLEdBQUdtQixTQUFBLENBQVMsQ0FBQztnQkFDL0JyQyxNQUFJLENBQUNmLE9BQU8sQ0FBQzhDLEtBQUssa0JBQUFFLE1BQUEsQ0FDQ2YsWUFBWSxHQUFHSCxXQUFXLFVBQzdDLENBQUM7Z0JBQUMsT0FBQVMsU0FBQSxDQUFBaUIsTUFBQTtjQUFBO2dCQUFBLElBRUN4QixRQUFRO2tCQUFBTyxTQUFBLENBQUEzRCxJQUFBO2tCQUFBO2dCQUFBO2dCQUFBLE9BQUEyRCxTQUFBLENBQUExRCxNQUFBO2NBQUE7Z0JBR2JrQyxNQUFJLENBQUNmLE9BQU8sQ0FBQzhDLEtBQUssQ0FBQUMsdUJBQUEsQ0FBQXJCLFNBQUEsd0JBQUFzQixNQUFBLENBQ0tTLE1BQU0sQ0FBQ3pCLFFBQVEsQ0FBQzBCLFVBQVUsQ0FBQyxhQUFBUixJQUFBLENBQUF4QixTQUFBLEVBQzlDWixRQUFPLENBQUNxQyxHQUFHLENBRWYsQ0FBQztnQkFDRHBDLE1BQUksQ0FBQzhCLElBQUksQ0FBQyxVQUFVLEVBQUViLFFBQVEsQ0FBQztnQkFDL0I7Z0JBQ0E7Z0JBQUEsTUFDSWpCLE1BQUksQ0FBQzRDLGdCQUFnQixDQUFDM0IsUUFBUSxDQUFDLElBQUlMLGVBQWU7a0JBQUFZLFNBQUEsQ0FBQTNELElBQUE7a0JBQUE7Z0JBQUE7Z0JBQzlDc0QsVUFBVSxHQUFHL0MsK0JBQStCLENBQUM0QixNQUFJLENBQUNoQixLQUFLLENBQUM7Z0JBQUEsTUFDMURpQixtQkFBbUIsSUFBSWtCLFVBQVU7a0JBQUFLLFNBQUEsQ0FBQTNELElBQUE7a0JBQUE7Z0JBQUE7Z0JBQ25DbUMsTUFBSSxDQUFDZixPQUFPLENBQUN1RCxLQUFLLGdDQUFBUCxNQUFBLENBQ2VoQyxtQkFBbUIsa0NBQ3BELENBQUM7Z0JBQUN1QixTQUFBLENBQUEzRCxJQUFBO2dCQUFBLE9BQ2dCbUMsTUFBSSxDQUFDNkMsUUFBUSxDQUFDNUIsUUFBUSxDQUFDO2NBQUE7Z0JBQW5DRyxHQUFHLEdBQUFJLFNBQUEsQ0FBQUksSUFBQTtnQkFBQSxNQUNIUixHQUFHO2NBQUE7Z0JBQUFJLFNBQUEsQ0FBQTNELElBQUE7Z0JBQUEsT0FFTCtDLGVBQWUsQ0FBQ2tDLE9BQU8sQ0FBQy9CLFdBQVcsQ0FBQztjQUFBO2dCQUMxQztBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Z0JBQ1UsSUFDRSxVQUFVLElBQUloQixRQUFPLElBQ3JCQSxRQUFPLENBQUNnRCxPQUFPLElBQ2YsZ0JBQWdCLElBQUloRCxRQUFPLENBQUNnRCxPQUFPLEVBQ25DO2tCQUNBLE9BQU9oRCxRQUFPLENBQUNnRCxPQUFPLENBQUMsZ0JBQWdCLENBQUM7Z0JBQzFDO2dCQUFDLE9BQUF2QixTQUFBLENBQUExRCxNQUFBLFdBQ01rQyxNQUFJLENBQUNELE9BQU8sQ0FBQ0EsUUFBTyxFQUFFRSxtQkFBbUIsR0FBRyxDQUFDLENBQUM7Y0FBQTtnQkFBQSxLQUVuREQsTUFBSSxDQUFDZ0QsZUFBZSxDQUFDL0IsUUFBUSxDQUFDO2tCQUFBTyxTQUFBLENBQUEzRCxJQUFBO2tCQUFBO2dCQUFBO2dCQUFBMkQsU0FBQSxDQUFBM0QsSUFBQTtnQkFBQSxPQUNkbUMsTUFBSSxDQUFDNkMsUUFBUSxDQUFDNUIsUUFBUSxDQUFDO2NBQUE7Z0JBQW5DRyxJQUFHLEdBQUFJLFNBQUEsQ0FBQUksSUFBQTtnQkFBQSxNQUNIUixJQUFHO2NBQUE7Z0JBQUFJLFNBQUEsQ0FBQTNELElBQUE7Z0JBQUEsT0FFUW1DLE1BQUksQ0FBQ2lELGVBQWUsQ0FBQ2hDLFFBQVEsQ0FBQztjQUFBO2dCQUEzQ0ssSUFBSSxHQUFBRSxTQUFBLENBQUFJLElBQUE7Z0JBQUEsT0FBQUosU0FBQSxDQUFBMUQsTUFBQSxXQUNId0QsSUFBSTtjQUFBO2NBQUE7Z0JBQUEsT0FBQUUsU0FBQSxDQUFBdkQsSUFBQTtZQUFBO1VBQUEsR0FBQXdDLE9BQUE7UUFBQSxDQUNaLEdBQUUsQ0FBQztRQUNKLE9BQU87VUFBRUgsTUFBTSxFQUFOQSxNQUFNO1VBQUVFLE9BQU8sRUFBUEE7UUFBUSxDQUFDO01BQzVCLENBQUMsQ0FBQztJQUNKOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFYLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUEyQixrQkFBa0JBLENBQUEsRUFBRztNQUNuQixPQUFPLElBQUksQ0FBQ3pDLEtBQUssQ0FBQ2tFLGdCQUFnQjtJQUNwQzs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBckQsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQStCLFVBQVVBLENBQUM5QixPQUFvQixFQUFFO01BQUEsSUFBQW9ELFNBQUE7TUFDL0I7TUFDQSxJQUFNSixPQUFPLEdBQUdoRCxPQUFPLENBQUNnRCxPQUFPLElBQUksQ0FBQyxDQUFDO01BQ3JDLElBQUksSUFBSSxDQUFDL0QsS0FBSyxDQUFDb0UsV0FBVyxFQUFFO1FBQzFCTCxPQUFPLENBQUNNLGFBQWEsYUFBQXBCLE1BQUEsQ0FBYSxJQUFJLENBQUNqRCxLQUFLLENBQUNvRSxXQUFXLENBQUU7TUFDNUQ7TUFDQSxJQUFJLElBQUksQ0FBQ3BFLEtBQUssQ0FBQ3NFLFlBQVksRUFBRTtRQUMzQixJQUFNQyxXQUFXLEdBQUcsRUFBRTtRQUN0QixTQUFBQyxFQUFBLE1BQUFDLFlBQUEsR0FBbUJDLGFBQUEsQ0FBWSxJQUFJLENBQUMxRSxLQUFLLENBQUNzRSxZQUFZLENBQUMsRUFBQUUsRUFBQSxHQUFBQyxZQUFBLENBQUF2RCxNQUFBLEVBQUFzRCxFQUFBLElBQUU7VUFBQSxJQUFBRyxTQUFBO1VBQXBELElBQU1DLElBQUksR0FBQUgsWUFBQSxDQUFBRCxFQUFBO1VBQ2JELFdBQVcsQ0FBQ00sSUFBSSxDQUFBN0IsdUJBQUEsQ0FBQTJCLFNBQUEsTUFBQTFCLE1BQUEsQ0FBSTJCLElBQUksUUFBQXpCLElBQUEsQ0FBQXdCLFNBQUEsRUFBSSxJQUFJLENBQUMzRSxLQUFLLENBQUNzRSxZQUFZLENBQUNNLElBQUksQ0FBQyxDQUFFLENBQUM7UUFDOUQ7UUFDQWIsT0FBTyxDQUFDLHFCQUFxQixDQUFDLEdBQUdRLFdBQVcsQ0FBQ08sSUFBSSxDQUFDLElBQUksQ0FBQztNQUN6RDtNQUVBLElBQU1DLFFBQVEsR0FBR3BILFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ3VCLElBQUksRUFBRXlCLE9BQU8sQ0FBQztNQUVuRCxJQUFNaUIsY0FBYyxHQUFHQyx5QkFBQSxDQUFBZCxTQUFBLElBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUMsRUFBQWhCLElBQUEsQ0FBQWdCLFNBQUEsRUFBVXBELE9BQU8sQ0FBQ21DLE1BQU0sQ0FBQzs7TUFFMUU7TUFDQSxJQUFNZ0MsU0FBUyxHQUFHLFFBQVEsSUFBQUMsV0FBYyxJQUFJLE1BQU0sSUFBQUEsV0FBYztNQUVoRSxJQUNFLENBQUNELFNBQVM7TUFBSTtNQUNkLENBQUNGLGNBQWMsSUFDZixDQUFDLENBQUNqRSxPQUFPLENBQUN1QixJQUFJLElBQ2QsRUFBRSxtQkFBbUIsSUFBSXlCLE9BQU8sQ0FBQyxJQUNqQyxFQUFFLGdCQUFnQixJQUFJQSxPQUFPLENBQUMsSUFDOUIsQ0FBQyxDQUFDZ0IsUUFBUSxFQUNWO1FBQ0EsSUFBSSxDQUFDOUUsT0FBTyxDQUFDOEMsS0FBSyxvREFBQUUsTUFBQSxDQUNtQzhCLFFBQVEsQ0FDN0QsQ0FBQztRQUNEaEIsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEdBQUdMLE1BQU0sQ0FBQ3FCLFFBQVEsQ0FBQztNQUM5QztNQUNBaEUsT0FBTyxDQUFDZ0QsT0FBTyxHQUFHQSxPQUFPO0lBQzNCOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBSEU7SUFBQWxELEdBQUE7SUFBQUMsS0FBQSxFQUlBLFNBQUFzRSxzQkFBc0JBLENBQUNuRCxRQUFzQixFQUFvQjtNQUMvRCxPQUNFLElBQUksQ0FBQzdCLGFBQWEsSUFDakI2QixRQUFRLENBQUM4QixPQUFPLElBQUk5QixRQUFRLENBQUM4QixPQUFPLENBQUMsY0FBYyxDQUFFO0lBRTFEOztJQUVBO0FBQ0Y7QUFDQTtJQUNFO0VBQUE7SUFBQWxELEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUF1RSxrQkFBQSxHQUFBaEgsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUNBLFNBQUErRyxTQUF3QnJELFFBQXNCO1FBQUEsSUFBQXNELFdBQUEsRUFBQUMsU0FBQSxFQUFBQyxTQUFBO1FBQUEsT0FBQW5ILG1CQUFBLENBQUFHLElBQUEsVUFBQWlILFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBL0csSUFBQSxHQUFBK0csU0FBQSxDQUFBOUcsSUFBQTtZQUFBO2NBQ3RDMEcsV0FBVyxHQUFHLElBQUksQ0FBQ0gsc0JBQXNCLENBQUNuRCxRQUFRLENBQUMsSUFBSSxFQUFFO2NBQ3pEdUQsU0FBUyxHQUFHLCtCQUErQixDQUFDSSxJQUFJLENBQUNMLFdBQVcsQ0FBQyxHQUMvRHZILFFBQVEsR0FDUix5QkFBeUIsQ0FBQzRILElBQUksQ0FBQ0wsV0FBVyxDQUFDLEdBQzNDM0gsU0FBUyxHQUNULGlCQUFpQixDQUFDZ0ksSUFBSSxDQUFDTCxXQUFXLENBQUMsR0FDbkM5SCxRQUFRLEdBQ1J5QixTQUFTO2NBQUF5RyxTQUFBLENBQUEvRyxJQUFBO2NBQUEsT0FBQStHLFNBQUEsQ0FBQTdHLE1BQUEsV0FFSjBHLFNBQVMsQ0FBQ3ZELFFBQVEsQ0FBQ0ssSUFBSSxDQUFDO1lBQUE7Y0FBQXFELFNBQUEsQ0FBQS9HLElBQUE7Y0FBQStHLFNBQUEsQ0FBQXBDLEVBQUEsR0FBQW9DLFNBQUE7Y0FFL0I7Y0FDQSxJQUFJLENBQUMxRixPQUFPLENBQUM4QyxLQUFLLENBQUFDLHVCQUFBLENBQUF5QyxTQUFBLDRDQUFBeEMsTUFBQSxDQUN5QnNDLFdBQVcsZ0JBQUFwQyxJQUFBLENBQUFzQyxTQUFBLEVBQ2xERSxTQUFBLENBQUFwQyxFQUFBLENBQWFzQyxPQUFPLENBRXhCLENBQUM7Y0FBQyxPQUFBRixTQUFBLENBQUE3RyxNQUFBLFdBQ0ttRCxRQUFRLENBQUNLLElBQUk7WUFBQTtZQUFBO2NBQUEsT0FBQXFELFNBQUEsQ0FBQTFHLElBQUE7VUFBQTtRQUFBLEdBQUFxRyxRQUFBO01BQUEsQ0FFdkI7TUFBQSxTQXBCS1EsaUJBQWlCQSxDQUFBQyxHQUFBO1FBQUEsT0FBQVYsa0JBQUEsQ0FBQWxILEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBakIwSCxpQkFBaUI7SUFBQTtJQXNCdkI7QUFDRjtBQUNBO0FBQ0E7SUFIRTtFQUFBO0lBQUFqRixHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBa0YsZ0JBQUEsR0FBQTNILGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FJQSxTQUFBMEgsU0FBc0JoRSxRQUFzQjtRQUFBLElBQUFLLElBQUEsRUFBQUYsR0FBQTtRQUFBLE9BQUE5RCxtQkFBQSxDQUFBRyxJQUFBLFVBQUF5SCxVQUFBQyxTQUFBO1VBQUEsa0JBQUFBLFNBQUEsQ0FBQXZILElBQUEsR0FBQXVILFNBQUEsQ0FBQXRILElBQUE7WUFBQTtjQUFBLE1BQ3RDb0QsUUFBUSxDQUFDMEIsVUFBVSxLQUFLLEdBQUc7Z0JBQUF3QyxTQUFBLENBQUF0SCxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxPQUFBc0gsU0FBQSxDQUFBckgsTUFBQSxXQUV0QixJQUFJLENBQUMwQixrQkFBa0I7WUFBQTtjQUFBMkYsU0FBQSxDQUFBdEgsSUFBQTtjQUFBLE9BRWIsSUFBSSxDQUFDaUgsaUJBQWlCLENBQUM3RCxRQUFRLENBQUM7WUFBQTtjQUE3Q0ssSUFBSSxHQUFBNkQsU0FBQSxDQUFBdkQsSUFBQTtjQUFBLEtBRU4sSUFBSSxDQUFDd0Qsc0JBQXNCLENBQUM5RCxJQUFJLENBQUM7Z0JBQUE2RCxTQUFBLENBQUF0SCxJQUFBO2dCQUFBO2NBQUE7Y0FBQXNILFNBQUEsQ0FBQXRILElBQUE7Y0FBQSxPQUN2QixJQUFJLENBQUNnRixRQUFRLENBQUM1QixRQUFRLEVBQUVLLElBQUksQ0FBQztZQUFBO2NBQXpDRixHQUFHLEdBQUErRCxTQUFBLENBQUF2RCxJQUFBO2NBQUEsTUFDR1IsR0FBRztZQUFBO2NBQUEsTUFFUEgsUUFBUSxDQUFDMEIsVUFBVSxLQUFLLEdBQUc7Z0JBQUF3QyxTQUFBLENBQUF0SCxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUV2QixJQUFJd0gsWUFBWSxDQUNwQix3QkFBd0IsRUFDeEIsa0JBQWtCLEVBQ2xCL0QsSUFDRixDQUFDO1lBQUE7Y0FBQSxPQUFBNkQsU0FBQSxDQUFBckgsTUFBQSxXQUVJd0QsSUFBSTtZQUFBO1lBQUE7Y0FBQSxPQUFBNkQsU0FBQSxDQUFBbEgsSUFBQTtVQUFBO1FBQUEsR0FBQWdILFFBQUE7TUFBQSxDQUNaO01BQUEsU0FwQktoQyxlQUFlQSxDQUFBcUMsR0FBQTtRQUFBLE9BQUFOLGdCQUFBLENBQUE3SCxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQWY2RixlQUFlO0lBQUE7SUFzQnJCO0FBQ0Y7QUFDQTtBQUNBO0lBSEU7RUFBQTtJQUFBcEQsR0FBQTtJQUFBQyxLQUFBLEVBSUEsU0FBQThDLGdCQUFnQkEsQ0FBQzNCLFFBQXNCLEVBQUU7TUFDdkM7TUFDQTtNQUNBO01BQ0EsSUFBSUEsUUFBUSxDQUFDMEIsVUFBVSxLQUFLLEdBQUcsRUFBRTtRQUMvQjtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQU00QyxlQUFlLEdBQUcsQ0FDdEIsd0NBQXdDLEVBQ3hDLHFEQUFxRCxFQUNyRCw4Q0FBOEMsQ0FDL0M7UUFDRCxTQUFBQyxHQUFBLE1BQUFDLGdCQUFBLEdBQWdCRixlQUFlLEVBQUFDLEdBQUEsR0FBQUMsZ0JBQUEsQ0FBQXZGLE1BQUEsRUFBQXNGLEdBQUEsSUFBRTtVQUFBLElBQUFFLFNBQUE7VUFBNUIsSUFBTUMsQ0FBQyxHQUFBRixnQkFBQSxDQUFBRCxHQUFBO1VBQ1YsSUFBSXZCLHlCQUFBLENBQUF5QixTQUFBLEdBQUF6RSxRQUFRLENBQUNLLElBQUksRUFBQWEsSUFBQSxDQUFBdUQsU0FBQSxFQUFVQyxDQUFDLENBQUMsRUFBRSxPQUFPLEtBQUs7UUFDN0M7UUFFQSxPQUFPLElBQUk7TUFDYjtNQUVBLE9BQU8sS0FBSztJQUNkOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBSEU7SUFBQTlGLEdBQUE7SUFBQUMsS0FBQSxFQUlBLFNBQUFrRCxlQUFlQSxDQUFDL0IsUUFBc0IsRUFBRTtNQUN0QyxPQUFPQSxRQUFRLENBQUMwQixVQUFVLElBQUksR0FBRztJQUNuQzs7SUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUhFO0lBQUE5QyxHQUFBO0lBQUFDLEtBQUEsRUFJQSxTQUFBc0Ysc0JBQXNCQSxDQUFDUSxLQUF1QixFQUFFO01BQzlDLE9BQU8sS0FBSztJQUNkOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBSEU7SUFBQS9GLEdBQUE7SUFBQUMsS0FBQSxFQUlBLFNBQUErRixVQUFVQSxDQUFDdkUsSUFBUyxFQUFFO01BQ3BCLElBQU13RSxNQUFNLEdBQUd4RSxJQUFJOztNQUVuQjtNQUNBLElBQUl3RSxNQUFNLENBQUNDLE1BQU0sRUFBRTtRQUNqQixPQUFPRCxNQUFNLENBQUNDLE1BQU0sQ0FBQ0MsS0FBSztNQUM1QjtNQUVBLE9BQU9GLE1BQU07SUFDZjs7SUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUhFO0lBQUFqRyxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBbUcsU0FBQSxHQUFBNUksaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUlBLFNBQUEySSxTQUFlakYsUUFBc0IsRUFBRUssSUFBVTtRQUFBLElBQUE2RSxVQUFBO1FBQUEsSUFBQTNELEtBQUE7UUFBQSxPQUFBbEYsbUJBQUEsQ0FBQUcsSUFBQSxVQUFBMkksVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUF6SSxJQUFBLEdBQUF5SSxVQUFBLENBQUF4SSxJQUFBO1lBQUE7Y0FBQXdJLFVBQUEsQ0FBQXpJLElBQUE7Y0FBQXlJLFVBQUEsQ0FBQTlELEVBQUEsR0FHckMsSUFBSTtjQUFBOEQsVUFBQSxDQUFBQyxFQUFBLEdBQVloRixJQUFJO2NBQUEsSUFBQStFLFVBQUEsQ0FBQUMsRUFBQTtnQkFBQUQsVUFBQSxDQUFBeEksSUFBQTtnQkFBQTtjQUFBO2NBQUF3SSxVQUFBLENBQUF4SSxJQUFBO2NBQUEsT0FBVyxJQUFJLENBQUNpSCxpQkFBaUIsQ0FBQzdELFFBQVEsQ0FBQztZQUFBO2NBQUFvRixVQUFBLENBQUFDLEVBQUEsR0FBQUQsVUFBQSxDQUFBekUsSUFBQTtZQUFBO2NBQUF5RSxVQUFBLENBQUFFLEVBQUEsR0FBQUYsVUFBQSxDQUFBQyxFQUFBO2NBQXZFOUQsS0FBSyxHQUFBNkQsVUFBQSxDQUFBOUQsRUFBQSxDQUFRc0QsVUFBVSxDQUFBMUQsSUFBQSxDQUFBa0UsVUFBQSxDQUFBOUQsRUFBQSxFQUFBOEQsVUFBQSxDQUFBRSxFQUFBO2NBQUFGLFVBQUEsQ0FBQXhJLElBQUE7Y0FBQTtZQUFBO2NBQUF3SSxVQUFBLENBQUF6SSxJQUFBO2NBQUF5SSxVQUFBLENBQUFHLEVBQUEsR0FBQUgsVUFBQTtZQUFBO2NBQUEsS0FLckJJLGNBQUEsQ0FBY2pFLEtBQUssQ0FBQztnQkFBQTZELFVBQUEsQ0FBQXhJLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE1BQ2xCMkUsS0FBSyxDQUFDdEMsTUFBTSxLQUFLLENBQUM7Z0JBQUFtRyxVQUFBLENBQUF4SSxJQUFBO2dCQUFBO2NBQUE7Y0FDcEIyRSxLQUFLLEdBQUdBLEtBQUssQ0FBQyxDQUFDLENBQUM7Y0FBQzZELFVBQUEsQ0FBQXhJLElBQUE7Y0FBQTtZQUFBO2NBQUEsT0FBQXdJLFVBQUEsQ0FBQXZJLE1BQUEsV0FFVixJQUFJdUgsWUFBWSwwRUFHckIscUJBQXFCLEVBQ3JCN0MsS0FDRixDQUFDO1lBQUE7Y0FJTEEsS0FBSyxHQUNIa0UsT0FBQSxDQUFPbEUsS0FBSyxNQUFLLFFBQVEsSUFDekJBLEtBQUssS0FBSyxJQUFJLElBQ2QsT0FBT0EsS0FBSyxDQUFDcUMsT0FBTyxLQUFLLFFBQVEsR0FDN0JyQyxLQUFLLEdBQ0w7Z0JBQ0VtRSxTQUFTLGdCQUFBMUUsTUFBQSxDQUFnQmhCLFFBQVEsQ0FBQzBCLFVBQVUsQ0FBRTtnQkFDOUNrQyxPQUFPLEVBQUU1RCxRQUFRLENBQUNLO2NBQ3BCLENBQUM7Y0FBQyxNQUVKTCxRQUFRLENBQUM4QixPQUFPLENBQUMsY0FBYyxDQUFDLElBQUksSUFBSSxJQUFJa0IseUJBQUEsQ0FBQWtDLFVBQUEsR0FBQWxGLFFBQVEsQ0FBQzhCLE9BQU8sQ0FBQyxjQUFjLENBQUMsRUFBQVosSUFBQSxDQUFBZ0UsVUFBQSxFQUFVLFdBQVcsQ0FBQztnQkFBQUUsVUFBQSxDQUFBeEksSUFBQTtnQkFBQTtjQUFBO2NBQ3BHLElBQUksQ0FBQ29CLE9BQU8sQ0FBQzhDLEtBQUssd0JBQUFFLE1BQUEsQ0FBd0JoQixRQUFRLENBQUNLLElBQUksQ0FBRSxDQUFDO2NBQUMsT0FBQStFLFVBQUEsQ0FBQXZJLE1BQUEsV0FDcEQsSUFBSXVILFlBQVksNkdBQUFwRCxNQUFBLENBSVRoQixRQUFRLENBQUMwQixVQUFVLDZMQUsvQkgsS0FBSyxDQUFDbUUsU0FBUyxFQUNmbkUsS0FBSyxDQUFDcUMsT0FDUixDQUFDO1lBQUE7Y0FBQSxPQUFBd0IsVUFBQSxDQUFBdkksTUFBQSxXQUdJMEUsS0FBSyxZQUFZNkMsWUFBWSxHQUNoQzdDLEtBQUssR0FDTCxJQUFJNkMsWUFBWSxDQUFDN0MsS0FBSyxDQUFDcUMsT0FBTyxFQUFFckMsS0FBSyxDQUFDbUUsU0FBUyxFQUFFbkUsS0FBSyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUE2RCxVQUFBLENBQUFwSSxJQUFBO1VBQUE7UUFBQSxHQUFBaUksUUFBQTtNQUFBLENBQzVEO01BQUEsU0FsREtyRCxRQUFRQSxDQUFBK0QsR0FBQSxFQUFBQyxHQUFBO1FBQUEsT0FBQVosU0FBQSxDQUFBOUksS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFSeUYsUUFBUTtJQUFBO0VBQUE7QUFBQSxFQW5UK0J4RyxZQUFZOztBQXdXM0Q7QUFDQTtBQUNBO0FBRkF5SyxlQUFBLENBeFdhcEksT0FBTyxhQUNEbkMsU0FBUyxDQUFDLFVBQVUsQ0FBQztBQUFBLElBMFdsQzhJLFlBQVksMEJBQUEwQixNQUFBO0VBQ2hCO0FBQ0Y7QUFDQTs7RUFJRSxTQUFBMUIsYUFBWVIsT0FBZSxFQUFFOEIsU0FBOEIsRUFBRUssSUFBVSxFQUFFO0lBQUEsSUFBQUMsTUFBQTtJQUFBbkksZUFBQSxPQUFBdUcsWUFBQTtJQUN2RTRCLE1BQUEsR0FBQWxJLFVBQUEsT0FBQXNHLFlBQUEsR0FBTVIsT0FBTztJQUNib0MsTUFBQSxDQUFLckQsSUFBSSxHQUFHK0MsU0FBUyxJQUFJTSxNQUFBLENBQUtyRCxJQUFJO0lBQ2xDcUQsTUFBQSxDQUFLTixTQUFTLEdBQUdNLE1BQUEsQ0FBS3JELElBQUk7SUFDMUJxRCxNQUFBLENBQUtELElBQUksR0FBR0EsSUFBSTtJQUFDLE9BQUFDLE1BQUE7RUFDbkI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUpFdEgsU0FBQSxDQUFBMEYsWUFBQSxFQUFBMEIsTUFBQTtFQUFBLE9BQUFuSCxZQUFBLENBQUF5RixZQUFBO0lBQUF4RixHQUFBO0lBQUFxSCxHQUFBLEVBS0EsU0FBQUEsSUFBQSxFQUFjO01BQ1osT0FBTyxJQUFJLENBQUNGLElBQUk7SUFDbEI7RUFBQztBQUFBLGVBQUFHLGdCQUFBLENBckJ3Qm5CLEtBQUs7QUF3QmhDLGVBQWV0SCxPQUFPO0FBQ3RCLE9BQU8sSUFBTXdGLFNBQVMsR0FBRyxRQUFRLElBQUFDLFdBQWMsSUFBSSxNQUFNLElBQUFBLFdBQWMiLCJpZ25vcmVMaXN0IjpbXX0=