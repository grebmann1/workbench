import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _wrapNativeSuper from "@babel/runtime-corejs3/helpers/wrapNativeSuper";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context12, _context13; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context12 = ownKeys(Object(t), !0)).call(_context12, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context13 = ownKeys(Object(t))).call(_context13, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _endsWithInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/ends-with";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _includesInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/includes";
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.join.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.object.keys.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.to-string.js";
import "core-js/modules/es.string.replace.js";
/**
 *
 */
import { createHash, randomBytes } from 'crypto';
import querystring from 'querystring';
import Transport, { HttpProxyTransport, XdProxyTransport } from './transport';
var defaultOAuth2Config = {
  loginUrl: 'https://login.salesforce.com'
};

// Makes a nodejs base64 encoded string compatible with rfc4648 alternative encoding for urls.
// @param base64Encoded a nodejs base64 encoded string
function base64UrlEscape(base64Encoded) {
  // builtin node js base 64 encoding is not 64 url compatible.
  // See https://toolsn.ietf.org/html/rfc4648#section-5
  return base64Encoded.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

/**
 * type defs
 */

/**
 * OAuth2 class
 */
export var OAuth2 = /*#__PURE__*/function () {
  /**
   *
   */
  function OAuth2(config) {
    _classCallCheck(this, OAuth2);
    var loginUrl = config.loginUrl,
      authzServiceUrl = config.authzServiceUrl,
      tokenServiceUrl = config.tokenServiceUrl,
      revokeServiceUrl = config.revokeServiceUrl,
      clientId = config.clientId,
      clientSecret = config.clientSecret,
      redirectUri = config.redirectUri,
      proxyUrl = config.proxyUrl,
      httpProxy = config.httpProxy,
      useVerifier = config.useVerifier;
    if (authzServiceUrl && tokenServiceUrl) {
      var _context;
      this.loginUrl = _sliceInstanceProperty(_context = authzServiceUrl.split('/')).call(_context, 0, 3).join('/');
      this.authzServiceUrl = authzServiceUrl;
      this.tokenServiceUrl = tokenServiceUrl;
      this.revokeServiceUrl = revokeServiceUrl || "".concat(this.loginUrl, "/services/oauth2/revoke");
    } else {
      var _context2, _context3, _context4, _context5;
      this.loginUrl = loginUrl !== null && loginUrl !== void 0 ? loginUrl : defaultOAuth2Config.loginUrl;
      var maybeSlash = _endsWithInstanceProperty(_context2 = this.loginUrl).call(_context2, '/') ? '' : '/';
      this.authzServiceUrl = _concatInstanceProperty(_context3 = "".concat(this.loginUrl)).call(_context3, maybeSlash, "services/oauth2/authorize");
      this.tokenServiceUrl = _concatInstanceProperty(_context4 = "".concat(this.loginUrl)).call(_context4, maybeSlash, "services/oauth2/token");
      this.revokeServiceUrl = _concatInstanceProperty(_context5 = "".concat(this.loginUrl)).call(_context5, maybeSlash, "services/oauth2/revoke");
    }
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.redirectUri = redirectUri;
    if (proxyUrl) {
      this._transport = new XdProxyTransport(proxyUrl);
    } else if (httpProxy) {
      this._transport = new HttpProxyTransport(httpProxy);
    } else {
      this._transport = new Transport();
    }
    if (useVerifier) {
      // Set a code verifier string for OAuth authorization
      this.codeVerifier = base64UrlEscape(randomBytes(Math.ceil(128)).toString('base64'));
    }
  }

  /**
   * Get Salesforce OAuth2 authorization page URL to redirect user agent.
   */
  return _createClass(OAuth2, [{
    key: "getAuthorizationUrl",
    value: function getAuthorizationUrl() {
      var _context6;
      var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      if (this.codeVerifier) {
        // code verifier must be a base 64 url encoded hash of 128 bytes of random data. Our random data is also
        // base 64 url encoded. See Connection.create();
        params.code_challenge = base64UrlEscape(createHash('sha256').update(this.codeVerifier).digest('base64'));
      }
      var _params = _objectSpread(_objectSpread({}, params), {}, {
        response_type: 'code',
        client_id: this.clientId,
        redirect_uri: this.redirectUri
      });
      return this.authzServiceUrl + (_includesInstanceProperty(_context6 = this.authzServiceUrl).call(_context6, '?') ? '&' : '?') + querystring.stringify(_params);
    }

    /**
     * OAuth2 Refresh Token Flow
     */
  }, {
    key: "refreshToken",
    value: (function () {
      var _refreshToken2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(_refreshToken) {
        var params, ret;
        return _regeneratorRuntime.wrap(function _callee$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              if (this.clientId) {
                _context7.next = 2;
                break;
              }
              throw new Error('No OAuth2 client id information is specified');
            case 2:
              params = {
                grant_type: 'refresh_token',
                refresh_token: _refreshToken,
                client_id: this.clientId
              };
              if (this.clientSecret) {
                params.client_secret = this.clientSecret;
              }
              _context7.next = 6;
              return this._postParams(params);
            case 6:
              ret = _context7.sent;
              return _context7.abrupt("return", ret);
            case 8:
            case "end":
              return _context7.stop();
          }
        }, _callee, this);
      }));
      function refreshToken(_x) {
        return _refreshToken2.apply(this, arguments);
      }
      return refreshToken;
    }()
    /**
     * Send access token request to the token endpoint.
     * When a code (string) is passed in first argument, it will use Web Server Authentication Flow (Authorization Code Grant).
     * Otherwise, it will use the specified `grant_type` and pass parameters to the endpoint.
     */
    )
  }, {
    key: "requestToken",
    value: (function () {
      var _requestToken = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(codeOrParams) {
        var params,
          _params,
          ret,
          _args2 = arguments;
        return _regeneratorRuntime.wrap(function _callee2$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              params = _args2.length > 1 && _args2[1] !== undefined ? _args2[1] : {};
              if (!(typeof codeOrParams === 'string' && (!this.clientId || !this.redirectUri))) {
                _context8.next = 3;
                break;
              }
              throw new Error('No OAuth2 client id or redirect uri configuration is specified');
            case 3:
              _params = _objectSpread(_objectSpread({}, params), typeof codeOrParams === 'string' ? {
                grant_type: 'authorization_code',
                code: codeOrParams
              } : codeOrParams);
              if (this.clientId) {
                _params.client_id = this.clientId;
              }
              if (this.clientSecret) {
                _params.client_secret = this.clientSecret;
              }
              if (this.redirectUri) {
                _params.redirect_uri = this.redirectUri;
              }
              _context8.next = 9;
              return this._postParams(_params);
            case 9:
              ret = _context8.sent;
              return _context8.abrupt("return", ret);
            case 11:
            case "end":
              return _context8.stop();
          }
        }, _callee2, this);
      }));
      function requestToken(_x2) {
        return _requestToken.apply(this, arguments);
      }
      return requestToken;
    }()
    /**
     * OAuth2 Username-Password Flow (Resource Owner Password Credentials)
     */
    )
  }, {
    key: "authenticate",
    value: (function () {
      var _authenticate = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3(username, password) {
        var ret;
        return _regeneratorRuntime.wrap(function _callee3$(_context9) {
          while (1) switch (_context9.prev = _context9.next) {
            case 0:
              if (!(!this.clientId || !this.clientSecret)) {
                _context9.next = 2;
                break;
              }
              throw new Error('No valid OAuth2 client configuration set');
            case 2:
              _context9.next = 4;
              return this._postParams({
                grant_type: 'password',
                username: username,
                password: password,
                client_id: this.clientId,
                client_secret: this.clientSecret
              });
            case 4:
              ret = _context9.sent;
              return _context9.abrupt("return", ret);
            case 6:
            case "end":
              return _context9.stop();
          }
        }, _callee3, this);
      }));
      function authenticate(_x3, _x4) {
        return _authenticate.apply(this, arguments);
      }
      return authenticate;
    }()
    /**
     * OAuth2 Revoke Session Token
     */
    )
  }, {
    key: "revokeToken",
    value: (function () {
      var _revokeToken = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4(token) {
        var response, res;
        return _regeneratorRuntime.wrap(function _callee4$(_context10) {
          while (1) switch (_context10.prev = _context10.next) {
            case 0:
              _context10.next = 2;
              return this._transport.httpRequest({
                method: 'POST',
                url: this.revokeServiceUrl,
                body: querystring.stringify({
                  token: token
                }),
                headers: {
                  'content-type': 'application/x-www-form-urlencoded'
                }
              });
            case 2:
              response = _context10.sent;
              if (!(response.statusCode >= 400)) {
                _context10.next = 7;
                break;
              }
              res = querystring.parse(response.body);
              if (!res || !res.error) {
                res = {
                  error: "ERROR_HTTP_".concat(response.statusCode),
                  error_description: response.body
                };
              }
              throw new (/*#__PURE__*/function (_Error) {
                function _class(_ref) {
                  var _this;
                  var error = _ref.error,
                    error_description = _ref.error_description;
                  _classCallCheck(this, _class);
                  _this = _callSuper(this, _class, [error_description]);
                  _this.name = error;
                  return _this;
                }
                _inherits(_class, _Error);
                return _createClass(_class);
              }(/*#__PURE__*/_wrapNativeSuper(Error)))(res);
            case 7:
            case "end":
              return _context10.stop();
          }
        }, _callee4, this);
      }));
      function revokeToken(_x5) {
        return _revokeToken.apply(this, arguments);
      }
      return revokeToken;
    }()
    /**
     * @private
     */
    )
  }, {
    key: "_postParams",
    value: (function () {
      var _postParams2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee5(params) {
        var response, res;
        return _regeneratorRuntime.wrap(function _callee5$(_context11) {
          while (1) switch (_context11.prev = _context11.next) {
            case 0:
              if (this.codeVerifier) params.code_verifier = this.codeVerifier;
              _context11.next = 3;
              return this._transport.httpRequest({
                method: 'POST',
                url: this.tokenServiceUrl,
                body: querystring.stringify(params),
                headers: {
                  'content-type': 'application/x-www-form-urlencoded'
                }
              });
            case 3:
              response = _context11.sent;
              try {
                res = JSON.parse(response.body);
              } catch (e) {
                /* eslint-disable no-empty */
              }
              if (!(response.statusCode >= 400)) {
                _context11.next = 8;
                break;
              }
              res = res || {
                error: "ERROR_HTTP_".concat(response.statusCode),
                error_description: response.body
              };
              throw new (/*#__PURE__*/function (_Error2) {
                function _class2(_ref2) {
                  var _this2;
                  var error = _ref2.error,
                    error_description = _ref2.error_description;
                  _classCallCheck(this, _class2);
                  _this2 = _callSuper(this, _class2, [error_description]);
                  _this2.name = error;
                  return _this2;
                }
                _inherits(_class2, _Error2);
                return _createClass(_class2);
              }(/*#__PURE__*/_wrapNativeSuper(Error)))(res);
            case 8:
              return _context11.abrupt("return", res);
            case 9:
            case "end":
              return _context11.stop();
          }
        }, _callee5, this);
      }));
      function _postParams(_x6) {
        return _postParams2.apply(this, arguments);
      }
      return _postParams;
    }())
  }]);
}();
export default OAuth2;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJjcmVhdGVIYXNoIiwicmFuZG9tQnl0ZXMiLCJxdWVyeXN0cmluZyIsIlRyYW5zcG9ydCIsIkh0dHBQcm94eVRyYW5zcG9ydCIsIlhkUHJveHlUcmFuc3BvcnQiLCJkZWZhdWx0T0F1dGgyQ29uZmlnIiwibG9naW5VcmwiLCJiYXNlNjRVcmxFc2NhcGUiLCJiYXNlNjRFbmNvZGVkIiwicmVwbGFjZSIsIk9BdXRoMiIsImNvbmZpZyIsIl9jbGFzc0NhbGxDaGVjayIsImF1dGh6U2VydmljZVVybCIsInRva2VuU2VydmljZVVybCIsInJldm9rZVNlcnZpY2VVcmwiLCJjbGllbnRJZCIsImNsaWVudFNlY3JldCIsInJlZGlyZWN0VXJpIiwicHJveHlVcmwiLCJodHRwUHJveHkiLCJ1c2VWZXJpZmllciIsIl9jb250ZXh0IiwiX3NsaWNlSW5zdGFuY2VQcm9wZXJ0eSIsInNwbGl0IiwiY2FsbCIsImpvaW4iLCJjb25jYXQiLCJfY29udGV4dDIiLCJfY29udGV4dDMiLCJfY29udGV4dDQiLCJfY29udGV4dDUiLCJtYXliZVNsYXNoIiwiX2VuZHNXaXRoSW5zdGFuY2VQcm9wZXJ0eSIsIl9jb25jYXRJbnN0YW5jZVByb3BlcnR5IiwiX3RyYW5zcG9ydCIsImNvZGVWZXJpZmllciIsIk1hdGgiLCJjZWlsIiwidG9TdHJpbmciLCJfY3JlYXRlQ2xhc3MiLCJrZXkiLCJ2YWx1ZSIsImdldEF1dGhvcml6YXRpb25VcmwiLCJfY29udGV4dDYiLCJwYXJhbXMiLCJhcmd1bWVudHMiLCJsZW5ndGgiLCJ1bmRlZmluZWQiLCJjb2RlX2NoYWxsZW5nZSIsInVwZGF0ZSIsImRpZ2VzdCIsIl9wYXJhbXMiLCJfb2JqZWN0U3ByZWFkIiwicmVzcG9uc2VfdHlwZSIsImNsaWVudF9pZCIsInJlZGlyZWN0X3VyaSIsIl9pbmNsdWRlc0luc3RhbmNlUHJvcGVydHkiLCJzdHJpbmdpZnkiLCJfcmVmcmVzaFRva2VuMiIsIl9hc3luY1RvR2VuZXJhdG9yIiwiX3JlZ2VuZXJhdG9yUnVudGltZSIsIm1hcmsiLCJfY2FsbGVlIiwicmVmcmVzaFRva2VuIiwicmV0Iiwid3JhcCIsIl9jYWxsZWUkIiwiX2NvbnRleHQ3IiwicHJldiIsIm5leHQiLCJFcnJvciIsImdyYW50X3R5cGUiLCJyZWZyZXNoX3Rva2VuIiwiY2xpZW50X3NlY3JldCIsIl9wb3N0UGFyYW1zIiwic2VudCIsImFicnVwdCIsInN0b3AiLCJfeCIsImFwcGx5IiwiX3JlcXVlc3RUb2tlbiIsIl9jYWxsZWUyIiwiY29kZU9yUGFyYW1zIiwiX2FyZ3MyIiwiX2NhbGxlZTIkIiwiX2NvbnRleHQ4IiwiY29kZSIsInJlcXVlc3RUb2tlbiIsIl94MiIsIl9hdXRoZW50aWNhdGUiLCJfY2FsbGVlMyIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJfY2FsbGVlMyQiLCJfY29udGV4dDkiLCJhdXRoZW50aWNhdGUiLCJfeDMiLCJfeDQiLCJfcmV2b2tlVG9rZW4iLCJfY2FsbGVlNCIsInRva2VuIiwicmVzcG9uc2UiLCJyZXMiLCJfY2FsbGVlNCQiLCJfY29udGV4dDEwIiwiaHR0cFJlcXVlc3QiLCJtZXRob2QiLCJ1cmwiLCJib2R5IiwiaGVhZGVycyIsInN0YXR1c0NvZGUiLCJwYXJzZSIsImVycm9yIiwiZXJyb3JfZGVzY3JpcHRpb24iLCJfRXJyb3IiLCJfY2xhc3MiLCJfcmVmIiwiX3RoaXMiLCJfY2FsbFN1cGVyIiwibmFtZSIsIl9pbmhlcml0cyIsIl93cmFwTmF0aXZlU3VwZXIiLCJyZXZva2VUb2tlbiIsIl94NSIsIl9wb3N0UGFyYW1zMiIsIl9jYWxsZWU1IiwiX2NhbGxlZTUkIiwiX2NvbnRleHQxMSIsImNvZGVfdmVyaWZpZXIiLCJKU09OIiwiZSIsIl9FcnJvcjIiLCJfY2xhc3MyIiwiX3JlZjIiLCJfdGhpczIiLCJfeDYiXSwic291cmNlcyI6WyIuLi9zcmMvb2F1dGgyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICpcbiAqL1xuaW1wb3J0IHtjcmVhdGVIYXNoLCByYW5kb21CeXRlc30gZnJvbSAnY3J5cHRvJztcbmltcG9ydCBxdWVyeXN0cmluZyBmcm9tICdxdWVyeXN0cmluZyc7XG5pbXBvcnQgVHJhbnNwb3J0LCB7SHR0cFByb3h5VHJhbnNwb3J0LCBYZFByb3h5VHJhbnNwb3J0fSBmcm9tICcuL3RyYW5zcG9ydCc7XG5pbXBvcnQge09wdGlvbmFsfSBmcm9tICcuL3R5cGVzJztcblxuY29uc3QgZGVmYXVsdE9BdXRoMkNvbmZpZyA9IHtcbiAgbG9naW5Vcmw6ICdodHRwczovL2xvZ2luLnNhbGVzZm9yY2UuY29tJyxcbn07XG5cbi8vIE1ha2VzIGEgbm9kZWpzIGJhc2U2NCBlbmNvZGVkIHN0cmluZyBjb21wYXRpYmxlIHdpdGggcmZjNDY0OCBhbHRlcm5hdGl2ZSBlbmNvZGluZyBmb3IgdXJscy5cbi8vIEBwYXJhbSBiYXNlNjRFbmNvZGVkIGEgbm9kZWpzIGJhc2U2NCBlbmNvZGVkIHN0cmluZ1xuZnVuY3Rpb24gYmFzZTY0VXJsRXNjYXBlKGJhc2U2NEVuY29kZWQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIGJ1aWx0aW4gbm9kZSBqcyBiYXNlIDY0IGVuY29kaW5nIGlzIG5vdCA2NCB1cmwgY29tcGF0aWJsZS5cbiAgLy8gU2VlIGh0dHBzOi8vdG9vbHNuLmlldGYub3JnL2h0bWwvcmZjNDY0OCNzZWN0aW9uLTVcbiAgcmV0dXJuIGJhc2U2NEVuY29kZWRcbiAgICAucmVwbGFjZSgvXFwrL2csICctJylcbiAgICAucmVwbGFjZSgvXFwvL2csICdfJylcbiAgICAucmVwbGFjZSgvPS9nLCAnJyk7XG59XG5cbi8qKlxuICogdHlwZSBkZWZzXG4gKi9cbmV4cG9ydCB0eXBlIE9BdXRoMkNvbmZpZyA9IHtcbiAgY2xpZW50SWQ/OiBzdHJpbmc7XG4gIGNsaWVudFNlY3JldD86IHN0cmluZztcbiAgcmVkaXJlY3RVcmk/OiBzdHJpbmc7XG4gIGxvZ2luVXJsPzogc3RyaW5nO1xuICBhdXRoelNlcnZpY2VVcmw/OiBzdHJpbmc7XG4gIHRva2VuU2VydmljZVVybD86IHN0cmluZztcbiAgcmV2b2tlU2VydmljZVVybD86IHN0cmluZztcbiAgcHJveHlVcmw/OiBzdHJpbmc7XG4gIGh0dHBQcm94eT86IHN0cmluZztcbiAgdXNlVmVyaWZpZXI/OiBib29sZWFuO1xufTtcblxuZXhwb3J0IHR5cGUgQXV0aHpSZXF1ZXN0UGFyYW1zID0ge1xuICBzY29wZT86IHN0cmluZztcbiAgc3RhdGU/OiBzdHJpbmc7XG4gIGNvZGVfY2hhbGxlbmdlPzogc3RyaW5nO1xufSAmIHtcbiAgW2F0dHI6IHN0cmluZ106IHN0cmluZztcbn07XG5cbmV4cG9ydCB0eXBlIFRva2VuUmVzcG9uc2UgPSB7XG4gIHRva2VuX3R5cGU6ICdCZWFyZXInO1xuICAvKipcbiAgICogU3BhY2Utc2VwYXJhdGVkIGxpc3Qgb2YgT0F1dGggc2NvcGVzIGFzc29jaWF0ZWQgd2l0aCB0aGUgYWNjZXNzIHRva2VuXG4gICAqXG4gICAqIEZvciB0aGUgT0F1dGggMi4wIFdlYiBTZXJ2ZXIgRmxvdywgdGhpcyBjYW4gYmUgYSBzdWJzZXQgb2YgdGhlIHJlZ2lzdGVyZWQgc2NvcGVzIGlmIHNwZWNpZmllZCB3aGVuIHJlcXVlc3RpbmcgdGhlIGF1dGggY29kZS5cbiAgICpcbiAgICogU2VlOiBodHRwczovL2hlbHAuc2FsZXNmb3JjZS5jb20vcy9hcnRpY2xlVmlldz9pZD14Y2xvdWQucmVtb3RlYWNjZXNzX29hdXRoX3Rva2Vuc19zY29wZXMuaHRtJnR5cGU9NVxuICAgKi9cbiAgc2NvcGU6IHN0cmluZztcbiAgLyoqXG4gICAqIElkZW50aXR5IFVSTFxuICAgKlxuICAgKiBUaGUgZm9ybWF0IG9mIHRoZSBVUkwgaXMgaHR0cHM6Ly9sb2dpbi5zYWxlc2ZvcmNlLmNvbS9pZC9vcmdJRC91c2VySUQuXG4gICAqL1xuICBpZDogc3RyaW5nO1xuICBhY2Nlc3NfdG9rZW46IHN0cmluZztcbiAgcmVmcmVzaF90b2tlbj86IHN0cmluZztcbiAgc2lnbmF0dXJlOiBzdHJpbmc7XG4gIGlzc3VlZF9hdDogc3RyaW5nO1xuICBpbnN0YW5jZV91cmw6IHN0cmluZztcbiAgc2ZkY19jb21tdW5pdHlfdXJsPzogc3RyaW5nO1xuICBzZmRjX2NvbW11bml0eV9pZD86IHN0cmluZztcbn07XG5cbi8qKlxuICogT0F1dGgyIGNsYXNzXG4gKi9cbmV4cG9ydCBjbGFzcyBPQXV0aDIge1xuICBsb2dpblVybDogc3RyaW5nO1xuICBhdXRoelNlcnZpY2VVcmw6IHN0cmluZztcbiAgdG9rZW5TZXJ2aWNlVXJsOiBzdHJpbmc7XG4gIHJldm9rZVNlcnZpY2VVcmw6IHN0cmluZztcbiAgY2xpZW50SWQ6IE9wdGlvbmFsPHN0cmluZz47XG4gIGNsaWVudFNlY3JldDogT3B0aW9uYWw8c3RyaW5nPjtcbiAgcmVkaXJlY3RVcmk6IE9wdGlvbmFsPHN0cmluZz47XG4gIGNvZGVWZXJpZmllcjogT3B0aW9uYWw8c3RyaW5nPjtcblxuICBfdHJhbnNwb3J0OiBUcmFuc3BvcnQ7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25maWc6IE9BdXRoMkNvbmZpZykge1xuICAgIGNvbnN0IHtcbiAgICAgIGxvZ2luVXJsLFxuICAgICAgYXV0aHpTZXJ2aWNlVXJsLFxuICAgICAgdG9rZW5TZXJ2aWNlVXJsLFxuICAgICAgcmV2b2tlU2VydmljZVVybCxcbiAgICAgIGNsaWVudElkLFxuICAgICAgY2xpZW50U2VjcmV0LFxuICAgICAgcmVkaXJlY3RVcmksXG4gICAgICBwcm94eVVybCxcbiAgICAgIGh0dHBQcm94eSxcbiAgICAgIHVzZVZlcmlmaWVyLFxuICAgIH0gPSBjb25maWc7XG4gICAgaWYgKGF1dGh6U2VydmljZVVybCAmJiB0b2tlblNlcnZpY2VVcmwpIHtcbiAgICAgIHRoaXMubG9naW5VcmwgPSBhdXRoelNlcnZpY2VVcmwuc3BsaXQoJy8nKS5zbGljZSgwLCAzKS5qb2luKCcvJyk7XG4gICAgICB0aGlzLmF1dGh6U2VydmljZVVybCA9IGF1dGh6U2VydmljZVVybDtcbiAgICAgIHRoaXMudG9rZW5TZXJ2aWNlVXJsID0gdG9rZW5TZXJ2aWNlVXJsO1xuICAgICAgdGhpcy5yZXZva2VTZXJ2aWNlVXJsID1cbiAgICAgICAgcmV2b2tlU2VydmljZVVybCB8fCBgJHt0aGlzLmxvZ2luVXJsfS9zZXJ2aWNlcy9vYXV0aDIvcmV2b2tlYDtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5sb2dpblVybCA9IGxvZ2luVXJsID8/IGRlZmF1bHRPQXV0aDJDb25maWcubG9naW5VcmxcblxuICAgICAgY29uc3QgbWF5YmVTbGFzaCA9IHRoaXMubG9naW5VcmwuZW5kc1dpdGgoJy8nKSA/ICcnIDogJy8nXG5cbiAgICAgIHRoaXMuYXV0aHpTZXJ2aWNlVXJsID0gYCR7dGhpcy5sb2dpblVybH0ke21heWJlU2xhc2h9c2VydmljZXMvb2F1dGgyL2F1dGhvcml6ZWBcbiAgICAgIHRoaXMudG9rZW5TZXJ2aWNlVXJsID0gYCR7dGhpcy5sb2dpblVybH0ke21heWJlU2xhc2h9c2VydmljZXMvb2F1dGgyL3Rva2VuYFxuICAgICAgdGhpcy5yZXZva2VTZXJ2aWNlVXJsID0gYCR7dGhpcy5sb2dpblVybH0ke21heWJlU2xhc2h9c2VydmljZXMvb2F1dGgyL3Jldm9rZWBcbiAgICB9XG4gICAgdGhpcy5jbGllbnRJZCA9IGNsaWVudElkO1xuICAgIHRoaXMuY2xpZW50U2VjcmV0ID0gY2xpZW50U2VjcmV0O1xuICAgIHRoaXMucmVkaXJlY3RVcmkgPSByZWRpcmVjdFVyaTtcbiAgICBpZiAocHJveHlVcmwpIHtcbiAgICAgIHRoaXMuX3RyYW5zcG9ydCA9IG5ldyBYZFByb3h5VHJhbnNwb3J0KHByb3h5VXJsKTtcbiAgICB9IGVsc2UgaWYgKGh0dHBQcm94eSkge1xuICAgICAgdGhpcy5fdHJhbnNwb3J0ID0gbmV3IEh0dHBQcm94eVRyYW5zcG9ydChodHRwUHJveHkpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl90cmFuc3BvcnQgPSBuZXcgVHJhbnNwb3J0KCk7XG4gICAgfVxuICAgIGlmICh1c2VWZXJpZmllcikge1xuICAgICAgLy8gU2V0IGEgY29kZSB2ZXJpZmllciBzdHJpbmcgZm9yIE9BdXRoIGF1dGhvcml6YXRpb25cbiAgICAgIHRoaXMuY29kZVZlcmlmaWVyID0gYmFzZTY0VXJsRXNjYXBlKFxuICAgICAgICByYW5kb21CeXRlcyhNYXRoLmNlaWwoMTI4KSkudG9TdHJpbmcoJ2Jhc2U2NCcpLFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogR2V0IFNhbGVzZm9yY2UgT0F1dGgyIGF1dGhvcml6YXRpb24gcGFnZSBVUkwgdG8gcmVkaXJlY3QgdXNlciBhZ2VudC5cbiAgICovXG4gIGdldEF1dGhvcml6YXRpb25VcmwocGFyYW1zOiBBdXRoelJlcXVlc3RQYXJhbXMgPSB7fSkge1xuICAgIGlmICh0aGlzLmNvZGVWZXJpZmllcikge1xuICAgICAgLy8gY29kZSB2ZXJpZmllciBtdXN0IGJlIGEgYmFzZSA2NCB1cmwgZW5jb2RlZCBoYXNoIG9mIDEyOCBieXRlcyBvZiByYW5kb20gZGF0YS4gT3VyIHJhbmRvbSBkYXRhIGlzIGFsc29cbiAgICAgIC8vIGJhc2UgNjQgdXJsIGVuY29kZWQuIFNlZSBDb25uZWN0aW9uLmNyZWF0ZSgpO1xuICAgICAgcGFyYW1zLmNvZGVfY2hhbGxlbmdlID0gYmFzZTY0VXJsRXNjYXBlKFxuICAgICAgICBjcmVhdGVIYXNoKCdzaGEyNTYnKS51cGRhdGUodGhpcy5jb2RlVmVyaWZpZXIpLmRpZ2VzdCgnYmFzZTY0JyksXG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IF9wYXJhbXMgPSB7XG4gICAgICAuLi5wYXJhbXMsXG4gICAgICByZXNwb25zZV90eXBlOiAnY29kZScsXG4gICAgICBjbGllbnRfaWQ6IHRoaXMuY2xpZW50SWQsXG4gICAgICByZWRpcmVjdF91cmk6IHRoaXMucmVkaXJlY3RVcmksXG4gICAgfTtcbiAgICByZXR1cm4gKFxuICAgICAgdGhpcy5hdXRoelNlcnZpY2VVcmwgK1xuICAgICAgKHRoaXMuYXV0aHpTZXJ2aWNlVXJsLmluY2x1ZGVzKCc/JykgPyAnJicgOiAnPycpICtcbiAgICAgIHF1ZXJ5c3RyaW5nLnN0cmluZ2lmeShfcGFyYW1zIGFzIHsgW25hbWU6IHN0cmluZ106IGFueSB9KVxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogT0F1dGgyIFJlZnJlc2ggVG9rZW4gRmxvd1xuICAgKi9cbiAgYXN5bmMgcmVmcmVzaFRva2VuKHJlZnJlc2hUb2tlbjogc3RyaW5nKTogUHJvbWlzZTxUb2tlblJlc3BvbnNlPiB7XG4gICAgaWYgKCF0aGlzLmNsaWVudElkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIE9BdXRoMiBjbGllbnQgaWQgaW5mb3JtYXRpb24gaXMgc3BlY2lmaWVkJyk7XG4gICAgfVxuICAgIGNvbnN0IHBhcmFtczogeyBbcHJvcDogc3RyaW5nXTogc3RyaW5nIH0gPSB7XG4gICAgICBncmFudF90eXBlOiAncmVmcmVzaF90b2tlbicsXG4gICAgICByZWZyZXNoX3Rva2VuOiByZWZyZXNoVG9rZW4sXG4gICAgICBjbGllbnRfaWQ6IHRoaXMuY2xpZW50SWQsXG4gICAgfTtcbiAgICBpZiAodGhpcy5jbGllbnRTZWNyZXQpIHtcbiAgICAgIHBhcmFtcy5jbGllbnRfc2VjcmV0ID0gdGhpcy5jbGllbnRTZWNyZXQ7XG4gICAgfVxuICAgIGNvbnN0IHJldCA9IGF3YWl0IHRoaXMuX3Bvc3RQYXJhbXMocGFyYW1zKTtcbiAgICByZXR1cm4gcmV0IGFzIFRva2VuUmVzcG9uc2U7XG4gIH1cblxuICAvKipcbiAgICogU2VuZCBhY2Nlc3MgdG9rZW4gcmVxdWVzdCB0byB0aGUgdG9rZW4gZW5kcG9pbnQuXG4gICAqIFdoZW4gYSBjb2RlIChzdHJpbmcpIGlzIHBhc3NlZCBpbiBmaXJzdCBhcmd1bWVudCwgaXQgd2lsbCB1c2UgV2ViIFNlcnZlciBBdXRoZW50aWNhdGlvbiBGbG93IChBdXRob3JpemF0aW9uIENvZGUgR3JhbnQpLlxuICAgKiBPdGhlcndpc2UsIGl0IHdpbGwgdXNlIHRoZSBzcGVjaWZpZWQgYGdyYW50X3R5cGVgIGFuZCBwYXNzIHBhcmFtZXRlcnMgdG8gdGhlIGVuZHBvaW50LlxuICAgKi9cbiAgYXN5bmMgcmVxdWVzdFRva2VuKFxuICAgIGNvZGVPclBhcmFtczogc3RyaW5nIHwgeyBncmFudF90eXBlOiBzdHJpbmc7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfSxcbiAgICBwYXJhbXM6IHsgW3Byb3A6IHN0cmluZ106IHN0cmluZyB9ID0ge30sXG4gICk6IFByb21pc2U8VG9rZW5SZXNwb25zZT4ge1xuICAgIGlmIChcbiAgICAgIHR5cGVvZiBjb2RlT3JQYXJhbXMgPT09ICdzdHJpbmcnICYmXG4gICAgICAoIXRoaXMuY2xpZW50SWQgfHwgIXRoaXMucmVkaXJlY3RVcmkpXG4gICAgKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdObyBPQXV0aDIgY2xpZW50IGlkIG9yIHJlZGlyZWN0IHVyaSBjb25maWd1cmF0aW9uIGlzIHNwZWNpZmllZCcsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBfcGFyYW1zOiB7IFtwcm9wOiBzdHJpbmddOiBzdHJpbmcgfSA9IHtcbiAgICAgIC4uLnBhcmFtcyxcbiAgICAgIC4uLih0eXBlb2YgY29kZU9yUGFyYW1zID09PSAnc3RyaW5nJ1xuICAgICAgICA/IHsgZ3JhbnRfdHlwZTogJ2F1dGhvcml6YXRpb25fY29kZScsIGNvZGU6IGNvZGVPclBhcmFtcyB9XG4gICAgICAgIDogY29kZU9yUGFyYW1zKSxcbiAgICB9O1xuICAgIGlmICh0aGlzLmNsaWVudElkKSB7XG4gICAgICBfcGFyYW1zLmNsaWVudF9pZCA9IHRoaXMuY2xpZW50SWQ7XG4gICAgfVxuICAgIGlmICh0aGlzLmNsaWVudFNlY3JldCkge1xuICAgICAgX3BhcmFtcy5jbGllbnRfc2VjcmV0ID0gdGhpcy5jbGllbnRTZWNyZXQ7XG4gICAgfVxuICAgIGlmICh0aGlzLnJlZGlyZWN0VXJpKSB7XG4gICAgICBfcGFyYW1zLnJlZGlyZWN0X3VyaSA9IHRoaXMucmVkaXJlY3RVcmk7XG4gICAgfVxuICAgIGNvbnN0IHJldCA9IGF3YWl0IHRoaXMuX3Bvc3RQYXJhbXMoX3BhcmFtcyk7XG4gICAgcmV0dXJuIHJldCBhcyBUb2tlblJlc3BvbnNlO1xuICB9XG5cbiAgLyoqXG4gICAqIE9BdXRoMiBVc2VybmFtZS1QYXNzd29yZCBGbG93IChSZXNvdXJjZSBPd25lciBQYXNzd29yZCBDcmVkZW50aWFscylcbiAgICovXG4gIGFzeW5jIGF1dGhlbnRpY2F0ZShcbiAgICB1c2VybmFtZTogc3RyaW5nLFxuICAgIHBhc3N3b3JkOiBzdHJpbmcsXG4gICk6IFByb21pc2U8VG9rZW5SZXNwb25zZT4ge1xuICAgIGlmICghdGhpcy5jbGllbnRJZCB8fCAhdGhpcy5jbGllbnRTZWNyZXQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gdmFsaWQgT0F1dGgyIGNsaWVudCBjb25maWd1cmF0aW9uIHNldCcpO1xuICAgIH1cbiAgICBjb25zdCByZXQgPSBhd2FpdCB0aGlzLl9wb3N0UGFyYW1zKHtcbiAgICAgIGdyYW50X3R5cGU6ICdwYXNzd29yZCcsXG4gICAgICB1c2VybmFtZSxcbiAgICAgIHBhc3N3b3JkLFxuICAgICAgY2xpZW50X2lkOiB0aGlzLmNsaWVudElkLFxuICAgICAgY2xpZW50X3NlY3JldDogdGhpcy5jbGllbnRTZWNyZXQsXG4gICAgfSk7XG4gICAgcmV0dXJuIHJldCBhcyBUb2tlblJlc3BvbnNlO1xuICB9XG5cbiAgLyoqXG4gICAqIE9BdXRoMiBSZXZva2UgU2Vzc2lvbiBUb2tlblxuICAgKi9cbiAgYXN5bmMgcmV2b2tlVG9rZW4odG9rZW46IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5fdHJhbnNwb3J0Lmh0dHBSZXF1ZXN0KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsOiB0aGlzLnJldm9rZVNlcnZpY2VVcmwsXG4gICAgICBib2R5OiBxdWVyeXN0cmluZy5zdHJpbmdpZnkoeyB0b2tlbiB9KSxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQnLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA+PSA0MDApIHtcbiAgICAgIGxldCByZXM6IGFueSA9IHF1ZXJ5c3RyaW5nLnBhcnNlKHJlc3BvbnNlLmJvZHkpO1xuICAgICAgaWYgKCFyZXMgfHwgIXJlcy5lcnJvcikge1xuICAgICAgICByZXMgPSB7XG4gICAgICAgICAgZXJyb3I6IGBFUlJPUl9IVFRQXyR7cmVzcG9uc2Uuc3RhdHVzQ29kZX1gLFxuICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uOiByZXNwb25zZS5ib2R5LFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IChjbGFzcyBleHRlbmRzIEVycm9yIHtcbiAgICAgICAgY29uc3RydWN0b3Ioe1xuICAgICAgICAgIGVycm9yLFxuICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uLFxuICAgICAgICB9OiB7XG4gICAgICAgICAgZXJyb3I6IHN0cmluZztcbiAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogc3RyaW5nO1xuICAgICAgICB9KSB7XG4gICAgICAgICAgc3VwZXIoZXJyb3JfZGVzY3JpcHRpb24pO1xuICAgICAgICAgIHRoaXMubmFtZSA9IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9KShyZXMpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgYXN5bmMgX3Bvc3RQYXJhbXMocGFyYW1zOiB7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfSk6IFByb21pc2U8YW55PiB7XG4gICAgaWYgKHRoaXMuY29kZVZlcmlmaWVyKSBwYXJhbXMuY29kZV92ZXJpZmllciA9IHRoaXMuY29kZVZlcmlmaWVyO1xuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLl90cmFuc3BvcnQuaHR0cFJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmw6IHRoaXMudG9rZW5TZXJ2aWNlVXJsLFxuICAgICAgYm9keTogcXVlcnlzdHJpbmcuc3RyaW5naWZ5KHBhcmFtcyksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgbGV0IHJlcztcbiAgICB0cnkge1xuICAgICAgcmVzID0gSlNPTi5wYXJzZShyZXNwb25zZS5ib2R5KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvKiBlc2xpbnQtZGlzYWJsZSBuby1lbXB0eSAqL1xuICAgIH1cbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA+PSA0MDApIHtcbiAgICAgIHJlcyA9IHJlcyB8fCB7XG4gICAgICAgIGVycm9yOiBgRVJST1JfSFRUUF8ke3Jlc3BvbnNlLnN0YXR1c0NvZGV9YCxcbiAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IHJlc3BvbnNlLmJvZHksXG4gICAgICB9O1xuICAgICAgdGhyb3cgbmV3IChjbGFzcyBleHRlbmRzIEVycm9yIHtcbiAgICAgICAgY29uc3RydWN0b3Ioe1xuICAgICAgICAgIGVycm9yLFxuICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uLFxuICAgICAgICB9OiB7XG4gICAgICAgICAgZXJyb3I6IHN0cmluZztcbiAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogc3RyaW5nO1xuICAgICAgICB9KSB7XG4gICAgICAgICAgc3VwZXIoZXJyb3JfZGVzY3JpcHRpb24pO1xuICAgICAgICAgIHRoaXMubmFtZSA9IGVycm9yO1xuICAgICAgICB9XG4gICAgICB9KShyZXMpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IE9BdXRoMjtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQSxTQUFRQSxVQUFVLEVBQUVDLFdBQVcsUUFBTyxRQUFRO0FBQzlDLE9BQU9DLFdBQVcsTUFBTSxhQUFhO0FBQ3JDLE9BQU9DLFNBQVMsSUFBR0Msa0JBQWtCLEVBQUVDLGdCQUFnQixRQUFPLGFBQWE7QUFHM0UsSUFBTUMsbUJBQW1CLEdBQUc7RUFDMUJDLFFBQVEsRUFBRTtBQUNaLENBQUM7O0FBRUQ7QUFDQTtBQUNBLFNBQVNDLGVBQWVBLENBQUNDLGFBQXFCLEVBQVU7RUFDdEQ7RUFDQTtFQUNBLE9BQU9BLGFBQWEsQ0FDakJDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQ25CQSxPQUFPLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUNuQkEsT0FBTyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUM7QUFDdEI7O0FBRUE7QUFDQTtBQUNBOztBQStDQTtBQUNBO0FBQ0E7QUFDQSxXQUFhQyxNQUFNO0VBWWpCO0FBQ0Y7QUFDQTtFQUNFLFNBQUFBLE9BQVlDLE1BQW9CLEVBQUU7SUFBQUMsZUFBQSxPQUFBRixNQUFBO0lBQ2hDLElBQ0VKLFFBQVEsR0FVTkssTUFBTSxDQVZSTCxRQUFRO01BQ1JPLGVBQWUsR0FTYkYsTUFBTSxDQVRSRSxlQUFlO01BQ2ZDLGVBQWUsR0FRYkgsTUFBTSxDQVJSRyxlQUFlO01BQ2ZDLGdCQUFnQixHQU9kSixNQUFNLENBUFJJLGdCQUFnQjtNQUNoQkMsUUFBUSxHQU1OTCxNQUFNLENBTlJLLFFBQVE7TUFDUkMsWUFBWSxHQUtWTixNQUFNLENBTFJNLFlBQVk7TUFDWkMsV0FBVyxHQUlUUCxNQUFNLENBSlJPLFdBQVc7TUFDWEMsUUFBUSxHQUdOUixNQUFNLENBSFJRLFFBQVE7TUFDUkMsU0FBUyxHQUVQVCxNQUFNLENBRlJTLFNBQVM7TUFDVEMsV0FBVyxHQUNUVixNQUFNLENBRFJVLFdBQVc7SUFFYixJQUFJUixlQUFlLElBQUlDLGVBQWUsRUFBRTtNQUFBLElBQUFRLFFBQUE7TUFDdEMsSUFBSSxDQUFDaEIsUUFBUSxHQUFHaUIsc0JBQUEsQ0FBQUQsUUFBQSxHQUFBVCxlQUFlLENBQUNXLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBQUMsSUFBQSxDQUFBSCxRQUFBLEVBQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDSSxJQUFJLENBQUMsR0FBRyxDQUFDO01BQ2hFLElBQUksQ0FBQ2IsZUFBZSxHQUFHQSxlQUFlO01BQ3RDLElBQUksQ0FBQ0MsZUFBZSxHQUFHQSxlQUFlO01BQ3RDLElBQUksQ0FBQ0MsZ0JBQWdCLEdBQ25CQSxnQkFBZ0IsT0FBQVksTUFBQSxDQUFPLElBQUksQ0FBQ3JCLFFBQVEsNEJBQXlCO0lBQ2pFLENBQUMsTUFBTTtNQUFBLElBQUFzQixTQUFBLEVBQUFDLFNBQUEsRUFBQUMsU0FBQSxFQUFBQyxTQUFBO01BQ0wsSUFBSSxDQUFDekIsUUFBUSxHQUFHQSxRQUFRLGFBQVJBLFFBQVEsY0FBUkEsUUFBUSxHQUFJRCxtQkFBbUIsQ0FBQ0MsUUFBUTtNQUV4RCxJQUFNMEIsVUFBVSxHQUFHQyx5QkFBQSxDQUFBTCxTQUFBLE9BQUksQ0FBQ3RCLFFBQVEsRUFBQW1CLElBQUEsQ0FBQUcsU0FBQSxFQUFVLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHO01BRXpELElBQUksQ0FBQ2YsZUFBZSxHQUFBcUIsdUJBQUEsQ0FBQUwsU0FBQSxNQUFBRixNQUFBLENBQU0sSUFBSSxDQUFDckIsUUFBUSxHQUFBbUIsSUFBQSxDQUFBSSxTQUFBLEVBQUdHLFVBQVUsOEJBQTJCO01BQy9FLElBQUksQ0FBQ2xCLGVBQWUsR0FBQW9CLHVCQUFBLENBQUFKLFNBQUEsTUFBQUgsTUFBQSxDQUFNLElBQUksQ0FBQ3JCLFFBQVEsR0FBQW1CLElBQUEsQ0FBQUssU0FBQSxFQUFHRSxVQUFVLDBCQUF1QjtNQUMzRSxJQUFJLENBQUNqQixnQkFBZ0IsR0FBQW1CLHVCQUFBLENBQUFILFNBQUEsTUFBQUosTUFBQSxDQUFNLElBQUksQ0FBQ3JCLFFBQVEsR0FBQW1CLElBQUEsQ0FBQU0sU0FBQSxFQUFHQyxVQUFVLDJCQUF3QjtJQUMvRTtJQUNBLElBQUksQ0FBQ2hCLFFBQVEsR0FBR0EsUUFBUTtJQUN4QixJQUFJLENBQUNDLFlBQVksR0FBR0EsWUFBWTtJQUNoQyxJQUFJLENBQUNDLFdBQVcsR0FBR0EsV0FBVztJQUM5QixJQUFJQyxRQUFRLEVBQUU7TUFDWixJQUFJLENBQUNnQixVQUFVLEdBQUcsSUFBSS9CLGdCQUFnQixDQUFDZSxRQUFRLENBQUM7SUFDbEQsQ0FBQyxNQUFNLElBQUlDLFNBQVMsRUFBRTtNQUNwQixJQUFJLENBQUNlLFVBQVUsR0FBRyxJQUFJaEMsa0JBQWtCLENBQUNpQixTQUFTLENBQUM7SUFDckQsQ0FBQyxNQUFNO01BQ0wsSUFBSSxDQUFDZSxVQUFVLEdBQUcsSUFBSWpDLFNBQVMsQ0FBQyxDQUFDO0lBQ25DO0lBQ0EsSUFBSW1CLFdBQVcsRUFBRTtNQUNmO01BQ0EsSUFBSSxDQUFDZSxZQUFZLEdBQUc3QixlQUFlLENBQ2pDUCxXQUFXLENBQUNxQyxJQUFJLENBQUNDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsUUFBUSxDQUMvQyxDQUFDO0lBQ0g7RUFDRjs7RUFFQTtBQUNGO0FBQ0E7RUFGRSxPQUFBQyxZQUFBLENBQUE5QixNQUFBO0lBQUErQixHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBQyxtQkFBbUJBLENBQUEsRUFBa0M7TUFBQSxJQUFBQyxTQUFBO01BQUEsSUFBakNDLE1BQTBCLEdBQUFDLFNBQUEsQ0FBQUMsTUFBQSxRQUFBRCxTQUFBLFFBQUFFLFNBQUEsR0FBQUYsU0FBQSxNQUFHLENBQUMsQ0FBQztNQUNqRCxJQUFJLElBQUksQ0FBQ1YsWUFBWSxFQUFFO1FBQ3JCO1FBQ0E7UUFDQVMsTUFBTSxDQUFDSSxjQUFjLEdBQUcxQyxlQUFlLENBQ3JDUixVQUFVLENBQUMsUUFBUSxDQUFDLENBQUNtRCxNQUFNLENBQUMsSUFBSSxDQUFDZCxZQUFZLENBQUMsQ0FBQ2UsTUFBTSxDQUFDLFFBQVEsQ0FDaEUsQ0FBQztNQUNIO01BRUEsSUFBTUMsT0FBTyxHQUFBQyxhQUFBLENBQUFBLGFBQUEsS0FDUlIsTUFBTTtRQUNUUyxhQUFhLEVBQUUsTUFBTTtRQUNyQkMsU0FBUyxFQUFFLElBQUksQ0FBQ3ZDLFFBQVE7UUFDeEJ3QyxZQUFZLEVBQUUsSUFBSSxDQUFDdEM7TUFBVyxFQUMvQjtNQUNELE9BQ0UsSUFBSSxDQUFDTCxlQUFlLElBQ25CNEMseUJBQUEsQ0FBQWIsU0FBQSxPQUFJLENBQUMvQixlQUFlLEVBQUFZLElBQUEsQ0FBQW1CLFNBQUEsRUFBVSxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQ2hEM0MsV0FBVyxDQUFDeUQsU0FBUyxDQUFDTixPQUFrQyxDQUFDO0lBRTdEOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFYLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFpQixjQUFBLEdBQUFDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBQyxRQUFtQkMsYUFBb0I7UUFBQSxJQUFBbkIsTUFBQSxFQUFBb0IsR0FBQTtRQUFBLE9BQUFKLG1CQUFBLENBQUFLLElBQUEsVUFBQUMsU0FBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFDLElBQUEsR0FBQUQsU0FBQSxDQUFBRSxJQUFBO1lBQUE7Y0FBQSxJQUNoQyxJQUFJLENBQUN0RCxRQUFRO2dCQUFBb0QsU0FBQSxDQUFBRSxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUNWLElBQUlDLEtBQUssQ0FBQyw4Q0FBOEMsQ0FBQztZQUFBO2NBRTNEMUIsTUFBa0MsR0FBRztnQkFDekMyQixVQUFVLEVBQUUsZUFBZTtnQkFDM0JDLGFBQWEsRUFBRVQsYUFBWTtnQkFDM0JULFNBQVMsRUFBRSxJQUFJLENBQUN2QztjQUNsQixDQUFDO2NBQ0QsSUFBSSxJQUFJLENBQUNDLFlBQVksRUFBRTtnQkFDckI0QixNQUFNLENBQUM2QixhQUFhLEdBQUcsSUFBSSxDQUFDekQsWUFBWTtjQUMxQztjQUFDbUQsU0FBQSxDQUFBRSxJQUFBO2NBQUEsT0FDaUIsSUFBSSxDQUFDSyxXQUFXLENBQUM5QixNQUFNLENBQUM7WUFBQTtjQUFwQ29CLEdBQUcsR0FBQUcsU0FBQSxDQUFBUSxJQUFBO2NBQUEsT0FBQVIsU0FBQSxDQUFBUyxNQUFBLFdBQ0ZaLEdBQUc7WUFBQTtZQUFBO2NBQUEsT0FBQUcsU0FBQSxDQUFBVSxJQUFBO1VBQUE7UUFBQSxHQUFBZixPQUFBO01BQUEsQ0FDWDtNQUFBLFNBZEtDLFlBQVlBLENBQUFlLEVBQUE7UUFBQSxPQUFBcEIsY0FBQSxDQUFBcUIsS0FBQSxPQUFBbEMsU0FBQTtNQUFBO01BQUEsT0FBWmtCLFlBQVk7SUFBQTtJQWdCbEI7QUFDRjtBQUNBO0FBQ0E7QUFDQTtJQUpFO0VBQUE7SUFBQXZCLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUF1QyxhQUFBLEdBQUFyQixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBS0EsU0FBQW9CLFNBQ0VDLFlBQXFFO1FBQUEsSUFBQXRDLE1BQUE7VUFBQU8sT0FBQTtVQUFBYSxHQUFBO1VBQUFtQixNQUFBLEdBQUF0QyxTQUFBO1FBQUEsT0FBQWUsbUJBQUEsQ0FBQUssSUFBQSxVQUFBbUIsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFqQixJQUFBLEdBQUFpQixTQUFBLENBQUFoQixJQUFBO1lBQUE7Y0FDckV6QixNQUFrQyxHQUFBdUMsTUFBQSxDQUFBckMsTUFBQSxRQUFBcUMsTUFBQSxRQUFBcEMsU0FBQSxHQUFBb0MsTUFBQSxNQUFHLENBQUMsQ0FBQztjQUFBLE1BR3JDLE9BQU9ELFlBQVksS0FBSyxRQUFRLEtBQy9CLENBQUMsSUFBSSxDQUFDbkUsUUFBUSxJQUFJLENBQUMsSUFBSSxDQUFDRSxXQUFXLENBQUM7Z0JBQUFvRSxTQUFBLENBQUFoQixJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUUvQixJQUFJQyxLQUFLLENBQ2IsZ0VBQ0YsQ0FBQztZQUFBO2NBRUduQixPQUFtQyxHQUFBQyxhQUFBLENBQUFBLGFBQUEsS0FDcENSLE1BQU0sR0FDTCxPQUFPc0MsWUFBWSxLQUFLLFFBQVEsR0FDaEM7Z0JBQUVYLFVBQVUsRUFBRSxvQkFBb0I7Z0JBQUVlLElBQUksRUFBRUo7Y0FBYSxDQUFDLEdBQ3hEQSxZQUFZO2NBRWxCLElBQUksSUFBSSxDQUFDbkUsUUFBUSxFQUFFO2dCQUNqQm9DLE9BQU8sQ0FBQ0csU0FBUyxHQUFHLElBQUksQ0FBQ3ZDLFFBQVE7Y0FDbkM7Y0FDQSxJQUFJLElBQUksQ0FBQ0MsWUFBWSxFQUFFO2dCQUNyQm1DLE9BQU8sQ0FBQ3NCLGFBQWEsR0FBRyxJQUFJLENBQUN6RCxZQUFZO2NBQzNDO2NBQ0EsSUFBSSxJQUFJLENBQUNDLFdBQVcsRUFBRTtnQkFDcEJrQyxPQUFPLENBQUNJLFlBQVksR0FBRyxJQUFJLENBQUN0QyxXQUFXO2NBQ3pDO2NBQUNvRSxTQUFBLENBQUFoQixJQUFBO2NBQUEsT0FDaUIsSUFBSSxDQUFDSyxXQUFXLENBQUN2QixPQUFPLENBQUM7WUFBQTtjQUFyQ2EsR0FBRyxHQUFBcUIsU0FBQSxDQUFBVixJQUFBO2NBQUEsT0FBQVUsU0FBQSxDQUFBVCxNQUFBLFdBQ0ZaLEdBQUc7WUFBQTtZQUFBO2NBQUEsT0FBQXFCLFNBQUEsQ0FBQVIsSUFBQTtVQUFBO1FBQUEsR0FBQUksUUFBQTtNQUFBLENBQ1g7TUFBQSxTQTdCS00sWUFBWUEsQ0FBQUMsR0FBQTtRQUFBLE9BQUFSLGFBQUEsQ0FBQUQsS0FBQSxPQUFBbEMsU0FBQTtNQUFBO01BQUEsT0FBWjBDLFlBQVk7SUFBQTtJQStCbEI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBL0MsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQWdELGFBQUEsR0FBQTlCLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBNkIsU0FDRUMsUUFBZ0IsRUFDaEJDLFFBQWdCO1FBQUEsSUFBQTVCLEdBQUE7UUFBQSxPQUFBSixtQkFBQSxDQUFBSyxJQUFBLFVBQUE0QixVQUFBQyxTQUFBO1VBQUEsa0JBQUFBLFNBQUEsQ0FBQTFCLElBQUEsR0FBQTBCLFNBQUEsQ0FBQXpCLElBQUE7WUFBQTtjQUFBLE1BRVosQ0FBQyxJQUFJLENBQUN0RCxRQUFRLElBQUksQ0FBQyxJQUFJLENBQUNDLFlBQVk7Z0JBQUE4RSxTQUFBLENBQUF6QixJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUNoQyxJQUFJQyxLQUFLLENBQUMsMENBQTBDLENBQUM7WUFBQTtjQUFBd0IsU0FBQSxDQUFBekIsSUFBQTtjQUFBLE9BRTNDLElBQUksQ0FBQ0ssV0FBVyxDQUFDO2dCQUNqQ0gsVUFBVSxFQUFFLFVBQVU7Z0JBQ3RCb0IsUUFBUSxFQUFSQSxRQUFRO2dCQUNSQyxRQUFRLEVBQVJBLFFBQVE7Z0JBQ1J0QyxTQUFTLEVBQUUsSUFBSSxDQUFDdkMsUUFBUTtnQkFDeEIwRCxhQUFhLEVBQUUsSUFBSSxDQUFDekQ7Y0FDdEIsQ0FBQyxDQUFDO1lBQUE7Y0FOSWdELEdBQUcsR0FBQThCLFNBQUEsQ0FBQW5CLElBQUE7Y0FBQSxPQUFBbUIsU0FBQSxDQUFBbEIsTUFBQSxXQU9GWixHQUFHO1lBQUE7WUFBQTtjQUFBLE9BQUE4QixTQUFBLENBQUFqQixJQUFBO1VBQUE7UUFBQSxHQUFBYSxRQUFBO01BQUEsQ0FDWDtNQUFBLFNBZktLLFlBQVlBLENBQUFDLEdBQUEsRUFBQUMsR0FBQTtRQUFBLE9BQUFSLGFBQUEsQ0FBQVYsS0FBQSxPQUFBbEMsU0FBQTtNQUFBO01BQUEsT0FBWmtELFlBQVk7SUFBQTtJQWlCbEI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBdkQsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQXlELFlBQUEsR0FBQXZDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBc0MsU0FBa0JDLEtBQWE7UUFBQSxJQUFBQyxRQUFBLEVBQUFDLEdBQUE7UUFBQSxPQUFBMUMsbUJBQUEsQ0FBQUssSUFBQSxVQUFBc0MsVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUFwQyxJQUFBLEdBQUFvQyxVQUFBLENBQUFuQyxJQUFBO1lBQUE7Y0FBQW1DLFVBQUEsQ0FBQW5DLElBQUE7Y0FBQSxPQUNOLElBQUksQ0FBQ25DLFVBQVUsQ0FBQ3VFLFdBQVcsQ0FBQztnQkFDakRDLE1BQU0sRUFBRSxNQUFNO2dCQUNkQyxHQUFHLEVBQUUsSUFBSSxDQUFDN0YsZ0JBQWdCO2dCQUMxQjhGLElBQUksRUFBRTVHLFdBQVcsQ0FBQ3lELFNBQVMsQ0FBQztrQkFBRTJDLEtBQUssRUFBTEE7Z0JBQU0sQ0FBQyxDQUFDO2dCQUN0Q1MsT0FBTyxFQUFFO2tCQUNQLGNBQWMsRUFBRTtnQkFDbEI7Y0FDRixDQUFDLENBQUM7WUFBQTtjQVBJUixRQUFRLEdBQUFHLFVBQUEsQ0FBQTdCLElBQUE7Y0FBQSxNQVFWMEIsUUFBUSxDQUFDUyxVQUFVLElBQUksR0FBRztnQkFBQU4sVUFBQSxDQUFBbkMsSUFBQTtnQkFBQTtjQUFBO2NBQ3hCaUMsR0FBUSxHQUFHdEcsV0FBVyxDQUFDK0csS0FBSyxDQUFDVixRQUFRLENBQUNPLElBQUksQ0FBQztjQUMvQyxJQUFJLENBQUNOLEdBQUcsSUFBSSxDQUFDQSxHQUFHLENBQUNVLEtBQUssRUFBRTtnQkFDdEJWLEdBQUcsR0FBRztrQkFDSlUsS0FBSyxnQkFBQXRGLE1BQUEsQ0FBZ0IyRSxRQUFRLENBQUNTLFVBQVUsQ0FBRTtrQkFDMUNHLGlCQUFpQixFQUFFWixRQUFRLENBQUNPO2dCQUM5QixDQUFDO2NBQ0g7Y0FBQyxNQUNLLDRCQUFBTSxNQUFBO2dCQUNKLFNBQUFDLE9BQUFDLElBQUEsRUFNRztrQkFBQSxJQUFBQyxLQUFBO2tCQUFBLElBTERMLEtBQUssR0FBQUksSUFBQSxDQUFMSixLQUFLO29CQUNMQyxpQkFBaUIsR0FBQUcsSUFBQSxDQUFqQkgsaUJBQWlCO2tCQUFBdEcsZUFBQSxPQUFBd0csTUFBQTtrQkFLakJFLEtBQUEsR0FBQUMsVUFBQSxPQUFBSCxNQUFBLEdBQU1GLGlCQUFpQjtrQkFDdkJJLEtBQUEsQ0FBS0UsSUFBSSxHQUFHUCxLQUFLO2tCQUFDLE9BQUFLLEtBQUE7Z0JBQ3BCO2dCQUFDRyxTQUFBLENBQUFMLE1BQUEsRUFBQUQsTUFBQTtnQkFBQSxPQUFBM0UsWUFBQSxDQUFBNEUsTUFBQTtjQUFBLGVBQUFNLGdCQUFBLENBVnNCbkQsS0FBSyxJQVczQmdDLEdBQUcsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBRSxVQUFBLENBQUEzQixJQUFBO1VBQUE7UUFBQSxHQUFBc0IsUUFBQTtNQUFBLENBRVY7TUFBQSxTQTlCS3VCLFdBQVdBLENBQUFDLEdBQUE7UUFBQSxPQUFBekIsWUFBQSxDQUFBbkIsS0FBQSxPQUFBbEMsU0FBQTtNQUFBO01BQUEsT0FBWDZFLFdBQVc7SUFBQTtJQWdDakI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBbEYsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQW1GLFlBQUEsR0FBQWpFLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBZ0UsU0FBa0JqRixNQUFrQztRQUFBLElBQUF5RCxRQUFBLEVBQUFDLEdBQUE7UUFBQSxPQUFBMUMsbUJBQUEsQ0FBQUssSUFBQSxVQUFBNkQsVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUEzRCxJQUFBLEdBQUEyRCxVQUFBLENBQUExRCxJQUFBO1lBQUE7Y0FDbEQsSUFBSSxJQUFJLENBQUNsQyxZQUFZLEVBQUVTLE1BQU0sQ0FBQ29GLGFBQWEsR0FBRyxJQUFJLENBQUM3RixZQUFZO2NBQUM0RixVQUFBLENBQUExRCxJQUFBO2NBQUEsT0FFekMsSUFBSSxDQUFDbkMsVUFBVSxDQUFDdUUsV0FBVyxDQUFDO2dCQUNqREMsTUFBTSxFQUFFLE1BQU07Z0JBQ2RDLEdBQUcsRUFBRSxJQUFJLENBQUM5RixlQUFlO2dCQUN6QitGLElBQUksRUFBRTVHLFdBQVcsQ0FBQ3lELFNBQVMsQ0FBQ2IsTUFBTSxDQUFDO2dCQUNuQ2lFLE9BQU8sRUFBRTtrQkFDUCxjQUFjLEVBQUU7Z0JBQ2xCO2NBQ0YsQ0FBQyxDQUFDO1lBQUE7Y0FQSVIsUUFBUSxHQUFBMEIsVUFBQSxDQUFBcEQsSUFBQTtjQVNkLElBQUk7Z0JBQ0YyQixHQUFHLEdBQUcyQixJQUFJLENBQUNsQixLQUFLLENBQUNWLFFBQVEsQ0FBQ08sSUFBSSxDQUFDO2NBQ2pDLENBQUMsQ0FBQyxPQUFPc0IsQ0FBQyxFQUFFO2dCQUNWO2NBQUE7Y0FDRCxNQUNHN0IsUUFBUSxDQUFDUyxVQUFVLElBQUksR0FBRztnQkFBQWlCLFVBQUEsQ0FBQTFELElBQUE7Z0JBQUE7Y0FBQTtjQUM1QmlDLEdBQUcsR0FBR0EsR0FBRyxJQUFJO2dCQUNYVSxLQUFLLGdCQUFBdEYsTUFBQSxDQUFnQjJFLFFBQVEsQ0FBQ1MsVUFBVSxDQUFFO2dCQUMxQ0csaUJBQWlCLEVBQUVaLFFBQVEsQ0FBQ087Y0FDOUIsQ0FBQztjQUFDLE1BQ0ksNEJBQUF1QixPQUFBO2dCQUNKLFNBQUFDLFFBQUFDLEtBQUEsRUFNRztrQkFBQSxJQUFBQyxNQUFBO2tCQUFBLElBTER0QixLQUFLLEdBQUFxQixLQUFBLENBQUxyQixLQUFLO29CQUNMQyxpQkFBaUIsR0FBQW9CLEtBQUEsQ0FBakJwQixpQkFBaUI7a0JBQUF0RyxlQUFBLE9BQUF5SCxPQUFBO2tCQUtqQkUsTUFBQSxHQUFBaEIsVUFBQSxPQUFBYyxPQUFBLEdBQU1uQixpQkFBaUI7a0JBQ3ZCcUIsTUFBQSxDQUFLZixJQUFJLEdBQUdQLEtBQUs7a0JBQUMsT0FBQXNCLE1BQUE7Z0JBQ3BCO2dCQUFDZCxTQUFBLENBQUFZLE9BQUEsRUFBQUQsT0FBQTtnQkFBQSxPQUFBNUYsWUFBQSxDQUFBNkYsT0FBQTtjQUFBLGVBQUFYLGdCQUFBLENBVnNCbkQsS0FBSyxJQVczQmdDLEdBQUcsQ0FBQztZQUFBO2NBQUEsT0FBQXlCLFVBQUEsQ0FBQW5ELE1BQUEsV0FFRjBCLEdBQUc7WUFBQTtZQUFBO2NBQUEsT0FBQXlCLFVBQUEsQ0FBQWxELElBQUE7VUFBQTtRQUFBLEdBQUFnRCxRQUFBO01BQUEsQ0FDWDtNQUFBLFNBcENLbkQsV0FBV0EsQ0FBQTZELEdBQUE7UUFBQSxPQUFBWCxZQUFBLENBQUE3QyxLQUFBLE9BQUFsQyxTQUFBO01BQUE7TUFBQSxPQUFYNkIsV0FBVztJQUFBO0VBQUE7QUFBQTtBQXVDbkIsZUFBZWpFLE1BQU0iLCJpZ25vcmVMaXN0IjpbXX0=