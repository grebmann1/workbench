import "core-js/modules/es.array.push.js";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context, _context2; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context = ownKeys(Object(t), !0)).call(_context, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context2 = ownKeys(Object(t))).call(_context2, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
/**
 *
 */

import { Parser as csvParse } from 'csv-parse';
import { parse as csvParseSync } from 'csv-parse/sync';
import { stringify as csvStringify } from 'csv-stringify';
import { stringify as csvStringifySync } from 'csv-stringify/sync';

// The following column delimiters are supported by the Bulk V2 API:
// https://developer.salesforce.com/docs/atlas.en-us.api_asynch.meta/api_asynch/create_job.htm
//
// BACKQUOTE, CARET, COMMA, PIPE, SEMICOLON, TAB
var csvDelimiters = ['`', '^', ',', '|', ';', '	'];

/**
 * @private
 */
export function parseCSV(str, options) {
  return csvParseSync(str, _objectSpread(_objectSpread({}, options), {}, {
    columns: true,
    delimiter: csvDelimiters
  }));
}

/**
 * @private
 */
export function toCSV(records, options) {
  return csvStringifySync(records, _objectSpread(_objectSpread({}, options), {}, {
    header: true
  }));
}

/**
 * @private
 */
export function parseCSVStream(options) {
  return new csvParse(_objectSpread(_objectSpread({}, options), {}, {
    columns: true
  }));
}

/**
 * @private
 */
export function serializeCSVStream(options) {
  return csvStringify(_objectSpread(_objectSpread({}, options), {}, {
    header: true
  }));
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQYXJzZXIiLCJjc3ZQYXJzZSIsInBhcnNlIiwiY3N2UGFyc2VTeW5jIiwic3RyaW5naWZ5IiwiY3N2U3RyaW5naWZ5IiwiY3N2U3RyaW5naWZ5U3luYyIsImNzdkRlbGltaXRlcnMiLCJwYXJzZUNTViIsInN0ciIsIm9wdGlvbnMiLCJfb2JqZWN0U3ByZWFkIiwiY29sdW1ucyIsImRlbGltaXRlciIsInRvQ1NWIiwicmVjb3JkcyIsImhlYWRlciIsInBhcnNlQ1NWU3RyZWFtIiwic2VyaWFsaXplQ1NWU3RyZWFtIl0sInNvdXJjZXMiOlsiLi4vc3JjL2Nzdi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqXG4gKi9cbmltcG9ydCB7IFRyYW5zZm9ybSB9IGZyb20gJ3N0cmVhbSc7XG5pbXBvcnQgeyBQYXJzZXIgYXMgY3N2UGFyc2UgfSBmcm9tICdjc3YtcGFyc2UnO1xuaW1wb3J0IHsgT3B0aW9ucyBhcyBQYXJzZU9wdHMsIHBhcnNlIGFzIGNzdlBhcnNlU3luYyB9IGZyb20gJ2Nzdi1wYXJzZS9zeW5jJztcbmltcG9ydCB7XG4gIE9wdGlvbnMgYXMgU3RyaW5naWZ5T3B0cyxcbiAgc3RyaW5naWZ5IGFzIGNzdlN0cmluZ2lmeSxcbn0gZnJvbSAnY3N2LXN0cmluZ2lmeSc7XG5pbXBvcnQgeyBzdHJpbmdpZnkgYXMgY3N2U3RyaW5naWZ5U3luYyB9IGZyb20gJ2Nzdi1zdHJpbmdpZnkvc3luYyc7XG5cbi8vIFRoZSBmb2xsb3dpbmcgY29sdW1uIGRlbGltaXRlcnMgYXJlIHN1cHBvcnRlZCBieSB0aGUgQnVsayBWMiBBUEk6XG4vLyBodHRwczovL2RldmVsb3Blci5zYWxlc2ZvcmNlLmNvbS9kb2NzL2F0bGFzLmVuLXVzLmFwaV9hc3luY2gubWV0YS9hcGlfYXN5bmNoL2NyZWF0ZV9qb2IuaHRtXG4vL1xuLy8gQkFDS1FVT1RFLCBDQVJFVCwgQ09NTUEsIFBJUEUsIFNFTUlDT0xPTiwgVEFCXG5jb25zdCBjc3ZEZWxpbWl0ZXJzID0gWydgJywnXicsJywnLCd8JywnOycsJ1x0J11cblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VDU1Yoc3RyOiBzdHJpbmcsIG9wdGlvbnM/OiBQYXJzZU9wdHMpOiBPYmplY3RbXSB7XG4gIHJldHVybiBjc3ZQYXJzZVN5bmMoc3RyLCB7IC4uLm9wdGlvbnMsIGNvbHVtbnM6IHRydWUsIGRlbGltaXRlcjogY3N2RGVsaW1pdGVycyB9KTtcbn1cblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5leHBvcnQgZnVuY3Rpb24gdG9DU1YocmVjb3JkczogT2JqZWN0W10sIG9wdGlvbnM/OiBTdHJpbmdpZnlPcHRzKTogc3RyaW5nIHtcbiAgcmV0dXJuIGNzdlN0cmluZ2lmeVN5bmMocmVjb3JkcywgeyAuLi5vcHRpb25zLCBoZWFkZXI6IHRydWUgfSk7XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQ1NWU3RyZWFtKG9wdGlvbnM/OiBQYXJzZU9wdHMpOiBUcmFuc2Zvcm0ge1xuICByZXR1cm4gbmV3IGNzdlBhcnNlKHsgLi4ub3B0aW9ucywgY29sdW1uczogdHJ1ZSB9KTtcbn1cblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5leHBvcnQgZnVuY3Rpb24gc2VyaWFsaXplQ1NWU3RyZWFtKG9wdGlvbnM/OiBTdHJpbmdpZnlPcHRzKTogVHJhbnNmb3JtIHtcbiAgcmV0dXJuIGNzdlN0cmluZ2lmeSh7IC4uLm9wdGlvbnMsIGhlYWRlcjogdHJ1ZSB9KTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBOztBQUVBLFNBQVNBLE1BQU0sSUFBSUMsUUFBUSxRQUFRLFdBQVc7QUFDOUMsU0FBK0JDLEtBQUssSUFBSUMsWUFBWSxRQUFRLGdCQUFnQjtBQUM1RSxTQUVFQyxTQUFTLElBQUlDLFlBQVksUUFDcEIsZUFBZTtBQUN0QixTQUFTRCxTQUFTLElBQUlFLGdCQUFnQixRQUFRLG9CQUFvQjs7QUFFbEU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNQyxhQUFhLEdBQUcsQ0FBQyxHQUFHLEVBQUMsR0FBRyxFQUFDLEdBQUcsRUFBQyxHQUFHLEVBQUMsR0FBRyxFQUFDLEdBQUcsQ0FBQzs7QUFFL0M7QUFDQTtBQUNBO0FBQ0EsT0FBTyxTQUFTQyxRQUFRQSxDQUFDQyxHQUFXLEVBQUVDLE9BQW1CLEVBQVk7RUFDbkUsT0FBT1AsWUFBWSxDQUFDTSxHQUFHLEVBQUFFLGFBQUEsQ0FBQUEsYUFBQSxLQUFPRCxPQUFPO0lBQUVFLE9BQU8sRUFBRSxJQUFJO0lBQUVDLFNBQVMsRUFBRU47RUFBYSxFQUFFLENBQUM7QUFDbkY7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsT0FBTyxTQUFTTyxLQUFLQSxDQUFDQyxPQUFpQixFQUFFTCxPQUF1QixFQUFVO0VBQ3hFLE9BQU9KLGdCQUFnQixDQUFDUyxPQUFPLEVBQUFKLGFBQUEsQ0FBQUEsYUFBQSxLQUFPRCxPQUFPO0lBQUVNLE1BQU0sRUFBRTtFQUFJLEVBQUUsQ0FBQztBQUNoRTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLFNBQVNDLGNBQWNBLENBQUNQLE9BQW1CLEVBQWE7RUFDN0QsT0FBTyxJQUFJVCxRQUFRLENBQUFVLGFBQUEsQ0FBQUEsYUFBQSxLQUFNRCxPQUFPO0lBQUVFLE9BQU8sRUFBRTtFQUFJLEVBQUUsQ0FBQztBQUNwRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxPQUFPLFNBQVNNLGtCQUFrQkEsQ0FBQ1IsT0FBdUIsRUFBYTtFQUNyRSxPQUFPTCxZQUFZLENBQUFNLGFBQUEsQ0FBQUEsYUFBQSxLQUFNRCxPQUFPO0lBQUVNLE1BQU0sRUFBRTtFQUFJLEVBQUUsQ0FBQztBQUNuRCIsImlnbm9yZUxpc3QiOltdfQ==