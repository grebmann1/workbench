import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _get from "@babel/runtime-corejs3/helpers/get";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _superPropGet(t, o, e, r) { var p = _get(_getPrototypeOf(1 & r ? t.prototype : t), o, e); return 2 & r && "function" == typeof p ? function (t) { return p.apply(e, t); } : p; }
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.join.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.number.constructor.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/es.string.replace.js";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _startsWithInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/starts-with";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context6, _context7; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context6 = ownKeys(Object(t), !0)).call(_context6, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context7 = ownKeys(Object(t))).call(_context7, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
/**
 * @file Manages method call to SOAP endpoint
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import HttpApi, { isBrowser } from './http-api';
import { isMapObject, isObject } from './util/function';
import { getBodySize } from './util/get-body-size';
import { isJWTToken } from './util/jwt';

/**
 *
 */
function getPropsSchema(schema, schemaDict) {
  if (schema.extends && schemaDict[schema.extends]) {
    var extendSchema = schemaDict[schema.extends];
    return _objectSpread(_objectSpread({}, getPropsSchema(extendSchema, schemaDict)), schema.props);
  }
  return schema.props;
}
function isNillValue(value) {
  return value == null || isMapObject(value) && isMapObject(value.$) && value.$['xsi:nil'] === 'true';
}

/**
 *
 */
export function castTypeUsingSchema(value, schema) {
  var schemaDict = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  if (_Array$isArray(schema)) {
    var _context;
    var nillable = schema.length === 2 && schema[0] === '?';
    var schema_ = nillable ? schema[1] : schema[0];
    if (value == null) {
      return nillable ? null : [];
    }
    return _mapInstanceProperty(_context = _Array$isArray(value) ? value : [value]).call(_context, function (v) {
      return castTypeUsingSchema(v, schema_, schemaDict);
    });
  } else if (isMapObject(schema)) {
    var _context2;
    // if schema is Schema Definition, not schema element
    if ('type' in schema && 'props' in schema && isMapObject(schema.props)) {
      var props = getPropsSchema(schema, schemaDict);
      return castTypeUsingSchema(value, props, schemaDict);
    }
    var _nillable = '?' in schema;
    var _schema_ = '?' in schema ? schema['?'] : schema;
    if (_nillable && isNillValue(value)) {
      return null;
    }
    var obj = isMapObject(value) ? value : {};
    return _reduceInstanceProperty(_context2 = _Object$keys(_schema_)).call(_context2, function (o, k) {
      var s = _schema_[k];
      var v = obj[k];
      var nillable = _Array$isArray(s) && s.length === 2 && s[0] === '?' || isMapObject(s) && '?' in s || typeof s === 'string' && _startsWithInstanceProperty(s).call(s, '?');
      if (typeof v === 'undefined' && nillable) {
        return o;
      }
      return _objectSpread(_objectSpread({}, o), {}, _defineProperty({}, k, castTypeUsingSchema(v, s, schemaDict)));
    }, obj);
  } else {
    var _nillable2 = typeof schema === 'string' && _startsWithInstanceProperty(schema).call(schema, '?');
    var type = typeof schema === 'string' ? _nillable2 ? schema.substring(1) : schema : 'any';
    switch (type) {
      case 'string':
        return isNillValue(value) ? _nillable2 ? null : '' : String(value);
      case 'number':
        return isNillValue(value) ? _nillable2 ? null : 0 : Number(value);
      case 'boolean':
        return isNillValue(value) ? _nillable2 ? null : false : value === 'true';
      case 'null':
        return null;
      default:
        {
          if (schemaDict[type]) {
            var cvalue = castTypeUsingSchema(value, schemaDict[type], schemaDict);
            var isEmpty = isMapObject(cvalue) && _Object$keys(cvalue).length === 0;
            return isEmpty && _nillable2 ? null : cvalue;
          }
          return value;
        }
    }
  }
}

/**
 * @private
 */
function lookupValue(obj, propRegExps) {
  var regexp = propRegExps.shift();
  if (!regexp) {
    return obj;
  }
  if (isMapObject(obj)) {
    for (var _i = 0, _Object$keys2 = _Object$keys(obj); _i < _Object$keys2.length; _i++) {
      var prop = _Object$keys2[_i];
      if (regexp.test(prop)) {
        return lookupValue(obj[prop], propRegExps);
      }
    }
    return null;
  }
}

/**
 * @private
 */
function toXML(name, value) {
  if (isObject(name)) {
    value = name;
    name = null;
  }
  if (_Array$isArray(value)) {
    return _mapInstanceProperty(value).call(value, function (v) {
      return toXML(name, v);
    }).join('');
  } else {
    var attrs = [];
    if (value === null) {
      attrs.push('xsi:nil="true"');
      value = '';
    } else if (isMapObject(value)) {
      var elems = [];
      for (var _i2 = 0, _Object$keys3 = _Object$keys(value); _i2 < _Object$keys3.length; _i2++) {
        var k = _Object$keys3[_i2];
        var v = value[k];
        if (_startsWithInstanceProperty(k).call(k, '@')) {
          var _context3;
          var kk = k.substring(1);
          attrs.push(_concatInstanceProperty(_context3 = "".concat(kk, "=\"")).call(_context3, v, "\""));
        } else {
          elems.push(toXML(k, v));
        }
      }
      value = elems.join('');
    } else {
      value = String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
    }
    var startTag = name ? '<' + name + (attrs.length > 0 ? ' ' + attrs.join(' ') : '') + '>' : '';
    var endTag = name ? '</' + name + '>' : '';
    return startTag + value + endTag;
  }
}

/**
 *
 */

/**
 * Class for SOAP endpoint of Salesforce
 *
 * @protected
 * @class
 * @constructor
 * @param {Connection} conn - Connection instance
 * @param {Object} options - SOAP endpoint setting options
 * @param {String} options.endpointUrl - SOAP endpoint URL
 * @param {String} [options.xmlns] - XML namespace for method call (default is "urn:partner.soap.sforce.com")
 */
export var SOAP = /*#__PURE__*/function (_HttpApi) {
  function SOAP(conn, options) {
    var _this;
    _classCallCheck(this, SOAP);
    _this = _callSuper(this, SOAP, [conn, options]);
    if (_this._conn.accessToken && isJWTToken(_this._conn.accessToken)) {
      // We need to block SOAP requests with JWT tokens because the response is:
      // statusCode=500 | body="INVALID_SESSION_ID" (xml), which triggers session refresh and enters in an infinite loop
      throw new Error('SOAP API does not support JWT-based access tokens. You must disable the "Issue JSON Web Token (JWT)-based access tokens" setting in your Connected App or External Client App');
    }
    _this._endpointUrl = options.endpointUrl;
    _this._xmlns = options.xmlns || 'urn:partner.soap.sforce.com';
    _this._headers = options.headers || null;
    return _this;
  }

  /**
   * Invoke SOAP call using method and arguments
   */
  _inherits(SOAP, _HttpApi);
  return _createClass(SOAP, [{
    key: "invoke",
    value: (function () {
      var _invoke = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(method, args, schema, schemaDict) {
        var res;
        return _regeneratorRuntime.wrap(function _callee$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              _context4.next = 2;
              return this.request({
                method: 'POST',
                url: this._endpointUrl,
                headers: {
                  'Content-Type': 'text/xml',
                  SOAPAction: '""'
                },
                _message: _defineProperty({}, method, args)
              });
            case 2:
              res = _context4.sent;
              return _context4.abrupt("return", schema ? castTypeUsingSchema(res, schema, schemaDict) : res);
            case 4:
            case "end":
              return _context4.stop();
          }
        }, _callee, this);
      }));
      function invoke(_x, _x2, _x3, _x4) {
        return _invoke.apply(this, arguments);
      }
      return invoke;
    }() /** @override */)
  }, {
    key: "beforeSend",
    value: function beforeSend(request) {
      request.body = this._createEnvelope(request._message);
      var headers = request.headers || {};
      var bodySize = getBodySize(request.body, request.headers);
      if (!isBrowser &&
      // Don't set content-length in browsers as it's not allowed
      request.method === 'POST' && !('transfer-encoding' in headers) && !('content-length' in headers) && !!bodySize) {
        this._logger.debug("missing 'content-length' header, setting it to: ".concat(bodySize));
        headers['content-length'] = String(bodySize);
      }
      request.headers = headers;
    }

    /** @override **/
  }, {
    key: "isSessionExpired",
    value: function isSessionExpired(response) {
      return response.statusCode === 500 && /<faultcode>[a-zA-Z]+:INVALID_SESSION_ID<\/faultcode>/.test(response.body);
    }

    /** @override **/
  }, {
    key: "parseError",
    value: function parseError(body) {
      var error = lookupValue(body, [/:Envelope$/, /:Body$/, /:Fault$/]);
      return {
        errorCode: error.faultcode,
        message: error.faultstring
      };
    }

    /** @override **/
  }, {
    key: "getResponseBody",
    value: (function () {
      var _getResponseBody = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(response) {
        var body, res, header;
        return _regeneratorRuntime.wrap(function _callee2$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _context5.next = 2;
              return _superPropGet(SOAP, "getResponseBody", this, 3)([response]);
            case 2:
              body = _context5.sent;
              res = lookupValue(body, [/:Envelope$/, /:Body$/, /.+/]);
              if (res && res.result != null) {
                header = lookupValue(body, [/:Envelope$/, /:Header$/, /.+/]);
                if (header) {
                  res.result = _objectSpread(_objectSpread({}, res.result), header);
                }
              }
              return _context5.abrupt("return", res);
            case 6:
            case "end":
              return _context5.stop();
          }
        }, _callee2, this);
      }));
      function getResponseBody(_x5) {
        return _getResponseBody.apply(this, arguments);
      }
      return getResponseBody;
    }()
    /**
     * @private
     */
    )
  }, {
    key: "_createEnvelope",
    value: function _createEnvelope(message) {
      var header = {};
      var conn = this._conn;
      if (conn.accessToken) {
        header.SessionHeader = {
          sessionId: conn.accessToken
        };
      }
      if (conn._callOptions) {
        header.CallOptions = conn._callOptions;
      }
      return ['<?xml version="1.0" encoding="UTF-8"?>', '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"', ' xmlns:xsd="http://www.w3.org/2001/XMLSchema"', ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">', '<soapenv:Header xmlns="' + this._xmlns + '">', toXML(header), this._headers ? toXML(this._headers) : '', '</soapenv:Header>', '<soapenv:Body xmlns="' + this._xmlns + '">', toXML(message), '</soapenv:Body>', '</soapenv:Envelope>'].join('');
    }
  }]);
}(HttpApi);
export default SOAP;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJIdHRwQXBpIiwiaXNCcm93c2VyIiwiaXNNYXBPYmplY3QiLCJpc09iamVjdCIsImdldEJvZHlTaXplIiwiaXNKV1RUb2tlbiIsImdldFByb3BzU2NoZW1hIiwic2NoZW1hIiwic2NoZW1hRGljdCIsImV4dGVuZHMiLCJleHRlbmRTY2hlbWEiLCJfb2JqZWN0U3ByZWFkIiwicHJvcHMiLCJpc05pbGxWYWx1ZSIsInZhbHVlIiwiJCIsImNhc3RUeXBlVXNpbmdTY2hlbWEiLCJhcmd1bWVudHMiLCJsZW5ndGgiLCJ1bmRlZmluZWQiLCJfQXJyYXkkaXNBcnJheSIsIl9jb250ZXh0IiwibmlsbGFibGUiLCJzY2hlbWFfIiwiX21hcEluc3RhbmNlUHJvcGVydHkiLCJjYWxsIiwidiIsIl9jb250ZXh0MiIsIm9iaiIsIl9yZWR1Y2VJbnN0YW5jZVByb3BlcnR5IiwiX09iamVjdCRrZXlzIiwibyIsImsiLCJzIiwiX3N0YXJ0c1dpdGhJbnN0YW5jZVByb3BlcnR5IiwiX2RlZmluZVByb3BlcnR5IiwidHlwZSIsInN1YnN0cmluZyIsIlN0cmluZyIsIk51bWJlciIsImN2YWx1ZSIsImlzRW1wdHkiLCJsb29rdXBWYWx1ZSIsInByb3BSZWdFeHBzIiwicmVnZXhwIiwic2hpZnQiLCJfaSIsIl9PYmplY3Qka2V5czIiLCJwcm9wIiwidGVzdCIsInRvWE1MIiwibmFtZSIsImpvaW4iLCJhdHRycyIsInB1c2giLCJlbGVtcyIsIl9pMiIsIl9PYmplY3Qka2V5czMiLCJfY29udGV4dDMiLCJrayIsIl9jb25jYXRJbnN0YW5jZVByb3BlcnR5IiwiY29uY2F0IiwicmVwbGFjZSIsInN0YXJ0VGFnIiwiZW5kVGFnIiwiU09BUCIsIl9IdHRwQXBpIiwiY29ubiIsIm9wdGlvbnMiLCJfdGhpcyIsIl9jbGFzc0NhbGxDaGVjayIsIl9jYWxsU3VwZXIiLCJfY29ubiIsImFjY2Vzc1Rva2VuIiwiRXJyb3IiLCJfZW5kcG9pbnRVcmwiLCJlbmRwb2ludFVybCIsIl94bWxucyIsInhtbG5zIiwiX2hlYWRlcnMiLCJoZWFkZXJzIiwiX2luaGVyaXRzIiwiX2NyZWF0ZUNsYXNzIiwia2V5IiwiX2ludm9rZSIsIl9hc3luY1RvR2VuZXJhdG9yIiwiX3JlZ2VuZXJhdG9yUnVudGltZSIsIm1hcmsiLCJfY2FsbGVlIiwibWV0aG9kIiwiYXJncyIsInJlcyIsIndyYXAiLCJfY2FsbGVlJCIsIl9jb250ZXh0NCIsInByZXYiLCJuZXh0IiwicmVxdWVzdCIsInVybCIsIlNPQVBBY3Rpb24iLCJfbWVzc2FnZSIsInNlbnQiLCJhYnJ1cHQiLCJzdG9wIiwiaW52b2tlIiwiX3giLCJfeDIiLCJfeDMiLCJfeDQiLCJhcHBseSIsImJlZm9yZVNlbmQiLCJib2R5IiwiX2NyZWF0ZUVudmVsb3BlIiwiYm9keVNpemUiLCJfbG9nZ2VyIiwiZGVidWciLCJpc1Nlc3Npb25FeHBpcmVkIiwicmVzcG9uc2UiLCJzdGF0dXNDb2RlIiwicGFyc2VFcnJvciIsImVycm9yIiwiZXJyb3JDb2RlIiwiZmF1bHRjb2RlIiwibWVzc2FnZSIsImZhdWx0c3RyaW5nIiwiX2dldFJlc3BvbnNlQm9keSIsIl9jYWxsZWUyIiwiaGVhZGVyIiwiX2NhbGxlZTIkIiwiX2NvbnRleHQ1IiwiX3N1cGVyUHJvcEdldCIsInJlc3VsdCIsImdldFJlc3BvbnNlQm9keSIsIl94NSIsIlNlc3Npb25IZWFkZXIiLCJzZXNzaW9uSWQiLCJfY2FsbE9wdGlvbnMiLCJDYWxsT3B0aW9ucyJdLCJzb3VyY2VzIjpbIi4uL3NyYy9zb2FwLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgTWFuYWdlcyBtZXRob2QgY2FsbCB0byBTT0FQIGVuZHBvaW50XG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IEh0dHBBcGksIHsgaXNCcm93c2VyIH0gZnJvbSAnLi9odHRwLWFwaSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHtcbiAgU2NoZW1hLFxuICBIdHRwUmVzcG9uc2UsXG4gIEh0dHBSZXF1ZXN0LFxuICBTb2FwU2NoZW1hLFxuICBTb2FwU2NoZW1hRGVmLFxufSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IGlzTWFwT2JqZWN0LCBpc09iamVjdCB9IGZyb20gJy4vdXRpbC9mdW5jdGlvbic7XG5pbXBvcnQgeyBnZXRCb2R5U2l6ZSB9IGZyb20gJy4vdXRpbC9nZXQtYm9keS1zaXplJztcbmltcG9ydCB7IGlzSldUVG9rZW4gfSBmcm9tICcuL3V0aWwvand0JztcblxuLyoqXG4gKlxuICovXG5mdW5jdGlvbiBnZXRQcm9wc1NjaGVtYShcbiAgc2NoZW1hOiBTb2FwU2NoZW1hRGVmLFxuICBzY2hlbWFEaWN0OiB7IFtuYW1lOiBzdHJpbmddOiBTb2FwU2NoZW1hRGVmIH0sXG4pOiBTb2FwU2NoZW1hRGVmWydwcm9wcyddIHtcbiAgaWYgKHNjaGVtYS5leHRlbmRzICYmIHNjaGVtYURpY3Rbc2NoZW1hLmV4dGVuZHNdKSB7XG4gICAgY29uc3QgZXh0ZW5kU2NoZW1hID0gc2NoZW1hRGljdFtzY2hlbWEuZXh0ZW5kc107XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLmdldFByb3BzU2NoZW1hKGV4dGVuZFNjaGVtYSwgc2NoZW1hRGljdCksXG4gICAgICAuLi5zY2hlbWEucHJvcHMsXG4gICAgfTtcbiAgfVxuICByZXR1cm4gc2NoZW1hLnByb3BzO1xufVxuXG5mdW5jdGlvbiBpc05pbGxWYWx1ZSh2YWx1ZTogdW5rbm93bikge1xuICByZXR1cm4gKFxuICAgIHZhbHVlID09IG51bGwgfHxcbiAgICAoaXNNYXBPYmplY3QodmFsdWUpICYmXG4gICAgICBpc01hcE9iamVjdCh2YWx1ZS4kKSAmJlxuICAgICAgdmFsdWUuJFsneHNpOm5pbCddID09PSAndHJ1ZScpXG4gICk7XG59XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNhc3RUeXBlVXNpbmdTY2hlbWEoXG4gIHZhbHVlOiB1bmtub3duLFxuICBzY2hlbWE/OiBTb2FwU2NoZW1hIHwgU29hcFNjaGVtYURlZixcbiAgc2NoZW1hRGljdDogeyBbbmFtZTogc3RyaW5nXTogU29hcFNjaGVtYURlZiB9ID0ge30sXG4pOiBhbnkge1xuICBpZiAoQXJyYXkuaXNBcnJheShzY2hlbWEpKSB7XG4gICAgY29uc3QgbmlsbGFibGUgPSBzY2hlbWEubGVuZ3RoID09PSAyICYmIHNjaGVtYVswXSA9PT0gJz8nO1xuICAgIGNvbnN0IHNjaGVtYV8gPSBuaWxsYWJsZSA/IHNjaGVtYVsxXSA6IHNjaGVtYVswXTtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIG5pbGxhYmxlID8gbnVsbCA6IFtdO1xuICAgIH1cbiAgICByZXR1cm4gKEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUgOiBbdmFsdWVdKS5tYXAoKHYpID0+XG4gICAgICBjYXN0VHlwZVVzaW5nU2NoZW1hKHYsIHNjaGVtYV8sIHNjaGVtYURpY3QpLFxuICAgICk7XG4gIH0gZWxzZSBpZiAoaXNNYXBPYmplY3Qoc2NoZW1hKSkge1xuICAgIC8vIGlmIHNjaGVtYSBpcyBTY2hlbWEgRGVmaW5pdGlvbiwgbm90IHNjaGVtYSBlbGVtZW50XG4gICAgaWYgKCd0eXBlJyBpbiBzY2hlbWEgJiYgJ3Byb3BzJyBpbiBzY2hlbWEgJiYgaXNNYXBPYmplY3Qoc2NoZW1hLnByb3BzKSkge1xuICAgICAgY29uc3QgcHJvcHMgPSBnZXRQcm9wc1NjaGVtYShzY2hlbWEgYXMgU29hcFNjaGVtYURlZiwgc2NoZW1hRGljdCk7XG4gICAgICByZXR1cm4gY2FzdFR5cGVVc2luZ1NjaGVtYSh2YWx1ZSwgcHJvcHMsIHNjaGVtYURpY3QpO1xuICAgIH1cbiAgICBjb25zdCBuaWxsYWJsZSA9ICc/JyBpbiBzY2hlbWE7XG4gICAgY29uc3Qgc2NoZW1hXyA9XG4gICAgICAnPycgaW4gc2NoZW1hID8gKHNjaGVtYVsnPyddIGFzIHsgW2tleTogc3RyaW5nXTogYW55IH0pIDogc2NoZW1hO1xuICAgIGlmIChuaWxsYWJsZSAmJiBpc05pbGxWYWx1ZSh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBvYmogPSBpc01hcE9iamVjdCh2YWx1ZSkgPyB2YWx1ZSA6IHt9O1xuICAgIHJldHVybiBPYmplY3Qua2V5cyhzY2hlbWFfKS5yZWR1Y2UoKG8sIGspID0+IHtcbiAgICAgIGNvbnN0IHMgPSBzY2hlbWFfW2tdO1xuICAgICAgY29uc3QgdiA9IG9ialtrXTtcbiAgICAgIGNvbnN0IG5pbGxhYmxlID1cbiAgICAgICAgKEFycmF5LmlzQXJyYXkocykgJiYgcy5sZW5ndGggPT09IDIgJiYgc1swXSA9PT0gJz8nKSB8fFxuICAgICAgICAoaXNNYXBPYmplY3QocykgJiYgJz8nIGluIHMpIHx8XG4gICAgICAgICh0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5zdGFydHNXaXRoKCc/JykpO1xuICAgICAgaWYgKHR5cGVvZiB2ID09PSAndW5kZWZpbmVkJyAmJiBuaWxsYWJsZSkge1xuICAgICAgICByZXR1cm4gbztcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLm8sXG4gICAgICAgIFtrXTogY2FzdFR5cGVVc2luZ1NjaGVtYSh2LCBzLCBzY2hlbWFEaWN0KSxcbiAgICAgIH07XG4gICAgfSwgb2JqKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBuaWxsYWJsZSA9IHR5cGVvZiBzY2hlbWEgPT09ICdzdHJpbmcnICYmIHNjaGVtYS5zdGFydHNXaXRoKCc/Jyk7XG4gICAgY29uc3QgdHlwZSA9XG4gICAgICB0eXBlb2Ygc2NoZW1hID09PSAnc3RyaW5nJ1xuICAgICAgICA/IG5pbGxhYmxlXG4gICAgICAgICAgPyBzY2hlbWEuc3Vic3RyaW5nKDEpXG4gICAgICAgICAgOiBzY2hlbWFcbiAgICAgICAgOiAnYW55JztcbiAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgIGNhc2UgJ3N0cmluZyc6XG4gICAgICAgIHJldHVybiBpc05pbGxWYWx1ZSh2YWx1ZSkgPyAobmlsbGFibGUgPyBudWxsIDogJycpIDogU3RyaW5nKHZhbHVlKTtcbiAgICAgIGNhc2UgJ251bWJlcic6XG4gICAgICAgIHJldHVybiBpc05pbGxWYWx1ZSh2YWx1ZSkgPyAobmlsbGFibGUgPyBudWxsIDogMCkgOiBOdW1iZXIodmFsdWUpO1xuICAgICAgY2FzZSAnYm9vbGVhbic6XG4gICAgICAgIHJldHVybiBpc05pbGxWYWx1ZSh2YWx1ZSlcbiAgICAgICAgICA/IG5pbGxhYmxlXG4gICAgICAgICAgICA/IG51bGxcbiAgICAgICAgICAgIDogZmFsc2VcbiAgICAgICAgICA6IHZhbHVlID09PSAndHJ1ZSc7XG4gICAgICBjYXNlICdudWxsJzpcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICBkZWZhdWx0OiB7XG4gICAgICAgIGlmIChzY2hlbWFEaWN0W3R5cGVdKSB7XG4gICAgICAgICAgY29uc3QgY3ZhbHVlID0gY2FzdFR5cGVVc2luZ1NjaGVtYShcbiAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgc2NoZW1hRGljdFt0eXBlXSxcbiAgICAgICAgICAgIHNjaGVtYURpY3QsXG4gICAgICAgICAgKTtcbiAgICAgICAgICBjb25zdCBpc0VtcHR5ID1cbiAgICAgICAgICAgIGlzTWFwT2JqZWN0KGN2YWx1ZSkgJiYgT2JqZWN0LmtleXMoY3ZhbHVlKS5sZW5ndGggPT09IDA7XG4gICAgICAgICAgcmV0dXJuIGlzRW1wdHkgJiYgbmlsbGFibGUgPyBudWxsIDogY3ZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB2YWx1ZSBhcyBhbnk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gbG9va3VwVmFsdWUob2JqOiB1bmtub3duLCBwcm9wUmVnRXhwczogUmVnRXhwW10pOiB1bmtub3duIHtcbiAgY29uc3QgcmVnZXhwID0gcHJvcFJlZ0V4cHMuc2hpZnQoKTtcbiAgaWYgKCFyZWdleHApIHtcbiAgICByZXR1cm4gb2JqO1xuICB9XG4gIGlmIChpc01hcE9iamVjdChvYmopKSB7XG4gICAgZm9yIChjb25zdCBwcm9wIG9mIE9iamVjdC5rZXlzKG9iaikpIHtcbiAgICAgIGlmIChyZWdleHAudGVzdChwcm9wKSkge1xuICAgICAgICByZXR1cm4gbG9va3VwVmFsdWUob2JqW3Byb3BdLCBwcm9wUmVnRXhwcyk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gdG9YTUwobmFtZTogb2JqZWN0IHwgc3RyaW5nIHwgbnVsbCwgdmFsdWU/OiBhbnkpOiBzdHJpbmcge1xuICBpZiAoaXNPYmplY3QobmFtZSkpIHtcbiAgICB2YWx1ZSA9IG5hbWU7XG4gICAgbmFtZSA9IG51bGw7XG4gIH1cbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlLm1hcCgodikgPT4gdG9YTUwobmFtZSwgdikpLmpvaW4oJycpO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IGF0dHJzID0gW107XG4gICAgaWYgKHZhbHVlID09PSBudWxsKSB7XG4gICAgICBhdHRycy5wdXNoKCd4c2k6bmlsPVwidHJ1ZVwiJyk7XG4gICAgICB2YWx1ZSA9ICcnO1xuICAgIH0gZWxzZSBpZiAoaXNNYXBPYmplY3QodmFsdWUpKSB7XG4gICAgICBjb25zdCBlbGVtcyA9IFtdO1xuICAgICAgZm9yIChjb25zdCBrIG9mIE9iamVjdC5rZXlzKHZhbHVlKSkge1xuICAgICAgICBjb25zdCB2ID0gdmFsdWVba107XG4gICAgICAgIGlmIChrLnN0YXJ0c1dpdGgoJ0AnKSkge1xuICAgICAgICAgIGNvbnN0IGtrID0gay5zdWJzdHJpbmcoMSk7XG4gICAgICAgICAgYXR0cnMucHVzaChgJHtra309XCIke3YgYXMgc3RyaW5nfVwiYCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZWxlbXMucHVzaCh0b1hNTChrLCB2KSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHZhbHVlID0gZWxlbXMuam9pbignJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZhbHVlID0gU3RyaW5nKHZhbHVlKVxuICAgICAgICAucmVwbGFjZSgvJi9nLCAnJmFtcDsnKVxuICAgICAgICAucmVwbGFjZSgvPC9nLCAnJmx0OycpXG4gICAgICAgIC5yZXBsYWNlKC8+L2csICcmZ3Q7JylcbiAgICAgICAgLnJlcGxhY2UoL1wiL2csICcmcXVvdDsnKVxuICAgICAgICAucmVwbGFjZSgvJy9nLCAnJmFwb3M7Jyk7XG4gICAgfVxuICAgIGNvbnN0IHN0YXJ0VGFnID0gbmFtZVxuICAgICAgPyAnPCcgKyBuYW1lICsgKGF0dHJzLmxlbmd0aCA+IDAgPyAnICcgKyBhdHRycy5qb2luKCcgJykgOiAnJykgKyAnPidcbiAgICAgIDogJyc7XG4gICAgY29uc3QgZW5kVGFnID0gbmFtZSA/ICc8LycgKyBuYW1lICsgJz4nIDogJyc7XG4gICAgcmV0dXJuIHN0YXJ0VGFnICsgdmFsdWUgKyBlbmRUYWc7XG4gIH1cbn1cblxuLyoqXG4gKlxuICovXG5leHBvcnQgdHlwZSBTT0FQT3B0aW9ucyA9IHtcbiAgZW5kcG9pbnRVcmw6IHN0cmluZztcbiAgeG1sbnM/OiBzdHJpbmc7XG4gIGhlYWRlcnM/Om9iamVjdDtcbn07XG5cbi8qKlxuICogQ2xhc3MgZm9yIFNPQVAgZW5kcG9pbnQgb2YgU2FsZXNmb3JjZVxuICpcbiAqIEBwcm90ZWN0ZWRcbiAqIEBjbGFzc1xuICogQGNvbnN0cnVjdG9yXG4gKiBAcGFyYW0ge0Nvbm5lY3Rpb259IGNvbm4gLSBDb25uZWN0aW9uIGluc3RhbmNlXG4gKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyAtIFNPQVAgZW5kcG9pbnQgc2V0dGluZyBvcHRpb25zXG4gKiBAcGFyYW0ge1N0cmluZ30gb3B0aW9ucy5lbmRwb2ludFVybCAtIFNPQVAgZW5kcG9pbnQgVVJMXG4gKiBAcGFyYW0ge1N0cmluZ30gW29wdGlvbnMueG1sbnNdIC0gWE1MIG5hbWVzcGFjZSBmb3IgbWV0aG9kIGNhbGwgKGRlZmF1bHQgaXMgXCJ1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb21cIilcbiAqL1xuZXhwb3J0IGNsYXNzIFNPQVA8UyBleHRlbmRzIFNjaGVtYT4gZXh0ZW5kcyBIdHRwQXBpPFM+IHtcbiAgX2VuZHBvaW50VXJsOiBzdHJpbmc7XG4gIF94bWxuczogc3RyaW5nO1xuICBfaGVhZGVyczogb2JqZWN0IHwgbnVsbDtcblxuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+LCBvcHRpb25zOiBTT0FQT3B0aW9ucykge1xuICAgIHN1cGVyKGNvbm4sIG9wdGlvbnMpO1xuICAgIGlmICh0aGlzLl9jb25uLmFjY2Vzc1Rva2VuICYmIGlzSldUVG9rZW4odGhpcy5fY29ubi5hY2Nlc3NUb2tlbikpIHtcbiAgICAgIC8vIFdlIG5lZWQgdG8gYmxvY2sgU09BUCByZXF1ZXN0cyB3aXRoIEpXVCB0b2tlbnMgYmVjYXVzZSB0aGUgcmVzcG9uc2UgaXM6XG4gICAgICAvLyBzdGF0dXNDb2RlPTUwMCB8IGJvZHk9XCJJTlZBTElEX1NFU1NJT05fSURcIiAoeG1sKSwgd2hpY2ggdHJpZ2dlcnMgc2Vzc2lvbiByZWZyZXNoIGFuZCBlbnRlcnMgaW4gYW4gaW5maW5pdGUgbG9vcFxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnU09BUCBBUEkgZG9lcyBub3Qgc3VwcG9ydCBKV1QtYmFzZWQgYWNjZXNzIHRva2Vucy4gWW91IG11c3QgZGlzYWJsZSB0aGUgXCJJc3N1ZSBKU09OIFdlYiBUb2tlbiAoSldUKS1iYXNlZCBhY2Nlc3MgdG9rZW5zXCIgc2V0dGluZyBpbiB5b3VyIENvbm5lY3RlZCBBcHAgb3IgRXh0ZXJuYWwgQ2xpZW50IEFwcCcsXG4gICAgICApO1xuICAgIH1cbiAgICB0aGlzLl9lbmRwb2ludFVybCA9IG9wdGlvbnMuZW5kcG9pbnRVcmw7XG4gICAgdGhpcy5feG1sbnMgPSBvcHRpb25zLnhtbG5zIHx8ICd1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb20nO1xuICAgIHRoaXMuX2hlYWRlcnMgPSBvcHRpb25zLmhlYWRlcnMgfHwgbnVsbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbnZva2UgU09BUCBjYWxsIHVzaW5nIG1ldGhvZCBhbmQgYXJndW1lbnRzXG4gICAqL1xuICBhc3luYyBpbnZva2UoXG4gICAgbWV0aG9kOiBzdHJpbmcsXG4gICAgYXJnczogb2JqZWN0LFxuICAgIHNjaGVtYT86IFNvYXBTY2hlbWEgfCBTb2FwU2NoZW1hRGVmLFxuICAgIHNjaGVtYURpY3Q/OiB7IFtuYW1lOiBzdHJpbmddOiBTb2FwU2NoZW1hRGVmIH0sXG4gICkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMucmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybDogdGhpcy5fZW5kcG9pbnRVcmwsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAndGV4dC94bWwnLFxuICAgICAgICBTT0FQQWN0aW9uOiAnXCJcIicsXG4gICAgICB9LFxuICAgICAgX21lc3NhZ2U6IHsgW21ldGhvZF06IGFyZ3MgfSxcbiAgICB9IGFzIEh0dHBSZXF1ZXN0KTtcbiAgICByZXR1cm4gc2NoZW1hID8gY2FzdFR5cGVVc2luZ1NjaGVtYShyZXMsIHNjaGVtYSwgc2NoZW1hRGljdCkgOiByZXM7XG4gIH1cblxuICAvKiogQG92ZXJyaWRlICovXG4gIGJlZm9yZVNlbmQocmVxdWVzdDogSHR0cFJlcXVlc3QgJiB7IF9tZXNzYWdlOiBvYmplY3QgfSkge1xuICAgIHJlcXVlc3QuYm9keSA9IHRoaXMuX2NyZWF0ZUVudmVsb3BlKHJlcXVlc3QuX21lc3NhZ2UpO1xuXG4gICAgY29uc3QgaGVhZGVycyA9IHJlcXVlc3QuaGVhZGVycyB8fCB7fTtcblxuICAgIGNvbnN0IGJvZHlTaXplID0gZ2V0Qm9keVNpemUocmVxdWVzdC5ib2R5LCByZXF1ZXN0LmhlYWRlcnMpO1xuXG4gICAgaWYgKFxuICAgICAgIWlzQnJvd3NlciAmJiAvLyBEb24ndCBzZXQgY29udGVudC1sZW5ndGggaW4gYnJvd3NlcnMgYXMgaXQncyBub3QgYWxsb3dlZFxuICAgICAgcmVxdWVzdC5tZXRob2QgPT09ICdQT1NUJyAmJlxuICAgICAgISgndHJhbnNmZXItZW5jb2RpbmcnIGluIGhlYWRlcnMpICYmXG4gICAgICAhKCdjb250ZW50LWxlbmd0aCcgaW4gaGVhZGVycykgJiZcbiAgICAgICEhYm9keVNpemVcbiAgICApIHtcbiAgICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgICAgYG1pc3NpbmcgJ2NvbnRlbnQtbGVuZ3RoJyBoZWFkZXIsIHNldHRpbmcgaXQgdG86ICR7Ym9keVNpemV9YCxcbiAgICAgICk7XG4gICAgICBoZWFkZXJzWydjb250ZW50LWxlbmd0aCddID0gU3RyaW5nKGJvZHlTaXplKTtcbiAgICB9XG5cbiAgICByZXF1ZXN0LmhlYWRlcnMgPSBoZWFkZXJzO1xuICB9XG5cbiAgLyoqIEBvdmVycmlkZSAqKi9cbiAgaXNTZXNzaW9uRXhwaXJlZChyZXNwb25zZTogSHR0cFJlc3BvbnNlKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIHJlc3BvbnNlLnN0YXR1c0NvZGUgPT09IDUwMCAmJlxuICAgICAgLzxmYXVsdGNvZGU+W2EtekEtWl0rOklOVkFMSURfU0VTU0lPTl9JRDxcXC9mYXVsdGNvZGU+Ly50ZXN0KHJlc3BvbnNlLmJvZHkpXG4gICAgKTtcbiAgfVxuXG4gIC8qKiBAb3ZlcnJpZGUgKiovXG4gIHBhcnNlRXJyb3IoYm9keTogc3RyaW5nKSB7XG4gICAgY29uc3QgZXJyb3IgPSBsb29rdXBWYWx1ZShib2R5LCBbLzpFbnZlbG9wZSQvLCAvOkJvZHkkLywgLzpGYXVsdCQvXSkgYXMge1xuICAgICAgW25hbWU6IHN0cmluZ106IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgICB9O1xuICAgIHJldHVybiB7XG4gICAgICBlcnJvckNvZGU6IGVycm9yLmZhdWx0Y29kZSxcbiAgICAgIG1lc3NhZ2U6IGVycm9yLmZhdWx0c3RyaW5nLFxuICAgIH07XG4gIH1cblxuICAvKiogQG92ZXJyaWRlICoqL1xuICBhc3luYyBnZXRSZXNwb25zZUJvZHkocmVzcG9uc2U6IEh0dHBSZXNwb25zZSkge1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCBzdXBlci5nZXRSZXNwb25zZUJvZHkocmVzcG9uc2UpO1xuICAgIGNvbnN0IHJlcyA9IGxvb2t1cFZhbHVlKGJvZHksIFsvOkVudmVsb3BlJC8sIC86Qm9keSQvLCAvLisvXSkgYXMgeyByZXN1bHQ/OiBhbnkgfTtcbiAgICBpZiAocmVzICYmIHJlcy5yZXN1bHQgIT0gbnVsbCkge1xuICAgICAgY29uc3QgaGVhZGVyID0gbG9va3VwVmFsdWUoYm9keSwgWy86RW52ZWxvcGUkLywgLzpIZWFkZXIkLywgLy4rL10pO1xuICAgICAgaWYgKGhlYWRlcikge1xuICAgICAgICByZXMucmVzdWx0ID0ge1xuICAgICAgICAgIC4uLnJlcy5yZXN1bHQsXG4gICAgICAgICAgLi4uaGVhZGVyLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfY3JlYXRlRW52ZWxvcGUobWVzc2FnZTogb2JqZWN0KSB7XG4gICAgY29uc3QgaGVhZGVyOiB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfSA9IHt9O1xuICAgIGNvbnN0IGNvbm4gPSB0aGlzLl9jb25uO1xuICAgIGlmIChjb25uLmFjY2Vzc1Rva2VuKSB7XG4gICAgICBoZWFkZXIuU2Vzc2lvbkhlYWRlciA9IHsgc2Vzc2lvbklkOiBjb25uLmFjY2Vzc1Rva2VuIH07XG4gICAgfVxuICAgIGlmIChjb25uLl9jYWxsT3B0aW9ucykge1xuICAgICAgaGVhZGVyLkNhbGxPcHRpb25zID0gY29ubi5fY2FsbE9wdGlvbnM7XG4gICAgfVxuICAgIHJldHVybiBbXG4gICAgICAnPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+JyxcbiAgICAgICc8c29hcGVudjpFbnZlbG9wZSB4bWxuczpzb2FwZW52PVwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvc29hcC9lbnZlbG9wZS9cIicsXG4gICAgICAnIHhtbG5zOnhzZD1cImh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hXCInLFxuICAgICAgJyB4bWxuczp4c2k9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZVwiPicsXG4gICAgICAnPHNvYXBlbnY6SGVhZGVyIHhtbG5zPVwiJyArIHRoaXMuX3htbG5zICsgJ1wiPicsXG4gICAgICB0b1hNTChoZWFkZXIpLFxuICAgICAgdGhpcy5faGVhZGVycz90b1hNTCh0aGlzLl9oZWFkZXJzKTonJyxcbiAgICAgICc8L3NvYXBlbnY6SGVhZGVyPicsXG4gICAgICAnPHNvYXBlbnY6Qm9keSB4bWxucz1cIicgKyB0aGlzLl94bWxucyArICdcIj4nLFxuICAgICAgdG9YTUwobWVzc2FnZSksXG4gICAgICAnPC9zb2FwZW52OkJvZHk+JyxcbiAgICAgICc8L3NvYXBlbnY6RW52ZWxvcGU+JyxcbiAgICBdLmpvaW4oJycpO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFNPQVA7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPQSxPQUFPLElBQUlDLFNBQVMsUUFBUSxZQUFZO0FBUy9DLFNBQVNDLFdBQVcsRUFBRUMsUUFBUSxRQUFRLGlCQUFpQjtBQUN2RCxTQUFTQyxXQUFXLFFBQVEsc0JBQXNCO0FBQ2xELFNBQVNDLFVBQVUsUUFBUSxZQUFZOztBQUV2QztBQUNBO0FBQ0E7QUFDQSxTQUFTQyxjQUFjQSxDQUNyQkMsTUFBcUIsRUFDckJDLFVBQTZDLEVBQ3JCO0VBQ3hCLElBQUlELE1BQU0sQ0FBQ0UsT0FBTyxJQUFJRCxVQUFVLENBQUNELE1BQU0sQ0FBQ0UsT0FBTyxDQUFDLEVBQUU7SUFDaEQsSUFBTUMsWUFBWSxHQUFHRixVQUFVLENBQUNELE1BQU0sQ0FBQ0UsT0FBTyxDQUFDO0lBQy9DLE9BQUFFLGFBQUEsQ0FBQUEsYUFBQSxLQUNLTCxjQUFjLENBQUNJLFlBQVksRUFBRUYsVUFBVSxDQUFDLEdBQ3hDRCxNQUFNLENBQUNLLEtBQUs7RUFFbkI7RUFDQSxPQUFPTCxNQUFNLENBQUNLLEtBQUs7QUFDckI7QUFFQSxTQUFTQyxXQUFXQSxDQUFDQyxLQUFjLEVBQUU7RUFDbkMsT0FDRUEsS0FBSyxJQUFJLElBQUksSUFDWlosV0FBVyxDQUFDWSxLQUFLLENBQUMsSUFDakJaLFdBQVcsQ0FBQ1ksS0FBSyxDQUFDQyxDQUFDLENBQUMsSUFDcEJELEtBQUssQ0FBQ0MsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLE1BQU87QUFFcEM7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsT0FBTyxTQUFTQyxtQkFBbUJBLENBQ2pDRixLQUFjLEVBQ2RQLE1BQW1DLEVBRTlCO0VBQUEsSUFETEMsVUFBNkMsR0FBQVMsU0FBQSxDQUFBQyxNQUFBLFFBQUFELFNBQUEsUUFBQUUsU0FBQSxHQUFBRixTQUFBLE1BQUcsQ0FBQyxDQUFDO0VBRWxELElBQUlHLGNBQUEsQ0FBY2IsTUFBTSxDQUFDLEVBQUU7SUFBQSxJQUFBYyxRQUFBO0lBQ3pCLElBQU1DLFFBQVEsR0FBR2YsTUFBTSxDQUFDVyxNQUFNLEtBQUssQ0FBQyxJQUFJWCxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRztJQUN6RCxJQUFNZ0IsT0FBTyxHQUFHRCxRQUFRLEdBQUdmLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBR0EsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUNoRCxJQUFJTyxLQUFLLElBQUksSUFBSSxFQUFFO01BQ2pCLE9BQU9RLFFBQVEsR0FBRyxJQUFJLEdBQUcsRUFBRTtJQUM3QjtJQUNBLE9BQU9FLG9CQUFBLENBQUFILFFBQUEsR0FBQ0QsY0FBQSxDQUFjTixLQUFLLENBQUMsR0FBR0EsS0FBSyxHQUFHLENBQUNBLEtBQUssQ0FBQyxFQUFBVyxJQUFBLENBQUFKLFFBQUEsRUFBTSxVQUFDSyxDQUFDO01BQUEsT0FDcERWLG1CQUFtQixDQUFDVSxDQUFDLEVBQUVILE9BQU8sRUFBRWYsVUFBVSxDQUFDO0lBQUEsQ0FDN0MsQ0FBQztFQUNILENBQUMsTUFBTSxJQUFJTixXQUFXLENBQUNLLE1BQU0sQ0FBQyxFQUFFO0lBQUEsSUFBQW9CLFNBQUE7SUFDOUI7SUFDQSxJQUFJLE1BQU0sSUFBSXBCLE1BQU0sSUFBSSxPQUFPLElBQUlBLE1BQU0sSUFBSUwsV0FBVyxDQUFDSyxNQUFNLENBQUNLLEtBQUssQ0FBQyxFQUFFO01BQ3RFLElBQU1BLEtBQUssR0FBR04sY0FBYyxDQUFDQyxNQUFNLEVBQW1CQyxVQUFVLENBQUM7TUFDakUsT0FBT1EsbUJBQW1CLENBQUNGLEtBQUssRUFBRUYsS0FBSyxFQUFFSixVQUFVLENBQUM7SUFDdEQ7SUFDQSxJQUFNYyxTQUFRLEdBQUcsR0FBRyxJQUFJZixNQUFNO0lBQzlCLElBQU1nQixRQUFPLEdBQ1gsR0FBRyxJQUFJaEIsTUFBTSxHQUFJQSxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQThCQSxNQUFNO0lBQ2xFLElBQUllLFNBQVEsSUFBSVQsV0FBVyxDQUFDQyxLQUFLLENBQUMsRUFBRTtNQUNsQyxPQUFPLElBQUk7SUFDYjtJQUNBLElBQU1jLEdBQUcsR0FBRzFCLFdBQVcsQ0FBQ1ksS0FBSyxDQUFDLEdBQUdBLEtBQUssR0FBRyxDQUFDLENBQUM7SUFDM0MsT0FBT2UsdUJBQUEsQ0FBQUYsU0FBQSxHQUFBRyxZQUFBLENBQVlQLFFBQU8sQ0FBQyxFQUFBRSxJQUFBLENBQUFFLFNBQUEsRUFBUSxVQUFDSSxDQUFDLEVBQUVDLENBQUMsRUFBSztNQUMzQyxJQUFNQyxDQUFDLEdBQUdWLFFBQU8sQ0FBQ1MsQ0FBQyxDQUFDO01BQ3BCLElBQU1OLENBQUMsR0FBR0UsR0FBRyxDQUFDSSxDQUFDLENBQUM7TUFDaEIsSUFBTVYsUUFBUSxHQUNYRixjQUFBLENBQWNhLENBQUMsQ0FBQyxJQUFJQSxDQUFDLENBQUNmLE1BQU0sS0FBSyxDQUFDLElBQUllLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLElBQ2xEL0IsV0FBVyxDQUFDK0IsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJQSxDQUFFLElBQzNCLE9BQU9BLENBQUMsS0FBSyxRQUFRLElBQUlDLDJCQUFBLENBQUFELENBQUMsRUFBQVIsSUFBQSxDQUFEUSxDQUFDLEVBQVksR0FBRyxDQUFFO01BQzlDLElBQUksT0FBT1AsQ0FBQyxLQUFLLFdBQVcsSUFBSUosUUFBUSxFQUFFO1FBQ3hDLE9BQU9TLENBQUM7TUFDVjtNQUNBLE9BQUFwQixhQUFBLENBQUFBLGFBQUEsS0FDS29CLENBQUMsT0FBQUksZUFBQSxLQUNISCxDQUFDLEVBQUdoQixtQkFBbUIsQ0FBQ1UsQ0FBQyxFQUFFTyxDQUFDLEVBQUV6QixVQUFVLENBQUM7SUFFOUMsQ0FBQyxFQUFFb0IsR0FBRyxDQUFDO0VBQ1QsQ0FBQyxNQUFNO0lBQ0wsSUFBTU4sVUFBUSxHQUFHLE9BQU9mLE1BQU0sS0FBSyxRQUFRLElBQUkyQiwyQkFBQSxDQUFBM0IsTUFBTSxFQUFBa0IsSUFBQSxDQUFObEIsTUFBTSxFQUFZLEdBQUcsQ0FBQztJQUNyRSxJQUFNNkIsSUFBSSxHQUNSLE9BQU83QixNQUFNLEtBQUssUUFBUSxHQUN0QmUsVUFBUSxHQUNOZixNQUFNLENBQUM4QixTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQ25COUIsTUFBTSxHQUNSLEtBQUs7SUFDWCxRQUFRNkIsSUFBSTtNQUNWLEtBQUssUUFBUTtRQUNYLE9BQU92QixXQUFXLENBQUNDLEtBQUssQ0FBQyxHQUFJUSxVQUFRLEdBQUcsSUFBSSxHQUFHLEVBQUUsR0FBSWdCLE1BQU0sQ0FBQ3hCLEtBQUssQ0FBQztNQUNwRSxLQUFLLFFBQVE7UUFDWCxPQUFPRCxXQUFXLENBQUNDLEtBQUssQ0FBQyxHQUFJUSxVQUFRLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBSWlCLE1BQU0sQ0FBQ3pCLEtBQUssQ0FBQztNQUNuRSxLQUFLLFNBQVM7UUFDWixPQUFPRCxXQUFXLENBQUNDLEtBQUssQ0FBQyxHQUNyQlEsVUFBUSxHQUNOLElBQUksR0FDSixLQUFLLEdBQ1BSLEtBQUssS0FBSyxNQUFNO01BQ3RCLEtBQUssTUFBTTtRQUNULE9BQU8sSUFBSTtNQUNiO1FBQVM7VUFDUCxJQUFJTixVQUFVLENBQUM0QixJQUFJLENBQUMsRUFBRTtZQUNwQixJQUFNSSxNQUFNLEdBQUd4QixtQkFBbUIsQ0FDaENGLEtBQUssRUFDTE4sVUFBVSxDQUFDNEIsSUFBSSxDQUFDLEVBQ2hCNUIsVUFDRixDQUFDO1lBQ0QsSUFBTWlDLE9BQU8sR0FDWHZDLFdBQVcsQ0FBQ3NDLE1BQU0sQ0FBQyxJQUFJVixZQUFBLENBQVlVLE1BQU0sQ0FBQyxDQUFDdEIsTUFBTSxLQUFLLENBQUM7WUFDekQsT0FBT3VCLE9BQU8sSUFBSW5CLFVBQVEsR0FBRyxJQUFJLEdBQUdrQixNQUFNO1VBQzVDO1VBQ0EsT0FBTzFCLEtBQUs7UUFDZDtJQUNGO0VBQ0Y7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTNEIsV0FBV0EsQ0FBQ2QsR0FBWSxFQUFFZSxXQUFxQixFQUFXO0VBQ2pFLElBQU1DLE1BQU0sR0FBR0QsV0FBVyxDQUFDRSxLQUFLLENBQUMsQ0FBQztFQUNsQyxJQUFJLENBQUNELE1BQU0sRUFBRTtJQUNYLE9BQU9oQixHQUFHO0VBQ1o7RUFDQSxJQUFJMUIsV0FBVyxDQUFDMEIsR0FBRyxDQUFDLEVBQUU7SUFDcEIsU0FBQWtCLEVBQUEsTUFBQUMsYUFBQSxHQUFtQmpCLFlBQUEsQ0FBWUYsR0FBRyxDQUFDLEVBQUFrQixFQUFBLEdBQUFDLGFBQUEsQ0FBQTdCLE1BQUEsRUFBQTRCLEVBQUEsSUFBRTtNQUFoQyxJQUFNRSxJQUFJLEdBQUFELGFBQUEsQ0FBQUQsRUFBQTtNQUNiLElBQUlGLE1BQU0sQ0FBQ0ssSUFBSSxDQUFDRCxJQUFJLENBQUMsRUFBRTtRQUNyQixPQUFPTixXQUFXLENBQUNkLEdBQUcsQ0FBQ29CLElBQUksQ0FBQyxFQUFFTCxXQUFXLENBQUM7TUFDNUM7SUFDRjtJQUNBLE9BQU8sSUFBSTtFQUNiO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsU0FBU08sS0FBS0EsQ0FBQ0MsSUFBNEIsRUFBRXJDLEtBQVcsRUFBVTtFQUNoRSxJQUFJWCxRQUFRLENBQUNnRCxJQUFJLENBQUMsRUFBRTtJQUNsQnJDLEtBQUssR0FBR3FDLElBQUk7SUFDWkEsSUFBSSxHQUFHLElBQUk7RUFDYjtFQUNBLElBQUkvQixjQUFBLENBQWNOLEtBQUssQ0FBQyxFQUFFO0lBQ3hCLE9BQU9VLG9CQUFBLENBQUFWLEtBQUssRUFBQVcsSUFBQSxDQUFMWCxLQUFLLEVBQUssVUFBQ1ksQ0FBQztNQUFBLE9BQUt3QixLQUFLLENBQUNDLElBQUksRUFBRXpCLENBQUMsQ0FBQztJQUFBLEVBQUMsQ0FBQzBCLElBQUksQ0FBQyxFQUFFLENBQUM7RUFDbEQsQ0FBQyxNQUFNO0lBQ0wsSUFBTUMsS0FBSyxHQUFHLEVBQUU7SUFDaEIsSUFBSXZDLEtBQUssS0FBSyxJQUFJLEVBQUU7TUFDbEJ1QyxLQUFLLENBQUNDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztNQUM1QnhDLEtBQUssR0FBRyxFQUFFO0lBQ1osQ0FBQyxNQUFNLElBQUlaLFdBQVcsQ0FBQ1ksS0FBSyxDQUFDLEVBQUU7TUFDN0IsSUFBTXlDLEtBQUssR0FBRyxFQUFFO01BQ2hCLFNBQUFDLEdBQUEsTUFBQUMsYUFBQSxHQUFnQjNCLFlBQUEsQ0FBWWhCLEtBQUssQ0FBQyxFQUFBMEMsR0FBQSxHQUFBQyxhQUFBLENBQUF2QyxNQUFBLEVBQUFzQyxHQUFBLElBQUU7UUFBL0IsSUFBTXhCLENBQUMsR0FBQXlCLGFBQUEsQ0FBQUQsR0FBQTtRQUNWLElBQU05QixDQUFDLEdBQUdaLEtBQUssQ0FBQ2tCLENBQUMsQ0FBQztRQUNsQixJQUFJRSwyQkFBQSxDQUFBRixDQUFDLEVBQUFQLElBQUEsQ0FBRE8sQ0FBQyxFQUFZLEdBQUcsQ0FBQyxFQUFFO1VBQUEsSUFBQTBCLFNBQUE7VUFDckIsSUFBTUMsRUFBRSxHQUFHM0IsQ0FBQyxDQUFDSyxTQUFTLENBQUMsQ0FBQyxDQUFDO1VBQ3pCZ0IsS0FBSyxDQUFDQyxJQUFJLENBQUFNLHVCQUFBLENBQUFGLFNBQUEsTUFBQUcsTUFBQSxDQUFJRixFQUFFLFVBQUFsQyxJQUFBLENBQUFpQyxTQUFBLEVBQUtoQyxDQUFDLE9BQWEsQ0FBQztRQUN0QyxDQUFDLE1BQU07VUFDTDZCLEtBQUssQ0FBQ0QsSUFBSSxDQUFDSixLQUFLLENBQUNsQixDQUFDLEVBQUVOLENBQUMsQ0FBQyxDQUFDO1FBQ3pCO01BQ0Y7TUFDQVosS0FBSyxHQUFHeUMsS0FBSyxDQUFDSCxJQUFJLENBQUMsRUFBRSxDQUFDO0lBQ3hCLENBQUMsTUFBTTtNQUNMdEMsS0FBSyxHQUFHd0IsTUFBTSxDQUFDeEIsS0FBSyxDQUFDLENBQ2xCZ0QsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FDdEJBLE9BQU8sQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQ3JCQSxPQUFPLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUNyQkEsT0FBTyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FDdkJBLE9BQU8sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDO0lBQzVCO0lBQ0EsSUFBTUMsUUFBUSxHQUFHWixJQUFJLEdBQ2pCLEdBQUcsR0FBR0EsSUFBSSxJQUFJRSxLQUFLLENBQUNuQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBR21DLEtBQUssQ0FBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FDbEUsRUFBRTtJQUNOLElBQU1ZLE1BQU0sR0FBR2IsSUFBSSxHQUFHLElBQUksR0FBR0EsSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFO0lBQzVDLE9BQU9ZLFFBQVEsR0FBR2pELEtBQUssR0FBR2tELE1BQU07RUFDbEM7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7O0FBT0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQWFDLElBQUksMEJBQUFDLFFBQUE7RUFLZixTQUFBRCxLQUFZRSxJQUFtQixFQUFFQyxPQUFvQixFQUFFO0lBQUEsSUFBQUMsS0FBQTtJQUFBQyxlQUFBLE9BQUFMLElBQUE7SUFDckRJLEtBQUEsR0FBQUUsVUFBQSxPQUFBTixJQUFBLEdBQU1FLElBQUksRUFBRUMsT0FBTztJQUNuQixJQUFJQyxLQUFBLENBQUtHLEtBQUssQ0FBQ0MsV0FBVyxJQUFJcEUsVUFBVSxDQUFDZ0UsS0FBQSxDQUFLRyxLQUFLLENBQUNDLFdBQVcsQ0FBQyxFQUFFO01BQ2hFO01BQ0E7TUFDQSxNQUFNLElBQUlDLEtBQUssQ0FDYiwrS0FDRixDQUFDO0lBQ0g7SUFDQUwsS0FBQSxDQUFLTSxZQUFZLEdBQUdQLE9BQU8sQ0FBQ1EsV0FBVztJQUN2Q1AsS0FBQSxDQUFLUSxNQUFNLEdBQUdULE9BQU8sQ0FBQ1UsS0FBSyxJQUFJLDZCQUE2QjtJQUM1RFQsS0FBQSxDQUFLVSxRQUFRLEdBQUdYLE9BQU8sQ0FBQ1ksT0FBTyxJQUFJLElBQUk7SUFBQyxPQUFBWCxLQUFBO0VBQzFDOztFQUVBO0FBQ0Y7QUFDQTtFQUZFWSxTQUFBLENBQUFoQixJQUFBLEVBQUFDLFFBQUE7RUFBQSxPQUFBZ0IsWUFBQSxDQUFBakIsSUFBQTtJQUFBa0IsR0FBQTtJQUFBckUsS0FBQTtNQUFBLElBQUFzRSxPQUFBLEdBQUFDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBQyxRQUNFQyxNQUFjLEVBQ2RDLElBQVksRUFDWm5GLE1BQW1DLEVBQ25DQyxVQUE4QztRQUFBLElBQUFtRixHQUFBO1FBQUEsT0FBQUwsbUJBQUEsQ0FBQU0sSUFBQSxVQUFBQyxTQUFBQyxTQUFBO1VBQUEsa0JBQUFBLFNBQUEsQ0FBQUMsSUFBQSxHQUFBRCxTQUFBLENBQUFFLElBQUE7WUFBQTtjQUFBRixTQUFBLENBQUFFLElBQUE7Y0FBQSxPQUU1QixJQUFJLENBQUNDLE9BQU8sQ0FBQztnQkFDN0JSLE1BQU0sRUFBRSxNQUFNO2dCQUNkUyxHQUFHLEVBQUUsSUFBSSxDQUFDdkIsWUFBWTtnQkFDdEJLLE9BQU8sRUFBRTtrQkFDUCxjQUFjLEVBQUUsVUFBVTtrQkFDMUJtQixVQUFVLEVBQUU7Z0JBQ2QsQ0FBQztnQkFDREMsUUFBUSxFQUFBakUsZUFBQSxLQUFLc0QsTUFBTSxFQUFHQyxJQUFJO2NBQzVCLENBQWdCLENBQUM7WUFBQTtjQVJYQyxHQUFHLEdBQUFHLFNBQUEsQ0FBQU8sSUFBQTtjQUFBLE9BQUFQLFNBQUEsQ0FBQVEsTUFBQSxXQVNGL0YsTUFBTSxHQUFHUyxtQkFBbUIsQ0FBQzJFLEdBQUcsRUFBRXBGLE1BQU0sRUFBRUMsVUFBVSxDQUFDLEdBQUdtRixHQUFHO1lBQUE7WUFBQTtjQUFBLE9BQUFHLFNBQUEsQ0FBQVMsSUFBQTtVQUFBO1FBQUEsR0FBQWYsT0FBQTtNQUFBLENBQ25FO01BQUEsU0FoQktnQixNQUFNQSxDQUFBQyxFQUFBLEVBQUFDLEdBQUEsRUFBQUMsR0FBQSxFQUFBQyxHQUFBO1FBQUEsT0FBQXhCLE9BQUEsQ0FBQXlCLEtBQUEsT0FBQTVGLFNBQUE7TUFBQTtNQUFBLE9BQU51RixNQUFNO0lBQUEsSUFrQlo7RUFBQTtJQUFBckIsR0FBQTtJQUFBckUsS0FBQSxFQUNBLFNBQUFnRyxVQUFVQSxDQUFDYixPQUEyQyxFQUFFO01BQ3REQSxPQUFPLENBQUNjLElBQUksR0FBRyxJQUFJLENBQUNDLGVBQWUsQ0FBQ2YsT0FBTyxDQUFDRyxRQUFRLENBQUM7TUFFckQsSUFBTXBCLE9BQU8sR0FBR2lCLE9BQU8sQ0FBQ2pCLE9BQU8sSUFBSSxDQUFDLENBQUM7TUFFckMsSUFBTWlDLFFBQVEsR0FBRzdHLFdBQVcsQ0FBQzZGLE9BQU8sQ0FBQ2MsSUFBSSxFQUFFZCxPQUFPLENBQUNqQixPQUFPLENBQUM7TUFFM0QsSUFDRSxDQUFDL0UsU0FBUztNQUFJO01BQ2RnRyxPQUFPLENBQUNSLE1BQU0sS0FBSyxNQUFNLElBQ3pCLEVBQUUsbUJBQW1CLElBQUlULE9BQU8sQ0FBQyxJQUNqQyxFQUFFLGdCQUFnQixJQUFJQSxPQUFPLENBQUMsSUFDOUIsQ0FBQyxDQUFDaUMsUUFBUSxFQUNWO1FBQ0EsSUFBSSxDQUFDQyxPQUFPLENBQUNDLEtBQUssb0RBQUF0RCxNQUFBLENBQ21Db0QsUUFBUSxDQUM3RCxDQUFDO1FBQ0RqQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsR0FBRzFDLE1BQU0sQ0FBQzJFLFFBQVEsQ0FBQztNQUM5QztNQUVBaEIsT0FBTyxDQUFDakIsT0FBTyxHQUFHQSxPQUFPO0lBQzNCOztJQUVBO0VBQUE7SUFBQUcsR0FBQTtJQUFBckUsS0FBQSxFQUNBLFNBQUFzRyxnQkFBZ0JBLENBQUNDLFFBQXNCLEVBQUU7TUFDdkMsT0FDRUEsUUFBUSxDQUFDQyxVQUFVLEtBQUssR0FBRyxJQUMzQixzREFBc0QsQ0FBQ3JFLElBQUksQ0FBQ29FLFFBQVEsQ0FBQ04sSUFBSSxDQUFDO0lBRTlFOztJQUVBO0VBQUE7SUFBQTVCLEdBQUE7SUFBQXJFLEtBQUEsRUFDQSxTQUFBeUcsVUFBVUEsQ0FBQ1IsSUFBWSxFQUFFO01BQ3ZCLElBQU1TLEtBQUssR0FBRzlFLFdBQVcsQ0FBQ3FFLElBQUksRUFBRSxDQUFDLFlBQVksRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBRWxFO01BQ0QsT0FBTztRQUNMVSxTQUFTLEVBQUVELEtBQUssQ0FBQ0UsU0FBUztRQUMxQkMsT0FBTyxFQUFFSCxLQUFLLENBQUNJO01BQ2pCLENBQUM7SUFDSDs7SUFFQTtFQUFBO0lBQUF6QyxHQUFBO0lBQUFyRSxLQUFBO01BQUEsSUFBQStHLGdCQUFBLEdBQUF4QyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQ0EsU0FBQXVDLFNBQXNCVCxRQUFzQjtRQUFBLElBQUFOLElBQUEsRUFBQXBCLEdBQUEsRUFBQW9DLE1BQUE7UUFBQSxPQUFBekMsbUJBQUEsQ0FBQU0sSUFBQSxVQUFBb0MsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFsQyxJQUFBLEdBQUFrQyxTQUFBLENBQUFqQyxJQUFBO1lBQUE7Y0FBQWlDLFNBQUEsQ0FBQWpDLElBQUE7Y0FBQSxPQUFBa0MsYUFBQSxDQUFBakUsSUFBQSwrQkFDRG9ELFFBQVE7WUFBQTtjQUEzQ04sSUFBSSxHQUFBa0IsU0FBQSxDQUFBNUIsSUFBQTtjQUNKVixHQUFHLEdBQUdqRCxXQUFXLENBQUNxRSxJQUFJLEVBQUUsQ0FBQyxZQUFZLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO2NBQzdELElBQUlwQixHQUFHLElBQUlBLEdBQUcsQ0FBQ3dDLE1BQU0sSUFBSSxJQUFJLEVBQUU7Z0JBQ3ZCSixNQUFNLEdBQUdyRixXQUFXLENBQUNxRSxJQUFJLEVBQUUsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUNsRSxJQUFJZ0IsTUFBTSxFQUFFO2tCQUNWcEMsR0FBRyxDQUFDd0MsTUFBTSxHQUFBeEgsYUFBQSxDQUFBQSxhQUFBLEtBQ0xnRixHQUFHLENBQUN3QyxNQUFNLEdBQ1ZKLE1BQU0sQ0FDVjtnQkFDSDtjQUNGO2NBQUMsT0FBQUUsU0FBQSxDQUFBM0IsTUFBQSxXQUNNWCxHQUFHO1lBQUE7WUFBQTtjQUFBLE9BQUFzQyxTQUFBLENBQUExQixJQUFBO1VBQUE7UUFBQSxHQUFBdUIsUUFBQTtNQUFBLENBQ1g7TUFBQSxTQWJLTSxlQUFlQSxDQUFBQyxHQUFBO1FBQUEsT0FBQVIsZ0JBQUEsQ0FBQWhCLEtBQUEsT0FBQTVGLFNBQUE7TUFBQTtNQUFBLE9BQWZtSCxlQUFlO0lBQUE7SUFlckI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBakQsR0FBQTtJQUFBckUsS0FBQSxFQUdBLFNBQUFrRyxlQUFlQSxDQUFDVyxPQUFlLEVBQUU7TUFDL0IsSUFBTUksTUFBK0IsR0FBRyxDQUFDLENBQUM7TUFDMUMsSUFBTTVELElBQUksR0FBRyxJQUFJLENBQUNLLEtBQUs7TUFDdkIsSUFBSUwsSUFBSSxDQUFDTSxXQUFXLEVBQUU7UUFDcEJzRCxNQUFNLENBQUNPLGFBQWEsR0FBRztVQUFFQyxTQUFTLEVBQUVwRSxJQUFJLENBQUNNO1FBQVksQ0FBQztNQUN4RDtNQUNBLElBQUlOLElBQUksQ0FBQ3FFLFlBQVksRUFBRTtRQUNyQlQsTUFBTSxDQUFDVSxXQUFXLEdBQUd0RSxJQUFJLENBQUNxRSxZQUFZO01BQ3hDO01BQ0EsT0FBTyxDQUNMLHdDQUF3QyxFQUN4Qyw2RUFBNkUsRUFDN0UsK0NBQStDLEVBQy9DLHlEQUF5RCxFQUN6RCx5QkFBeUIsR0FBRyxJQUFJLENBQUMzRCxNQUFNLEdBQUcsSUFBSSxFQUM5QzNCLEtBQUssQ0FBQzZFLE1BQU0sQ0FBQyxFQUNiLElBQUksQ0FBQ2hELFFBQVEsR0FBQzdCLEtBQUssQ0FBQyxJQUFJLENBQUM2QixRQUFRLENBQUMsR0FBQyxFQUFFLEVBQ3JDLG1CQUFtQixFQUNuQix1QkFBdUIsR0FBRyxJQUFJLENBQUNGLE1BQU0sR0FBRyxJQUFJLEVBQzVDM0IsS0FBSyxDQUFDeUUsT0FBTyxDQUFDLEVBQ2QsaUJBQWlCLEVBQ2pCLHFCQUFxQixDQUN0QixDQUFDdkUsSUFBSSxDQUFDLEVBQUUsQ0FBQztJQUNaO0VBQUM7QUFBQSxFQTdIeUNwRCxPQUFPO0FBZ0luRCxlQUFlaUUsSUFBSSIsImlnbm9yZUxpc3QiOltdfQ==