import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof _Symbol && _getIteratorMethod(r) || r["@@iterator"]; if (!t) { if (_Array$isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { var _context22; if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = _sliceInstanceProperty(_context22 = {}.toString.call(r)).call(_context22, 8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? _Array$from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context20, _context21; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context20 = ownKeys(Object(t), !0)).call(_context20, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context21 = ownKeys(Object(t))).call(_context21, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.number.constructor.js";
import "core-js/modules/es.object.keys.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/es.regexp.to-string.js";
import _startsWithInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/starts-with";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
/**
 * @file Command line interface for JSforce
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import http from 'http';
import url from 'url';
import crypto from 'crypto';
import _openUrl from 'open';
import { Command } from 'commander';
import inquirer from 'inquirer';
import request from '../request';
import base64url from 'base64url';
import Repl from './repl';
import jsforce, { Connection, OAuth2 } from '..';
import version from '../VERSION';
var registry = jsforce.registry;
/**
 *
 */
export var Cli = /*#__PURE__*/function () {
  function Cli() {
    _classCallCheck(this, Cli);
    _defineProperty(this, "_repl", new Repl(this));
    _defineProperty(this, "_conn", new Connection());
    _defineProperty(this, "_connName", undefined);
    _defineProperty(this, "_outputEnabled", true);
    _defineProperty(this, "_defaultLoginUrl", undefined);
  }
  return _createClass(Cli, [{
    key: "readCommand",
    value:
    /**
     *
     */
    function readCommand() {
      return new Command().option('-u, --username [username]', 'Salesforce username').option('-p, --password [password]', 'Salesforce password (and security token, if available)').option('-c, --connection [connection]', 'Connection name stored in connection registry').option('-l, --loginUrl [loginUrl]', 'Salesforce login url').option('--sandbox', 'Login to Salesforce sandbox').option('-e, --evalScript [evalScript]', 'Script to evaluate').version(version).parse(process.argv);
    }
  }, {
    key: "start",
    value: function () {
      var _start = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
        var program;
        return _regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              program = this.readCommand();
              this._outputEnabled = !program.evalScript;
              _context.prev = 2;
              _context.next = 5;
              return this.connect(program);
            case 5:
              if (program.evalScript) {
                this._repl.start({
                  interactive: false,
                  evalScript: program.evalScript
                });
              } else {
                this._repl.start();
              }
              _context.next = 12;
              break;
            case 8:
              _context.prev = 8;
              _context.t0 = _context["catch"](2);
              console.error(_context.t0);
              process.exit();
            case 12:
            case "end":
              return _context.stop();
          }
        }, _callee, this, [[2, 8]]);
      }));
      function start() {
        return _start.apply(this, arguments);
      }
      return start;
    }()
  }, {
    key: "getCurrentConnection",
    value: function getCurrentConnection() {
      return this._conn;
    }
  }, {
    key: "print",
    value: function print() {
      if (this._outputEnabled) {
        var _console;
        (_console = console).log.apply(_console, arguments);
      }
    }
  }, {
    key: "saveCurrentConnection",
    value: function saveCurrentConnection() {
      if (this._connName) {
        var conn = this._conn;
        var connName = this._connName;
        var connConfig = {
          oauth2: conn.oauth2 ? {
            clientId: conn.oauth2.clientId || undefined,
            clientSecret: conn.oauth2.clientSecret || undefined,
            redirectUri: conn.oauth2.redirectUri || undefined,
            loginUrl: conn.oauth2.loginUrl || undefined
          } : undefined,
          accessToken: conn.accessToken || undefined,
          instanceUrl: conn.instanceUrl || undefined,
          refreshToken: conn.refreshToken || undefined
        };
        registry.saveConnectionConfig(connName, connConfig);
      }
    }
  }, {
    key: "setLoginServer",
    value: function setLoginServer(loginServer) {
      if (!loginServer) {
        return;
      }
      if (loginServer === 'production') {
        this._defaultLoginUrl = 'https://login.salesforce.com';
      } else if (loginServer === 'sandbox') {
        this._defaultLoginUrl = 'https://test.salesforce.com';
      } else if (!_startsWithInstanceProperty(loginServer).call(loginServer, 'https://')) {
        this._defaultLoginUrl = 'https://' + loginServer;
      } else {
        this._defaultLoginUrl = loginServer;
      }
      this.print("Using \"".concat(this._defaultLoginUrl, "\" as default login URL."));
    }

    /**
     *
     */
  }, {
    key: "connect",
    value: (function () {
      var _connect = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(options) {
        var _this = this;
        var loginServer, connConfig, username, password, identity;
        return _regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              loginServer = options.loginUrl ? options.loginUrl : options.sandbox ? 'sandbox' : null;
              this.setLoginServer(loginServer);
              this._connName = options.connection;
              _context2.next = 5;
              return registry.getConnectionConfig(options.connection);
            case 5:
              connConfig = _context2.sent;
              username = options.username;
              if (!connConfig) {
                connConfig = {};
                if (this._defaultLoginUrl) {
                  connConfig.loginUrl = this._defaultLoginUrl;
                }
                username = username || options.connection;
              }
              this._conn = new Connection(connConfig);
              password = options.password;
              if (!username) {
                _context2.next = 16;
                break;
              }
              _context2.next = 13;
              return this.startPasswordAuth(username, password);
            case 13:
              this.saveCurrentConnection();
              _context2.next = 34;
              break;
            case 16:
              if (!(this._connName && this._conn.accessToken)) {
                _context2.next = 34;
                break;
              }
              this._conn.on('refresh', function () {
                _this.print('Refreshing access token ... ');
                _this.saveCurrentConnection();
              });
              _context2.prev = 18;
              _context2.next = 21;
              return this._conn.identity();
            case 21:
              identity = _context2.sent;
              this.print("Logged in as : ".concat(identity.username));
              _context2.next = 34;
              break;
            case 25:
              _context2.prev = 25;
              _context2.t0 = _context2["catch"](18);
              if (_context2.t0 instanceof Error) {
                this.print(_context2.t0.message);
              }
              if (!this._conn.oauth2) {
                _context2.next = 32;
                break;
              }
              throw new Error('Please re-authorize connection.');
            case 32:
              _context2.next = 34;
              return this.startPasswordAuth(this._connName);
            case 34:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this, [[18, 25]]);
      }));
      function connect(_x) {
        return _connect.apply(this, arguments);
      }
      return connect;
    }()
    /**
     *
     */
    )
  }, {
    key: "startPasswordAuth",
    value: (function () {
      var _startPasswordAuth = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3(username, password) {
        return _regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              _context3.prev = 0;
              _context3.next = 3;
              return this.loginByPassword(username, password, 2);
            case 3:
              _context3.next = 12;
              break;
            case 5:
              _context3.prev = 5;
              _context3.t0 = _context3["catch"](0);
              if (!(_context3.t0 instanceof Error && _context3.t0.message === 'canceled')) {
                _context3.next = 11;
                break;
              }
              console.error('Password authentication canceled: Not logged in');
              _context3.next = 12;
              break;
            case 11:
              throw _context3.t0;
            case 12:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this, [[0, 5]]);
      }));
      function startPasswordAuth(_x2, _x3) {
        return _startPasswordAuth.apply(this, arguments);
      }
      return startPasswordAuth;
    }()
    /**
     *
     */
    )
  }, {
    key: "loginByPassword",
    value: (function () {
      var _loginByPassword = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4(username, password, retryCount) {
        var pass, result;
        return _regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              if (!(password === '')) {
                _context4.next = 2;
                break;
              }
              throw new Error('canceled');
            case 2:
              if (!(password == null)) {
                _context4.next = 7;
                break;
              }
              _context4.next = 5;
              return this.promptPassword('Password: ');
            case 5:
              pass = _context4.sent;
              return _context4.abrupt("return", this.loginByPassword(username, pass, retryCount));
            case 7:
              _context4.prev = 7;
              _context4.next = 10;
              return this._conn.login(username, password);
            case 10:
              result = _context4.sent;
              this.print("Logged in as : ".concat(username));
              return _context4.abrupt("return", result);
            case 15:
              _context4.prev = 15;
              _context4.t0 = _context4["catch"](7);
              if (_context4.t0 instanceof Error) {
                console.error(_context4.t0.message);
              }
              if (!(retryCount > 0)) {
                _context4.next = 22;
                break;
              }
              return _context4.abrupt("return", this.loginByPassword(username, undefined, retryCount - 1));
            case 22:
              throw new Error('canceled');
            case 23:
            case "end":
              return _context4.stop();
          }
        }, _callee4, this, [[7, 15]]);
      }));
      function loginByPassword(_x4, _x5, _x6) {
        return _loginByPassword.apply(this, arguments);
      }
      return loginByPassword;
    }()
    /**
     *
     */
    )
  }, {
    key: "disconnect",
    value: (function () {
      var _disconnect = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee5(connName) {
        var name;
        return _regeneratorRuntime.wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              name = connName || this._connName;
              _context5.t0 = name;
              if (!_context5.t0) {
                _context5.next = 6;
                break;
              }
              _context5.next = 5;
              return registry.getConnectionConfig(name);
            case 5:
              _context5.t0 = _context5.sent;
            case 6:
              if (!_context5.t0) {
                _context5.next = 10;
                break;
              }
              _context5.next = 9;
              return registry.removeConnectionConfig(name);
            case 9:
              this.print("Disconnect connection '".concat(name, "'"));
            case 10:
              this._connName = undefined;
              this._conn = new Connection();
            case 12:
            case "end":
              return _context5.stop();
          }
        }, _callee5, this);
      }));
      function disconnect(_x7) {
        return _disconnect.apply(this, arguments);
      }
      return disconnect;
    }()
    /**
     *
     */
    )
  }, {
    key: "authorize",
    value: (function () {
      var _authorize = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee6(clientName) {
        var name, oauth2Config, oauth2, verifier, challenge, state, authzUrl, params, identity;
        return _regeneratorRuntime.wrap(function _callee6$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              name = clientName || 'default';
              _context6.next = 3;
              return registry.getClientConfig(name);
            case 3:
              oauth2Config = _context6.sent;
              if (oauth2Config !== null && oauth2Config !== void 0 && oauth2Config.clientId) {
                _context6.next = 9;
                break;
              }
              if (!(name === 'default' || name === 'sandbox')) {
                _context6.next = 8;
                break;
              }
              this.print('No client information registered. Downloading JSforce default client information...');
              return _context6.abrupt("return", this.downloadDefaultClientInfo(name));
            case 8:
              throw new Error("No OAuth2 client information registered : '".concat(name, "'. Please register client info first."));
            case 9:
              oauth2 = new OAuth2(oauth2Config);
              verifier = base64url.encode(crypto.randomBytes(32));
              challenge = base64url.encode(crypto.createHash('sha256').update(verifier).digest());
              state = base64url.encode(crypto.randomBytes(32));
              authzUrl = oauth2.getAuthorizationUrl({
                code_challenge: challenge,
                state: state
              });
              this.print('Opening authorization page in browser...');
              this.print("URL: ".concat(authzUrl));
              this.openUrl(authzUrl);
              _context6.next = 19;
              return this.waitCallback(oauth2Config.redirectUri, state);
            case 19:
              params = _context6.sent;
              if (params.code) {
                _context6.next = 22;
                break;
              }
              throw new Error('No authorization code returned.');
            case 22:
              if (!(params.state !== state)) {
                _context6.next = 24;
                break;
              }
              throw new Error('Invalid state parameter returned.');
            case 24:
              this._conn = new Connection({
                oauth2: oauth2
              });
              this.print('Received authorization code. Please close the opened browser window.');
              _context6.next = 28;
              return this._conn.authorize(params.code, {
                code_verifier: verifier
              });
            case 28:
              this.print('Authorized. Fetching user info...');
              _context6.next = 31;
              return this._conn.identity();
            case 31:
              identity = _context6.sent;
              this.print("Logged in as : ".concat(identity.username));
              this._connName = identity.username;
              this.saveCurrentConnection();
            case 35:
            case "end":
              return _context6.stop();
          }
        }, _callee6, this);
      }));
      function authorize(_x8) {
        return _authorize.apply(this, arguments);
      }
      return authorize;
    }()
    /**
     *
     */
    )
  }, {
    key: "downloadDefaultClientInfo",
    value: (function () {
      var _downloadDefaultClientInfo = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee7(clientName) {
        var configUrl, res, clientConfig;
        return _regeneratorRuntime.wrap(function _callee7$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              configUrl = 'https://jsforce.github.io/client-config/default.json';
              _context7.next = 3;
              return new _Promise(function (resolve, reject) {
                request({
                  method: 'GET',
                  url: configUrl
                }).on('complete', resolve).on('error', reject);
              });
            case 3:
              res = _context7.sent;
              clientConfig = JSON.parse(res.body);
              if (clientName === 'sandbox') {
                clientConfig.loginUrl = 'https://test.salesforce.com';
              }
              _context7.next = 8;
              return registry.registerClientConfig(clientName, clientConfig);
            case 8:
              this.print('Client information downloaded successfully.');
              return _context7.abrupt("return", this.authorize(clientName));
            case 10:
            case "end":
              return _context7.stop();
          }
        }, _callee7, this);
      }));
      function downloadDefaultClientInfo(_x9) {
        return _downloadDefaultClientInfo.apply(this, arguments);
      }
      return downloadDefaultClientInfo;
    }())
  }, {
    key: "waitCallback",
    value: function () {
      var _waitCallback = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee8(serverUrl, state) {
        var code;
        return _regeneratorRuntime.wrap(function _callee8$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              if (!(serverUrl && _startsWithInstanceProperty(serverUrl).call(serverUrl, 'http://localhost:'))) {
                _context8.next = 4;
                break;
              }
              return _context8.abrupt("return", new _Promise(function (resolve, reject) {
                var server = http.createServer(function (req, res) {
                  if (!req.url) {
                    return;
                  }
                  var qparams = url.parse(req.url, true).query;
                  res.writeHead(200, {
                    'Content-Type': 'text/html'
                  });
                  res.write('<html><script>location.href="about:blank";</script></html>');
                  res.end();
                  if (qparams.error) {
                    reject(new Error(qparams.error));
                  } else {
                    resolve(qparams);
                  }
                  server.close();
                  req.connection.end();
                  req.connection.destroy();
                });
                var port = Number(url.parse(serverUrl).port);
                server.listen(port, 'localhost');
              }));
            case 4:
              _context8.next = 6;
              return this.promptMessage('Copy & paste authz code passed in redirected URL: ');
            case 6:
              code = _context8.sent;
              return _context8.abrupt("return", {
                code: decodeURIComponent(code),
                state: state
              });
            case 8:
            case "end":
              return _context8.stop();
          }
        }, _callee8, this);
      }));
      function waitCallback(_x10, _x11) {
        return _waitCallback.apply(this, arguments);
      }
      return waitCallback;
    }()
    /**
     *
     */
  }, {
    key: "register",
    value: (function () {
      var _register = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee10(clientName, clientConfig) {
        var _context9,
          _this2 = this;
        var name, prompts, registered, msg, ok;
        return _regeneratorRuntime.wrap(function _callee10$(_context11) {
          while (1) switch (_context11.prev = _context11.next) {
            case 0:
              name = clientName || 'default';
              prompts = {
                clientId: 'Input client ID : ',
                clientSecret: 'Input client secret (optional) : ',
                redirectUri: 'Input redirect URI : ',
                loginUrl: 'Input login URL (default is https://login.salesforce.com) : '
              };
              _context11.next = 4;
              return registry.getClientConfig(name);
            case 4:
              registered = _context11.sent;
              if (!registered) {
                _context11.next = 12;
                break;
              }
              msg = "Client '".concat(name, "' is already registered. Are you sure you want to override ? [yN] : ");
              _context11.next = 9;
              return this.promptConfirm(msg);
            case 9:
              ok = _context11.sent;
              if (ok) {
                _context11.next = 12;
                break;
              }
              throw new Error('Registration canceled.');
            case 12:
              _context11.next = 14;
              return _reduceInstanceProperty(_context9 = _Object$keys(prompts)).call(_context9, /*#__PURE__*/function () {
                var _ref = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee9(promise, name) {
                  var cconfig, promptName, message, value;
                  return _regeneratorRuntime.wrap(function _callee9$(_context10) {
                    while (1) switch (_context10.prev = _context10.next) {
                      case 0:
                        _context10.next = 2;
                        return promise;
                      case 2:
                        cconfig = _context10.sent;
                        promptName = name;
                        message = prompts[promptName];
                        if (cconfig[promptName]) {
                          _context10.next = 11;
                          break;
                        }
                        _context10.next = 8;
                        return _this2.promptMessage(message);
                      case 8:
                        value = _context10.sent;
                        if (!value) {
                          _context10.next = 11;
                          break;
                        }
                        return _context10.abrupt("return", _objectSpread(_objectSpread({}, cconfig), {}, _defineProperty({}, promptName, value)));
                      case 11:
                        return _context10.abrupt("return", cconfig);
                      case 12:
                      case "end":
                        return _context10.stop();
                    }
                  }, _callee9);
                }));
                return function (_x14, _x15) {
                  return _ref.apply(this, arguments);
                };
              }(), _Promise.resolve(clientConfig));
            case 14:
              clientConfig = _context11.sent;
              _context11.next = 17;
              return registry.registerClientConfig(name, clientConfig);
            case 17:
              this.print('Client registered successfully.');
            case 18:
            case "end":
              return _context11.stop();
          }
        }, _callee10, this);
      }));
      function register(_x12, _x13) {
        return _register.apply(this, arguments);
      }
      return register;
    }()
    /**
     *
     */
    )
  }, {
    key: "listConnections",
    value: (function () {
      var _listConnections = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee11() {
        var names, _iterator, _step, name;
        return _regeneratorRuntime.wrap(function _callee11$(_context12) {
          while (1) switch (_context12.prev = _context12.next) {
            case 0:
              _context12.next = 2;
              return registry.getConnectionNames();
            case 2:
              names = _context12.sent;
              _iterator = _createForOfIteratorHelper(names);
              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  name = _step.value;
                  this.print((name === this._connName ? '* ' : '  ') + name);
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            case 5:
            case "end":
              return _context12.stop();
          }
        }, _callee11, this);
      }));
      function listConnections() {
        return _listConnections.apply(this, arguments);
      }
      return listConnections;
    }()
    /**
     *
     */
    )
  }, {
    key: "getConnectionNames",
    value: (function () {
      var _getConnectionNames = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee12() {
        return _regeneratorRuntime.wrap(function _callee12$(_context13) {
          while (1) switch (_context13.prev = _context13.next) {
            case 0:
              return _context13.abrupt("return", registry.getConnectionNames());
            case 1:
            case "end":
              return _context13.stop();
          }
        }, _callee12);
      }));
      function getConnectionNames() {
        return _getConnectionNames.apply(this, arguments);
      }
      return getConnectionNames;
    }()
    /**
     *
     */
    )
  }, {
    key: "getClientNames",
    value: (function () {
      var _getClientNames = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee13() {
        return _regeneratorRuntime.wrap(function _callee13$(_context14) {
          while (1) switch (_context14.prev = _context14.next) {
            case 0:
              return _context14.abrupt("return", registry.getClientNames());
            case 1:
            case "end":
              return _context14.stop();
          }
        }, _callee13);
      }));
      function getClientNames() {
        return _getClientNames.apply(this, arguments);
      }
      return getClientNames;
    }()
    /**
     *
     */
    )
  }, {
    key: "prompt",
    value: (function () {
      var _prompt = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee14(type, message) {
        var answer;
        return _regeneratorRuntime.wrap(function _callee14$(_context15) {
          while (1) switch (_context15.prev = _context15.next) {
            case 0:
              this._repl.pause();
              _context15.next = 3;
              return inquirer.prompt([{
                type: type,
                name: 'value',
                message: message
              }]);
            case 3:
              answer = _context15.sent;
              this._repl.resume();
              return _context15.abrupt("return", answer.value);
            case 6:
            case "end":
              return _context15.stop();
          }
        }, _callee14, this);
      }));
      function prompt(_x16, _x17) {
        return _prompt.apply(this, arguments);
      }
      return prompt;
    }()
    /**
     *
     */
    )
  }, {
    key: "promptMessage",
    value: (function () {
      var _promptMessage = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee15(message) {
        return _regeneratorRuntime.wrap(function _callee15$(_context16) {
          while (1) switch (_context16.prev = _context16.next) {
            case 0:
              return _context16.abrupt("return", this.prompt('input', message));
            case 1:
            case "end":
              return _context16.stop();
          }
        }, _callee15, this);
      }));
      function promptMessage(_x18) {
        return _promptMessage.apply(this, arguments);
      }
      return promptMessage;
    }())
  }, {
    key: "promptPassword",
    value: function () {
      var _promptPassword = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee16(message) {
        return _regeneratorRuntime.wrap(function _callee16$(_context17) {
          while (1) switch (_context17.prev = _context17.next) {
            case 0:
              return _context17.abrupt("return", this.prompt('password', message));
            case 1:
            case "end":
              return _context17.stop();
          }
        }, _callee16, this);
      }));
      function promptPassword(_x19) {
        return _promptPassword.apply(this, arguments);
      }
      return promptPassword;
    }()
    /**
     *
     */
  }, {
    key: "promptConfirm",
    value: (function () {
      var _promptConfirm = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee17(message) {
        return _regeneratorRuntime.wrap(function _callee17$(_context18) {
          while (1) switch (_context18.prev = _context18.next) {
            case 0:
              return _context18.abrupt("return", this.prompt('confirm', message));
            case 1:
            case "end":
              return _context18.stop();
          }
        }, _callee17, this);
      }));
      function promptConfirm(_x20) {
        return _promptConfirm.apply(this, arguments);
      }
      return promptConfirm;
    }()
    /**
     *
     */
    )
  }, {
    key: "openUrl",
    value: function openUrl(url) {
      _openUrl(url);
    }

    /**
     *
     */
  }, {
    key: "openUrlUsingSession",
    value: function openUrlUsingSession(url) {
      var _context19;
      var frontdoorUrl = _concatInstanceProperty(_context19 = "".concat(this._conn.instanceUrl, "/secur/frontdoor.jsp?sid=")).call(_context19, this._conn.accessToken);
      if (url) {
        frontdoorUrl += '&retURL=' + encodeURIComponent(url);
      }
      this.openUrl(frontdoorUrl);
    }
  }]);
}();

/* ------------------------------------------------------------------------- */

var cli = new Cli();
export default cli;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJodHRwIiwidXJsIiwiY3J5cHRvIiwib3BlblVybCIsIkNvbW1hbmQiLCJpbnF1aXJlciIsInJlcXVlc3QiLCJiYXNlNjR1cmwiLCJSZXBsIiwianNmb3JjZSIsIkNvbm5lY3Rpb24iLCJPQXV0aDIiLCJ2ZXJzaW9uIiwicmVnaXN0cnkiLCJDbGkiLCJfY2xhc3NDYWxsQ2hlY2siLCJfZGVmaW5lUHJvcGVydHkiLCJ1bmRlZmluZWQiLCJfY3JlYXRlQ2xhc3MiLCJrZXkiLCJ2YWx1ZSIsInJlYWRDb21tYW5kIiwib3B0aW9uIiwicGFyc2UiLCJwcm9jZXNzIiwiYXJndiIsIl9zdGFydCIsIl9hc3luY1RvR2VuZXJhdG9yIiwiX3JlZ2VuZXJhdG9yUnVudGltZSIsIm1hcmsiLCJfY2FsbGVlIiwicHJvZ3JhbSIsIndyYXAiLCJfY2FsbGVlJCIsIl9jb250ZXh0IiwicHJldiIsIm5leHQiLCJfb3V0cHV0RW5hYmxlZCIsImV2YWxTY3JpcHQiLCJjb25uZWN0IiwiX3JlcGwiLCJzdGFydCIsImludGVyYWN0aXZlIiwidDAiLCJjb25zb2xlIiwiZXJyb3IiLCJleGl0Iiwic3RvcCIsImFwcGx5IiwiYXJndW1lbnRzIiwiZ2V0Q3VycmVudENvbm5lY3Rpb24iLCJfY29ubiIsInByaW50IiwiX2NvbnNvbGUiLCJsb2ciLCJzYXZlQ3VycmVudENvbm5lY3Rpb24iLCJfY29ubk5hbWUiLCJjb25uIiwiY29ubk5hbWUiLCJjb25uQ29uZmlnIiwib2F1dGgyIiwiY2xpZW50SWQiLCJjbGllbnRTZWNyZXQiLCJyZWRpcmVjdFVyaSIsImxvZ2luVXJsIiwiYWNjZXNzVG9rZW4iLCJpbnN0YW5jZVVybCIsInJlZnJlc2hUb2tlbiIsInNhdmVDb25uZWN0aW9uQ29uZmlnIiwic2V0TG9naW5TZXJ2ZXIiLCJsb2dpblNlcnZlciIsIl9kZWZhdWx0TG9naW5VcmwiLCJfc3RhcnRzV2l0aEluc3RhbmNlUHJvcGVydHkiLCJjYWxsIiwiY29uY2F0IiwiX2Nvbm5lY3QiLCJfY2FsbGVlMiIsIm9wdGlvbnMiLCJfdGhpcyIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJpZGVudGl0eSIsIl9jYWxsZWUyJCIsIl9jb250ZXh0MiIsInNhbmRib3giLCJjb25uZWN0aW9uIiwiZ2V0Q29ubmVjdGlvbkNvbmZpZyIsInNlbnQiLCJzdGFydFBhc3N3b3JkQXV0aCIsIm9uIiwiRXJyb3IiLCJtZXNzYWdlIiwiX3giLCJfc3RhcnRQYXNzd29yZEF1dGgiLCJfY2FsbGVlMyIsIl9jYWxsZWUzJCIsIl9jb250ZXh0MyIsImxvZ2luQnlQYXNzd29yZCIsIl94MiIsIl94MyIsIl9sb2dpbkJ5UGFzc3dvcmQiLCJfY2FsbGVlNCIsInJldHJ5Q291bnQiLCJwYXNzIiwicmVzdWx0IiwiX2NhbGxlZTQkIiwiX2NvbnRleHQ0IiwicHJvbXB0UGFzc3dvcmQiLCJhYnJ1cHQiLCJsb2dpbiIsIl94NCIsIl94NSIsIl94NiIsIl9kaXNjb25uZWN0IiwiX2NhbGxlZTUiLCJuYW1lIiwiX2NhbGxlZTUkIiwiX2NvbnRleHQ1IiwicmVtb3ZlQ29ubmVjdGlvbkNvbmZpZyIsImRpc2Nvbm5lY3QiLCJfeDciLCJfYXV0aG9yaXplIiwiX2NhbGxlZTYiLCJjbGllbnROYW1lIiwib2F1dGgyQ29uZmlnIiwidmVyaWZpZXIiLCJjaGFsbGVuZ2UiLCJzdGF0ZSIsImF1dGh6VXJsIiwicGFyYW1zIiwiX2NhbGxlZTYkIiwiX2NvbnRleHQ2IiwiZ2V0Q2xpZW50Q29uZmlnIiwiZG93bmxvYWREZWZhdWx0Q2xpZW50SW5mbyIsImVuY29kZSIsInJhbmRvbUJ5dGVzIiwiY3JlYXRlSGFzaCIsInVwZGF0ZSIsImRpZ2VzdCIsImdldEF1dGhvcml6YXRpb25VcmwiLCJjb2RlX2NoYWxsZW5nZSIsIndhaXRDYWxsYmFjayIsImNvZGUiLCJhdXRob3JpemUiLCJjb2RlX3ZlcmlmaWVyIiwiX3g4IiwiX2Rvd25sb2FkRGVmYXVsdENsaWVudEluZm8iLCJfY2FsbGVlNyIsImNvbmZpZ1VybCIsInJlcyIsImNsaWVudENvbmZpZyIsIl9jYWxsZWU3JCIsIl9jb250ZXh0NyIsIl9Qcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsIm1ldGhvZCIsIkpTT04iLCJib2R5IiwicmVnaXN0ZXJDbGllbnRDb25maWciLCJfeDkiLCJfd2FpdENhbGxiYWNrIiwiX2NhbGxlZTgiLCJzZXJ2ZXJVcmwiLCJfY2FsbGVlOCQiLCJfY29udGV4dDgiLCJzZXJ2ZXIiLCJjcmVhdGVTZXJ2ZXIiLCJyZXEiLCJxcGFyYW1zIiwicXVlcnkiLCJ3cml0ZUhlYWQiLCJ3cml0ZSIsImVuZCIsImNsb3NlIiwiZGVzdHJveSIsInBvcnQiLCJOdW1iZXIiLCJsaXN0ZW4iLCJwcm9tcHRNZXNzYWdlIiwiZGVjb2RlVVJJQ29tcG9uZW50IiwiX3gxMCIsIl94MTEiLCJfcmVnaXN0ZXIiLCJfY2FsbGVlMTAiLCJfY29udGV4dDkiLCJfdGhpczIiLCJwcm9tcHRzIiwicmVnaXN0ZXJlZCIsIm1zZyIsIm9rIiwiX2NhbGxlZTEwJCIsIl9jb250ZXh0MTEiLCJwcm9tcHRDb25maXJtIiwiX3JlZHVjZUluc3RhbmNlUHJvcGVydHkiLCJfT2JqZWN0JGtleXMiLCJfcmVmIiwiX2NhbGxlZTkiLCJwcm9taXNlIiwiY2NvbmZpZyIsInByb21wdE5hbWUiLCJfY2FsbGVlOSQiLCJfY29udGV4dDEwIiwiX29iamVjdFNwcmVhZCIsIl94MTQiLCJfeDE1IiwicmVnaXN0ZXIiLCJfeDEyIiwiX3gxMyIsIl9saXN0Q29ubmVjdGlvbnMiLCJfY2FsbGVlMTEiLCJuYW1lcyIsIl9pdGVyYXRvciIsIl9zdGVwIiwiX2NhbGxlZTExJCIsIl9jb250ZXh0MTIiLCJnZXRDb25uZWN0aW9uTmFtZXMiLCJfY3JlYXRlRm9yT2ZJdGVyYXRvckhlbHBlciIsInMiLCJuIiwiZG9uZSIsImVyciIsImUiLCJmIiwibGlzdENvbm5lY3Rpb25zIiwiX2dldENvbm5lY3Rpb25OYW1lcyIsIl9jYWxsZWUxMiIsIl9jYWxsZWUxMiQiLCJfY29udGV4dDEzIiwiX2dldENsaWVudE5hbWVzIiwiX2NhbGxlZTEzIiwiX2NhbGxlZTEzJCIsIl9jb250ZXh0MTQiLCJnZXRDbGllbnROYW1lcyIsIl9wcm9tcHQiLCJfY2FsbGVlMTQiLCJ0eXBlIiwiYW5zd2VyIiwiX2NhbGxlZTE0JCIsIl9jb250ZXh0MTUiLCJwYXVzZSIsInByb21wdCIsInJlc3VtZSIsIl94MTYiLCJfeDE3IiwiX3Byb21wdE1lc3NhZ2UiLCJfY2FsbGVlMTUiLCJfY2FsbGVlMTUkIiwiX2NvbnRleHQxNiIsIl94MTgiLCJfcHJvbXB0UGFzc3dvcmQiLCJfY2FsbGVlMTYiLCJfY2FsbGVlMTYkIiwiX2NvbnRleHQxNyIsIl94MTkiLCJfcHJvbXB0Q29uZmlybSIsIl9jYWxsZWUxNyIsIl9jYWxsZWUxNyQiLCJfY29udGV4dDE4IiwiX3gyMCIsIm9wZW5VcmxVc2luZ1Nlc3Npb24iLCJfY29udGV4dDE5IiwiZnJvbnRkb29yVXJsIiwiX2NvbmNhdEluc3RhbmNlUHJvcGVydHkiLCJlbmNvZGVVUklDb21wb25lbnQiLCJjbGkiXSwic291cmNlcyI6WyIuLi8uLi9zcmMvY2xpL2NsaS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIENvbW1hbmQgbGluZSBpbnRlcmZhY2UgZm9yIEpTZm9yY2VcbiAqIEBhdXRob3IgU2hpbmljaGkgVG9taXRhIDxzaGluaWNoaS50b21pdGFAZ21haWwuY29tPlxuICovXG5pbXBvcnQgaHR0cCBmcm9tICdodHRwJztcbmltcG9ydCB1cmwgZnJvbSAndXJsJztcbmltcG9ydCBjcnlwdG8gZnJvbSAnY3J5cHRvJztcbmltcG9ydCBvcGVuVXJsIGZyb20gJ29wZW4nO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJ2NvbW1hbmRlcic7XG5pbXBvcnQgaW5xdWlyZXIgZnJvbSAnaW5xdWlyZXInO1xuaW1wb3J0IHJlcXVlc3QgZnJvbSAnLi4vcmVxdWVzdCc7XG5pbXBvcnQgYmFzZTY0dXJsIGZyb20gJ2Jhc2U2NHVybCc7XG5pbXBvcnQgUmVwbCBmcm9tICcuL3JlcGwnO1xuaW1wb3J0IGpzZm9yY2UsIHsgQ29ubmVjdGlvbiwgT0F1dGgyIH0gZnJvbSAnLi4nO1xuaW1wb3J0IHZlcnNpb24gZnJvbSAnLi4vVkVSU0lPTic7XG5pbXBvcnQgeyBPcHRpb25hbCB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IENsaWVudENvbmZpZyB9IGZyb20gJy4uL3JlZ2lzdHJ5L3R5cGVzJztcblxuY29uc3QgcmVnaXN0cnkgPSBqc2ZvcmNlLnJlZ2lzdHJ5O1xuXG50eXBlIENsaUNvbW1hbmQgPSB7XG4gIGNvbm5lY3Rpb24/OiBzdHJpbmc7XG4gIHVzZXJuYW1lPzogc3RyaW5nO1xuICBwYXNzd29yZD86IHN0cmluZztcbiAgbG9naW5Vcmw/OiBzdHJpbmc7XG4gIHNhbmRib3g/OiBib29sZWFuO1xuICBldmFsU2NyaXB0Pzogc3RyaW5nO1xufSAmIENvbW1hbmRcblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgQ2xpIHtcbiAgX3JlcGw6IFJlcGwgPSBuZXcgUmVwbCh0aGlzKTtcbiAgX2Nvbm46IENvbm5lY3Rpb24gPSBuZXcgQ29ubmVjdGlvbigpO1xuICBfY29ubk5hbWU6IHN0cmluZyB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcbiAgX291dHB1dEVuYWJsZWQ6IGJvb2xlYW4gPSB0cnVlO1xuICBfZGVmYXVsdExvZ2luVXJsOiBzdHJpbmcgfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICByZWFkQ29tbWFuZCgpOiBDbGlDb21tYW5kIHtcbiAgICByZXR1cm4gbmV3IENvbW1hbmQoKVxuICAgICAgLm9wdGlvbignLXUsIC0tdXNlcm5hbWUgW3VzZXJuYW1lXScsICdTYWxlc2ZvcmNlIHVzZXJuYW1lJylcbiAgICAgIC5vcHRpb24oXG4gICAgICAgICctcCwgLS1wYXNzd29yZCBbcGFzc3dvcmRdJyxcbiAgICAgICAgJ1NhbGVzZm9yY2UgcGFzc3dvcmQgKGFuZCBzZWN1cml0eSB0b2tlbiwgaWYgYXZhaWxhYmxlKScsXG4gICAgICApXG4gICAgICAub3B0aW9uKFxuICAgICAgICAnLWMsIC0tY29ubmVjdGlvbiBbY29ubmVjdGlvbl0nLFxuICAgICAgICAnQ29ubmVjdGlvbiBuYW1lIHN0b3JlZCBpbiBjb25uZWN0aW9uIHJlZ2lzdHJ5JyxcbiAgICAgIClcbiAgICAgIC5vcHRpb24oJy1sLCAtLWxvZ2luVXJsIFtsb2dpblVybF0nLCAnU2FsZXNmb3JjZSBsb2dpbiB1cmwnKVxuICAgICAgLm9wdGlvbignLS1zYW5kYm94JywgJ0xvZ2luIHRvIFNhbGVzZm9yY2Ugc2FuZGJveCcpXG4gICAgICAub3B0aW9uKCctZSwgLS1ldmFsU2NyaXB0IFtldmFsU2NyaXB0XScsICdTY3JpcHQgdG8gZXZhbHVhdGUnKVxuICAgICAgLnZlcnNpb24odmVyc2lvbilcbiAgICAgIC5wYXJzZShwcm9jZXNzLmFyZ3YpO1xuICB9XG5cbiAgYXN5bmMgc3RhcnQoKSB7XG4gICAgY29uc3QgcHJvZ3JhbSA9IHRoaXMucmVhZENvbW1hbmQoKTtcbiAgICB0aGlzLl9vdXRwdXRFbmFibGVkID0gIXByb2dyYW0uZXZhbFNjcmlwdDtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5jb25uZWN0KHByb2dyYW0pO1xuICAgICAgaWYgKHByb2dyYW0uZXZhbFNjcmlwdCkge1xuICAgICAgICB0aGlzLl9yZXBsLnN0YXJ0KHtcbiAgICAgICAgICBpbnRlcmFjdGl2ZTogZmFsc2UsXG4gICAgICAgICAgZXZhbFNjcmlwdDogcHJvZ3JhbS5ldmFsU2NyaXB0LFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX3JlcGwuc3RhcnQoKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgIHByb2Nlc3MuZXhpdCgpO1xuICAgIH1cbiAgfVxuXG4gIGdldEN1cnJlbnRDb25uZWN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLl9jb25uO1xuICB9XG5cbiAgcHJpbnQoLi4uYXJnczogYW55W10pIHtcbiAgICBpZiAodGhpcy5fb3V0cHV0RW5hYmxlZCkge1xuICAgICAgY29uc29sZS5sb2coLi4uYXJncyk7XG4gICAgfVxuICB9XG5cbiAgc2F2ZUN1cnJlbnRDb25uZWN0aW9uKCkge1xuICAgIGlmICh0aGlzLl9jb25uTmFtZSkge1xuICAgICAgY29uc3QgY29ubiA9IHRoaXMuX2Nvbm47XG4gICAgICBjb25zdCBjb25uTmFtZSA9IHRoaXMuX2Nvbm5OYW1lO1xuICAgICAgY29uc3QgY29ubkNvbmZpZyA9IHtcbiAgICAgICAgb2F1dGgyOiBjb25uLm9hdXRoMlxuICAgICAgICAgID8ge1xuICAgICAgICAgICAgICBjbGllbnRJZDogY29ubi5vYXV0aDIuY2xpZW50SWQgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICBjbGllbnRTZWNyZXQ6IGNvbm4ub2F1dGgyLmNsaWVudFNlY3JldCB8fCB1bmRlZmluZWQsXG4gICAgICAgICAgICAgIHJlZGlyZWN0VXJpOiBjb25uLm9hdXRoMi5yZWRpcmVjdFVyaSB8fCB1bmRlZmluZWQsXG4gICAgICAgICAgICAgIGxvZ2luVXJsOiBjb25uLm9hdXRoMi5sb2dpblVybCB8fCB1bmRlZmluZWQsXG4gICAgICAgICAgICB9XG4gICAgICAgICAgOiB1bmRlZmluZWQsXG4gICAgICAgIGFjY2Vzc1Rva2VuOiBjb25uLmFjY2Vzc1Rva2VuIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgaW5zdGFuY2VVcmw6IGNvbm4uaW5zdGFuY2VVcmwgfHwgdW5kZWZpbmVkLFxuICAgICAgICByZWZyZXNoVG9rZW46IGNvbm4ucmVmcmVzaFRva2VuIHx8IHVuZGVmaW5lZCxcbiAgICAgIH07XG4gICAgICByZWdpc3RyeS5zYXZlQ29ubmVjdGlvbkNvbmZpZyhjb25uTmFtZSwgY29ubkNvbmZpZyk7XG4gICAgfVxuICB9XG5cbiAgc2V0TG9naW5TZXJ2ZXIobG9naW5TZXJ2ZXI6IE9wdGlvbmFsPHN0cmluZz4pIHtcbiAgICBpZiAoIWxvZ2luU2VydmVyKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChsb2dpblNlcnZlciA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICB0aGlzLl9kZWZhdWx0TG9naW5VcmwgPSAnaHR0cHM6Ly9sb2dpbi5zYWxlc2ZvcmNlLmNvbSc7XG4gICAgfSBlbHNlIGlmIChsb2dpblNlcnZlciA9PT0gJ3NhbmRib3gnKSB7XG4gICAgICB0aGlzLl9kZWZhdWx0TG9naW5VcmwgPSAnaHR0cHM6Ly90ZXN0LnNhbGVzZm9yY2UuY29tJztcbiAgICB9IGVsc2UgaWYgKCFsb2dpblNlcnZlci5zdGFydHNXaXRoKCdodHRwczovLycpKSB7XG4gICAgICB0aGlzLl9kZWZhdWx0TG9naW5VcmwgPSAnaHR0cHM6Ly8nICsgbG9naW5TZXJ2ZXI7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2RlZmF1bHRMb2dpblVybCA9IGxvZ2luU2VydmVyO1xuICAgIH1cbiAgICB0aGlzLnByaW50KGBVc2luZyBcIiR7dGhpcy5fZGVmYXVsdExvZ2luVXJsfVwiIGFzIGRlZmF1bHQgbG9naW4gVVJMLmApO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBhc3luYyBjb25uZWN0KG9wdGlvbnM6IHtcbiAgICB1c2VybmFtZT86IHN0cmluZztcbiAgICBwYXNzd29yZD86IHN0cmluZztcbiAgICBjb25uZWN0aW9uPzogc3RyaW5nO1xuICAgIGxvZ2luVXJsPzogc3RyaW5nO1xuICAgIHNhbmRib3g/OiBib29sZWFuO1xuICB9KSB7XG4gICAgY29uc3QgbG9naW5TZXJ2ZXIgPSBvcHRpb25zLmxvZ2luVXJsXG4gICAgICA/IG9wdGlvbnMubG9naW5VcmxcbiAgICAgIDogb3B0aW9ucy5zYW5kYm94XG4gICAgICA/ICdzYW5kYm94J1xuICAgICAgOiBudWxsO1xuICAgIHRoaXMuc2V0TG9naW5TZXJ2ZXIobG9naW5TZXJ2ZXIpO1xuICAgIHRoaXMuX2Nvbm5OYW1lID0gb3B0aW9ucy5jb25uZWN0aW9uO1xuICAgIGxldCBjb25uQ29uZmlnID0gYXdhaXQgcmVnaXN0cnkuZ2V0Q29ubmVjdGlvbkNvbmZpZyhvcHRpb25zLmNvbm5lY3Rpb24pO1xuICAgIGxldCB1c2VybmFtZSA9IG9wdGlvbnMudXNlcm5hbWU7XG4gICAgaWYgKCFjb25uQ29uZmlnKSB7XG4gICAgICBjb25uQ29uZmlnID0ge307XG4gICAgICBpZiAodGhpcy5fZGVmYXVsdExvZ2luVXJsKSB7XG4gICAgICAgIGNvbm5Db25maWcubG9naW5VcmwgPSB0aGlzLl9kZWZhdWx0TG9naW5Vcmw7XG4gICAgICB9XG4gICAgICB1c2VybmFtZSA9IHVzZXJuYW1lIHx8IG9wdGlvbnMuY29ubmVjdGlvbjtcbiAgICB9XG4gICAgdGhpcy5fY29ubiA9IG5ldyBDb25uZWN0aW9uKGNvbm5Db25maWcpO1xuICAgIGNvbnN0IHBhc3N3b3JkID0gb3B0aW9ucy5wYXNzd29yZDtcbiAgICBpZiAodXNlcm5hbWUpIHtcbiAgICAgIGF3YWl0IHRoaXMuc3RhcnRQYXNzd29yZEF1dGgodXNlcm5hbWUsIHBhc3N3b3JkKTtcbiAgICAgIHRoaXMuc2F2ZUN1cnJlbnRDb25uZWN0aW9uKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICh0aGlzLl9jb25uTmFtZSAmJiB0aGlzLl9jb25uLmFjY2Vzc1Rva2VuKSB7XG4gICAgICAgIHRoaXMuX2Nvbm4ub24oJ3JlZnJlc2gnLCAoKSA9PiB7XG4gICAgICAgICAgdGhpcy5wcmludCgnUmVmcmVzaGluZyBhY2Nlc3MgdG9rZW4gLi4uICcpO1xuICAgICAgICAgIHRoaXMuc2F2ZUN1cnJlbnRDb25uZWN0aW9uKCk7XG4gICAgICAgIH0pO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGlkZW50aXR5ID0gYXdhaXQgdGhpcy5fY29ubi5pZGVudGl0eSgpO1xuICAgICAgICAgIHRoaXMucHJpbnQoYExvZ2dlZCBpbiBhcyA6ICR7aWRlbnRpdHkudXNlcm5hbWV9YCk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgdGhpcy5wcmludChlcnIubWVzc2FnZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh0aGlzLl9jb25uLm9hdXRoMikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdQbGVhc2UgcmUtYXV0aG9yaXplIGNvbm5lY3Rpb24uJyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMuc3RhcnRQYXNzd29yZEF1dGgodGhpcy5fY29ubk5hbWUpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgc3RhcnRQYXNzd29yZEF1dGgodXNlcm5hbWU6IHN0cmluZywgcGFzc3dvcmQ/OiBzdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5sb2dpbkJ5UGFzc3dvcmQodXNlcm5hbWUsIHBhc3N3b3JkLCAyKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvciAmJiBlcnIubWVzc2FnZSA9PT0gJ2NhbmNlbGVkJykge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdQYXNzd29yZCBhdXRoZW50aWNhdGlvbiBjYW5jZWxlZDogTm90IGxvZ2dlZCBpbicpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgbG9naW5CeVBhc3N3b3JkKFxuICAgIHVzZXJuYW1lOiBzdHJpbmcsXG4gICAgcGFzc3dvcmQ6IHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgICByZXRyeUNvdW50OiBudW1iZXIsXG4gICk6IFByb21pc2U8eyBpZDogc3RyaW5nIH0+IHtcbiAgICBpZiAocGFzc3dvcmQgPT09ICcnKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2NhbmNlbGVkJyk7XG4gICAgfVxuICAgIGlmIChwYXNzd29yZCA9PSBudWxsKSB7XG4gICAgICBjb25zdCBwYXNzID0gYXdhaXQgdGhpcy5wcm9tcHRQYXNzd29yZCgnUGFzc3dvcmQ6ICcpO1xuICAgICAgcmV0dXJuIHRoaXMubG9naW5CeVBhc3N3b3JkKHVzZXJuYW1lLCBwYXNzLCByZXRyeUNvdW50KTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuX2Nvbm4ubG9naW4odXNlcm5hbWUsIHBhc3N3b3JkKTtcbiAgICAgIHRoaXMucHJpbnQoYExvZ2dlZCBpbiBhcyA6ICR7dXNlcm5hbWV9YCk7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyLm1lc3NhZ2UpO1xuICAgICAgfVxuICAgICAgaWYgKHJldHJ5Q291bnQgPiAwKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmxvZ2luQnlQYXNzd29yZCh1c2VybmFtZSwgdW5kZWZpbmVkLCByZXRyeUNvdW50IC0gMSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2NhbmNlbGVkJyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBhc3luYyBkaXNjb25uZWN0KGNvbm5OYW1lPzogc3RyaW5nKSB7XG4gICAgY29uc3QgbmFtZSA9IGNvbm5OYW1lIHx8IHRoaXMuX2Nvbm5OYW1lO1xuICAgIGlmIChuYW1lICYmIChhd2FpdCByZWdpc3RyeS5nZXRDb25uZWN0aW9uQ29uZmlnKG5hbWUpKSkge1xuICAgICAgYXdhaXQgcmVnaXN0cnkucmVtb3ZlQ29ubmVjdGlvbkNvbmZpZyhuYW1lKTtcbiAgICAgIHRoaXMucHJpbnQoYERpc2Nvbm5lY3QgY29ubmVjdGlvbiAnJHtuYW1lfSdgKTtcbiAgICB9XG4gICAgdGhpcy5fY29ubk5hbWUgPSB1bmRlZmluZWQ7XG4gICAgdGhpcy5fY29ubiA9IG5ldyBDb25uZWN0aW9uKCk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIGF1dGhvcml6ZShjbGllbnROYW1lOiBzdHJpbmcpIHtcbiAgICBjb25zdCBuYW1lID0gY2xpZW50TmFtZSB8fCAnZGVmYXVsdCc7XG4gICAgY29uc3Qgb2F1dGgyQ29uZmlnID0gYXdhaXQgcmVnaXN0cnkuZ2V0Q2xpZW50Q29uZmlnKG5hbWUpO1xuICAgIGlmICghb2F1dGgyQ29uZmlnPy5jbGllbnRJZCkge1xuICAgICAgaWYgKG5hbWUgPT09ICdkZWZhdWx0JyB8fCBuYW1lID09PSAnc2FuZGJveCcpIHtcbiAgICAgICAgdGhpcy5wcmludChcbiAgICAgICAgICAnTm8gY2xpZW50IGluZm9ybWF0aW9uIHJlZ2lzdGVyZWQuIERvd25sb2FkaW5nIEpTZm9yY2UgZGVmYXVsdCBjbGllbnQgaW5mb3JtYXRpb24uLi4nLFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gdGhpcy5kb3dubG9hZERlZmF1bHRDbGllbnRJbmZvKG5hbWUpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgTm8gT0F1dGgyIGNsaWVudCBpbmZvcm1hdGlvbiByZWdpc3RlcmVkIDogJyR7bmFtZX0nLiBQbGVhc2UgcmVnaXN0ZXIgY2xpZW50IGluZm8gZmlyc3QuYCxcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IG9hdXRoMiA9IG5ldyBPQXV0aDIob2F1dGgyQ29uZmlnKTtcbiAgICBjb25zdCB2ZXJpZmllciA9IGJhc2U2NHVybC5lbmNvZGUoY3J5cHRvLnJhbmRvbUJ5dGVzKDMyKSk7XG4gICAgY29uc3QgY2hhbGxlbmdlID0gYmFzZTY0dXJsLmVuY29kZShcbiAgICAgIGNyeXB0by5jcmVhdGVIYXNoKCdzaGEyNTYnKS51cGRhdGUodmVyaWZpZXIpLmRpZ2VzdCgpLFxuICAgICk7XG4gICAgY29uc3Qgc3RhdGUgPSBiYXNlNjR1cmwuZW5jb2RlKGNyeXB0by5yYW5kb21CeXRlcygzMikpO1xuICAgIGNvbnN0IGF1dGh6VXJsID0gb2F1dGgyLmdldEF1dGhvcml6YXRpb25Vcmwoe1xuICAgICAgY29kZV9jaGFsbGVuZ2U6IGNoYWxsZW5nZSxcbiAgICAgIHN0YXRlLFxuICAgIH0pO1xuICAgIHRoaXMucHJpbnQoJ09wZW5pbmcgYXV0aG9yaXphdGlvbiBwYWdlIGluIGJyb3dzZXIuLi4nKTtcbiAgICB0aGlzLnByaW50KGBVUkw6ICR7YXV0aHpVcmx9YCk7XG4gICAgdGhpcy5vcGVuVXJsKGF1dGh6VXJsKTtcbiAgICBjb25zdCBwYXJhbXMgPSBhd2FpdCB0aGlzLndhaXRDYWxsYmFjayhvYXV0aDJDb25maWcucmVkaXJlY3RVcmksIHN0YXRlKTtcbiAgICBpZiAoIXBhcmFtcy5jb2RlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIGF1dGhvcml6YXRpb24gY29kZSByZXR1cm5lZC4nKTtcbiAgICB9XG4gICAgaWYgKHBhcmFtcy5zdGF0ZSAhPT0gc3RhdGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBzdGF0ZSBwYXJhbWV0ZXIgcmV0dXJuZWQuJyk7XG4gICAgfVxuICAgIHRoaXMuX2Nvbm4gPSBuZXcgQ29ubmVjdGlvbih7IG9hdXRoMiB9KTtcbiAgICB0aGlzLnByaW50KFxuICAgICAgJ1JlY2VpdmVkIGF1dGhvcml6YXRpb24gY29kZS4gUGxlYXNlIGNsb3NlIHRoZSBvcGVuZWQgYnJvd3NlciB3aW5kb3cuJyxcbiAgICApO1xuICAgIGF3YWl0IHRoaXMuX2Nvbm4uYXV0aG9yaXplKHBhcmFtcy5jb2RlLCB7IGNvZGVfdmVyaWZpZXI6IHZlcmlmaWVyIH0pO1xuICAgIHRoaXMucHJpbnQoJ0F1dGhvcml6ZWQuIEZldGNoaW5nIHVzZXIgaW5mby4uLicpO1xuICAgIGNvbnN0IGlkZW50aXR5ID0gYXdhaXQgdGhpcy5fY29ubi5pZGVudGl0eSgpO1xuICAgIHRoaXMucHJpbnQoYExvZ2dlZCBpbiBhcyA6ICR7aWRlbnRpdHkudXNlcm5hbWV9YCk7XG4gICAgdGhpcy5fY29ubk5hbWUgPSBpZGVudGl0eS51c2VybmFtZTtcbiAgICB0aGlzLnNhdmVDdXJyZW50Q29ubmVjdGlvbigpO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBhc3luYyBkb3dubG9hZERlZmF1bHRDbGllbnRJbmZvKGNsaWVudE5hbWU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGNvbmZpZ1VybCA9ICdodHRwczovL2pzZm9yY2UuZ2l0aHViLmlvL2NsaWVudC1jb25maWcvZGVmYXVsdC5qc29uJztcbiAgICBjb25zdCByZXM6IHsgYm9keTogc3RyaW5nIH0gPSBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICByZXF1ZXN0KHsgbWV0aG9kOiAnR0VUJywgdXJsOiBjb25maWdVcmwgfSlcbiAgICAgICAgLm9uKCdjb21wbGV0ZScsIHJlc29sdmUpXG4gICAgICAgIC5vbignZXJyb3InLCByZWplY3QpO1xuICAgIH0pO1xuICAgIGNvbnN0IGNsaWVudENvbmZpZyA9IEpTT04ucGFyc2UocmVzLmJvZHkpO1xuICAgIGlmIChjbGllbnROYW1lID09PSAnc2FuZGJveCcpIHtcbiAgICAgIGNsaWVudENvbmZpZy5sb2dpblVybCA9ICdodHRwczovL3Rlc3Quc2FsZXNmb3JjZS5jb20nO1xuICAgIH1cbiAgICBhd2FpdCByZWdpc3RyeS5yZWdpc3RlckNsaWVudENvbmZpZyhjbGllbnROYW1lLCBjbGllbnRDb25maWcpO1xuICAgIHRoaXMucHJpbnQoJ0NsaWVudCBpbmZvcm1hdGlvbiBkb3dubG9hZGVkIHN1Y2Nlc3NmdWxseS4nKTtcbiAgICByZXR1cm4gdGhpcy5hdXRob3JpemUoY2xpZW50TmFtZSk7XG4gIH1cblxuICBhc3luYyB3YWl0Q2FsbGJhY2soXG4gICAgc2VydmVyVXJsOiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gICAgc3RhdGU6IHN0cmluZyxcbiAgKTogUHJvbWlzZTx7IGNvZGU6IHN0cmluZzsgc3RhdGU6IHN0cmluZyB9PiB7XG4gICAgaWYgKHNlcnZlclVybCAmJiBzZXJ2ZXJVcmwuc3RhcnRzV2l0aCgnaHR0cDovL2xvY2FsaG9zdDonKSkge1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgY29uc3Qgc2VydmVyID0gaHR0cC5jcmVhdGVTZXJ2ZXIoKHJlcSwgcmVzKSA9PiB7XG4gICAgICAgICAgaWYgKCFyZXEudXJsKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IHFwYXJhbXMgPSB1cmwucGFyc2UocmVxLnVybCwgdHJ1ZSkucXVlcnk7XG4gICAgICAgICAgcmVzLndyaXRlSGVhZCgyMDAsIHsgJ0NvbnRlbnQtVHlwZSc6ICd0ZXh0L2h0bWwnIH0pO1xuICAgICAgICAgIHJlcy53cml0ZShcbiAgICAgICAgICAgICc8aHRtbD48c2NyaXB0PmxvY2F0aW9uLmhyZWY9XCJhYm91dDpibGFua1wiOzwvc2NyaXB0PjwvaHRtbD4nLFxuICAgICAgICAgICk7XG4gICAgICAgICAgcmVzLmVuZCgpO1xuICAgICAgICAgIGlmIChxcGFyYW1zLmVycm9yKSB7XG4gICAgICAgICAgICByZWplY3QobmV3IEVycm9yKHFwYXJhbXMuZXJyb3IgYXMgc3RyaW5nKSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlc29sdmUocXBhcmFtcyBhcyB7IGNvZGU6IHN0cmluZzsgc3RhdGU6IHN0cmluZyB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgc2VydmVyLmNsb3NlKCk7XG4gICAgICAgICAgcmVxLmNvbm5lY3Rpb24uZW5kKCk7XG4gICAgICAgICAgcmVxLmNvbm5lY3Rpb24uZGVzdHJveSgpO1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgcG9ydCA9IE51bWJlcih1cmwucGFyc2Uoc2VydmVyVXJsKS5wb3J0KTtcbiAgICAgICAgc2VydmVyLmxpc3Rlbihwb3J0LCAnbG9jYWxob3N0Jyk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgY29kZSA9IGF3YWl0IHRoaXMucHJvbXB0TWVzc2FnZShcbiAgICAgICAgJ0NvcHkgJiBwYXN0ZSBhdXRoeiBjb2RlIHBhc3NlZCBpbiByZWRpcmVjdGVkIFVSTDogJyxcbiAgICAgICk7XG4gICAgICByZXR1cm4geyBjb2RlOiBkZWNvZGVVUklDb21wb25lbnQoY29kZSksIHN0YXRlIH07XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBhc3luYyByZWdpc3RlcihjbGllbnROYW1lOiBzdHJpbmcgfCB1bmRlZmluZWQsIGNsaWVudENvbmZpZzogQ2xpZW50Q29uZmlnKSB7XG4gICAgY29uc3QgbmFtZSA9IGNsaWVudE5hbWUgfHwgJ2RlZmF1bHQnO1xuICAgIGNvbnN0IHByb21wdHMgPSB7XG4gICAgICBjbGllbnRJZDogJ0lucHV0IGNsaWVudCBJRCA6ICcsXG4gICAgICBjbGllbnRTZWNyZXQ6ICdJbnB1dCBjbGllbnQgc2VjcmV0IChvcHRpb25hbCkgOiAnLFxuICAgICAgcmVkaXJlY3RVcmk6ICdJbnB1dCByZWRpcmVjdCBVUkkgOiAnLFxuICAgICAgbG9naW5Vcmw6ICdJbnB1dCBsb2dpbiBVUkwgKGRlZmF1bHQgaXMgaHR0cHM6Ly9sb2dpbi5zYWxlc2ZvcmNlLmNvbSkgOiAnLFxuICAgIH07XG4gICAgY29uc3QgcmVnaXN0ZXJlZCA9IGF3YWl0IHJlZ2lzdHJ5LmdldENsaWVudENvbmZpZyhuYW1lKTtcbiAgICBpZiAocmVnaXN0ZXJlZCkge1xuICAgICAgY29uc3QgbXNnID0gYENsaWVudCAnJHtuYW1lfScgaXMgYWxyZWFkeSByZWdpc3RlcmVkLiBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gb3ZlcnJpZGUgPyBbeU5dIDogYDtcbiAgICAgIGNvbnN0IG9rID0gYXdhaXQgdGhpcy5wcm9tcHRDb25maXJtKG1zZyk7XG4gICAgICBpZiAoIW9rKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignUmVnaXN0cmF0aW9uIGNhbmNlbGVkLicpO1xuICAgICAgfVxuICAgIH1cbiAgICBjbGllbnRDb25maWcgPSBhd2FpdCBPYmplY3Qua2V5cyhwcm9tcHRzKS5yZWR1Y2UoYXN5bmMgKHByb21pc2UsIG5hbWUpID0+IHtcbiAgICAgIGNvbnN0IGNjb25maWcgPSBhd2FpdCBwcm9taXNlO1xuICAgICAgY29uc3QgcHJvbXB0TmFtZSA9IG5hbWUgYXMga2V5b2YgdHlwZW9mIHByb21wdHM7XG4gICAgICBjb25zdCBtZXNzYWdlID0gcHJvbXB0c1twcm9tcHROYW1lXTtcbiAgICAgIGlmICghY2NvbmZpZ1twcm9tcHROYW1lXSkge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGF3YWl0IHRoaXMucHJvbXB0TWVzc2FnZShtZXNzYWdlKTtcbiAgICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLmNjb25maWcsXG4gICAgICAgICAgICBbcHJvbXB0TmFtZV06IHZhbHVlLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBjY29uZmlnO1xuICAgIH0sIFByb21pc2UucmVzb2x2ZShjbGllbnRDb25maWcpKTtcbiAgICBhd2FpdCByZWdpc3RyeS5yZWdpc3RlckNsaWVudENvbmZpZyhuYW1lLCBjbGllbnRDb25maWcpO1xuICAgIHRoaXMucHJpbnQoJ0NsaWVudCByZWdpc3RlcmVkIHN1Y2Nlc3NmdWxseS4nKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgbGlzdENvbm5lY3Rpb25zKCkge1xuICAgIGNvbnN0IG5hbWVzID0gYXdhaXQgcmVnaXN0cnkuZ2V0Q29ubmVjdGlvbk5hbWVzKCk7XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIG5hbWVzKSB7XG4gICAgICB0aGlzLnByaW50KChuYW1lID09PSB0aGlzLl9jb25uTmFtZSA/ICcqICcgOiAnICAnKSArIG5hbWUpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgZ2V0Q29ubmVjdGlvbk5hbWVzKCkge1xuICAgIHJldHVybiByZWdpc3RyeS5nZXRDb25uZWN0aW9uTmFtZXMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgZ2V0Q2xpZW50TmFtZXMoKSB7XG4gICAgcmV0dXJuIHJlZ2lzdHJ5LmdldENsaWVudE5hbWVzKCk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIHByb21wdCh0eXBlOiBzdHJpbmcsIG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHRoaXMuX3JlcGwucGF1c2UoKTtcbiAgICBjb25zdCBhbnN3ZXI6IHsgdmFsdWU6IHN0cmluZyB9ID0gYXdhaXQgaW5xdWlyZXIucHJvbXB0KFtcbiAgICAgIHtcbiAgICAgICAgdHlwZSxcbiAgICAgICAgbmFtZTogJ3ZhbHVlJyxcbiAgICAgICAgbWVzc2FnZSxcbiAgICAgIH0sXG4gICAgXSk7XG4gICAgdGhpcy5fcmVwbC5yZXN1bWUoKTtcbiAgICByZXR1cm4gYW5zd2VyLnZhbHVlO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBhc3luYyBwcm9tcHRNZXNzYWdlKG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLnByb21wdCgnaW5wdXQnLCBtZXNzYWdlKTtcbiAgfVxuXG4gIGFzeW5jIHByb21wdFBhc3N3b3JkKG1lc3NhZ2U6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLnByb21wdCgncGFzc3dvcmQnLCBtZXNzYWdlKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgcHJvbXB0Q29uZmlybShtZXNzYWdlOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5wcm9tcHQoJ2NvbmZpcm0nLCBtZXNzYWdlKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgb3BlblVybCh1cmw6IHN0cmluZykge1xuICAgIG9wZW5VcmwodXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgb3BlblVybFVzaW5nU2Vzc2lvbih1cmw/OiBzdHJpbmcpIHtcbiAgICBsZXQgZnJvbnRkb29yVXJsID0gYCR7dGhpcy5fY29ubi5pbnN0YW5jZVVybH0vc2VjdXIvZnJvbnRkb29yLmpzcD9zaWQ9JHt0aGlzLl9jb25uLmFjY2Vzc1Rva2VufWA7XG4gICAgaWYgKHVybCkge1xuICAgICAgZnJvbnRkb29yVXJsICs9ICcmcmV0VVJMPScgKyBlbmNvZGVVUklDb21wb25lbnQodXJsKTtcbiAgICB9XG4gICAgdGhpcy5vcGVuVXJsKGZyb250ZG9vclVybCk7XG4gIH1cbn1cblxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xuXG5jb25zdCBjbGkgPSBuZXcgQ2xpKCk7XG5cbmV4cG9ydCBkZWZhdWx0IGNsaTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPQSxJQUFJLE1BQU0sTUFBTTtBQUN2QixPQUFPQyxHQUFHLE1BQU0sS0FBSztBQUNyQixPQUFPQyxNQUFNLE1BQU0sUUFBUTtBQUMzQixPQUFPQyxRQUFPLE1BQU0sTUFBTTtBQUMxQixTQUFTQyxPQUFPLFFBQVEsV0FBVztBQUNuQyxPQUFPQyxRQUFRLE1BQU0sVUFBVTtBQUMvQixPQUFPQyxPQUFPLE1BQU0sWUFBWTtBQUNoQyxPQUFPQyxTQUFTLE1BQU0sV0FBVztBQUNqQyxPQUFPQyxJQUFJLE1BQU0sUUFBUTtBQUN6QixPQUFPQyxPQUFPLElBQUlDLFVBQVUsRUFBRUMsTUFBTSxRQUFRLElBQUk7QUFDaEQsT0FBT0MsT0FBTyxNQUFNLFlBQVk7QUFJaEMsSUFBTUMsUUFBUSxHQUFHSixPQUFPLENBQUNJLFFBQVE7QUFXakM7QUFDQTtBQUNBO0FBQ0EsV0FBYUMsR0FBRztFQUFBLFNBQUFBLElBQUE7SUFBQUMsZUFBQSxPQUFBRCxHQUFBO0lBQUFFLGVBQUEsZ0JBQ0EsSUFBSVIsSUFBSSxDQUFDLElBQUksQ0FBQztJQUFBUSxlQUFBLGdCQUNSLElBQUlOLFVBQVUsQ0FBQyxDQUFDO0lBQUFNLGVBQUEsb0JBQ0pDLFNBQVM7SUFBQUQsZUFBQSx5QkFDZixJQUFJO0lBQUFBLGVBQUEsMkJBQ1NDLFNBQVM7RUFBQTtFQUFBLE9BQUFDLFlBQUEsQ0FBQUosR0FBQTtJQUFBSyxHQUFBO0lBQUFDLEtBQUE7SUFFaEQ7QUFDRjtBQUNBO0lBQ0UsU0FBQUMsV0FBV0EsQ0FBQSxFQUFlO01BQ3hCLE9BQU8sSUFBSWpCLE9BQU8sQ0FBQyxDQUFDLENBQ2pCa0IsTUFBTSxDQUFDLDJCQUEyQixFQUFFLHFCQUFxQixDQUFDLENBQzFEQSxNQUFNLENBQ0wsMkJBQTJCLEVBQzNCLHdEQUNGLENBQUMsQ0FDQUEsTUFBTSxDQUNMLCtCQUErQixFQUMvQiwrQ0FDRixDQUFDLENBQ0FBLE1BQU0sQ0FBQywyQkFBMkIsRUFBRSxzQkFBc0IsQ0FBQyxDQUMzREEsTUFBTSxDQUFDLFdBQVcsRUFBRSw2QkFBNkIsQ0FBQyxDQUNsREEsTUFBTSxDQUFDLCtCQUErQixFQUFFLG9CQUFvQixDQUFDLENBQzdEVixPQUFPLENBQUNBLE9BQU8sQ0FBQyxDQUNoQlcsS0FBSyxDQUFDQyxPQUFPLENBQUNDLElBQUksQ0FBQztJQUN4QjtFQUFDO0lBQUFOLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFNLE1BQUEsR0FBQUMsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUVELFNBQUFDLFFBQUE7UUFBQSxJQUFBQyxPQUFBO1FBQUEsT0FBQUgsbUJBQUEsQ0FBQUksSUFBQSxVQUFBQyxTQUFBQyxRQUFBO1VBQUEsa0JBQUFBLFFBQUEsQ0FBQUMsSUFBQSxHQUFBRCxRQUFBLENBQUFFLElBQUE7WUFBQTtjQUNRTCxPQUFPLEdBQUcsSUFBSSxDQUFDVixXQUFXLENBQUMsQ0FBQztjQUNsQyxJQUFJLENBQUNnQixjQUFjLEdBQUcsQ0FBQ04sT0FBTyxDQUFDTyxVQUFVO2NBQUNKLFFBQUEsQ0FBQUMsSUFBQTtjQUFBRCxRQUFBLENBQUFFLElBQUE7Y0FBQSxPQUVsQyxJQUFJLENBQUNHLE9BQU8sQ0FBQ1IsT0FBTyxDQUFDO1lBQUE7Y0FDM0IsSUFBSUEsT0FBTyxDQUFDTyxVQUFVLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQ0UsS0FBSyxDQUFDQyxLQUFLLENBQUM7a0JBQ2ZDLFdBQVcsRUFBRSxLQUFLO2tCQUNsQkosVUFBVSxFQUFFUCxPQUFPLENBQUNPO2dCQUN0QixDQUFDLENBQUM7Y0FDSixDQUFDLE1BQU07Z0JBQ0wsSUFBSSxDQUFDRSxLQUFLLENBQUNDLEtBQUssQ0FBQyxDQUFDO2NBQ3BCO2NBQUNQLFFBQUEsQ0FBQUUsSUFBQTtjQUFBO1lBQUE7Y0FBQUYsUUFBQSxDQUFBQyxJQUFBO2NBQUFELFFBQUEsQ0FBQVMsRUFBQSxHQUFBVCxRQUFBO2NBRURVLE9BQU8sQ0FBQ0MsS0FBSyxDQUFBWCxRQUFBLENBQUFTLEVBQUksQ0FBQztjQUNsQm5CLE9BQU8sQ0FBQ3NCLElBQUksQ0FBQyxDQUFDO1lBQUM7WUFBQTtjQUFBLE9BQUFaLFFBQUEsQ0FBQWEsSUFBQTtVQUFBO1FBQUEsR0FBQWpCLE9BQUE7TUFBQSxDQUVsQjtNQUFBLFNBakJLVyxLQUFLQSxDQUFBO1FBQUEsT0FBQWYsTUFBQSxDQUFBc0IsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFMUixLQUFLO0lBQUE7RUFBQTtJQUFBdEIsR0FBQTtJQUFBQyxLQUFBLEVBbUJYLFNBQUE4QixvQkFBb0JBLENBQUEsRUFBRztNQUNyQixPQUFPLElBQUksQ0FBQ0MsS0FBSztJQUNuQjtFQUFDO0lBQUFoQyxHQUFBO0lBQUFDLEtBQUEsRUFFRCxTQUFBZ0MsS0FBS0EsQ0FBQSxFQUFpQjtNQUNwQixJQUFJLElBQUksQ0FBQ2YsY0FBYyxFQUFFO1FBQUEsSUFBQWdCLFFBQUE7UUFDdkIsQ0FBQUEsUUFBQSxHQUFBVCxPQUFPLEVBQUNVLEdBQUcsQ0FBQU4sS0FBQSxDQUFBSyxRQUFBLEVBQUFKLFNBQVEsQ0FBQztNQUN0QjtJQUNGO0VBQUM7SUFBQTlCLEdBQUE7SUFBQUMsS0FBQSxFQUVELFNBQUFtQyxxQkFBcUJBLENBQUEsRUFBRztNQUN0QixJQUFJLElBQUksQ0FBQ0MsU0FBUyxFQUFFO1FBQ2xCLElBQU1DLElBQUksR0FBRyxJQUFJLENBQUNOLEtBQUs7UUFDdkIsSUFBTU8sUUFBUSxHQUFHLElBQUksQ0FBQ0YsU0FBUztRQUMvQixJQUFNRyxVQUFVLEdBQUc7VUFDakJDLE1BQU0sRUFBRUgsSUFBSSxDQUFDRyxNQUFNLEdBQ2Y7WUFDRUMsUUFBUSxFQUFFSixJQUFJLENBQUNHLE1BQU0sQ0FBQ0MsUUFBUSxJQUFJNUMsU0FBUztZQUMzQzZDLFlBQVksRUFBRUwsSUFBSSxDQUFDRyxNQUFNLENBQUNFLFlBQVksSUFBSTdDLFNBQVM7WUFDbkQ4QyxXQUFXLEVBQUVOLElBQUksQ0FBQ0csTUFBTSxDQUFDRyxXQUFXLElBQUk5QyxTQUFTO1lBQ2pEK0MsUUFBUSxFQUFFUCxJQUFJLENBQUNHLE1BQU0sQ0FBQ0ksUUFBUSxJQUFJL0M7VUFDcEMsQ0FBQyxHQUNEQSxTQUFTO1VBQ2JnRCxXQUFXLEVBQUVSLElBQUksQ0FBQ1EsV0FBVyxJQUFJaEQsU0FBUztVQUMxQ2lELFdBQVcsRUFBRVQsSUFBSSxDQUFDUyxXQUFXLElBQUlqRCxTQUFTO1VBQzFDa0QsWUFBWSxFQUFFVixJQUFJLENBQUNVLFlBQVksSUFBSWxEO1FBQ3JDLENBQUM7UUFDREosUUFBUSxDQUFDdUQsb0JBQW9CLENBQUNWLFFBQVEsRUFBRUMsVUFBVSxDQUFDO01BQ3JEO0lBQ0Y7RUFBQztJQUFBeEMsR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQWlELGNBQWNBLENBQUNDLFdBQTZCLEVBQUU7TUFDNUMsSUFBSSxDQUFDQSxXQUFXLEVBQUU7UUFDaEI7TUFDRjtNQUNBLElBQUlBLFdBQVcsS0FBSyxZQUFZLEVBQUU7UUFDaEMsSUFBSSxDQUFDQyxnQkFBZ0IsR0FBRyw4QkFBOEI7TUFDeEQsQ0FBQyxNQUFNLElBQUlELFdBQVcsS0FBSyxTQUFTLEVBQUU7UUFDcEMsSUFBSSxDQUFDQyxnQkFBZ0IsR0FBRyw2QkFBNkI7TUFDdkQsQ0FBQyxNQUFNLElBQUksQ0FBQ0MsMkJBQUEsQ0FBQUYsV0FBVyxFQUFBRyxJQUFBLENBQVhILFdBQVcsRUFBWSxVQUFVLENBQUMsRUFBRTtRQUM5QyxJQUFJLENBQUNDLGdCQUFnQixHQUFHLFVBQVUsR0FBR0QsV0FBVztNQUNsRCxDQUFDLE1BQU07UUFDTCxJQUFJLENBQUNDLGdCQUFnQixHQUFHRCxXQUFXO01BQ3JDO01BQ0EsSUFBSSxDQUFDbEIsS0FBSyxZQUFBc0IsTUFBQSxDQUFXLElBQUksQ0FBQ0gsZ0JBQWdCLDZCQUF5QixDQUFDO0lBQ3RFOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFwRCxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBdUQsUUFBQSxHQUFBaEQsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUErQyxTQUFjQyxPQU1iO1FBQUEsSUFBQUMsS0FBQTtRQUFBLElBQUFSLFdBQUEsRUFBQVgsVUFBQSxFQUFBb0IsUUFBQSxFQUFBQyxRQUFBLEVBQUFDLFFBQUE7UUFBQSxPQUFBckQsbUJBQUEsQ0FBQUksSUFBQSxVQUFBa0QsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFoRCxJQUFBLEdBQUFnRCxTQUFBLENBQUEvQyxJQUFBO1lBQUE7Y0FDT2tDLFdBQVcsR0FBR08sT0FBTyxDQUFDYixRQUFRLEdBQ2hDYSxPQUFPLENBQUNiLFFBQVEsR0FDaEJhLE9BQU8sQ0FBQ08sT0FBTyxHQUNmLFNBQVMsR0FDVCxJQUFJO2NBQ1IsSUFBSSxDQUFDZixjQUFjLENBQUNDLFdBQVcsQ0FBQztjQUNoQyxJQUFJLENBQUNkLFNBQVMsR0FBR3FCLE9BQU8sQ0FBQ1EsVUFBVTtjQUFDRixTQUFBLENBQUEvQyxJQUFBO2NBQUEsT0FDYnZCLFFBQVEsQ0FBQ3lFLG1CQUFtQixDQUFDVCxPQUFPLENBQUNRLFVBQVUsQ0FBQztZQUFBO2NBQW5FMUIsVUFBVSxHQUFBd0IsU0FBQSxDQUFBSSxJQUFBO2NBQ1ZSLFFBQVEsR0FBR0YsT0FBTyxDQUFDRSxRQUFRO2NBQy9CLElBQUksQ0FBQ3BCLFVBQVUsRUFBRTtnQkFDZkEsVUFBVSxHQUFHLENBQUMsQ0FBQztnQkFDZixJQUFJLElBQUksQ0FBQ1ksZ0JBQWdCLEVBQUU7a0JBQ3pCWixVQUFVLENBQUNLLFFBQVEsR0FBRyxJQUFJLENBQUNPLGdCQUFnQjtnQkFDN0M7Z0JBQ0FRLFFBQVEsR0FBR0EsUUFBUSxJQUFJRixPQUFPLENBQUNRLFVBQVU7Y0FDM0M7Y0FDQSxJQUFJLENBQUNsQyxLQUFLLEdBQUcsSUFBSXpDLFVBQVUsQ0FBQ2lELFVBQVUsQ0FBQztjQUNqQ3FCLFFBQVEsR0FBR0gsT0FBTyxDQUFDRyxRQUFRO2NBQUEsS0FDN0JELFFBQVE7Z0JBQUFJLFNBQUEsQ0FBQS9DLElBQUE7Z0JBQUE7Y0FBQTtjQUFBK0MsU0FBQSxDQUFBL0MsSUFBQTtjQUFBLE9BQ0osSUFBSSxDQUFDb0QsaUJBQWlCLENBQUNULFFBQVEsRUFBRUMsUUFBUSxDQUFDO1lBQUE7Y0FDaEQsSUFBSSxDQUFDekIscUJBQXFCLENBQUMsQ0FBQztjQUFDNEIsU0FBQSxDQUFBL0MsSUFBQTtjQUFBO1lBQUE7Y0FBQSxNQUV6QixJQUFJLENBQUNvQixTQUFTLElBQUksSUFBSSxDQUFDTCxLQUFLLENBQUNjLFdBQVc7Z0JBQUFrQixTQUFBLENBQUEvQyxJQUFBO2dCQUFBO2NBQUE7Y0FDMUMsSUFBSSxDQUFDZSxLQUFLLENBQUNzQyxFQUFFLENBQUMsU0FBUyxFQUFFLFlBQU07Z0JBQzdCWCxLQUFJLENBQUMxQixLQUFLLENBQUMsOEJBQThCLENBQUM7Z0JBQzFDMEIsS0FBSSxDQUFDdkIscUJBQXFCLENBQUMsQ0FBQztjQUM5QixDQUFDLENBQUM7Y0FBQzRCLFNBQUEsQ0FBQWhELElBQUE7Y0FBQWdELFNBQUEsQ0FBQS9DLElBQUE7Y0FBQSxPQUVzQixJQUFJLENBQUNlLEtBQUssQ0FBQzhCLFFBQVEsQ0FBQyxDQUFDO1lBQUE7Y0FBdENBLFFBQVEsR0FBQUUsU0FBQSxDQUFBSSxJQUFBO2NBQ2QsSUFBSSxDQUFDbkMsS0FBSyxtQkFBQXNCLE1BQUEsQ0FBbUJPLFFBQVEsQ0FBQ0YsUUFBUSxDQUFFLENBQUM7Y0FBQ0ksU0FBQSxDQUFBL0MsSUFBQTtjQUFBO1lBQUE7Y0FBQStDLFNBQUEsQ0FBQWhELElBQUE7Y0FBQWdELFNBQUEsQ0FBQXhDLEVBQUEsR0FBQXdDLFNBQUE7Y0FFbEQsSUFBSUEsU0FBQSxDQUFBeEMsRUFBQSxZQUFlK0MsS0FBSyxFQUFFO2dCQUN4QixJQUFJLENBQUN0QyxLQUFLLENBQUMrQixTQUFBLENBQUF4QyxFQUFBLENBQUlnRCxPQUFPLENBQUM7Y0FDekI7Y0FBQyxLQUNHLElBQUksQ0FBQ3hDLEtBQUssQ0FBQ1MsTUFBTTtnQkFBQXVCLFNBQUEsQ0FBQS9DLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE1BQ2IsSUFBSXNELEtBQUssQ0FBQyxpQ0FBaUMsQ0FBQztZQUFBO2NBQUFQLFNBQUEsQ0FBQS9DLElBQUE7Y0FBQSxPQUU1QyxJQUFJLENBQUNvRCxpQkFBaUIsQ0FBQyxJQUFJLENBQUNoQyxTQUFTLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQTJCLFNBQUEsQ0FBQXBDLElBQUE7VUFBQTtRQUFBLEdBQUE2QixRQUFBO01BQUEsQ0FLckQ7TUFBQSxTQWpES3JDLE9BQU9BLENBQUFxRCxFQUFBO1FBQUEsT0FBQWpCLFFBQUEsQ0FBQTNCLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBUFYsT0FBTztJQUFBO0lBbURiO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQXBCLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUF5RSxrQkFBQSxHQUFBbEUsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUFpRSxTQUF3QmYsUUFBZ0IsRUFBRUMsUUFBaUI7UUFBQSxPQUFBcEQsbUJBQUEsQ0FBQUksSUFBQSxVQUFBK0QsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUE3RCxJQUFBLEdBQUE2RCxTQUFBLENBQUE1RCxJQUFBO1lBQUE7Y0FBQTRELFNBQUEsQ0FBQTdELElBQUE7Y0FBQTZELFNBQUEsQ0FBQTVELElBQUE7Y0FBQSxPQUVqRCxJQUFJLENBQUM2RCxlQUFlLENBQUNsQixRQUFRLEVBQUVDLFFBQVEsRUFBRSxDQUFDLENBQUM7WUFBQTtjQUFBZ0IsU0FBQSxDQUFBNUQsSUFBQTtjQUFBO1lBQUE7Y0FBQTRELFNBQUEsQ0FBQTdELElBQUE7Y0FBQTZELFNBQUEsQ0FBQXJELEVBQUEsR0FBQXFELFNBQUE7Y0FBQSxNQUU3Q0EsU0FBQSxDQUFBckQsRUFBQSxZQUFlK0MsS0FBSyxJQUFJTSxTQUFBLENBQUFyRCxFQUFBLENBQUlnRCxPQUFPLEtBQUssVUFBVTtnQkFBQUssU0FBQSxDQUFBNUQsSUFBQTtnQkFBQTtjQUFBO2NBQ3BEUSxPQUFPLENBQUNDLEtBQUssQ0FBQyxpREFBaUQsQ0FBQztjQUFDbUQsU0FBQSxDQUFBNUQsSUFBQTtjQUFBO1lBQUE7Y0FBQSxNQUFBNEQsU0FBQSxDQUFBckQsRUFBQTtZQUFBO1lBQUE7Y0FBQSxPQUFBcUQsU0FBQSxDQUFBakQsSUFBQTtVQUFBO1FBQUEsR0FBQStDLFFBQUE7TUFBQSxDQUt0RTtNQUFBLFNBVktOLGlCQUFpQkEsQ0FBQVUsR0FBQSxFQUFBQyxHQUFBO1FBQUEsT0FBQU4sa0JBQUEsQ0FBQTdDLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBakJ1QyxpQkFBaUI7SUFBQTtJQVl2QjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUFyRSxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBZ0YsZ0JBQUEsR0FBQXpFLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBd0UsU0FDRXRCLFFBQWdCLEVBQ2hCQyxRQUE0QixFQUM1QnNCLFVBQWtCO1FBQUEsSUFBQUMsSUFBQSxFQUFBQyxNQUFBO1FBQUEsT0FBQTVFLG1CQUFBLENBQUFJLElBQUEsVUFBQXlFLFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBdkUsSUFBQSxHQUFBdUUsU0FBQSxDQUFBdEUsSUFBQTtZQUFBO2NBQUEsTUFFZDRDLFFBQVEsS0FBSyxFQUFFO2dCQUFBMEIsU0FBQSxDQUFBdEUsSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDWCxJQUFJc0QsS0FBSyxDQUFDLFVBQVUsQ0FBQztZQUFBO2NBQUEsTUFFekJWLFFBQVEsSUFBSSxJQUFJO2dCQUFBMEIsU0FBQSxDQUFBdEUsSUFBQTtnQkFBQTtjQUFBO2NBQUFzRSxTQUFBLENBQUF0RSxJQUFBO2NBQUEsT0FDQyxJQUFJLENBQUN1RSxjQUFjLENBQUMsWUFBWSxDQUFDO1lBQUE7Y0FBOUNKLElBQUksR0FBQUcsU0FBQSxDQUFBbkIsSUFBQTtjQUFBLE9BQUFtQixTQUFBLENBQUFFLE1BQUEsV0FDSCxJQUFJLENBQUNYLGVBQWUsQ0FBQ2xCLFFBQVEsRUFBRXdCLElBQUksRUFBRUQsVUFBVSxDQUFDO1lBQUE7Y0FBQUksU0FBQSxDQUFBdkUsSUFBQTtjQUFBdUUsU0FBQSxDQUFBdEUsSUFBQTtjQUFBLE9BR2xDLElBQUksQ0FBQ2UsS0FBSyxDQUFDMEQsS0FBSyxDQUFDOUIsUUFBUSxFQUFFQyxRQUFRLENBQUM7WUFBQTtjQUFuRHdCLE1BQU0sR0FBQUUsU0FBQSxDQUFBbkIsSUFBQTtjQUNaLElBQUksQ0FBQ25DLEtBQUssbUJBQUFzQixNQUFBLENBQW1CSyxRQUFRLENBQUUsQ0FBQztjQUFDLE9BQUEyQixTQUFBLENBQUFFLE1BQUEsV0FDbENKLE1BQU07WUFBQTtjQUFBRSxTQUFBLENBQUF2RSxJQUFBO2NBQUF1RSxTQUFBLENBQUEvRCxFQUFBLEdBQUErRCxTQUFBO2NBRWIsSUFBSUEsU0FBQSxDQUFBL0QsRUFBQSxZQUFlK0MsS0FBSyxFQUFFO2dCQUN4QjlDLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDNkQsU0FBQSxDQUFBL0QsRUFBQSxDQUFJZ0QsT0FBTyxDQUFDO2NBQzVCO2NBQUMsTUFDR1csVUFBVSxHQUFHLENBQUM7Z0JBQUFJLFNBQUEsQ0FBQXRFLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE9BQUFzRSxTQUFBLENBQUFFLE1BQUEsV0FDVCxJQUFJLENBQUNYLGVBQWUsQ0FBQ2xCLFFBQVEsRUFBRTlELFNBQVMsRUFBRXFGLFVBQVUsR0FBRyxDQUFDLENBQUM7WUFBQTtjQUFBLE1BRTFELElBQUlaLEtBQUssQ0FBQyxVQUFVLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQWdCLFNBQUEsQ0FBQTNELElBQUE7VUFBQTtRQUFBLEdBQUFzRCxRQUFBO01BQUEsQ0FHaEM7TUFBQSxTQTFCS0osZUFBZUEsQ0FBQWEsR0FBQSxFQUFBQyxHQUFBLEVBQUFDLEdBQUE7UUFBQSxPQUFBWixnQkFBQSxDQUFBcEQsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFmZ0QsZUFBZTtJQUFBO0lBNEJyQjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUE5RSxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBNkYsV0FBQSxHQUFBdEYsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUFxRixTQUFpQnhELFFBQWlCO1FBQUEsSUFBQXlELElBQUE7UUFBQSxPQUFBdkYsbUJBQUEsQ0FBQUksSUFBQSxVQUFBb0YsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFsRixJQUFBLEdBQUFrRixTQUFBLENBQUFqRixJQUFBO1lBQUE7Y0FDMUIrRSxJQUFJLEdBQUd6RCxRQUFRLElBQUksSUFBSSxDQUFDRixTQUFTO2NBQUE2RCxTQUFBLENBQUExRSxFQUFBLEdBQ25Dd0UsSUFBSTtjQUFBLEtBQUFFLFNBQUEsQ0FBQTFFLEVBQUE7Z0JBQUEwRSxTQUFBLENBQUFqRixJQUFBO2dCQUFBO2NBQUE7Y0FBQWlGLFNBQUEsQ0FBQWpGLElBQUE7Y0FBQSxPQUFXdkIsUUFBUSxDQUFDeUUsbUJBQW1CLENBQUM2QixJQUFJLENBQUM7WUFBQTtjQUFBRSxTQUFBLENBQUExRSxFQUFBLEdBQUEwRSxTQUFBLENBQUE5QixJQUFBO1lBQUE7Y0FBQSxLQUFBOEIsU0FBQSxDQUFBMUUsRUFBQTtnQkFBQTBFLFNBQUEsQ0FBQWpGLElBQUE7Z0JBQUE7Y0FBQTtjQUFBaUYsU0FBQSxDQUFBakYsSUFBQTtjQUFBLE9BQzdDdkIsUUFBUSxDQUFDeUcsc0JBQXNCLENBQUNILElBQUksQ0FBQztZQUFBO2NBQzNDLElBQUksQ0FBQy9ELEtBQUssMkJBQUFzQixNQUFBLENBQTJCeUMsSUFBSSxNQUFHLENBQUM7WUFBQztjQUVoRCxJQUFJLENBQUMzRCxTQUFTLEdBQUd2QyxTQUFTO2NBQzFCLElBQUksQ0FBQ2tDLEtBQUssR0FBRyxJQUFJekMsVUFBVSxDQUFDLENBQUM7WUFBQztZQUFBO2NBQUEsT0FBQTJHLFNBQUEsQ0FBQXRFLElBQUE7VUFBQTtRQUFBLEdBQUFtRSxRQUFBO01BQUEsQ0FDL0I7TUFBQSxTQVJLSyxVQUFVQSxDQUFBQyxHQUFBO1FBQUEsT0FBQVAsV0FBQSxDQUFBakUsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFWc0UsVUFBVTtJQUFBO0lBVWhCO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQXBHLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFxRyxVQUFBLEdBQUE5RixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQTZGLFNBQWdCQyxVQUFrQjtRQUFBLElBQUFSLElBQUEsRUFBQVMsWUFBQSxFQUFBaEUsTUFBQSxFQUFBaUUsUUFBQSxFQUFBQyxTQUFBLEVBQUFDLEtBQUEsRUFBQUMsUUFBQSxFQUFBQyxNQUFBLEVBQUFoRCxRQUFBO1FBQUEsT0FBQXJELG1CQUFBLENBQUFJLElBQUEsVUFBQWtHLFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBaEcsSUFBQSxHQUFBZ0csU0FBQSxDQUFBL0YsSUFBQTtZQUFBO2NBQzFCK0UsSUFBSSxHQUFHUSxVQUFVLElBQUksU0FBUztjQUFBUSxTQUFBLENBQUEvRixJQUFBO2NBQUEsT0FDVHZCLFFBQVEsQ0FBQ3VILGVBQWUsQ0FBQ2pCLElBQUksQ0FBQztZQUFBO2NBQW5EUyxZQUFZLEdBQUFPLFNBQUEsQ0FBQTVDLElBQUE7Y0FBQSxJQUNicUMsWUFBWSxhQUFaQSxZQUFZLGVBQVpBLFlBQVksQ0FBRS9ELFFBQVE7Z0JBQUFzRSxTQUFBLENBQUEvRixJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUNyQitFLElBQUksS0FBSyxTQUFTLElBQUlBLElBQUksS0FBSyxTQUFTO2dCQUFBZ0IsU0FBQSxDQUFBL0YsSUFBQTtnQkFBQTtjQUFBO2NBQzFDLElBQUksQ0FBQ2dCLEtBQUssQ0FDUixxRkFDRixDQUFDO2NBQUMsT0FBQStFLFNBQUEsQ0FBQXZCLE1BQUEsV0FDSyxJQUFJLENBQUN5Qix5QkFBeUIsQ0FBQ2xCLElBQUksQ0FBQztZQUFBO2NBQUEsTUFFdkMsSUFBSXpCLEtBQUssK0NBQUFoQixNQUFBLENBQ2lDeUMsSUFBSSwwQ0FDcEQsQ0FBQztZQUFBO2NBRUd2RCxNQUFNLEdBQUcsSUFBSWpELE1BQU0sQ0FBQ2lILFlBQVksQ0FBQztjQUNqQ0MsUUFBUSxHQUFHdEgsU0FBUyxDQUFDK0gsTUFBTSxDQUFDcEksTUFBTSxDQUFDcUksV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2NBQ25EVCxTQUFTLEdBQUd2SCxTQUFTLENBQUMrSCxNQUFNLENBQ2hDcEksTUFBTSxDQUFDc0ksVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDQyxNQUFNLENBQUNaLFFBQVEsQ0FBQyxDQUFDYSxNQUFNLENBQUMsQ0FDdEQsQ0FBQztjQUNLWCxLQUFLLEdBQUd4SCxTQUFTLENBQUMrSCxNQUFNLENBQUNwSSxNQUFNLENBQUNxSSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7Y0FDaERQLFFBQVEsR0FBR3BFLE1BQU0sQ0FBQytFLG1CQUFtQixDQUFDO2dCQUMxQ0MsY0FBYyxFQUFFZCxTQUFTO2dCQUN6QkMsS0FBSyxFQUFMQTtjQUNGLENBQUMsQ0FBQztjQUNGLElBQUksQ0FBQzNFLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQztjQUN0RCxJQUFJLENBQUNBLEtBQUssU0FBQXNCLE1BQUEsQ0FBU3NELFFBQVEsQ0FBRSxDQUFDO2NBQzlCLElBQUksQ0FBQzdILE9BQU8sQ0FBQzZILFFBQVEsQ0FBQztjQUFDRyxTQUFBLENBQUEvRixJQUFBO2NBQUEsT0FDRixJQUFJLENBQUN5RyxZQUFZLENBQUNqQixZQUFZLENBQUM3RCxXQUFXLEVBQUVnRSxLQUFLLENBQUM7WUFBQTtjQUFqRUUsTUFBTSxHQUFBRSxTQUFBLENBQUE1QyxJQUFBO2NBQUEsSUFDUDBDLE1BQU0sQ0FBQ2EsSUFBSTtnQkFBQVgsU0FBQSxDQUFBL0YsSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDUixJQUFJc0QsS0FBSyxDQUFDLGlDQUFpQyxDQUFDO1lBQUE7Y0FBQSxNQUVoRHVDLE1BQU0sQ0FBQ0YsS0FBSyxLQUFLQSxLQUFLO2dCQUFBSSxTQUFBLENBQUEvRixJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUNsQixJQUFJc0QsS0FBSyxDQUFDLG1DQUFtQyxDQUFDO1lBQUE7Y0FFdEQsSUFBSSxDQUFDdkMsS0FBSyxHQUFHLElBQUl6QyxVQUFVLENBQUM7Z0JBQUVrRCxNQUFNLEVBQU5BO2NBQU8sQ0FBQyxDQUFDO2NBQ3ZDLElBQUksQ0FBQ1IsS0FBSyxDQUNSLHNFQUNGLENBQUM7Y0FBQytFLFNBQUEsQ0FBQS9GLElBQUE7Y0FBQSxPQUNJLElBQUksQ0FBQ2UsS0FBSyxDQUFDNEYsU0FBUyxDQUFDZCxNQUFNLENBQUNhLElBQUksRUFBRTtnQkFBRUUsYUFBYSxFQUFFbkI7Y0FBUyxDQUFDLENBQUM7WUFBQTtjQUNwRSxJQUFJLENBQUN6RSxLQUFLLENBQUMsbUNBQW1DLENBQUM7Y0FBQytFLFNBQUEsQ0FBQS9GLElBQUE7Y0FBQSxPQUN6QixJQUFJLENBQUNlLEtBQUssQ0FBQzhCLFFBQVEsQ0FBQyxDQUFDO1lBQUE7Y0FBdENBLFFBQVEsR0FBQWtELFNBQUEsQ0FBQTVDLElBQUE7Y0FDZCxJQUFJLENBQUNuQyxLQUFLLG1CQUFBc0IsTUFBQSxDQUFtQk8sUUFBUSxDQUFDRixRQUFRLENBQUUsQ0FBQztjQUNqRCxJQUFJLENBQUN2QixTQUFTLEdBQUd5QixRQUFRLENBQUNGLFFBQVE7Y0FDbEMsSUFBSSxDQUFDeEIscUJBQXFCLENBQUMsQ0FBQztZQUFDO1lBQUE7Y0FBQSxPQUFBNEUsU0FBQSxDQUFBcEYsSUFBQTtVQUFBO1FBQUEsR0FBQTJFLFFBQUE7TUFBQSxDQUM5QjtNQUFBLFNBNUNLcUIsU0FBU0EsQ0FBQUUsR0FBQTtRQUFBLE9BQUF4QixVQUFBLENBQUF6RSxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVQ4RixTQUFTO0lBQUE7SUE4Q2Y7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBNUgsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQThILDBCQUFBLEdBQUF2SCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQXNILFNBQWdDeEIsVUFBa0I7UUFBQSxJQUFBeUIsU0FBQSxFQUFBQyxHQUFBLEVBQUFDLFlBQUE7UUFBQSxPQUFBMUgsbUJBQUEsQ0FBQUksSUFBQSxVQUFBdUgsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFySCxJQUFBLEdBQUFxSCxTQUFBLENBQUFwSCxJQUFBO1lBQUE7Y0FDMUNnSCxTQUFTLEdBQUcsc0RBQXNEO2NBQUFJLFNBQUEsQ0FBQXBILElBQUE7Y0FBQSxPQUNwQyxJQUFBcUgsUUFBQSxDQUFZLFVBQUNDLE9BQU8sRUFBRUMsTUFBTSxFQUFLO2dCQUNuRXJKLE9BQU8sQ0FBQztrQkFBRXNKLE1BQU0sRUFBRSxLQUFLO2tCQUFFM0osR0FBRyxFQUFFbUo7Z0JBQVUsQ0FBQyxDQUFDLENBQ3ZDM0QsRUFBRSxDQUFDLFVBQVUsRUFBRWlFLE9BQU8sQ0FBQyxDQUN2QmpFLEVBQUUsQ0FBQyxPQUFPLEVBQUVrRSxNQUFNLENBQUM7Y0FDeEIsQ0FBQyxDQUFDO1lBQUE7Y0FKSU4sR0FBcUIsR0FBQUcsU0FBQSxDQUFBakUsSUFBQTtjQUtyQitELFlBQVksR0FBR08sSUFBSSxDQUFDdEksS0FBSyxDQUFDOEgsR0FBRyxDQUFDUyxJQUFJLENBQUM7Y0FDekMsSUFBSW5DLFVBQVUsS0FBSyxTQUFTLEVBQUU7Z0JBQzVCMkIsWUFBWSxDQUFDdEYsUUFBUSxHQUFHLDZCQUE2QjtjQUN2RDtjQUFDd0YsU0FBQSxDQUFBcEgsSUFBQTtjQUFBLE9BQ0t2QixRQUFRLENBQUNrSixvQkFBb0IsQ0FBQ3BDLFVBQVUsRUFBRTJCLFlBQVksQ0FBQztZQUFBO2NBQzdELElBQUksQ0FBQ2xHLEtBQUssQ0FBQyw2Q0FBNkMsQ0FBQztjQUFDLE9BQUFvRyxTQUFBLENBQUE1QyxNQUFBLFdBQ25ELElBQUksQ0FBQ21DLFNBQVMsQ0FBQ3BCLFVBQVUsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBNkIsU0FBQSxDQUFBekcsSUFBQTtVQUFBO1FBQUEsR0FBQW9HLFFBQUE7TUFBQSxDQUNsQztNQUFBLFNBZEtkLHlCQUF5QkEsQ0FBQTJCLEdBQUE7UUFBQSxPQUFBZCwwQkFBQSxDQUFBbEcsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUF6Qm9GLHlCQUF5QjtJQUFBO0VBQUE7SUFBQWxILEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUE2SSxhQUFBLEdBQUF0SSxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBZ0IvQixTQUFBcUksU0FDRUMsU0FBNkIsRUFDN0JwQyxLQUFhO1FBQUEsSUFBQWUsSUFBQTtRQUFBLE9BQUFsSCxtQkFBQSxDQUFBSSxJQUFBLFVBQUFvSSxVQUFBQyxTQUFBO1VBQUEsa0JBQUFBLFNBQUEsQ0FBQWxJLElBQUEsR0FBQWtJLFNBQUEsQ0FBQWpJLElBQUE7WUFBQTtjQUFBLE1BRVQrSCxTQUFTLElBQUkzRiwyQkFBQSxDQUFBMkYsU0FBUyxFQUFBMUYsSUFBQSxDQUFUMEYsU0FBUyxFQUFZLG1CQUFtQixDQUFDO2dCQUFBRSxTQUFBLENBQUFqSSxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxPQUFBaUksU0FBQSxDQUFBekQsTUFBQSxXQUNqRCxJQUFBNkMsUUFBQSxDQUFZLFVBQUNDLE9BQU8sRUFBRUMsTUFBTSxFQUFLO2dCQUN0QyxJQUFNVyxNQUFNLEdBQUd0SyxJQUFJLENBQUN1SyxZQUFZLENBQUMsVUFBQ0MsR0FBRyxFQUFFbkIsR0FBRyxFQUFLO2tCQUM3QyxJQUFJLENBQUNtQixHQUFHLENBQUN2SyxHQUFHLEVBQUU7b0JBQ1o7a0JBQ0Y7a0JBQ0EsSUFBTXdLLE9BQU8sR0FBR3hLLEdBQUcsQ0FBQ3NCLEtBQUssQ0FBQ2lKLEdBQUcsQ0FBQ3ZLLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQ3lLLEtBQUs7a0JBQzlDckIsR0FBRyxDQUFDc0IsU0FBUyxDQUFDLEdBQUcsRUFBRTtvQkFBRSxjQUFjLEVBQUU7a0JBQVksQ0FBQyxDQUFDO2tCQUNuRHRCLEdBQUcsQ0FBQ3VCLEtBQUssQ0FDUCw0REFDRixDQUFDO2tCQUNEdkIsR0FBRyxDQUFDd0IsR0FBRyxDQUFDLENBQUM7a0JBQ1QsSUFBSUosT0FBTyxDQUFDNUgsS0FBSyxFQUFFO29CQUNqQjhHLE1BQU0sQ0FBQyxJQUFJakUsS0FBSyxDQUFDK0UsT0FBTyxDQUFDNUgsS0FBZSxDQUFDLENBQUM7a0JBQzVDLENBQUMsTUFBTTtvQkFDTDZHLE9BQU8sQ0FBQ2UsT0FBMEMsQ0FBQztrQkFDckQ7a0JBQ0FILE1BQU0sQ0FBQ1EsS0FBSyxDQUFDLENBQUM7a0JBQ2ROLEdBQUcsQ0FBQ25GLFVBQVUsQ0FBQ3dGLEdBQUcsQ0FBQyxDQUFDO2tCQUNwQkwsR0FBRyxDQUFDbkYsVUFBVSxDQUFDMEYsT0FBTyxDQUFDLENBQUM7Z0JBQzFCLENBQUMsQ0FBQztnQkFDRixJQUFNQyxJQUFJLEdBQUdDLE1BQU0sQ0FBQ2hMLEdBQUcsQ0FBQ3NCLEtBQUssQ0FBQzRJLFNBQVMsQ0FBQyxDQUFDYSxJQUFJLENBQUM7Z0JBQzlDVixNQUFNLENBQUNZLE1BQU0sQ0FBQ0YsSUFBSSxFQUFFLFdBQVcsQ0FBQztjQUNsQyxDQUFDLENBQUM7WUFBQTtjQUFBWCxTQUFBLENBQUFqSSxJQUFBO2NBQUEsT0FFaUIsSUFBSSxDQUFDK0ksYUFBYSxDQUNuQyxvREFDRixDQUFDO1lBQUE7Y0FGS3JDLElBQUksR0FBQXVCLFNBQUEsQ0FBQTlFLElBQUE7Y0FBQSxPQUFBOEUsU0FBQSxDQUFBekQsTUFBQSxXQUdIO2dCQUFFa0MsSUFBSSxFQUFFc0Msa0JBQWtCLENBQUN0QyxJQUFJLENBQUM7Z0JBQUVmLEtBQUssRUFBTEE7Y0FBTSxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUFzQyxTQUFBLENBQUF0SCxJQUFBO1VBQUE7UUFBQSxHQUFBbUgsUUFBQTtNQUFBLENBRW5EO01BQUEsU0FsQ0tyQixZQUFZQSxDQUFBd0MsSUFBQSxFQUFBQyxJQUFBO1FBQUEsT0FBQXJCLGFBQUEsQ0FBQWpILEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBWjRGLFlBQVk7SUFBQTtJQW9DbEI7QUFDRjtBQUNBO0VBRkU7SUFBQTFILEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFtSyxTQUFBLEdBQUE1SixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQTJKLFVBQWU3RCxVQUE4QixFQUFFMkIsWUFBMEI7UUFBQSxJQUFBbUMsU0FBQTtVQUFBQyxNQUFBO1FBQUEsSUFBQXZFLElBQUEsRUFBQXdFLE9BQUEsRUFBQUMsVUFBQSxFQUFBQyxHQUFBLEVBQUFDLEVBQUE7UUFBQSxPQUFBbEssbUJBQUEsQ0FBQUksSUFBQSxVQUFBK0osV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUE3SixJQUFBLEdBQUE2SixVQUFBLENBQUE1SixJQUFBO1lBQUE7Y0FDakUrRSxJQUFJLEdBQUdRLFVBQVUsSUFBSSxTQUFTO2NBQzlCZ0UsT0FBTyxHQUFHO2dCQUNkOUgsUUFBUSxFQUFFLG9CQUFvQjtnQkFDOUJDLFlBQVksRUFBRSxtQ0FBbUM7Z0JBQ2pEQyxXQUFXLEVBQUUsdUJBQXVCO2dCQUNwQ0MsUUFBUSxFQUFFO2NBQ1osQ0FBQztjQUFBZ0ksVUFBQSxDQUFBNUosSUFBQTtjQUFBLE9BQ3dCdkIsUUFBUSxDQUFDdUgsZUFBZSxDQUFDakIsSUFBSSxDQUFDO1lBQUE7Y0FBakR5RSxVQUFVLEdBQUFJLFVBQUEsQ0FBQXpHLElBQUE7Y0FBQSxLQUNacUcsVUFBVTtnQkFBQUksVUFBQSxDQUFBNUosSUFBQTtnQkFBQTtjQUFBO2NBQ055SixHQUFHLGNBQUFuSCxNQUFBLENBQWN5QyxJQUFJO2NBQUE2RSxVQUFBLENBQUE1SixJQUFBO2NBQUEsT0FDVixJQUFJLENBQUM2SixhQUFhLENBQUNKLEdBQUcsQ0FBQztZQUFBO2NBQWxDQyxFQUFFLEdBQUFFLFVBQUEsQ0FBQXpHLElBQUE7Y0FBQSxJQUNIdUcsRUFBRTtnQkFBQUUsVUFBQSxDQUFBNUosSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDQyxJQUFJc0QsS0FBSyxDQUFDLHdCQUF3QixDQUFDO1lBQUE7Y0FBQXNHLFVBQUEsQ0FBQTVKLElBQUE7Y0FBQSxPQUd4QjhKLHVCQUFBLENBQUFULFNBQUEsR0FBQVUsWUFBQSxDQUFZUixPQUFPLENBQUMsRUFBQWxILElBQUEsQ0FBQWdILFNBQUE7Z0JBQUEsSUFBQVcsSUFBQSxHQUFBekssaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUFRLFNBQUF3SyxTQUFPQyxPQUFPLEVBQUVuRixJQUFJO2tCQUFBLElBQUFvRixPQUFBLEVBQUFDLFVBQUEsRUFBQTdHLE9BQUEsRUFBQXZFLEtBQUE7a0JBQUEsT0FBQVEsbUJBQUEsQ0FBQUksSUFBQSxVQUFBeUssVUFBQUMsVUFBQTtvQkFBQSxrQkFBQUEsVUFBQSxDQUFBdkssSUFBQSxHQUFBdUssVUFBQSxDQUFBdEssSUFBQTtzQkFBQTt3QkFBQXNLLFVBQUEsQ0FBQXRLLElBQUE7d0JBQUEsT0FDN0NrSyxPQUFPO3NCQUFBO3dCQUF2QkMsT0FBTyxHQUFBRyxVQUFBLENBQUFuSCxJQUFBO3dCQUNQaUgsVUFBVSxHQUFHckYsSUFBSTt3QkFDakJ4QixPQUFPLEdBQUdnRyxPQUFPLENBQUNhLFVBQVUsQ0FBQzt3QkFBQSxJQUM5QkQsT0FBTyxDQUFDQyxVQUFVLENBQUM7MEJBQUFFLFVBQUEsQ0FBQXRLLElBQUE7MEJBQUE7d0JBQUE7d0JBQUFzSyxVQUFBLENBQUF0SyxJQUFBO3dCQUFBLE9BQ0ZzSixNQUFJLENBQUNQLGFBQWEsQ0FBQ3hGLE9BQU8sQ0FBQztzQkFBQTt3QkFBekN2RSxLQUFLLEdBQUFzTCxVQUFBLENBQUFuSCxJQUFBO3dCQUFBLEtBQ1BuRSxLQUFLOzBCQUFBc0wsVUFBQSxDQUFBdEssSUFBQTswQkFBQTt3QkFBQTt3QkFBQSxPQUFBc0ssVUFBQSxDQUFBOUYsTUFBQSxXQUFBK0YsYUFBQSxDQUFBQSxhQUFBLEtBRUZKLE9BQU8sT0FBQXZMLGVBQUEsS0FDVHdMLFVBQVUsRUFBR3BMLEtBQUs7c0JBQUE7d0JBQUEsT0FBQXNMLFVBQUEsQ0FBQTlGLE1BQUEsV0FJbEIyRixPQUFPO3NCQUFBO3NCQUFBO3dCQUFBLE9BQUFHLFVBQUEsQ0FBQTNKLElBQUE7b0JBQUE7a0JBQUEsR0FBQXNKLFFBQUE7Z0JBQUEsQ0FDZjtnQkFBQSxpQkFBQU8sSUFBQSxFQUFBQyxJQUFBO2tCQUFBLE9BQUFULElBQUEsQ0FBQXBKLEtBQUEsT0FBQUMsU0FBQTtnQkFBQTtjQUFBLEtBQUV3RyxRQUFBLENBQVFDLE9BQU8sQ0FBQ0osWUFBWSxDQUFDLENBQUM7WUFBQTtjQWRqQ0EsWUFBWSxHQUFBMEMsVUFBQSxDQUFBekcsSUFBQTtjQUFBeUcsVUFBQSxDQUFBNUosSUFBQTtjQUFBLE9BZU52QixRQUFRLENBQUNrSixvQkFBb0IsQ0FBQzVDLElBQUksRUFBRW1DLFlBQVksQ0FBQztZQUFBO2NBQ3ZELElBQUksQ0FBQ2xHLEtBQUssQ0FBQyxpQ0FBaUMsQ0FBQztZQUFDO1lBQUE7Y0FBQSxPQUFBNEksVUFBQSxDQUFBakosSUFBQTtVQUFBO1FBQUEsR0FBQXlJLFNBQUE7TUFBQSxDQUMvQztNQUFBLFNBakNLc0IsUUFBUUEsQ0FBQUMsSUFBQSxFQUFBQyxJQUFBO1FBQUEsT0FBQXpCLFNBQUEsQ0FBQXZJLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBUjZKLFFBQVE7SUFBQTtJQW1DZDtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUEzTCxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBNkwsZ0JBQUEsR0FBQXRMLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBcUwsVUFBQTtRQUFBLElBQUFDLEtBQUEsRUFBQUMsU0FBQSxFQUFBQyxLQUFBLEVBQUFsRyxJQUFBO1FBQUEsT0FBQXZGLG1CQUFBLENBQUFJLElBQUEsVUFBQXNMLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBcEwsSUFBQSxHQUFBb0wsVUFBQSxDQUFBbkwsSUFBQTtZQUFBO2NBQUFtTCxVQUFBLENBQUFuTCxJQUFBO2NBQUEsT0FDc0J2QixRQUFRLENBQUMyTSxrQkFBa0IsQ0FBQyxDQUFDO1lBQUE7Y0FBM0NMLEtBQUssR0FBQUksVUFBQSxDQUFBaEksSUFBQTtjQUFBNkgsU0FBQSxHQUFBSywwQkFBQSxDQUNRTixLQUFLO2NBQUE7Z0JBQXhCLEtBQUFDLFNBQUEsQ0FBQU0sQ0FBQSxNQUFBTCxLQUFBLEdBQUFELFNBQUEsQ0FBQU8sQ0FBQSxJQUFBQyxJQUFBLEdBQTBCO2tCQUFmekcsSUFBSSxHQUFBa0csS0FBQSxDQUFBak0sS0FBQTtrQkFDYixJQUFJLENBQUNnQyxLQUFLLENBQUMsQ0FBQytELElBQUksS0FBSyxJQUFJLENBQUMzRCxTQUFTLEdBQUcsSUFBSSxHQUFHLElBQUksSUFBSTJELElBQUksQ0FBQztnQkFDNUQ7Y0FBQyxTQUFBMEcsR0FBQTtnQkFBQVQsU0FBQSxDQUFBVSxDQUFBLENBQUFELEdBQUE7Y0FBQTtnQkFBQVQsU0FBQSxDQUFBVyxDQUFBO2NBQUE7WUFBQTtZQUFBO2NBQUEsT0FBQVIsVUFBQSxDQUFBeEssSUFBQTtVQUFBO1FBQUEsR0FBQW1LLFNBQUE7TUFBQSxDQUNGO01BQUEsU0FMS2MsZUFBZUEsQ0FBQTtRQUFBLE9BQUFmLGdCQUFBLENBQUFqSyxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQWYrSyxlQUFlO0lBQUE7SUFPckI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBN00sR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQTZNLG1CQUFBLEdBQUF0TSxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQXFNLFVBQUE7UUFBQSxPQUFBdE0sbUJBQUEsQ0FBQUksSUFBQSxVQUFBbU0sV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUFqTSxJQUFBLEdBQUFpTSxVQUFBLENBQUFoTSxJQUFBO1lBQUE7Y0FBQSxPQUFBZ00sVUFBQSxDQUFBeEgsTUFBQSxXQUNTL0YsUUFBUSxDQUFDMk0sa0JBQWtCLENBQUMsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBWSxVQUFBLENBQUFyTCxJQUFBO1VBQUE7UUFBQSxHQUFBbUwsU0FBQTtNQUFBLENBQ3JDO01BQUEsU0FGS1Ysa0JBQWtCQSxDQUFBO1FBQUEsT0FBQVMsbUJBQUEsQ0FBQWpMLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBbEJ1SyxrQkFBa0I7SUFBQTtJQUl4QjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUFyTSxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBaU4sZUFBQSxHQUFBMU0saUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUF5TSxVQUFBO1FBQUEsT0FBQTFNLG1CQUFBLENBQUFJLElBQUEsVUFBQXVNLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBck0sSUFBQSxHQUFBcU0sVUFBQSxDQUFBcE0sSUFBQTtZQUFBO2NBQUEsT0FBQW9NLFVBQUEsQ0FBQTVILE1BQUEsV0FDUy9GLFFBQVEsQ0FBQzROLGNBQWMsQ0FBQyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUFELFVBQUEsQ0FBQXpMLElBQUE7VUFBQTtRQUFBLEdBQUF1TCxTQUFBO01BQUEsQ0FDakM7TUFBQSxTQUZLRyxjQUFjQSxDQUFBO1FBQUEsT0FBQUosZUFBQSxDQUFBckwsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFkd0wsY0FBYztJQUFBO0lBSXBCO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQXROLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFzTixPQUFBLEdBQUEvTSxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQThNLFVBQWFDLElBQVksRUFBRWpKLE9BQWU7UUFBQSxJQUFBa0osTUFBQTtRQUFBLE9BQUFqTixtQkFBQSxDQUFBSSxJQUFBLFVBQUE4TSxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTVNLElBQUEsR0FBQTRNLFVBQUEsQ0FBQTNNLElBQUE7WUFBQTtjQUN4QyxJQUFJLENBQUNJLEtBQUssQ0FBQ3dNLEtBQUssQ0FBQyxDQUFDO2NBQUNELFVBQUEsQ0FBQTNNLElBQUE7Y0FBQSxPQUNxQi9CLFFBQVEsQ0FBQzRPLE1BQU0sQ0FBQyxDQUN0RDtnQkFDRUwsSUFBSSxFQUFKQSxJQUFJO2dCQUNKekgsSUFBSSxFQUFFLE9BQU87Z0JBQ2J4QixPQUFPLEVBQVBBO2NBQ0YsQ0FBQyxDQUNGLENBQUM7WUFBQTtjQU5Ja0osTUFBeUIsR0FBQUUsVUFBQSxDQUFBeEosSUFBQTtjQU8vQixJQUFJLENBQUMvQyxLQUFLLENBQUMwTSxNQUFNLENBQUMsQ0FBQztjQUFDLE9BQUFILFVBQUEsQ0FBQW5JLE1BQUEsV0FDYmlJLE1BQU0sQ0FBQ3pOLEtBQUs7WUFBQTtZQUFBO2NBQUEsT0FBQTJOLFVBQUEsQ0FBQWhNLElBQUE7VUFBQTtRQUFBLEdBQUE0TCxTQUFBO01BQUEsQ0FDcEI7TUFBQSxTQVhLTSxNQUFNQSxDQUFBRSxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBVixPQUFBLENBQUExTCxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQU5nTSxNQUFNO0lBQUE7SUFhWjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUE5TixHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBaU8sY0FBQSxHQUFBMU4saUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUF5TixVQUFvQjNKLE9BQWU7UUFBQSxPQUFBL0QsbUJBQUEsQ0FBQUksSUFBQSxVQUFBdU4sV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUFyTixJQUFBLEdBQUFxTixVQUFBLENBQUFwTixJQUFBO1lBQUE7Y0FBQSxPQUFBb04sVUFBQSxDQUFBNUksTUFBQSxXQUMxQixJQUFJLENBQUNxSSxNQUFNLENBQUMsT0FBTyxFQUFFdEosT0FBTyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUE2SixVQUFBLENBQUF6TSxJQUFBO1VBQUE7UUFBQSxHQUFBdU0sU0FBQTtNQUFBLENBQ3JDO01BQUEsU0FGS25FLGFBQWFBLENBQUFzRSxJQUFBO1FBQUEsT0FBQUosY0FBQSxDQUFBck0sS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFia0ksYUFBYTtJQUFBO0VBQUE7SUFBQWhLLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFzTyxlQUFBLEdBQUEvTixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBSW5CLFNBQUE4TixVQUFxQmhLLE9BQWU7UUFBQSxPQUFBL0QsbUJBQUEsQ0FBQUksSUFBQSxVQUFBNE4sV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUExTixJQUFBLEdBQUEwTixVQUFBLENBQUF6TixJQUFBO1lBQUE7Y0FBQSxPQUFBeU4sVUFBQSxDQUFBakosTUFBQSxXQUMzQixJQUFJLENBQUNxSSxNQUFNLENBQUMsVUFBVSxFQUFFdEosT0FBTyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUFrSyxVQUFBLENBQUE5TSxJQUFBO1VBQUE7UUFBQSxHQUFBNE0sU0FBQTtNQUFBLENBQ3hDO01BQUEsU0FGS2hKLGNBQWNBLENBQUFtSixJQUFBO1FBQUEsT0FBQUosZUFBQSxDQUFBMU0sS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFkMEQsY0FBYztJQUFBO0lBSXBCO0FBQ0Y7QUFDQTtFQUZFO0lBQUF4RixHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBMk8sY0FBQSxHQUFBcE8saUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUFtTyxVQUFvQnJLLE9BQWU7UUFBQSxPQUFBL0QsbUJBQUEsQ0FBQUksSUFBQSxVQUFBaU8sV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUEvTixJQUFBLEdBQUErTixVQUFBLENBQUE5TixJQUFBO1lBQUE7Y0FBQSxPQUFBOE4sVUFBQSxDQUFBdEosTUFBQSxXQUMxQixJQUFJLENBQUNxSSxNQUFNLENBQUMsU0FBUyxFQUFFdEosT0FBTyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUF1SyxVQUFBLENBQUFuTixJQUFBO1VBQUE7UUFBQSxHQUFBaU4sU0FBQTtNQUFBLENBQ3ZDO01BQUEsU0FGSy9ELGFBQWFBLENBQUFrRSxJQUFBO1FBQUEsT0FBQUosY0FBQSxDQUFBL00sS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFiZ0osYUFBYTtJQUFBO0lBSW5CO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQTlLLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUFqQixPQUFPQSxDQUFDRixHQUFXLEVBQUU7TUFDbkJFLFFBQU8sQ0FBQ0YsR0FBRyxDQUFDO0lBQ2Q7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQWtCLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUFnUCxtQkFBbUJBLENBQUNuUSxHQUFZLEVBQUU7TUFBQSxJQUFBb1EsVUFBQTtNQUNoQyxJQUFJQyxZQUFZLEdBQUFDLHVCQUFBLENBQUFGLFVBQUEsTUFBQTNMLE1BQUEsQ0FBTSxJQUFJLENBQUN2QixLQUFLLENBQUNlLFdBQVcsZ0NBQUFPLElBQUEsQ0FBQTRMLFVBQUEsRUFBNEIsSUFBSSxDQUFDbE4sS0FBSyxDQUFDYyxXQUFXLENBQUU7TUFDaEcsSUFBSWhFLEdBQUcsRUFBRTtRQUNQcVEsWUFBWSxJQUFJLFVBQVUsR0FBR0Usa0JBQWtCLENBQUN2USxHQUFHLENBQUM7TUFDdEQ7TUFDQSxJQUFJLENBQUNFLE9BQU8sQ0FBQ21RLFlBQVksQ0FBQztJQUM1QjtFQUFDO0FBQUE7O0FBR0g7O0FBRUEsSUFBTUcsR0FBRyxHQUFHLElBQUkzUCxHQUFHLENBQUMsQ0FBQztBQUVyQixlQUFlMlAsR0FBRyIsImlnbm9yZUxpc3QiOltdfQ==