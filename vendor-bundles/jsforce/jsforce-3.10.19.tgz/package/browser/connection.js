import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Symbol$toPrimitive from "@babel/runtime-corejs3/core-js-stable/symbol/to-primitive";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _toConsumableArray from "@babel/runtime-corejs3/helpers/toConsumableArray";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";
var _excluded = ["Id", "type", "attributes"],
  _excluded2 = ["Id", "type", "attributes"],
  _excluded3 = ["Id", "type", "attributes"],
  _excluded4 = ["Id", "type", "attributes"];
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[_Symbol$toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof _Symbol && _getIteratorMethod(r) || r["@@iterator"]; if (!t) { if (_Array$isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { var _context59; if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = _sliceInstanceProperty(_context59 = {}.toString.call(r)).call(_context59, 8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? _Array$from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context57, _context58; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context57 = ownKeys(Object(t), !0)).call(_context57, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context58 = ownKeys(Object(t))).call(_context58, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _startsWithInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/starts-with";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _parseInt from "@babel/runtime-corejs3/core-js-stable/parse-int";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$entries from "@babel/runtime-corejs3/core-js-stable/object/entries";
import _includesInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/includes";
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.join.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.number.constructor.js";
import "core-js/modules/es.object.keys.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/es.regexp.to-string.js";
import "core-js/modules/es.string.match.js";
import "core-js/modules/es.string.replace.js";
/**
 *
 */
import { EventEmitter } from 'events';
import jsforce from './jsforce';
import Transport, { CanvasTransport, XdProxyTransport, HttpProxyTransport } from './transport';
import { getLogger } from './util/logger';
import OAuth2 from './oauth2';
import Cache from './cache';
import HttpApi from './http-api';
import SessionRefreshDelegate from './session-refresh-delegate';
import Query from './query';
import SObject from './sobject';
import QuickAction from './quick-action';
import Process from './process';
import { formatDate } from './util/formatter';
import FormData from 'form-data';

/**
 * type definitions
 */

/**
 *
 */
var defaultConnectionConfig = {
  loginUrl: 'https://login.salesforce.com',
  instanceUrl: '',
  version: '50.0',
  logLevel: 'NONE',
  maxRequest: 10
};

/**
 *
 */
function esc(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/**
 *
 */
function parseSignedRequest(sr) {
  if (typeof sr === 'string') {
    if (_startsWithInstanceProperty(sr).call(sr, '{')) {
      // might be JSON
      return JSON.parse(sr);
    } // might be original base64-encoded signed request
    var msg = sr.split('.').pop(); // retrieve latter part
    if (!msg) {
      throw new Error('Invalid signed request');
    }
    var json = Buffer.from(msg, 'base64').toString('utf-8');
    return JSON.parse(json);
  }
  return sr;
}

/** @private **/
function parseIdUrl(url) {
  var _context;
  var _url$split$slice = _sliceInstanceProperty(_context = url.split('/')).call(_context, -2),
    _url$split$slice2 = _slicedToArray(_url$split$slice, 2),
    organizationId = _url$split$slice2[0],
    id = _url$split$slice2[1];
  return {
    id: id,
    organizationId: organizationId,
    url: url
  };
}

/**
 * Send basic message in case a refresh is needed when the session expired but there is no OAuth setup !!! SF-toolkit
 * @private 
 */
function defaultRefreshFn(conn, callback) {
  callback(new Error('defaultRefreshFn'), undefined);
}

/**
 * Session Refresh delegate function for OAuth2 authz code flow
 * @private
 */
function oauthRefreshFn(_x, _x2) {
  return _oauthRefreshFn.apply(this, arguments);
}
/**
 * Session Refresh delegate function for username/password login
 * @private
 */
function _oauthRefreshFn() {
  _oauthRefreshFn = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee37(conn, callback) {
    var res, userInfo;
    return _regeneratorRuntime.wrap(function _callee37$(_context56) {
      while (1) switch (_context56.prev = _context56.next) {
        case 0:
          _context56.prev = 0;
          if (conn.refreshToken) {
            _context56.next = 3;
            break;
          }
          throw new Error('No refresh token found in the connection');
        case 3:
          _context56.next = 5;
          return conn.oauth2.refreshToken(conn.refreshToken);
        case 5:
          res = _context56.sent;
          userInfo = parseIdUrl(res.id);
          conn._establish({
            instanceUrl: res.instance_url,
            accessToken: res.access_token,
            userInfo: userInfo
          });
          callback(undefined, res.access_token, res);
          _context56.next = 18;
          break;
        case 11:
          _context56.prev = 11;
          _context56.t0 = _context56["catch"](0);
          if (!(_context56.t0 instanceof Error)) {
            _context56.next = 17;
            break;
          }
          callback(_context56.t0);
          _context56.next = 18;
          break;
        case 17:
          throw _context56.t0;
        case 18:
        case "end":
          return _context56.stop();
      }
    }, _callee37, null, [[0, 11]]);
  }));
  return _oauthRefreshFn.apply(this, arguments);
}
function createUsernamePasswordRefreshFn(username, password) {
  return /*#__PURE__*/function () {
    var _ref = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(conn, callback) {
      return _regeneratorRuntime.wrap(function _callee$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return conn.login(username, password);
          case 3:
            if (conn.accessToken) {
              _context2.next = 5;
              break;
            }
            throw new Error('Access token not found after login');
          case 5:
            callback(null, conn.accessToken);
            _context2.next = 15;
            break;
          case 8:
            _context2.prev = 8;
            _context2.t0 = _context2["catch"](0);
            if (!(_context2.t0 instanceof Error)) {
              _context2.next = 14;
              break;
            }
            callback(_context2.t0);
            _context2.next = 15;
            break;
          case 14:
            throw _context2.t0;
          case 15:
          case "end":
            return _context2.stop();
        }
      }, _callee, null, [[0, 8]]);
    }));
    return function (_x3, _x4) {
      return _ref.apply(this, arguments);
    };
  }();
}

/**
 * @private
 */
function toSaveResult(err) {
  return {
    success: false,
    errors: [err]
  };
}

/**
 *
 */
function raiseNoModuleError(name) {
  var _context3;
  throw new Error(_concatInstanceProperty(_context3 = "API module '".concat(name, "' is not loaded, load 'jsforce/api/")).call(_context3, name, "' explicitly"));
}

/*
 * Constant of maximum records num in DML operation (update/delete)
 */
var MAX_DML_COUNT = 200;

/**
 *
 */
export var Connection = /*#__PURE__*/function (_EventEmitter) {
  /**
   *
   */
  function Connection() {
    var _this;
    var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    _classCallCheck(this, Connection);
    _this = _callSuper(this, Connection);
    _defineProperty(_this, "limitInfo", {});
    _defineProperty(_this, "sobjects", {});
    /**
     * Synonym of Connection#create()
     */
    _defineProperty(_this, "insert", _this.create);
    /**
     * Synonym of Connection#destroy()
     */
    _defineProperty(_this, "delete", _this.destroy);
    /**
     * Synonym of Connection#destroy()
     */
    _defineProperty(_this, "del", _this.destroy);
    /**
     * Module which manages process rules and approval processes
     */
    _defineProperty(_this, "process", new Process(_this));
    var loginUrl = config.loginUrl,
      instanceUrl = config.instanceUrl,
      version = config.version,
      oauth2 = config.oauth2,
      maxRequest = config.maxRequest,
      logLevel = config.logLevel,
      proxyUrl = config.proxyUrl,
      httpProxy = config.httpProxy;
    _this.loginUrl = loginUrl || defaultConnectionConfig.loginUrl;
    _this.instanceUrl = instanceUrl || defaultConnectionConfig.instanceUrl;
    if (_this.isLightningInstance()) {
      throw new Error('lightning URLs are not valid as instance URLs');
    }
    _this.version = version || defaultConnectionConfig.version;
    _this.oauth2 = oauth2 instanceof OAuth2 ? oauth2 : new OAuth2(_objectSpread({
      loginUrl: _this.loginUrl,
      proxyUrl: proxyUrl,
      httpProxy: httpProxy
    }, oauth2));
    var refreshFn = config.refreshFn;
    if (!refreshFn && _this.oauth2.clientId) {
      refreshFn = oauthRefreshFn;
    } else if (!refreshFn && !_this.oauth2.clientId) {
      refreshFn = defaultRefreshFn;
    }
    if (refreshFn) {
      _this._refreshDelegate = new SessionRefreshDelegate(_this, refreshFn);
    }
    _this._maxRequest = maxRequest || defaultConnectionConfig.maxRequest;
    _this._logger = logLevel ? Connection._logger.createInstance(logLevel) : Connection._logger;
    _this._logLevel = logLevel;
    _this._transport = proxyUrl ? new XdProxyTransport(proxyUrl) : httpProxy ? new HttpProxyTransport(httpProxy) : new Transport();
    _this._callOptions = config.callOptions;
    _this.cache = new Cache();
    var describeCacheKey = function describeCacheKey(type) {
      return type ? "describe.".concat(type) : 'describe';
    };
    var describe = Connection.prototype.describe;
    _this.describe = _this.cache.createCachedFunction(describe, _this, {
      key: describeCacheKey,
      strategy: 'NOCACHE'
    });
    _this.describe$ = _this.cache.createCachedFunction(describe, _this, {
      key: describeCacheKey,
      strategy: 'HIT'
    });
    _this.describe$$ = _this.cache.createCachedFunction(describe, _this, {
      key: describeCacheKey,
      strategy: 'IMMEDIATE'
    });
    _this.describeSObject = _this.describe;
    _this.describeSObject$ = _this.describe$;
    _this.describeSObject$$ = _this.describe$$;
    var describeGlobal = Connection.prototype.describeGlobal;
    _this.describeGlobal = _this.cache.createCachedFunction(describeGlobal, _this, {
      key: 'describeGlobal',
      strategy: 'NOCACHE'
    });
    _this.describeGlobal$ = _this.cache.createCachedFunction(describeGlobal, _this, {
      key: 'describeGlobal',
      strategy: 'HIT'
    });
    _this.describeGlobal$$ = _this.cache.createCachedFunction(describeGlobal, _this, {
      key: 'describeGlobal',
      strategy: 'IMMEDIATE'
    });
    var accessToken = config.accessToken,
      refreshToken = config.refreshToken,
      sessionId = config.sessionId,
      serverUrl = config.serverUrl,
      signedRequest = config.signedRequest;
    _this._establish({
      accessToken: accessToken,
      refreshToken: refreshToken,
      instanceUrl: instanceUrl,
      sessionId: sessionId,
      serverUrl: serverUrl,
      signedRequest: signedRequest
    });
    jsforce.emit('connection:new', _this);
    return _this;
  }

  /* @private */
  _inherits(Connection, _EventEmitter);
  return _createClass(Connection, [{
    key: "analytics",
    get:
    /**
     * Cap for session-refresh retries on a single request. When unset, HttpApi
     * uses its built-in default. `0` fails immediately on an expired session.
     */

    // describe: (name: string) => Promise<DescribeSObjectResult>;

    // describeGlobal: () => Promise<DescribeGlobalResult>;

    // API libs are not instantiated here so that core module to remain without dependencies to them
    // It is responsible for developers to import api libs explicitly if they are using 'jsforce/core' instead of 'jsforce'.
    function get() {
      return raiseNoModuleError('analytics');
    }
  }, {
    key: "apex",
    get: function get() {
      return raiseNoModuleError('apex');
    }
  }, {
    key: "bulk",
    get: function get() {
      return raiseNoModuleError('bulk');
    }
  }, {
    key: "bulk2",
    get: function get() {
      return raiseNoModuleError('bulk2');
    }
  }, {
    key: "chatter",
    get: function get() {
      return raiseNoModuleError('chatter');
    }
  }, {
    key: "metadata",
    get: function get() {
      return raiseNoModuleError('metadata');
    }
  }, {
    key: "soap",
    get: function get() {
      return raiseNoModuleError('soap');
    }
  }, {
    key: "streaming",
    get: function get() {
      return raiseNoModuleError('streaming');
    }
  }, {
    key: "tooling",
    get: function get() {
      return raiseNoModuleError('tooling');
    }
  }, {
    key: "_establish",
    value: function _establish(options) {
      var _context4;
      var accessToken = options.accessToken,
        refreshToken = options.refreshToken,
        instanceUrl = options.instanceUrl,
        sessionId = options.sessionId,
        serverUrl = options.serverUrl,
        signedRequest = options.signedRequest,
        userInfo = options.userInfo;
      this.instanceUrl = serverUrl ? _sliceInstanceProperty(_context4 = serverUrl.split('/')).call(_context4, 0, 3).join('/') : instanceUrl || this.instanceUrl;
      this.accessToken = sessionId || accessToken || this.accessToken;
      this.refreshToken = refreshToken || this.refreshToken;
      if (this.refreshToken && !this._refreshDelegate) {
        throw new Error('Refresh token is specified without oauth2 client information or refresh function');
      }
      var signedRequestObject = signedRequest && parseSignedRequest(signedRequest);
      if (signedRequestObject) {
        this.accessToken = signedRequestObject.client.oauthToken;
        if (CanvasTransport.supported) {
          this._transport = new CanvasTransport(signedRequestObject);
        }
      }
      this.userInfo = userInfo || this.userInfo;
      this._sessionType = sessionId ? 'soap' : 'oauth2';
      this._resetInstance();
    }

    /* @priveate */
  }, {
    key: "_clearSession",
    value: function _clearSession() {
      this.accessToken = null;
      this.refreshToken = null;
      this.instanceUrl = defaultConnectionConfig.instanceUrl;
      this.userInfo = null;
      this._sessionType = null;
    }

    /* @priveate */
  }, {
    key: "_resetInstance",
    value: function _resetInstance() {
      var _this2 = this;
      this.limitInfo = {};
      this.sobjects = {};
      // TODO impl cache
      this.cache.clear();
      this.cache.get('describeGlobal').removeAllListeners('value');
      this.cache.get('describeGlobal').on('value', function (_ref2) {
        var result = _ref2.result;
        if (result) {
          var _iterator = _createForOfIteratorHelper(result.sobjects),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var so = _step.value;
              _this2.sobject(so.name);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
      });
      /*
      if (this.tooling) {
        this.tooling._resetInstance();
      }
      */
    }

    /**
     * Authorize the connection using OAuth2 flow.
     * Typically, just pass the code returned from authorization server in the first argument to complete authorization.
     * If you want to authorize with grant types other than `authorization_code`, you can also pass params object with the grant type.
     *
     * @returns {Promise<UserInfo>} An object that contains the user ID, org ID and identity URL.
     *
     */
  }, {
    key: "authorize",
    value: (function () {
      var _authorize = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(codeOrParams) {
        var _context5;
        var params,
          res,
          userInfo,
          _args2 = arguments;
        return _regeneratorRuntime.wrap(function _callee2$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              params = _args2.length > 1 && _args2[1] !== undefined ? _args2[1] : {};
              _context6.next = 3;
              return this.oauth2.requestToken(codeOrParams, params);
            case 3:
              res = _context6.sent;
              userInfo = parseIdUrl(res.id);
              this._establish({
                instanceUrl: res.instance_url,
                accessToken: res.access_token,
                refreshToken: res.refresh_token,
                userInfo: userInfo
              });
              this._logger.debug(_concatInstanceProperty(_context5 = "<login> completed. user id = ".concat(userInfo.id, ", org id = ")).call(_context5, userInfo.organizationId));
              return _context6.abrupt("return", userInfo);
            case 8:
            case "end":
              return _context6.stop();
          }
        }, _callee2, this);
      }));
      function authorize(_x5) {
        return _authorize.apply(this, arguments);
      }
      return authorize;
    }()
    /**
     *
     */
    )
  }, {
    key: "login",
    value: (function () {
      var _login = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3(username, password) {
        var _this$oauth;
        return _regeneratorRuntime.wrap(function _callee3$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              this._refreshDelegate = new SessionRefreshDelegate(this, createUsernamePasswordRefreshFn(username, password));
              if (!((_this$oauth = this.oauth2) !== null && _this$oauth !== void 0 && _this$oauth.clientId && this.oauth2.clientSecret)) {
                _context7.next = 3;
                break;
              }
              return _context7.abrupt("return", this.loginByOAuth2(username, password));
            case 3:
              return _context7.abrupt("return", this.loginBySoap(username, password));
            case 4:
            case "end":
              return _context7.stop();
          }
        }, _callee3, this);
      }));
      function login(_x6, _x7) {
        return _login.apply(this, arguments);
      }
      return login;
    }()
    /**
     * Login by OAuth2 username & password flow
     */
    )
  }, {
    key: "loginByOAuth2",
    value: (function () {
      var _loginByOAuth = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4(username, password) {
        var _context8;
        var res, userInfo;
        return _regeneratorRuntime.wrap(function _callee4$(_context9) {
          while (1) switch (_context9.prev = _context9.next) {
            case 0:
              _context9.next = 2;
              return this.oauth2.authenticate(username, password);
            case 2:
              res = _context9.sent;
              userInfo = parseIdUrl(res.id);
              this._establish({
                instanceUrl: res.instance_url,
                accessToken: res.access_token,
                userInfo: userInfo
              });
              this._logger.info(_concatInstanceProperty(_context8 = "<login> completed. user id = ".concat(userInfo.id, ", org id = ")).call(_context8, userInfo.organizationId));
              return _context9.abrupt("return", userInfo);
            case 7:
            case "end":
              return _context9.stop();
          }
        }, _callee4, this);
      }));
      function loginByOAuth2(_x8, _x9) {
        return _loginByOAuth.apply(this, arguments);
      }
      return loginByOAuth2;
    }()
    /**
     * Login by SOAP protocol
     * @deprecated The SOAP login() API will be retired in Summer '27 (API version 65.0). 
     * Please use OAuth 2.0 Username-Password Flow instead. 
     * For more information, see https://help.salesforce.com/s/articleView?id=release-notes.rn_api_upcoming_retirement_258rn.htm&release=258&type=5
     */
    )
  }, {
    key: "loginBySoap",
    value: (function () {
      var _loginBySoap = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee5(username, password) {
        var _context10, _context11;
        var body, soapLoginEndpoint, response, m, faultstring, serverUrl, sessionId, userId, organizationId, idUrl, userInfo;
        return _regeneratorRuntime.wrap(function _callee5$(_context12) {
          while (1) switch (_context12.prev = _context12.next) {
            case 0:
              this._logger.warn('DEPRECATION WARNING: The SOAP login() API will be retired in Summer \'27 (API version 65.0). ' + 'Please use OAuth 2.0 Username-Password Flow instead. ' + 'For more information, see https://help.salesforce.com/s/articleView?id=release-notes.rn_api_upcoming_retirement_258rn.htm&release=258&type=5');
              if (!(!username || !password)) {
                _context12.next = 3;
                break;
              }
              return _context12.abrupt("return", _Promise.reject(new Error('no username password given')));
            case 3:
              body = ['<se:Envelope xmlns:se="http://schemas.xmlsoap.org/soap/envelope/">', '<se:Header/>', '<se:Body>', '<login xmlns="urn:partner.soap.sforce.com">', "<username>".concat(esc(username), "</username>"), "<password>".concat(esc(password), "</password>"), '</login>', '</se:Body>', '</se:Envelope>'].join('');
              soapLoginEndpoint = [this.loginUrl, 'services/Soap/u', this.version].join('/');
              _context12.next = 7;
              return this._transport.httpRequest({
                method: 'POST',
                url: soapLoginEndpoint,
                body: body,
                headers: {
                  'Content-Type': 'text/xml',
                  SOAPAction: '""'
                }
              });
            case 7:
              response = _context12.sent;
              if (!(response.statusCode >= 400)) {
                _context12.next = 12;
                break;
              }
              m = response.body.match(/<faultstring>([^<]+)<\/faultstring>/);
              faultstring = m && m[1];
              throw new Error(faultstring || response.body);
            case 12:
              if (!response.body.match(/<passwordExpired>true<\/passwordExpired>/g)) {
                _context12.next = 14;
                break;
              }
              throw new Error('Unable to login because the used password has expired.');
            case 14:
              this._logger.debug("SOAP response = ".concat(response.body));
              m = response.body.match(/<serverUrl>([^<]+)<\/serverUrl>/);
              serverUrl = m && m[1];
              m = response.body.match(/<sessionId>([^<]+)<\/sessionId>/);
              sessionId = m && m[1];
              m = response.body.match(/<userId>([^<]+)<\/userId>/);
              userId = m && m[1];
              m = response.body.match(/<organizationId>([^<]+)<\/organizationId>/);
              organizationId = m && m[1];
              if (!(!serverUrl || !sessionId || !userId || !organizationId)) {
                _context12.next = 25;
                break;
              }
              throw new Error('could not extract session information from login response');
            case 25:
              idUrl = [this.loginUrl, 'id', organizationId, userId].join('/');
              userInfo = {
                id: userId,
                organizationId: organizationId,
                url: idUrl
              };
              this._establish({
                serverUrl: _sliceInstanceProperty(_context10 = serverUrl.split('/')).call(_context10, 0, 3).join('/'),
                sessionId: sessionId,
                userInfo: userInfo
              });
              this._logger.info(_concatInstanceProperty(_context11 = "<login> completed. user id = ".concat(userId, ", org id = ")).call(_context11, organizationId));
              return _context12.abrupt("return", userInfo);
            case 30:
            case "end":
              return _context12.stop();
          }
        }, _callee5, this);
      }));
      function loginBySoap(_x10, _x11) {
        return _loginBySoap.apply(this, arguments);
      }
      return loginBySoap;
    }()
    /**
     * Logout the current session
     */
    )
  }, {
    key: "logout",
    value: (function () {
      var _logout = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee6(revoke) {
        return _regeneratorRuntime.wrap(function _callee6$(_context13) {
          while (1) switch (_context13.prev = _context13.next) {
            case 0:
              this._refreshDelegate = undefined;
              if (!(this._sessionType === 'oauth2')) {
                _context13.next = 3;
                break;
              }
              return _context13.abrupt("return", this.logoutByOAuth2(revoke));
            case 3:
              return _context13.abrupt("return", this.logoutBySoap(revoke));
            case 4:
            case "end":
              return _context13.stop();
          }
        }, _callee6, this);
      }));
      function logout(_x12) {
        return _logout.apply(this, arguments);
      }
      return logout;
    }()
    /**
     * Logout the current session by revoking access token via OAuth2 session revoke
     */
    )
  }, {
    key: "logoutByOAuth2",
    value: (function () {
      var _logoutByOAuth = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee7(revoke) {
        var token;
        return _regeneratorRuntime.wrap(function _callee7$(_context14) {
          while (1) switch (_context14.prev = _context14.next) {
            case 0:
              token = revoke ? this.refreshToken : this.accessToken;
              if (!token) {
                _context14.next = 4;
                break;
              }
              _context14.next = 4;
              return this.oauth2.revokeToken(token);
            case 4:
              // Destroy the session bound to this connection
              this._clearSession();
              this._resetInstance();
            case 6:
            case "end":
              return _context14.stop();
          }
        }, _callee7, this);
      }));
      function logoutByOAuth2(_x13) {
        return _logoutByOAuth.apply(this, arguments);
      }
      return logoutByOAuth2;
    }()
    /**
     * Logout the session by using SOAP web service API
     */
    )
  }, {
    key: "logoutBySoap",
    value: (function () {
      var _logoutBySoap = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee8(revoke) {
        var _context15;
        var body, response, m, faultstring;
        return _regeneratorRuntime.wrap(function _callee8$(_context16) {
          while (1) switch (_context16.prev = _context16.next) {
            case 0:
              body = ['<se:Envelope xmlns:se="http://schemas.xmlsoap.org/soap/envelope/">', '<se:Header>', '<SessionHeader xmlns="urn:partner.soap.sforce.com">', "<sessionId>".concat(esc(revoke ? this.refreshToken : this.accessToken), "</sessionId>"), '</SessionHeader>', '</se:Header>', '<se:Body>', '<logout xmlns="urn:partner.soap.sforce.com"/>', '</se:Body>', '</se:Envelope>'].join('');
              _context16.next = 3;
              return this._transport.httpRequest({
                method: 'POST',
                url: [this.instanceUrl, 'services/Soap/u', this.version].join('/'),
                body: body,
                headers: {
                  'Content-Type': 'text/xml',
                  SOAPAction: '""'
                }
              });
            case 3:
              response = _context16.sent;
              this._logger.debug(_concatInstanceProperty(_context15 = "SOAP statusCode = ".concat(response.statusCode, ", response = ")).call(_context15, response.body));
              if (!(response.statusCode >= 400)) {
                _context16.next = 9;
                break;
              }
              m = response.body.match(/<faultstring>([^<]+)<\/faultstring>/);
              faultstring = m && m[1];
              throw new Error(faultstring || response.body);
            case 9:
              // Destroy the session bound to this connection
              this._clearSession();
              this._resetInstance();
            case 11:
            case "end":
              return _context16.stop();
          }
        }, _callee8, this);
      }));
      function logoutBySoap(_x14) {
        return _logoutBySoap.apply(this, arguments);
      }
      return logoutBySoap;
    }()
    /**
     * Send REST API request with given HTTP request info, with connected session information.
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */
    )
  }, {
    key: "request",
    value: function request(_request) {
      var _this3 = this;
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      // if request is simple string, regard it as url in GET method
      var request_ = typeof _request === 'string' ? {
        method: 'GET',
        url: _request
      } : _request;
      // if url is given in relative path, prepend base url or instance url before.
      request_ = _objectSpread(_objectSpread({}, request_), {}, {
        url: this._normalizeUrl(request_.url)
      });
      var httpApi = new HttpApi(this, options);
      // log api usage and its quota
      httpApi.on('response', function (response) {
        if (response.headers && response.headers['sforce-limit-info']) {
          var apiUsage = response.headers['sforce-limit-info'].match(/api-usage=(\d+)\/(\d+)/);
          if (apiUsage) {
            _this3.limitInfo = {
              apiUsage: {
                used: _parseInt(apiUsage[1], 10),
                limit: _parseInt(apiUsage[2], 10)
              }
            };
          }
        }
      });
      return httpApi.request(request_);
    }
  }, {
    key: "httpApi",
    value: function httpApi(request, options) {
      var _options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      return new HttpApi(this, _options);
    }

    /**
     * Send HTTP GET request
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */
  }, {
    key: "requestGet",
    value: function requestGet(url, options) {
      var request = {
        method: 'GET',
        url: url
      };
      return this.request(request, options);
    }

    /**
     * Send HTTP POST request with JSON body, with connected session information
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */
  }, {
    key: "requestPost",
    value: function requestPost(url, body, options) {
      var request = {
        method: 'POST',
        url: url,
        body: _JSON$stringify(body),
        headers: {
          'content-type': 'application/json'
        }
      };
      return this.request(request, options);
    }

    /**
     * Send HTTP PUT request with JSON body, with connected session information
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */
  }, {
    key: "requestPut",
    value: function requestPut(url, body, options) {
      var request = {
        method: 'PUT',
        url: url,
        body: _JSON$stringify(body),
        headers: {
          'content-type': 'application/json'
        }
      };
      return this.request(request, options);
    }

    /**
     * Send HTTP PATCH request with JSON body
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */
  }, {
    key: "requestPatch",
    value: function requestPatch(url, body, options) {
      var request = {
        method: 'PATCH',
        url: url,
        body: _JSON$stringify(body),
        headers: {
          'content-type': 'application/json'
        }
      };
      return this.request(request, options);
    }

    /**
     * Send HTTP DELETE request
     *
     * Endpoint URL can be absolute URL ('https://na1.salesforce.com/services/data/v32.0/sobjects/Account/describe')
     * , relative path from root ('/services/data/v32.0/sobjects/Account/describe')
     * , or relative path from version root ('/sobjects/Account/describe').
     */
  }, {
    key: "requestDelete",
    value: function requestDelete(url, options) {
      var request = {
        method: 'DELETE',
        url: url
      };
      return this.request(request, options);
    }

    /** @private **/
  }, {
    key: "_baseUrl",
    value: function _baseUrl() {
      return [this.instanceUrl, 'services/data', "v".concat(this.version)].join('/');
    }

    /**
     * Convert path to absolute url
     * @private
     */
  }, {
    key: "_normalizeUrl",
    value: function _normalizeUrl(url) {
      if (_startsWithInstanceProperty(url).call(url, '/')) {
        if (_startsWithInstanceProperty(url).call(url, this.instanceUrl + '/services/')) {
          return url;
        }
        if (_startsWithInstanceProperty(url).call(url, '/services/')) {
          return this.instanceUrl + url;
        }
        return this._baseUrl() + url;
      }
      return url;
    }

    /**
     *
     */
  }, {
    key: "query",
    value: function query(soql, options) {
      return new Query(this, soql, options);
    }

    /**
     * Execute search by SOSL
     *
     * @param {String} sosl - SOSL string
     * @param {Callback.<Array.<RecordResult>>} [callback] - Callback function
     * @returns {Promise.<Array.<RecordResult>>}
     */
  }, {
    key: "search",
    value: function search(sosl) {
      var url = this._baseUrl() + '/search?q=' + encodeURIComponent(sosl);
      return this.request(url);
    }

    /**
     *
     */
  }, {
    key: "queryMore",
    value: function queryMore(locator, options) {
      return new Query(this, {
        locator: locator
      }, options);
    }

    /* */
  }, {
    key: "_ensureVersion",
    value: function _ensureVersion(majorVersion) {
      var versions = this.version.split('.');
      return _parseInt(versions[0], 10) >= majorVersion;
    }

    /* */
  }, {
    key: "_supports",
    value: function _supports(feature) {
      switch (feature) {
        case 'sobject-collection':
          // sobject collection is available only in API ver 42.0+
          return !this.tooling;
        //this._ensureVersion(42);
        default:
          return false;
      }
    }

    /**
     * Retrieve specified records
     */
  }, {
    key: "retrieve",
    value: function () {
      var _retrieve = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee9(type, ids) {
        var options,
          _args9 = arguments;
        return _regeneratorRuntime.wrap(function _callee9$(_context17) {
          while (1) switch (_context17.prev = _context17.next) {
            case 0:
              options = _args9.length > 2 && _args9[2] !== undefined ? _args9[2] : {};
              return _context17.abrupt("return", _Array$isArray(ids) ?
              // check the version whether SObject collection API is supported (42.0)
              this._ensureVersion(42) ? this._retrieveMany(type, ids, options) : this._retrieveParallel(type, ids, options) : this._retrieveSingle(type, ids, options));
            case 2:
            case "end":
              return _context17.stop();
          }
        }, _callee9, this);
      }));
      function retrieve(_x15, _x16) {
        return _retrieve.apply(this, arguments);
      }
      return retrieve;
    }() /** @private */
  }, {
    key: "_retrieveSingle",
    value: (function () {
      var _retrieveSingle2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee10(type, id, options) {
        var url, fields, headers;
        return _regeneratorRuntime.wrap(function _callee10$(_context18) {
          while (1) switch (_context18.prev = _context18.next) {
            case 0:
              if (id) {
                _context18.next = 2;
                break;
              }
              throw new Error('Invalid record ID. Specify valid record ID value');
            case 2:
              url = [this._baseUrl(), 'sobjects', type, id].join('/');
              fields = options.fields, headers = options.headers;
              if (fields) {
                url += "?fields=".concat(fields.join(','));
              }
              return _context18.abrupt("return", this.request({
                method: 'GET',
                url: url,
                headers: headers
              }));
            case 6:
            case "end":
              return _context18.stop();
          }
        }, _callee10, this);
      }));
      function _retrieveSingle(_x17, _x18, _x19) {
        return _retrieveSingle2.apply(this, arguments);
      }
      return _retrieveSingle;
    }() /** @private */)
  }, {
    key: "_retrieveParallel",
    value: (function () {
      var _retrieveParallel2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee11(type, ids, options) {
        var _this4 = this;
        return _regeneratorRuntime.wrap(function _callee11$(_context19) {
          while (1) switch (_context19.prev = _context19.next) {
            case 0:
              if (!(ids.length > this._maxRequest)) {
                _context19.next = 2;
                break;
              }
              throw new Error('Exceeded max limit of concurrent call');
            case 2:
              return _context19.abrupt("return", _Promise.all(_mapInstanceProperty(ids).call(ids, function (id) {
                return _this4._retrieveSingle(type, id, options).catch(function (err) {
                  if (options.allOrNone || err.errorCode !== 'NOT_FOUND') {
                    throw err;
                  }
                  return null;
                });
              })));
            case 3:
            case "end":
              return _context19.stop();
          }
        }, _callee11, this);
      }));
      function _retrieveParallel(_x20, _x21, _x22) {
        return _retrieveParallel2.apply(this, arguments);
      }
      return _retrieveParallel;
    }() /** @private */)
  }, {
    key: "_retrieveMany",
    value: (function () {
      var _retrieveMany2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee12(type, ids, options) {
        var _context20;
        var url, fields;
        return _regeneratorRuntime.wrap(function _callee12$(_context21) {
          while (1) switch (_context21.prev = _context21.next) {
            case 0:
              if (!(ids.length === 0)) {
                _context21.next = 2;
                break;
              }
              return _context21.abrupt("return", []);
            case 2:
              url = [this._baseUrl(), 'composite', 'sobjects', type].join('/');
              _context21.t0 = options.fields;
              if (_context21.t0) {
                _context21.next = 10;
                break;
              }
              _context21.t1 = _mapInstanceProperty;
              _context21.next = 8;
              return this.describe$(type);
            case 8:
              _context21.t2 = _context20 = _context21.sent.fields;
              _context21.t0 = (0, _context21.t1)(_context21.t2).call(_context20, function (field) {
                return field.name;
              });
            case 10:
              fields = _context21.t0;
              return _context21.abrupt("return", this.request({
                method: 'POST',
                url: url,
                body: _JSON$stringify({
                  ids: ids,
                  fields: fields
                }),
                headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                  'content-type': 'application/json'
                })
              }));
            case 12:
            case "end":
              return _context21.stop();
          }
        }, _callee12, this);
      }));
      function _retrieveMany(_x23, _x24, _x25) {
        return _retrieveMany2.apply(this, arguments);
      }
      return _retrieveMany;
    }()
    /**
     * Create records
     */
    )
  }, {
    key: "create",
    value: (
    /**
     * @param type
     * @param records
     * @param options
     */
    function () {
      var _create = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee13(type, records) {
        var options,
          ret,
          _args13 = arguments;
        return _regeneratorRuntime.wrap(function _callee13$(_context22) {
          while (1) switch (_context22.prev = _context22.next) {
            case 0:
              options = _args13.length > 2 && _args13[2] !== undefined ? _args13[2] : {};
              if (!_Array$isArray(records)) {
                _context22.next = 14;
                break;
              }
              if (!this._ensureVersion(42)) {
                _context22.next = 8;
                break;
              }
              _context22.next = 5;
              return this._createMany(type, records, options);
            case 5:
              _context22.t1 = _context22.sent;
              _context22.next = 11;
              break;
            case 8:
              _context22.next = 10;
              return this._createParallel(type, records, options);
            case 10:
              _context22.t1 = _context22.sent;
            case 11:
              _context22.t0 = _context22.t1;
              _context22.next = 17;
              break;
            case 14:
              _context22.next = 16;
              return this._createSingle(type, records, options);
            case 16:
              _context22.t0 = _context22.sent;
            case 17:
              ret = _context22.t0;
              return _context22.abrupt("return", ret);
            case 19:
            case "end":
              return _context22.stop();
          }
        }, _callee13, this);
      }));
      function create(_x26, _x27) {
        return _create.apply(this, arguments);
      }
      return create;
    }() /** @private */)
  }, {
    key: "_createSingle",
    value: (function () {
      var _createSingle2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee14(type, record, options) {
        var Id, rtype, attributes, rec, sobjectType, url, contentType, body, _context23, form;
        return _regeneratorRuntime.wrap(function _callee14$(_context24) {
          while (1) switch (_context24.prev = _context24.next) {
            case 0:
              Id = record.Id, rtype = record.type, attributes = record.attributes, rec = _objectWithoutProperties(record, _excluded);
              sobjectType = type || (attributes === null || attributes === void 0 ? void 0 : attributes.type) || rtype;
              if (sobjectType) {
                _context24.next = 4;
                break;
              }
              throw new Error('No SObject Type defined in record');
            case 4:
              url = [this._baseUrl(), 'sobjects', sobjectType].join('/');
              if (options !== null && options !== void 0 && options.multipartFileFields) {
                // Send the record as a multipart/form-data request. Useful for fields containing large binary blobs.
                form = new FormData(); // Extract the fields requested to be sent separately from the JSON
                _forEachInstanceProperty(_context23 = _Object$entries(options.multipartFileFields)).call(_context23, function (_ref3) {
                  var _ref4 = _slicedToArray(_ref3, 2),
                    fieldName = _ref4[0],
                    fileDetails = _ref4[1];
                  form.append(fieldName, Buffer.from(rec[fieldName], 'base64'), fileDetails);
                  delete rec[fieldName];
                });
                // Serialize the remaining fields as JSON
                form.append(type, _JSON$stringify(rec), {
                  contentType: 'application/json'
                });
                contentType = form.getHeaders()['content-type']; // This is necessary to ensure the 'boundary' is present
                body = form;
              } else {
                // Default behavior: send the request as JSON
                contentType = 'application/json';
                body = _JSON$stringify(rec);
              }
              return _context24.abrupt("return", this.request({
                method: 'POST',
                url: url,
                body: body,
                headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                  'content-type': contentType
                })
              }));
            case 7:
            case "end":
              return _context24.stop();
          }
        }, _callee14, this);
      }));
      function _createSingle(_x28, _x29, _x30) {
        return _createSingle2.apply(this, arguments);
      }
      return _createSingle;
    }() /** @private */)
  }, {
    key: "_createParallel",
    value: (function () {
      var _createParallel2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee15(type, records, options) {
        var _this5 = this;
        return _regeneratorRuntime.wrap(function _callee15$(_context25) {
          while (1) switch (_context25.prev = _context25.next) {
            case 0:
              if (!(records.length > this._maxRequest)) {
                _context25.next = 2;
                break;
              }
              throw new Error('Exceeded max limit of concurrent call');
            case 2:
              return _context25.abrupt("return", _Promise.all(_mapInstanceProperty(records).call(records, function (record) {
                return _this5._createSingle(type, record, options).catch(function (err) {
                  // be aware that allOrNone in parallel mode will not revert the other successful requests
                  // it only raises error when met at least one failed request.
                  if (options.allOrNone || !err.errorCode) {
                    throw err;
                  }
                  return toSaveResult(err);
                });
              })));
            case 3:
            case "end":
              return _context25.stop();
          }
        }, _callee15, this);
      }));
      function _createParallel(_x31, _x32, _x33) {
        return _createParallel2.apply(this, arguments);
      }
      return _createParallel;
    }() /** @private */)
  }, {
    key: "_createMany",
    value: (function () {
      var _createMany2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee16(type, records, options) {
        var _context26, _records, url;
        return _regeneratorRuntime.wrap(function _callee16$(_context27) {
          while (1) switch (_context27.prev = _context27.next) {
            case 0:
              if (!(records.length === 0)) {
                _context27.next = 2;
                break;
              }
              return _context27.abrupt("return", _Promise.resolve([]));
            case 2:
              if (!(records.length > MAX_DML_COUNT && options.allowRecursive)) {
                _context27.next = 16;
                break;
              }
              _context27.t0 = _concatInstanceProperty(_context26 = []);
              _context27.t1 = _context26;
              _context27.t2 = _toConsumableArray;
              _context27.next = 8;
              return this._createMany(type, _sliceInstanceProperty(records).call(records, 0, MAX_DML_COUNT), options);
            case 8:
              _context27.t3 = _context27.sent;
              _context27.t4 = (0, _context27.t2)(_context27.t3);
              _context27.t5 = _toConsumableArray;
              _context27.next = 13;
              return this._createMany(type, _sliceInstanceProperty(records).call(records, MAX_DML_COUNT), options);
            case 13:
              _context27.t6 = _context27.sent;
              _context27.t7 = (0, _context27.t5)(_context27.t6);
              return _context27.abrupt("return", _context27.t0.call.call(_context27.t0, _context27.t1, _context27.t4, _context27.t7));
            case 16:
              _records = _mapInstanceProperty(records).call(records, function (record) {
                var Id = record.Id,
                  rtype = record.type,
                  attributes = record.attributes,
                  rec = _objectWithoutProperties(record, _excluded2);
                var sobjectType = type || (attributes === null || attributes === void 0 ? void 0 : attributes.type) || rtype;
                if (!sobjectType) {
                  throw new Error('No SObject Type defined in record');
                }
                return _objectSpread({
                  attributes: {
                    type: sobjectType
                  }
                }, rec);
              });
              url = [this._baseUrl(), 'composite', 'sobjects'].join('/');
              return _context27.abrupt("return", this.request({
                method: 'POST',
                url: url,
                body: _JSON$stringify({
                  allOrNone: options.allOrNone || false,
                  records: _records
                }),
                headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                  'content-type': 'application/json'
                })
              }));
            case 19:
            case "end":
              return _context27.stop();
          }
        }, _callee16, this);
      }));
      function _createMany(_x34, _x35, _x36) {
        return _createMany2.apply(this, arguments);
      }
      return _createMany;
    }())
  }, {
    key: "update",
    value:
    /**
     * @param type
     * @param records
     * @param options
     */
    function update(type, records) {
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return _Array$isArray(records) ?
      // check the version whether SObject collection API is supported (42.0)
      this._ensureVersion(42) ? this._updateMany(type, records, options) : this._updateParallel(type, records, options) : this._updateSingle(type, records, options);
    }

    /** @private */
  }, {
    key: "_updateSingle",
    value: (function () {
      var _updateSingle2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee17(type, record, options) {
        var id, rtype, attributes, rec, sobjectType, url;
        return _regeneratorRuntime.wrap(function _callee17$(_context28) {
          while (1) switch (_context28.prev = _context28.next) {
            case 0:
              id = record.Id, rtype = record.type, attributes = record.attributes, rec = _objectWithoutProperties(record, _excluded3);
              if (id) {
                _context28.next = 3;
                break;
              }
              throw new Error('Record id is not found in record.');
            case 3:
              sobjectType = type || (attributes === null || attributes === void 0 ? void 0 : attributes.type) || rtype;
              if (sobjectType) {
                _context28.next = 6;
                break;
              }
              throw new Error('No SObject Type defined in record');
            case 6:
              url = [this._baseUrl(), 'sobjects', sobjectType, id].join('/');
              return _context28.abrupt("return", this.request({
                method: 'PATCH',
                url: url,
                body: _JSON$stringify(rec),
                headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                  'content-type': 'application/json'
                })
              }, {
                noContentResponse: {
                  id: id,
                  success: true,
                  errors: []
                }
              }));
            case 8:
            case "end":
              return _context28.stop();
          }
        }, _callee17, this);
      }));
      function _updateSingle(_x37, _x38, _x39) {
        return _updateSingle2.apply(this, arguments);
      }
      return _updateSingle;
    }() /** @private */)
  }, {
    key: "_updateParallel",
    value: (function () {
      var _updateParallel2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee18(type, records, options) {
        var _this6 = this;
        return _regeneratorRuntime.wrap(function _callee18$(_context29) {
          while (1) switch (_context29.prev = _context29.next) {
            case 0:
              if (!(records.length > this._maxRequest)) {
                _context29.next = 2;
                break;
              }
              throw new Error('Exceeded max limit of concurrent call');
            case 2:
              return _context29.abrupt("return", _Promise.all(_mapInstanceProperty(records).call(records, function (record) {
                return _this6._updateSingle(type, record, options).catch(function (err) {
                  // be aware that allOrNone in parallel mode will not revert the other successful requests
                  // it only raises error when met at least one failed request.
                  if (options.allOrNone || !err.errorCode) {
                    throw err;
                  }
                  return toSaveResult(err);
                });
              })));
            case 3:
            case "end":
              return _context29.stop();
          }
        }, _callee18, this);
      }));
      function _updateParallel(_x40, _x41, _x42) {
        return _updateParallel2.apply(this, arguments);
      }
      return _updateParallel;
    }() /** @private */)
  }, {
    key: "_updateMany",
    value: (function () {
      var _updateMany2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee19(type, records, options) {
        var _context30, _records, url;
        return _regeneratorRuntime.wrap(function _callee19$(_context31) {
          while (1) switch (_context31.prev = _context31.next) {
            case 0:
              if (!(records.length === 0)) {
                _context31.next = 2;
                break;
              }
              return _context31.abrupt("return", []);
            case 2:
              if (!(records.length > MAX_DML_COUNT && options.allowRecursive)) {
                _context31.next = 16;
                break;
              }
              _context31.t0 = _concatInstanceProperty(_context30 = []);
              _context31.t1 = _context30;
              _context31.t2 = _toConsumableArray;
              _context31.next = 8;
              return this._updateMany(type, _sliceInstanceProperty(records).call(records, 0, MAX_DML_COUNT), options);
            case 8:
              _context31.t3 = _context31.sent;
              _context31.t4 = (0, _context31.t2)(_context31.t3);
              _context31.t5 = _toConsumableArray;
              _context31.next = 13;
              return this._updateMany(type, _sliceInstanceProperty(records).call(records, MAX_DML_COUNT), options);
            case 13:
              _context31.t6 = _context31.sent;
              _context31.t7 = (0, _context31.t5)(_context31.t6);
              return _context31.abrupt("return", _context31.t0.call.call(_context31.t0, _context31.t1, _context31.t4, _context31.t7));
            case 16:
              _records = _mapInstanceProperty(records).call(records, function (record) {
                var id = record.Id,
                  rtype = record.type,
                  attributes = record.attributes,
                  rec = _objectWithoutProperties(record, _excluded4);
                if (!id) {
                  throw new Error('Record id is not found in record.');
                }
                var sobjectType = type || (attributes === null || attributes === void 0 ? void 0 : attributes.type) || rtype;
                if (!sobjectType) {
                  throw new Error('No SObject Type defined in record');
                }
                return _objectSpread({
                  id: id,
                  attributes: {
                    type: sobjectType
                  }
                }, rec);
              });
              url = [this._baseUrl(), 'composite', 'sobjects'].join('/');
              return _context31.abrupt("return", this.request({
                method: 'PATCH',
                url: url,
                body: _JSON$stringify({
                  allOrNone: options.allOrNone || false,
                  records: _records
                }),
                headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                  'content-type': 'application/json'
                })
              }));
            case 19:
            case "end":
              return _context31.stop();
          }
        }, _callee19, this);
      }));
      function _updateMany(_x43, _x44, _x45) {
        return _updateMany2.apply(this, arguments);
      }
      return _updateMany;
    }()
    /**
     * Upsert records
     */
    )
  }, {
    key: "upsert",
    value: (
    /**
     *
     * @param type
     * @param records
     * @param extIdField
     * @param options
     */
    function () {
      var _upsert = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee20(type, records, extIdField) {
        var options,
          _args20 = arguments;
        return _regeneratorRuntime.wrap(function _callee20$(_context32) {
          while (1) switch (_context32.prev = _context32.next) {
            case 0:
              options = _args20.length > 3 && _args20[3] !== undefined ? _args20[3] : {};
              return _context32.abrupt("return", _Array$isArray(records) ?
              // check the version whether SObject collection API is supported (46.0)
              this._ensureVersion(46) ? this._upsertMany(type, records, extIdField, options) : this._upsertParallel(type, records, extIdField, options) : this._upsertParallel(type, records, extIdField, options));
            case 2:
            case "end":
              return _context32.stop();
          }
        }, _callee20, this);
      }));
      function upsert(_x46, _x47, _x48) {
        return _upsert.apply(this, arguments);
      }
      return upsert;
    }() /** @private */)
  }, {
    key: "_upsertMany",
    value: (function () {
      var _upsertMany2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee21(type, records, extIdField) {
        var options,
          _context33,
          _records,
          url,
          _args21 = arguments;
        return _regeneratorRuntime.wrap(function _callee21$(_context35) {
          while (1) switch (_context35.prev = _context35.next) {
            case 0:
              options = _args21.length > 3 && _args21[3] !== undefined ? _args21[3] : {};
              if (!(records.length === 0)) {
                _context35.next = 3;
                break;
              }
              return _context35.abrupt("return", []);
            case 3:
              if (!(records.length > MAX_DML_COUNT && options.allowRecursive)) {
                _context35.next = 17;
                break;
              }
              _context35.t0 = _concatInstanceProperty(_context33 = []);
              _context35.t1 = _context33;
              _context35.t2 = _toConsumableArray;
              _context35.next = 9;
              return this._upsertMany(type, _sliceInstanceProperty(records).call(records, 0, MAX_DML_COUNT), extIdField, options);
            case 9:
              _context35.t3 = _context35.sent;
              _context35.t4 = (0, _context35.t2)(_context35.t3);
              _context35.t5 = _toConsumableArray;
              _context35.next = 14;
              return this._upsertMany(type, _sliceInstanceProperty(records).call(records, MAX_DML_COUNT), extIdField, options);
            case 14:
              _context35.t6 = _context35.sent;
              _context35.t7 = (0, _context35.t5)(_context35.t6);
              return _context35.abrupt("return", _context35.t0.call.call(_context35.t0, _context35.t1, _context35.t4, _context35.t7));
            case 17:
              _records = _mapInstanceProperty(records).call(records, function (recordItem) {
                var _context34;
                var extId = recordItem[extIdField],
                  recordType = recordItem.type,
                  attributes = recordItem.attributes,
                  rec = _objectWithoutProperties(recordItem, _mapInstanceProperty(_context34 = [extIdField, "type", "attributes"]).call(_context34, _toPropertyKey));
                var sobjectType = recordType || (attributes === null || attributes === void 0 ? void 0 : attributes.type) || type;
                if (!extId) {
                  throw new Error('External ID is not found in record.');
                }
                if (!sobjectType) {
                  throw new Error('No SObject Type defined in record');
                }
                return _objectSpread(_defineProperty(_defineProperty({}, extIdField, extId), "attributes", {
                  type: sobjectType
                }), rec);
              });
              url = [this._baseUrl(), 'composite', 'sobjects', type, extIdField].join('/');
              return _context35.abrupt("return", this.request({
                method: 'PATCH',
                url: url,
                body: _JSON$stringify({
                  allOrNone: options.allOrNone || false,
                  records: _records
                }),
                headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                  'content-type': 'application/json'
                })
              }));
            case 20:
            case "end":
              return _context35.stop();
          }
        }, _callee21, this);
      }));
      function _upsertMany(_x49, _x50, _x51) {
        return _upsertMany2.apply(this, arguments);
      }
      return _upsertMany;
    }() /** @private */)
  }, {
    key: "_upsertParallel",
    value: (function () {
      var _upsertParallel2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee22(type, records, extIdField) {
        var _this7 = this;
        var options,
          isArray,
          _records,
          results,
          _args22 = arguments;
        return _regeneratorRuntime.wrap(function _callee22$(_context37) {
          while (1) switch (_context37.prev = _context37.next) {
            case 0:
              options = _args22.length > 3 && _args22[3] !== undefined ? _args22[3] : {};
              isArray = _Array$isArray(records);
              _records = _Array$isArray(records) ? records : [records];
              if (!(_records.length > this._maxRequest)) {
                _context37.next = 5;
                break;
              }
              throw new Error('Exceeded max limit of concurrent call');
            case 5:
              _context37.next = 7;
              return _Promise.all(_mapInstanceProperty(_records).call(_records, function (record) {
                var _context36;
                var extId = record[extIdField],
                  rtype = record.type,
                  attributes = record.attributes,
                  rec = _objectWithoutProperties(record, _mapInstanceProperty(_context36 = [extIdField, "type", "attributes"]).call(_context36, _toPropertyKey));
                var url = [_this7._baseUrl(), 'sobjects', type, extIdField, extId].join('/');
                return _this7.request({
                  method: 'PATCH',
                  url: url,
                  body: _JSON$stringify(rec),
                  headers: _objectSpread(_objectSpread({}, options.headers || {}), {}, {
                    'content-type': 'application/json'
                  })
                }, {
                  noContentResponse: {
                    success: true,
                    errors: []
                  }
                }).catch(function (err) {
                  // Be aware that `allOrNone` option in upsert method
                  // will not revert the other successful requests.
                  // It only raises error when met at least one failed request.
                  if (!isArray || options.allOrNone || !err.errorCode) {
                    throw err;
                  }
                  return toSaveResult(err);
                });
              }));
            case 7:
              results = _context37.sent;
              return _context37.abrupt("return", isArray ? results : results[0]);
            case 9:
            case "end":
              return _context37.stop();
          }
        }, _callee22, this);
      }));
      function _upsertParallel(_x52, _x53, _x54) {
        return _upsertParallel2.apply(this, arguments);
      }
      return _upsertParallel;
    }()
    /**
     * Delete records
     */
    )
  }, {
    key: "destroy",
    value: (
    /**
     * @param type
     * @param ids
     * @param options
     */
    function () {
      var _destroy = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee23(type, ids) {
        var options,
          _args23 = arguments;
        return _regeneratorRuntime.wrap(function _callee23$(_context38) {
          while (1) switch (_context38.prev = _context38.next) {
            case 0:
              options = _args23.length > 2 && _args23[2] !== undefined ? _args23[2] : {};
              return _context38.abrupt("return", _Array$isArray(ids) ?
              // check the version whether SObject collection API is supported (42.0)
              this._ensureVersion(42) ? this._destroyMany(type, ids, options) : this._destroyParallel(type, ids, options) : this._destroySingle(type, ids, options));
            case 2:
            case "end":
              return _context38.stop();
          }
        }, _callee23, this);
      }));
      function destroy(_x55, _x56) {
        return _destroy.apply(this, arguments);
      }
      return destroy;
    }() /** @private */)
  }, {
    key: "_destroySingle",
    value: (function () {
      var _destroySingle2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee24(type, id, options) {
        var url;
        return _regeneratorRuntime.wrap(function _callee24$(_context39) {
          while (1) switch (_context39.prev = _context39.next) {
            case 0:
              url = [this._baseUrl(), 'sobjects', type, id].join('/');
              return _context39.abrupt("return", this.request({
                method: 'DELETE',
                url: url,
                headers: options.headers || {}
              }, {
                noContentResponse: {
                  id: id,
                  success: true,
                  errors: []
                }
              }));
            case 2:
            case "end":
              return _context39.stop();
          }
        }, _callee24, this);
      }));
      function _destroySingle(_x57, _x58, _x59) {
        return _destroySingle2.apply(this, arguments);
      }
      return _destroySingle;
    }() /** @private */)
  }, {
    key: "_destroyParallel",
    value: (function () {
      var _destroyParallel2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee25(type, ids, options) {
        var _this8 = this;
        return _regeneratorRuntime.wrap(function _callee25$(_context40) {
          while (1) switch (_context40.prev = _context40.next) {
            case 0:
              if (!(ids.length > this._maxRequest)) {
                _context40.next = 2;
                break;
              }
              throw new Error('Exceeded max limit of concurrent call');
            case 2:
              return _context40.abrupt("return", _Promise.all(_mapInstanceProperty(ids).call(ids, function (id) {
                return _this8._destroySingle(type, id, options).catch(function (err) {
                  // Be aware that `allOrNone` option in parallel mode
                  // will not revert the other successful requests.
                  // It only raises error when met at least one failed request.
                  if (options.allOrNone || !err.errorCode) {
                    throw err;
                  }
                  return toSaveResult(err);
                });
              })));
            case 3:
            case "end":
              return _context40.stop();
          }
        }, _callee25, this);
      }));
      function _destroyParallel(_x60, _x61, _x62) {
        return _destroyParallel2.apply(this, arguments);
      }
      return _destroyParallel;
    }() /** @private */)
  }, {
    key: "_destroyMany",
    value: (function () {
      var _destroyMany2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee26(type, ids, options) {
        var _context41, url;
        return _regeneratorRuntime.wrap(function _callee26$(_context42) {
          while (1) switch (_context42.prev = _context42.next) {
            case 0:
              if (!(ids.length === 0)) {
                _context42.next = 2;
                break;
              }
              return _context42.abrupt("return", []);
            case 2:
              if (!(ids.length > MAX_DML_COUNT && options.allowRecursive)) {
                _context42.next = 16;
                break;
              }
              _context42.t0 = _concatInstanceProperty(_context41 = []);
              _context42.t1 = _context41;
              _context42.t2 = _toConsumableArray;
              _context42.next = 8;
              return this._destroyMany(type, _sliceInstanceProperty(ids).call(ids, 0, MAX_DML_COUNT), options);
            case 8:
              _context42.t3 = _context42.sent;
              _context42.t4 = (0, _context42.t2)(_context42.t3);
              _context42.t5 = _toConsumableArray;
              _context42.next = 13;
              return this._destroyMany(type, _sliceInstanceProperty(ids).call(ids, MAX_DML_COUNT), options);
            case 13:
              _context42.t6 = _context42.sent;
              _context42.t7 = (0, _context42.t5)(_context42.t6);
              return _context42.abrupt("return", _context42.t0.call.call(_context42.t0, _context42.t1, _context42.t4, _context42.t7));
            case 16:
              url = [this._baseUrl(), 'composite', 'sobjects?ids='].join('/') + ids.join(',');
              if (options.allOrNone) {
                url += '&allOrNone=true';
              }
              return _context42.abrupt("return", this.request({
                method: 'DELETE',
                url: url,
                headers: options.headers || {}
              }));
            case 19:
            case "end":
              return _context42.stop();
          }
        }, _callee26, this);
      }));
      function _destroyMany(_x63, _x64, _x65) {
        return _destroyMany2.apply(this, arguments);
      }
      return _destroyMany;
    }())
  }, {
    key: "describe",
    value: (
    /**
     * Describe SObject metadata
     */
    function () {
      var _describe = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee27(type) {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee27$(_context43) {
          while (1) switch (_context43.prev = _context43.next) {
            case 0:
              url = [this._baseUrl(), 'sobjects', type, 'describe'].join('/');
              _context43.next = 3;
              return this.request(url);
            case 3:
              body = _context43.sent;
              return _context43.abrupt("return", body);
            case 5:
            case "end":
              return _context43.stop();
          }
        }, _callee27, this);
      }));
      function describe(_x66) {
        return _describe.apply(this, arguments);
      }
      return describe;
    }()
    /**
     * Describe global SObjects
     */
    )
  }, {
    key: "describeGlobal",
    value: (function () {
      var _describeGlobal = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee28() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee28$(_context44) {
          while (1) switch (_context44.prev = _context44.next) {
            case 0:
              url = "".concat(this._baseUrl(), "/sobjects");
              _context44.next = 3;
              return this.request(url);
            case 3:
              body = _context44.sent;
              return _context44.abrupt("return", body);
            case 5:
            case "end":
              return _context44.stop();
          }
        }, _callee28, this);
      }));
      function describeGlobal() {
        return _describeGlobal.apply(this, arguments);
      }
      return describeGlobal;
    }()
    /**
     * Get SObject instance
     */
    )
  }, {
    key: "sobject",
    value: function sobject(type) {
      var so = this.sobjects[type] || new SObject(this, type);
      this.sobjects[type] = so;
      return so;
    }

    /**
     * Get identity information of current user
     */
  }, {
    key: "identity",
    value: (function () {
      var _identity = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee29() {
        var _this$userInfo;
        var options,
          url,
          _res,
          res,
          _args29 = arguments;
        return _regeneratorRuntime.wrap(function _callee29$(_context45) {
          while (1) switch (_context45.prev = _context45.next) {
            case 0:
              options = _args29.length > 0 && _args29[0] !== undefined ? _args29[0] : {};
              url = (_this$userInfo = this.userInfo) === null || _this$userInfo === void 0 ? void 0 : _this$userInfo.url;
              if (url) {
                _context45.next = 7;
                break;
              }
              _context45.next = 5;
              return this.request({
                method: 'GET',
                url: this._baseUrl(),
                headers: options.headers
              });
            case 5:
              _res = _context45.sent;
              url = _res.identity;
            case 7:
              url += '?format=json';
              if (this.accessToken) {
                url += "&oauth_token=".concat(encodeURIComponent(this.accessToken));
              }
              _context45.next = 11;
              return this.request({
                method: 'GET',
                url: url
              });
            case 11:
              res = _context45.sent;
              this.userInfo = {
                id: res.user_id,
                organizationId: res.organization_id,
                url: res.id
              };
              return _context45.abrupt("return", res);
            case 14:
            case "end":
              return _context45.stop();
          }
        }, _callee29, this);
      }));
      function identity() {
        return _identity.apply(this, arguments);
      }
      return identity;
    }()
    /**
     * List recently viewed records
     */
    )
  }, {
    key: "recent",
    value: (function () {
      var _recent = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee30(type, limit) {
        var url, _yield$this$request, recentItems;
        return _regeneratorRuntime.wrap(function _callee30$(_context46) {
          while (1) switch (_context46.prev = _context46.next) {
            case 0:
              /* eslint-disable no-param-reassign */
              if (typeof type === 'number') {
                limit = type;
                type = undefined;
              }
              if (!type) {
                _context46.next = 8;
                break;
              }
              url = [this._baseUrl(), 'sobjects', type].join('/');
              _context46.next = 5;
              return this.request(url);
            case 5:
              _yield$this$request = _context46.sent;
              recentItems = _yield$this$request.recentItems;
              return _context46.abrupt("return", limit ? _sliceInstanceProperty(recentItems).call(recentItems, 0, limit) : recentItems);
            case 8:
              url = "".concat(this._baseUrl(), "/recent");
              if (limit) {
                url += "?limit=".concat(limit);
              }
              return _context46.abrupt("return", this.request(url));
            case 11:
            case "end":
              return _context46.stop();
          }
        }, _callee30, this);
      }));
      function recent(_x67, _x68) {
        return _recent.apply(this, arguments);
      }
      return recent;
    }()
    /**
     * Retrieve updated records
     */
    )
  }, {
    key: "updated",
    value: (function () {
      var _updated = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee31(type, start, end) {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee31$(_context47) {
          while (1) switch (_context47.prev = _context47.next) {
            case 0:
              /* eslint-disable no-param-reassign */
              url = [this._baseUrl(), 'sobjects', type, 'updated'].join('/');
              if (typeof start === 'string') {
                start = new Date(start);
              }
              start = formatDate(start);
              url += "?start=".concat(encodeURIComponent(start));
              if (typeof end === 'string') {
                end = new Date(end);
              }
              end = formatDate(end);
              url += "&end=".concat(encodeURIComponent(end));
              _context47.next = 9;
              return this.request(url);
            case 9:
              body = _context47.sent;
              return _context47.abrupt("return", body);
            case 11:
            case "end":
              return _context47.stop();
          }
        }, _callee31, this);
      }));
      function updated(_x69, _x70, _x71) {
        return _updated.apply(this, arguments);
      }
      return updated;
    }()
    /**
     * Retrieve deleted records
     */
    )
  }, {
    key: "deleted",
    value: (function () {
      var _deleted = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee32(type, start, end) {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee32$(_context48) {
          while (1) switch (_context48.prev = _context48.next) {
            case 0:
              /* eslint-disable no-param-reassign */
              url = [this._baseUrl(), 'sobjects', type, 'deleted'].join('/');
              if (typeof start === 'string') {
                start = new Date(start);
              }
              start = formatDate(start);
              url += "?start=".concat(encodeURIComponent(start));
              if (typeof end === 'string') {
                end = new Date(end);
              }
              end = formatDate(end);
              url += "&end=".concat(encodeURIComponent(end));
              _context48.next = 9;
              return this.request(url);
            case 9:
              body = _context48.sent;
              return _context48.abrupt("return", body);
            case 11:
            case "end":
              return _context48.stop();
          }
        }, _callee32, this);
      }));
      function deleted(_x72, _x73, _x74) {
        return _deleted.apply(this, arguments);
      }
      return deleted;
    }()
    /**
     * Returns a list of all tabs
     */
    )
  }, {
    key: "tabs",
    value: (function () {
      var _tabs = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee33() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee33$(_context49) {
          while (1) switch (_context49.prev = _context49.next) {
            case 0:
              url = [this._baseUrl(), 'tabs'].join('/');
              _context49.next = 3;
              return this.request(url);
            case 3:
              body = _context49.sent;
              return _context49.abrupt("return", body);
            case 5:
            case "end":
              return _context49.stop();
          }
        }, _callee33, this);
      }));
      function tabs() {
        return _tabs.apply(this, arguments);
      }
      return tabs;
    }()
    /**
     * Returns current system limit in the organization
     */
    )
  }, {
    key: "limits",
    value: (function () {
      var _limits = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee34() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee34$(_context50) {
          while (1) switch (_context50.prev = _context50.next) {
            case 0:
              url = [this._baseUrl(), 'limits'].join('/');
              _context50.next = 3;
              return this.request(url);
            case 3:
              body = _context50.sent;
              return _context50.abrupt("return", body);
            case 5:
            case "end":
              return _context50.stop();
          }
        }, _callee34, this);
      }));
      function limits() {
        return _limits.apply(this, arguments);
      }
      return limits;
    }()
    /**
     * Returns a theme info
     */
    )
  }, {
    key: "theme",
    value: (function () {
      var _theme = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee35() {
        var url, body;
        return _regeneratorRuntime.wrap(function _callee35$(_context51) {
          while (1) switch (_context51.prev = _context51.next) {
            case 0:
              url = [this._baseUrl(), 'theme'].join('/');
              _context51.next = 3;
              return this.request(url);
            case 3:
              body = _context51.sent;
              return _context51.abrupt("return", body);
            case 5:
            case "end":
              return _context51.stop();
          }
        }, _callee35, this);
      }));
      function theme() {
        return _theme.apply(this, arguments);
      }
      return theme;
    }()
    /**
     * Returns all registered global quick actions
     */
    )
  }, {
    key: "quickActions",
    value: (function () {
      var _quickActions = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee36() {
        var body;
        return _regeneratorRuntime.wrap(function _callee36$(_context52) {
          while (1) switch (_context52.prev = _context52.next) {
            case 0:
              _context52.next = 2;
              return this.request('/quickActions');
            case 2:
              body = _context52.sent;
              return _context52.abrupt("return", body);
            case 4:
            case "end":
              return _context52.stop();
          }
        }, _callee36, this);
      }));
      function quickActions() {
        return _quickActions.apply(this, arguments);
      }
      return quickActions;
    }()
    /**
     * Get reference for specified global quick action
     */
    )
  }, {
    key: "quickAction",
    value: function quickAction(actionName) {
      return new QuickAction(this, "/quickActions/".concat(actionName));
    }
  }, {
    key: "isLightningInstance",
    value: function isLightningInstance() {
      var _context53, _context54, _context55;
      return _includesInstanceProperty(_context53 = this.instanceUrl).call(_context53, '.lightning.force.com') || _includesInstanceProperty(_context54 = this.instanceUrl).call(_context54, '.lightning.crmforce.mil') || _includesInstanceProperty(_context55 = this.instanceUrl).call(_context55, '.lightning.sfcrmapps.cn');
    }
  }]);
}(EventEmitter);
_defineProperty(Connection, "_logger", getLogger('connection'));
export default Connection;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJqc2ZvcmNlIiwiVHJhbnNwb3J0IiwiQ2FudmFzVHJhbnNwb3J0IiwiWGRQcm94eVRyYW5zcG9ydCIsIkh0dHBQcm94eVRyYW5zcG9ydCIsImdldExvZ2dlciIsIk9BdXRoMiIsIkNhY2hlIiwiSHR0cEFwaSIsIlNlc3Npb25SZWZyZXNoRGVsZWdhdGUiLCJRdWVyeSIsIlNPYmplY3QiLCJRdWlja0FjdGlvbiIsIlByb2Nlc3MiLCJmb3JtYXREYXRlIiwiRm9ybURhdGEiLCJkZWZhdWx0Q29ubmVjdGlvbkNvbmZpZyIsImxvZ2luVXJsIiwiaW5zdGFuY2VVcmwiLCJ2ZXJzaW9uIiwibG9nTGV2ZWwiLCJtYXhSZXF1ZXN0IiwiZXNjIiwic3RyIiwiU3RyaW5nIiwicmVwbGFjZSIsInBhcnNlU2lnbmVkUmVxdWVzdCIsInNyIiwiX3N0YXJ0c1dpdGhJbnN0YW5jZVByb3BlcnR5IiwiY2FsbCIsIkpTT04iLCJwYXJzZSIsIm1zZyIsInNwbGl0IiwicG9wIiwiRXJyb3IiLCJqc29uIiwiQnVmZmVyIiwiZnJvbSIsInRvU3RyaW5nIiwicGFyc2VJZFVybCIsInVybCIsIl9jb250ZXh0IiwiX3VybCRzcGxpdCRzbGljZSIsIl9zbGljZUluc3RhbmNlUHJvcGVydHkiLCJfdXJsJHNwbGl0JHNsaWNlMiIsIl9zbGljZWRUb0FycmF5Iiwib3JnYW5pemF0aW9uSWQiLCJpZCIsImRlZmF1bHRSZWZyZXNoRm4iLCJjb25uIiwiY2FsbGJhY2siLCJ1bmRlZmluZWQiLCJvYXV0aFJlZnJlc2hGbiIsIl94IiwiX3gyIiwiX29hdXRoUmVmcmVzaEZuIiwiYXBwbHkiLCJhcmd1bWVudHMiLCJfYXN5bmNUb0dlbmVyYXRvciIsIl9yZWdlbmVyYXRvclJ1bnRpbWUiLCJtYXJrIiwiX2NhbGxlZTM3IiwicmVzIiwidXNlckluZm8iLCJ3cmFwIiwiX2NhbGxlZTM3JCIsIl9jb250ZXh0NTYiLCJwcmV2IiwibmV4dCIsInJlZnJlc2hUb2tlbiIsIm9hdXRoMiIsInNlbnQiLCJfZXN0YWJsaXNoIiwiaW5zdGFuY2VfdXJsIiwiYWNjZXNzVG9rZW4iLCJhY2Nlc3NfdG9rZW4iLCJ0MCIsInN0b3AiLCJjcmVhdGVVc2VybmFtZVBhc3N3b3JkUmVmcmVzaEZuIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsIl9yZWYiLCJfY2FsbGVlIiwiX2NhbGxlZSQiLCJfY29udGV4dDIiLCJsb2dpbiIsIl94MyIsIl94NCIsInRvU2F2ZVJlc3VsdCIsImVyciIsInN1Y2Nlc3MiLCJlcnJvcnMiLCJyYWlzZU5vTW9kdWxlRXJyb3IiLCJuYW1lIiwiX2NvbnRleHQzIiwiX2NvbmNhdEluc3RhbmNlUHJvcGVydHkiLCJjb25jYXQiLCJNQVhfRE1MX0NPVU5UIiwiQ29ubmVjdGlvbiIsIl9FdmVudEVtaXR0ZXIiLCJfdGhpcyIsImNvbmZpZyIsImxlbmd0aCIsIl9jbGFzc0NhbGxDaGVjayIsIl9jYWxsU3VwZXIiLCJfZGVmaW5lUHJvcGVydHkiLCJjcmVhdGUiLCJkZXN0cm95IiwicHJveHlVcmwiLCJodHRwUHJveHkiLCJpc0xpZ2h0bmluZ0luc3RhbmNlIiwiX29iamVjdFNwcmVhZCIsInJlZnJlc2hGbiIsImNsaWVudElkIiwiX3JlZnJlc2hEZWxlZ2F0ZSIsIl9tYXhSZXF1ZXN0IiwiX2xvZ2dlciIsImNyZWF0ZUluc3RhbmNlIiwiX2xvZ0xldmVsIiwiX3RyYW5zcG9ydCIsIl9jYWxsT3B0aW9ucyIsImNhbGxPcHRpb25zIiwiY2FjaGUiLCJkZXNjcmliZUNhY2hlS2V5IiwidHlwZSIsImRlc2NyaWJlIiwicHJvdG90eXBlIiwiY3JlYXRlQ2FjaGVkRnVuY3Rpb24iLCJrZXkiLCJzdHJhdGVneSIsImRlc2NyaWJlJCIsImRlc2NyaWJlJCQiLCJkZXNjcmliZVNPYmplY3QiLCJkZXNjcmliZVNPYmplY3QkIiwiZGVzY3JpYmVTT2JqZWN0JCQiLCJkZXNjcmliZUdsb2JhbCIsImRlc2NyaWJlR2xvYmFsJCIsImRlc2NyaWJlR2xvYmFsJCQiLCJzZXNzaW9uSWQiLCJzZXJ2ZXJVcmwiLCJzaWduZWRSZXF1ZXN0IiwiZW1pdCIsIl9pbmhlcml0cyIsIl9jcmVhdGVDbGFzcyIsImdldCIsInZhbHVlIiwib3B0aW9ucyIsIl9jb250ZXh0NCIsImpvaW4iLCJzaWduZWRSZXF1ZXN0T2JqZWN0IiwiY2xpZW50Iiwib2F1dGhUb2tlbiIsInN1cHBvcnRlZCIsIl9zZXNzaW9uVHlwZSIsIl9yZXNldEluc3RhbmNlIiwiX2NsZWFyU2Vzc2lvbiIsIl90aGlzMiIsImxpbWl0SW5mbyIsInNvYmplY3RzIiwiY2xlYXIiLCJyZW1vdmVBbGxMaXN0ZW5lcnMiLCJvbiIsIl9yZWYyIiwicmVzdWx0IiwiX2l0ZXJhdG9yIiwiX2NyZWF0ZUZvck9mSXRlcmF0b3JIZWxwZXIiLCJfc3RlcCIsInMiLCJuIiwiZG9uZSIsInNvIiwic29iamVjdCIsImUiLCJmIiwiX2F1dGhvcml6ZSIsIl9jYWxsZWUyIiwiY29kZU9yUGFyYW1zIiwiX2NvbnRleHQ1IiwicGFyYW1zIiwiX2FyZ3MyIiwiX2NhbGxlZTIkIiwiX2NvbnRleHQ2IiwicmVxdWVzdFRva2VuIiwicmVmcmVzaF90b2tlbiIsImRlYnVnIiwiYWJydXB0IiwiYXV0aG9yaXplIiwiX3g1IiwiX2xvZ2luIiwiX2NhbGxlZTMiLCJfdGhpcyRvYXV0aCIsIl9jYWxsZWUzJCIsIl9jb250ZXh0NyIsImNsaWVudFNlY3JldCIsImxvZ2luQnlPQXV0aDIiLCJsb2dpbkJ5U29hcCIsIl94NiIsIl94NyIsIl9sb2dpbkJ5T0F1dGgiLCJfY2FsbGVlNCIsIl9jb250ZXh0OCIsIl9jYWxsZWU0JCIsIl9jb250ZXh0OSIsImF1dGhlbnRpY2F0ZSIsImluZm8iLCJfeDgiLCJfeDkiLCJfbG9naW5CeVNvYXAiLCJfY2FsbGVlNSIsIl9jb250ZXh0MTAiLCJfY29udGV4dDExIiwiYm9keSIsInNvYXBMb2dpbkVuZHBvaW50IiwicmVzcG9uc2UiLCJtIiwiZmF1bHRzdHJpbmciLCJ1c2VySWQiLCJpZFVybCIsIl9jYWxsZWU1JCIsIl9jb250ZXh0MTIiLCJ3YXJuIiwiX1Byb21pc2UiLCJyZWplY3QiLCJodHRwUmVxdWVzdCIsIm1ldGhvZCIsImhlYWRlcnMiLCJTT0FQQWN0aW9uIiwic3RhdHVzQ29kZSIsIm1hdGNoIiwiX3gxMCIsIl94MTEiLCJfbG9nb3V0IiwiX2NhbGxlZTYiLCJyZXZva2UiLCJfY2FsbGVlNiQiLCJfY29udGV4dDEzIiwibG9nb3V0QnlPQXV0aDIiLCJsb2dvdXRCeVNvYXAiLCJsb2dvdXQiLCJfeDEyIiwiX2xvZ291dEJ5T0F1dGgiLCJfY2FsbGVlNyIsInRva2VuIiwiX2NhbGxlZTckIiwiX2NvbnRleHQxNCIsInJldm9rZVRva2VuIiwiX3gxMyIsIl9sb2dvdXRCeVNvYXAiLCJfY2FsbGVlOCIsIl9jb250ZXh0MTUiLCJfY2FsbGVlOCQiLCJfY29udGV4dDE2IiwiX3gxNCIsInJlcXVlc3QiLCJfdGhpczMiLCJyZXF1ZXN0XyIsIl9ub3JtYWxpemVVcmwiLCJodHRwQXBpIiwiYXBpVXNhZ2UiLCJ1c2VkIiwiX3BhcnNlSW50IiwibGltaXQiLCJfb3B0aW9ucyIsInJlcXVlc3RHZXQiLCJyZXF1ZXN0UG9zdCIsIl9KU09OJHN0cmluZ2lmeSIsInJlcXVlc3RQdXQiLCJyZXF1ZXN0UGF0Y2giLCJyZXF1ZXN0RGVsZXRlIiwiX2Jhc2VVcmwiLCJxdWVyeSIsInNvcWwiLCJzZWFyY2giLCJzb3NsIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwicXVlcnlNb3JlIiwibG9jYXRvciIsIl9lbnN1cmVWZXJzaW9uIiwibWFqb3JWZXJzaW9uIiwidmVyc2lvbnMiLCJfc3VwcG9ydHMiLCJmZWF0dXJlIiwidG9vbGluZyIsIl9yZXRyaWV2ZSIsIl9jYWxsZWU5IiwiaWRzIiwiX2FyZ3M5IiwiX2NhbGxlZTkkIiwiX2NvbnRleHQxNyIsIl9BcnJheSRpc0FycmF5IiwiX3JldHJpZXZlTWFueSIsIl9yZXRyaWV2ZVBhcmFsbGVsIiwiX3JldHJpZXZlU2luZ2xlIiwicmV0cmlldmUiLCJfeDE1IiwiX3gxNiIsIl9yZXRyaWV2ZVNpbmdsZTIiLCJfY2FsbGVlMTAiLCJmaWVsZHMiLCJfY2FsbGVlMTAkIiwiX2NvbnRleHQxOCIsIl94MTciLCJfeDE4IiwiX3gxOSIsIl9yZXRyaWV2ZVBhcmFsbGVsMiIsIl9jYWxsZWUxMSIsIl90aGlzNCIsIl9jYWxsZWUxMSQiLCJfY29udGV4dDE5IiwiYWxsIiwiX21hcEluc3RhbmNlUHJvcGVydHkiLCJjYXRjaCIsImFsbE9yTm9uZSIsImVycm9yQ29kZSIsIl94MjAiLCJfeDIxIiwiX3gyMiIsIl9yZXRyaWV2ZU1hbnkyIiwiX2NhbGxlZTEyIiwiX2NvbnRleHQyMCIsIl9jYWxsZWUxMiQiLCJfY29udGV4dDIxIiwidDEiLCJ0MiIsImZpZWxkIiwiX3gyMyIsIl94MjQiLCJfeDI1IiwiX2NyZWF0ZSIsIl9jYWxsZWUxMyIsInJlY29yZHMiLCJyZXQiLCJfYXJnczEzIiwiX2NhbGxlZTEzJCIsIl9jb250ZXh0MjIiLCJfY3JlYXRlTWFueSIsIl9jcmVhdGVQYXJhbGxlbCIsIl9jcmVhdGVTaW5nbGUiLCJfeDI2IiwiX3gyNyIsIl9jcmVhdGVTaW5nbGUyIiwiX2NhbGxlZTE0IiwicmVjb3JkIiwiSWQiLCJydHlwZSIsImF0dHJpYnV0ZXMiLCJyZWMiLCJzb2JqZWN0VHlwZSIsImNvbnRlbnRUeXBlIiwiX2NvbnRleHQyMyIsImZvcm0iLCJfY2FsbGVlMTQkIiwiX2NvbnRleHQyNCIsIl9vYmplY3RXaXRob3V0UHJvcGVydGllcyIsIl9leGNsdWRlZCIsIm11bHRpcGFydEZpbGVGaWVsZHMiLCJfZm9yRWFjaEluc3RhbmNlUHJvcGVydHkiLCJfT2JqZWN0JGVudHJpZXMiLCJfcmVmMyIsIl9yZWY0IiwiZmllbGROYW1lIiwiZmlsZURldGFpbHMiLCJhcHBlbmQiLCJnZXRIZWFkZXJzIiwiX3gyOCIsIl94MjkiLCJfeDMwIiwiX2NyZWF0ZVBhcmFsbGVsMiIsIl9jYWxsZWUxNSIsIl90aGlzNSIsIl9jYWxsZWUxNSQiLCJfY29udGV4dDI1IiwiX3gzMSIsIl94MzIiLCJfeDMzIiwiX2NyZWF0ZU1hbnkyIiwiX2NhbGxlZTE2IiwiX2NvbnRleHQyNiIsIl9yZWNvcmRzIiwiX2NhbGxlZTE2JCIsIl9jb250ZXh0MjciLCJyZXNvbHZlIiwiYWxsb3dSZWN1cnNpdmUiLCJfdG9Db25zdW1hYmxlQXJyYXkiLCJ0MyIsInQ0IiwidDUiLCJ0NiIsInQ3IiwiX2V4Y2x1ZGVkMiIsIl94MzQiLCJfeDM1IiwiX3gzNiIsInVwZGF0ZSIsIl91cGRhdGVNYW55IiwiX3VwZGF0ZVBhcmFsbGVsIiwiX3VwZGF0ZVNpbmdsZSIsIl91cGRhdGVTaW5nbGUyIiwiX2NhbGxlZTE3IiwiX2NhbGxlZTE3JCIsIl9jb250ZXh0MjgiLCJfZXhjbHVkZWQzIiwibm9Db250ZW50UmVzcG9uc2UiLCJfeDM3IiwiX3gzOCIsIl94MzkiLCJfdXBkYXRlUGFyYWxsZWwyIiwiX2NhbGxlZTE4IiwiX3RoaXM2IiwiX2NhbGxlZTE4JCIsIl9jb250ZXh0MjkiLCJfeDQwIiwiX3g0MSIsIl94NDIiLCJfdXBkYXRlTWFueTIiLCJfY2FsbGVlMTkiLCJfY29udGV4dDMwIiwiX2NhbGxlZTE5JCIsIl9jb250ZXh0MzEiLCJfZXhjbHVkZWQ0IiwiX3g0MyIsIl94NDQiLCJfeDQ1IiwiX3Vwc2VydCIsIl9jYWxsZWUyMCIsImV4dElkRmllbGQiLCJfYXJnczIwIiwiX2NhbGxlZTIwJCIsIl9jb250ZXh0MzIiLCJfdXBzZXJ0TWFueSIsIl91cHNlcnRQYXJhbGxlbCIsInVwc2VydCIsIl94NDYiLCJfeDQ3IiwiX3g0OCIsIl91cHNlcnRNYW55MiIsIl9jYWxsZWUyMSIsIl9jb250ZXh0MzMiLCJfYXJnczIxIiwiX2NhbGxlZTIxJCIsIl9jb250ZXh0MzUiLCJyZWNvcmRJdGVtIiwiX2NvbnRleHQzNCIsImV4dElkIiwicmVjb3JkVHlwZSIsIl90b1Byb3BlcnR5S2V5IiwiX3g0OSIsIl94NTAiLCJfeDUxIiwiX3Vwc2VydFBhcmFsbGVsMiIsIl9jYWxsZWUyMiIsIl90aGlzNyIsImlzQXJyYXkiLCJyZXN1bHRzIiwiX2FyZ3MyMiIsIl9jYWxsZWUyMiQiLCJfY29udGV4dDM3IiwiX2NvbnRleHQzNiIsIl94NTIiLCJfeDUzIiwiX3g1NCIsIl9kZXN0cm95IiwiX2NhbGxlZTIzIiwiX2FyZ3MyMyIsIl9jYWxsZWUyMyQiLCJfY29udGV4dDM4IiwiX2Rlc3Ryb3lNYW55IiwiX2Rlc3Ryb3lQYXJhbGxlbCIsIl9kZXN0cm95U2luZ2xlIiwiX3g1NSIsIl94NTYiLCJfZGVzdHJveVNpbmdsZTIiLCJfY2FsbGVlMjQiLCJfY2FsbGVlMjQkIiwiX2NvbnRleHQzOSIsIl94NTciLCJfeDU4IiwiX3g1OSIsIl9kZXN0cm95UGFyYWxsZWwyIiwiX2NhbGxlZTI1IiwiX3RoaXM4IiwiX2NhbGxlZTI1JCIsIl9jb250ZXh0NDAiLCJfeDYwIiwiX3g2MSIsIl94NjIiLCJfZGVzdHJveU1hbnkyIiwiX2NhbGxlZTI2IiwiX2NvbnRleHQ0MSIsIl9jYWxsZWUyNiQiLCJfY29udGV4dDQyIiwiX3g2MyIsIl94NjQiLCJfeDY1IiwiX2Rlc2NyaWJlIiwiX2NhbGxlZTI3IiwiX2NhbGxlZTI3JCIsIl9jb250ZXh0NDMiLCJfeDY2IiwiX2Rlc2NyaWJlR2xvYmFsIiwiX2NhbGxlZTI4IiwiX2NhbGxlZTI4JCIsIl9jb250ZXh0NDQiLCJfaWRlbnRpdHkiLCJfY2FsbGVlMjkiLCJfdGhpcyR1c2VySW5mbyIsIl9yZXMiLCJfYXJnczI5IiwiX2NhbGxlZTI5JCIsIl9jb250ZXh0NDUiLCJpZGVudGl0eSIsInVzZXJfaWQiLCJvcmdhbml6YXRpb25faWQiLCJfcmVjZW50IiwiX2NhbGxlZTMwIiwiX3lpZWxkJHRoaXMkcmVxdWVzdCIsInJlY2VudEl0ZW1zIiwiX2NhbGxlZTMwJCIsIl9jb250ZXh0NDYiLCJyZWNlbnQiLCJfeDY3IiwiX3g2OCIsIl91cGRhdGVkIiwiX2NhbGxlZTMxIiwic3RhcnQiLCJlbmQiLCJfY2FsbGVlMzEkIiwiX2NvbnRleHQ0NyIsIkRhdGUiLCJ1cGRhdGVkIiwiX3g2OSIsIl94NzAiLCJfeDcxIiwiX2RlbGV0ZWQiLCJfY2FsbGVlMzIiLCJfY2FsbGVlMzIkIiwiX2NvbnRleHQ0OCIsImRlbGV0ZWQiLCJfeDcyIiwiX3g3MyIsIl94NzQiLCJfdGFicyIsIl9jYWxsZWUzMyIsIl9jYWxsZWUzMyQiLCJfY29udGV4dDQ5IiwidGFicyIsIl9saW1pdHMiLCJfY2FsbGVlMzQiLCJfY2FsbGVlMzQkIiwiX2NvbnRleHQ1MCIsImxpbWl0cyIsIl90aGVtZSIsIl9jYWxsZWUzNSIsIl9jYWxsZWUzNSQiLCJfY29udGV4dDUxIiwidGhlbWUiLCJfcXVpY2tBY3Rpb25zIiwiX2NhbGxlZTM2IiwiX2NhbGxlZTM2JCIsIl9jb250ZXh0NTIiLCJxdWlja0FjdGlvbnMiLCJxdWlja0FjdGlvbiIsImFjdGlvbk5hbWUiLCJfY29udGV4dDUzIiwiX2NvbnRleHQ1NCIsIl9jb250ZXh0NTUiLCJfaW5jbHVkZXNJbnN0YW5jZVByb3BlcnR5Il0sInNvdXJjZXMiOlsiLi4vc3JjL2Nvbm5lY3Rpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKlxuICovXG5pbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IGpzZm9yY2UgZnJvbSAnLi9qc2ZvcmNlJztcbmltcG9ydCB7XG4gIEh0dHBSZXF1ZXN0LFxuICBIdHRwUmVzcG9uc2UsXG4gIENhbGxiYWNrLFxuICBSZWNvcmQsXG4gIFNhdmVSZXN1bHQsXG4gIFVwc2VydFJlc3VsdCxcbiAgRGVzY3JpYmVHbG9iYWxSZXN1bHQsXG4gIERlc2NyaWJlU09iamVjdFJlc3VsdCxcbiAgRGVzY3JpYmVUYWIsXG4gIERlc2NyaWJlVGhlbWUsXG4gIERlc2NyaWJlUXVpY2tBY3Rpb25SZXN1bHQsXG4gIFVwZGF0ZWRSZXN1bHQsXG4gIERlbGV0ZWRSZXN1bHQsXG4gIFNlYXJjaFJlc3VsdCxcbiAgT3JnYW5pemF0aW9uTGltaXRzSW5mbyxcbiAgT3B0aW9uYWwsXG4gIFNpZ25lZFJlcXVlc3RPYmplY3QsXG4gIFNhdmVFcnJvcixcbiAgRG1sT3B0aW9ucyxcbiAgUmV0cmlldmVPcHRpb25zLFxuICBTY2hlbWEsXG4gIFNPYmplY3ROYW1lcyxcbiAgU09iamVjdElucHV0UmVjb3JkLFxuICBTT2JqZWN0VXBkYXRlUmVjb3JkLFxuICBTT2JqZWN0RmllbGROYW1lcyxcbiAgVXNlckluZm8sXG4gIElkZW50aXR5SW5mbyxcbiAgTGltaXRJbmZvLFxufSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IFN0cmVhbVByb21pc2UgfSBmcm9tICcuL3V0aWwvcHJvbWlzZSc7XG5pbXBvcnQgVHJhbnNwb3J0LCB7XG4gIENhbnZhc1RyYW5zcG9ydCxcbiAgWGRQcm94eVRyYW5zcG9ydCxcbiAgSHR0cFByb3h5VHJhbnNwb3J0LFxufSBmcm9tICcuL3RyYW5zcG9ydCc7XG5pbXBvcnQgeyBMb2dnZXIsIGdldExvZ2dlciB9IGZyb20gJy4vdXRpbC9sb2dnZXInO1xuaW1wb3J0IHsgTG9nTGV2ZWxDb25maWcgfSBmcm9tICcuL3V0aWwvbG9nZ2VyJztcbmltcG9ydCBPQXV0aDIsIHsgVG9rZW5SZXNwb25zZSB9IGZyb20gJy4vb2F1dGgyJztcbmltcG9ydCB7IE9BdXRoMkNvbmZpZyB9IGZyb20gJy4vb2F1dGgyJztcbmltcG9ydCBDYWNoZSwgeyBDYWNoZWRGdW5jdGlvbiB9IGZyb20gJy4vY2FjaGUnO1xuaW1wb3J0IEh0dHBBcGkgZnJvbSAnLi9odHRwLWFwaSc7XG5pbXBvcnQgU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZSwge1xuICBTZXNzaW9uUmVmcmVzaEZ1bmMsXG59IGZyb20gJy4vc2Vzc2lvbi1yZWZyZXNoLWRlbGVnYXRlJztcbmltcG9ydCBRdWVyeSBmcm9tICcuL3F1ZXJ5JztcbmltcG9ydCB7IFF1ZXJ5T3B0aW9ucyB9IGZyb20gJy4vcXVlcnknO1xuaW1wb3J0IFNPYmplY3QgZnJvbSAnLi9zb2JqZWN0JztcbmltcG9ydCBRdWlja0FjdGlvbiBmcm9tICcuL3F1aWNrLWFjdGlvbic7XG5pbXBvcnQgUHJvY2VzcyBmcm9tICcuL3Byb2Nlc3MnO1xuaW1wb3J0IHsgZm9ybWF0RGF0ZSB9IGZyb20gJy4vdXRpbC9mb3JtYXR0ZXInO1xuaW1wb3J0IEFuYWx5dGljcyBmcm9tICcuL2FwaS9hbmFseXRpY3MnO1xuaW1wb3J0IEFwZXggZnJvbSAnLi9hcGkvYXBleCc7XG5pbXBvcnQgeyBCdWxrIH0gZnJvbSAnLi9hcGkvYnVsayc7XG5pbXBvcnQgeyBCdWxrVjIgfSBmcm9tICcuL2FwaS9idWxrMic7XG5pbXBvcnQgQ2hhdHRlciBmcm9tICcuL2FwaS9jaGF0dGVyJztcbmltcG9ydCBNZXRhZGF0YSBmcm9tICcuL2FwaS9tZXRhZGF0YSc7XG5pbXBvcnQgU29hcEFwaSBmcm9tICcuL2FwaS9zb2FwJztcbmltcG9ydCBTdHJlYW1pbmcgZnJvbSAnLi9hcGkvc3RyZWFtaW5nJztcbmltcG9ydCBUb29saW5nIGZyb20gJy4vYXBpL3Rvb2xpbmcnO1xuaW1wb3J0IEZvcm1EYXRhIGZyb20gJ2Zvcm0tZGF0YSc7XG5cbi8qKlxuICogdHlwZSBkZWZpbml0aW9uc1xuICovXG5leHBvcnQgdHlwZSBDb25uZWN0aW9uQ29uZmlnPFMgZXh0ZW5kcyBTY2hlbWEgPSBTY2hlbWE+ID0ge1xuICB2ZXJzaW9uPzogc3RyaW5nO1xuICBsb2dpblVybD86IHN0cmluZztcbiAgYWNjZXNzVG9rZW4/OiBzdHJpbmc7XG4gIHJlZnJlc2hUb2tlbj86IHN0cmluZztcbiAgaW5zdGFuY2VVcmw/OiBzdHJpbmc7XG4gIHNlc3Npb25JZD86IHN0cmluZztcbiAgc2VydmVyVXJsPzogc3RyaW5nO1xuICBzaWduZWRSZXF1ZXN0Pzogc3RyaW5nO1xuICBvYXV0aDI/OiBPQXV0aDIgfCBPQXV0aDJDb25maWc7XG4gIG1heFJlcXVlc3Q/OiBudW1iZXI7XG4gIHByb3h5VXJsPzogc3RyaW5nO1xuICBodHRwUHJveHk/OiBzdHJpbmc7XG4gIGxvZ0xldmVsPzogTG9nTGV2ZWxDb25maWc7XG4gIGNhbGxPcHRpb25zPzogeyBbbmFtZTogc3RyaW5nXTogc3RyaW5nIH07XG4gIHJlZnJlc2hGbj86IFNlc3Npb25SZWZyZXNoRnVuYzxTPjtcbn07XG5cbmV4cG9ydCB0eXBlIENvbm5lY3Rpb25Fc3RhYmxpc2hPcHRpb25zID0ge1xuICBhY2Nlc3NUb2tlbj86IE9wdGlvbmFsPHN0cmluZz47XG4gIHJlZnJlc2hUb2tlbj86IE9wdGlvbmFsPHN0cmluZz47XG4gIGluc3RhbmNlVXJsPzogT3B0aW9uYWw8c3RyaW5nPjtcbiAgc2Vzc2lvbklkPzogT3B0aW9uYWw8c3RyaW5nPjtcbiAgc2VydmVyVXJsPzogT3B0aW9uYWw8c3RyaW5nPjtcbiAgc2lnbmVkUmVxdWVzdD86IE9wdGlvbmFsPHN0cmluZyB8IFNpZ25lZFJlcXVlc3RPYmplY3Q+O1xuICB1c2VySW5mbz86IE9wdGlvbmFsPFVzZXJJbmZvPjtcbn07XG5cbi8qKlxuICpcbiAqL1xuY29uc3QgZGVmYXVsdENvbm5lY3Rpb25Db25maWc6IHtcbiAgbG9naW5Vcmw6IHN0cmluZztcbiAgaW5zdGFuY2VVcmw6IHN0cmluZztcbiAgdmVyc2lvbjogc3RyaW5nO1xuICBsb2dMZXZlbDogTG9nTGV2ZWxDb25maWc7XG4gIG1heFJlcXVlc3Q6IG51bWJlcjtcbn0gPSB7XG4gIGxvZ2luVXJsOiAnaHR0cHM6Ly9sb2dpbi5zYWxlc2ZvcmNlLmNvbScsXG4gIGluc3RhbmNlVXJsOiAnJyxcbiAgdmVyc2lvbjogJzUwLjAnLFxuICBsb2dMZXZlbDogJ05PTkUnLFxuICBtYXhSZXF1ZXN0OiAxMCxcbn07XG5cbi8qKlxuICpcbiAqL1xuZnVuY3Rpb24gZXNjKHN0cjogT3B0aW9uYWw8c3RyaW5nPik6IHN0cmluZyB7XG4gIHJldHVybiBTdHJpbmcoc3RyIHx8ICcnKVxuICAgIC5yZXBsYWNlKC8mL2csICcmYW1wOycpXG4gICAgLnJlcGxhY2UoLzwvZywgJyZsdDsnKVxuICAgIC5yZXBsYWNlKC8+L2csICcmZ3Q7JylcbiAgICAucmVwbGFjZSgvXCIvZywgJyZxdW90OycpO1xufVxuXG4vKipcbiAqXG4gKi9cbmZ1bmN0aW9uIHBhcnNlU2lnbmVkUmVxdWVzdChzcjogc3RyaW5nIHwgT2JqZWN0KTogU2lnbmVkUmVxdWVzdE9iamVjdCB7XG4gIGlmICh0eXBlb2Ygc3IgPT09ICdzdHJpbmcnKSB7XG4gICAgaWYgKHNyLnN0YXJ0c1dpdGgoJ3snKSkge1xuICAgICAgLy8gbWlnaHQgYmUgSlNPTlxuICAgICAgcmV0dXJuIEpTT04ucGFyc2Uoc3IpO1xuICAgIH0gLy8gbWlnaHQgYmUgb3JpZ2luYWwgYmFzZTY0LWVuY29kZWQgc2lnbmVkIHJlcXVlc3RcbiAgICBjb25zdCBtc2cgPSBzci5zcGxpdCgnLicpLnBvcCgpOyAvLyByZXRyaWV2ZSBsYXR0ZXIgcGFydFxuICAgIGlmICghbXNnKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgc2lnbmVkIHJlcXVlc3QnKTtcbiAgICB9XG4gICAgY29uc3QganNvbiA9IEJ1ZmZlci5mcm9tKG1zZywgJ2Jhc2U2NCcpLnRvU3RyaW5nKCd1dGYtOCcpO1xuICAgIHJldHVybiBKU09OLnBhcnNlKGpzb24pO1xuICB9XG4gIHJldHVybiBzciBhcyBTaWduZWRSZXF1ZXN0T2JqZWN0O1xufVxuXG4vKiogQHByaXZhdGUgKiovXG5mdW5jdGlvbiBwYXJzZUlkVXJsKHVybDogc3RyaW5nKSB7XG4gIGNvbnN0IFtvcmdhbml6YXRpb25JZCwgaWRdID0gdXJsLnNwbGl0KCcvJykuc2xpY2UoLTIpO1xuICByZXR1cm4geyBpZCwgb3JnYW5pemF0aW9uSWQsIHVybCB9O1xufVxuXG4vKipcbiAqIFNlbmQgYmFzaWMgbWVzc2FnZSBpbiBjYXNlIGEgcmVmcmVzaCBpcyBuZWVkZWQgd2hlbiB0aGUgc2Vzc2lvbiBleHBpcmVkIGJ1dCB0aGVyZSBpcyBubyBPQXV0aCBzZXR1cCAhISEgU0YtdG9vbGtpdFxuICogQHByaXZhdGUgXG4gKi8gXG5mdW5jdGlvbiBkZWZhdWx0UmVmcmVzaEZuPFMgZXh0ZW5kcyBTY2hlbWE+KFxuICBjb25uOiBDb25uZWN0aW9uPFM+LFxuICBjYWxsYmFjazogQ2FsbGJhY2s8c3RyaW5nLCBUb2tlblJlc3BvbnNlPixcbikge1xuICBjYWxsYmFjayhuZXcgRXJyb3IoJ2RlZmF1bHRSZWZyZXNoRm4nKSwgdW5kZWZpbmVkKTtcbn1cblxuLyoqXG4gKiBTZXNzaW9uIFJlZnJlc2ggZGVsZWdhdGUgZnVuY3Rpb24gZm9yIE9BdXRoMiBhdXRoeiBjb2RlIGZsb3dcbiAqIEBwcml2YXRlXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIG9hdXRoUmVmcmVzaEZuPFMgZXh0ZW5kcyBTY2hlbWE+KFxuICBjb25uOiBDb25uZWN0aW9uPFM+LFxuICBjYWxsYmFjazogQ2FsbGJhY2s8c3RyaW5nLCBUb2tlblJlc3BvbnNlPixcbikge1xuICB0cnkge1xuICAgIGlmICghY29ubi5yZWZyZXNoVG9rZW4pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gcmVmcmVzaCB0b2tlbiBmb3VuZCBpbiB0aGUgY29ubmVjdGlvbicpO1xuICAgIH1cbiAgICBjb25zdCByZXMgPSBhd2FpdCBjb25uLm9hdXRoMi5yZWZyZXNoVG9rZW4oY29ubi5yZWZyZXNoVG9rZW4pO1xuICAgIGNvbnN0IHVzZXJJbmZvID0gcGFyc2VJZFVybChyZXMuaWQpO1xuICAgIGNvbm4uX2VzdGFibGlzaCh7XG4gICAgICBpbnN0YW5jZVVybDogcmVzLmluc3RhbmNlX3VybCxcbiAgICAgIGFjY2Vzc1Rva2VuOiByZXMuYWNjZXNzX3Rva2VuLFxuICAgICAgdXNlckluZm8sXG4gICAgfSk7XG4gICAgY2FsbGJhY2sodW5kZWZpbmVkLCByZXMuYWNjZXNzX3Rva2VuLCByZXMpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgIGNhbGxiYWNrKGVycik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBTZXNzaW9uIFJlZnJlc2ggZGVsZWdhdGUgZnVuY3Rpb24gZm9yIHVzZXJuYW1lL3Bhc3N3b3JkIGxvZ2luXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBjcmVhdGVVc2VybmFtZVBhc3N3b3JkUmVmcmVzaEZuPFMgZXh0ZW5kcyBTY2hlbWE+KFxuICB1c2VybmFtZTogc3RyaW5nLFxuICBwYXNzd29yZDogc3RyaW5nLFxuKSB7XG4gIHJldHVybiBhc3luYyAoXG4gICAgY29ubjogQ29ubmVjdGlvbjxTPixcbiAgICBjYWxsYmFjazogQ2FsbGJhY2s8c3RyaW5nLCBUb2tlblJlc3BvbnNlPixcbiAgKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGNvbm4ubG9naW4odXNlcm5hbWUsIHBhc3N3b3JkKTtcbiAgICAgIGlmICghY29ubi5hY2Nlc3NUb2tlbikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0FjY2VzcyB0b2tlbiBub3QgZm91bmQgYWZ0ZXIgbG9naW4nKTtcbiAgICAgIH1cbiAgICAgIGNhbGxiYWNrKG51bGwsIGNvbm4uYWNjZXNzVG9rZW4pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgIGNhbGxiYWNrKGVycik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG4gICAgfVxuICB9O1xufVxuXG4vKipcbiAqIEBwcml2YXRlXG4gKi9cbmZ1bmN0aW9uIHRvU2F2ZVJlc3VsdChlcnI6IFNhdmVFcnJvcik6IFNhdmVSZXN1bHQge1xuICByZXR1cm4ge1xuICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgIGVycm9yczogW2Vycl0sXG4gIH07XG59XG5cbi8qKlxuICpcbiAqL1xuZnVuY3Rpb24gcmFpc2VOb01vZHVsZUVycm9yKG5hbWU6IHN0cmluZyk6IG5ldmVyIHtcbiAgdGhyb3cgbmV3IEVycm9yKFxuICAgIGBBUEkgbW9kdWxlICcke25hbWV9JyBpcyBub3QgbG9hZGVkLCBsb2FkICdqc2ZvcmNlL2FwaS8ke25hbWV9JyBleHBsaWNpdGx5YCxcbiAgKTtcbn1cblxuLypcbiAqIENvbnN0YW50IG9mIG1heGltdW0gcmVjb3JkcyBudW0gaW4gRE1MIG9wZXJhdGlvbiAodXBkYXRlL2RlbGV0ZSlcbiAqL1xuY29uc3QgTUFYX0RNTF9DT1VOVCA9IDIwMDtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgQ29ubmVjdGlvbjxTIGV4dGVuZHMgU2NoZW1hID0gU2NoZW1hPiBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIHN0YXRpYyBfbG9nZ2VyID0gZ2V0TG9nZ2VyKCdjb25uZWN0aW9uJyk7XG5cbiAgdmVyc2lvbjogc3RyaW5nO1xuICBsb2dpblVybDogc3RyaW5nO1xuICBpbnN0YW5jZVVybDogc3RyaW5nO1xuICBhY2Nlc3NUb2tlbjogT3B0aW9uYWw8c3RyaW5nPjtcbiAgcmVmcmVzaFRva2VuOiBPcHRpb25hbDxzdHJpbmc+O1xuICB1c2VySW5mbzogT3B0aW9uYWw8VXNlckluZm8+O1xuICBsaW1pdEluZm86IExpbWl0SW5mbyA9IHt9O1xuICBvYXV0aDI6IE9BdXRoMjtcbiAgc29iamVjdHM6IHsgW04gaW4gU09iamVjdE5hbWVzPFM+XT86IFNPYmplY3Q8UywgTj4gfSA9IHt9O1xuICBjYWNoZTogQ2FjaGU7XG4gIF9jYWxsT3B0aW9uczogT3B0aW9uYWw8eyBbbmFtZTogc3RyaW5nXTogc3RyaW5nIH0+O1xuICBfbWF4UmVxdWVzdDogbnVtYmVyO1xuICBfbG9nZ2VyOiBMb2dnZXI7XG4gIF9sb2dMZXZlbDogT3B0aW9uYWw8TG9nTGV2ZWxDb25maWc+O1xuICBfdHJhbnNwb3J0OiBUcmFuc3BvcnQ7XG4gIF9zZXNzaW9uVHlwZTogT3B0aW9uYWw8J3NvYXAnIHwgJ29hdXRoMic+O1xuICBfcmVmcmVzaERlbGVnYXRlOiBPcHRpb25hbDxTZXNzaW9uUmVmcmVzaERlbGVnYXRlPFM+PjtcbiAgLyoqXG4gICAqIENhcCBmb3Igc2Vzc2lvbi1yZWZyZXNoIHJldHJpZXMgb24gYSBzaW5nbGUgcmVxdWVzdC4gV2hlbiB1bnNldCwgSHR0cEFwaVxuICAgKiB1c2VzIGl0cyBidWlsdC1pbiBkZWZhdWx0LiBgMGAgZmFpbHMgaW1tZWRpYXRlbHkgb24gYW4gZXhwaXJlZCBzZXNzaW9uLlxuICAgKi9cbiAgX21heFNlc3Npb25SZWZyZXNoUmV0cmllcz86IG51bWJlcjtcblxuICAvLyBkZXNjcmliZTogKG5hbWU6IHN0cmluZykgPT4gUHJvbWlzZTxEZXNjcmliZVNPYmplY3RSZXN1bHQ+O1xuICBkZXNjcmliZSQ6IENhY2hlZEZ1bmN0aW9uPChuYW1lOiBzdHJpbmcpID0+IFByb21pc2U8RGVzY3JpYmVTT2JqZWN0UmVzdWx0Pj47XG4gIGRlc2NyaWJlJCQ6IENhY2hlZEZ1bmN0aW9uPChuYW1lOiBzdHJpbmcpID0+IERlc2NyaWJlU09iamVjdFJlc3VsdD47XG4gIGRlc2NyaWJlU09iamVjdDogKG5hbWU6IHN0cmluZykgPT4gUHJvbWlzZTxEZXNjcmliZVNPYmplY3RSZXN1bHQ+O1xuICBkZXNjcmliZVNPYmplY3QkOiBDYWNoZWRGdW5jdGlvbjxcbiAgICAobmFtZTogc3RyaW5nKSA9PiBQcm9taXNlPERlc2NyaWJlU09iamVjdFJlc3VsdD5cbiAgPjtcbiAgZGVzY3JpYmVTT2JqZWN0JCQ6IENhY2hlZEZ1bmN0aW9uPChuYW1lOiBzdHJpbmcpID0+IERlc2NyaWJlU09iamVjdFJlc3VsdD47XG4gIC8vIGRlc2NyaWJlR2xvYmFsOiAoKSA9PiBQcm9taXNlPERlc2NyaWJlR2xvYmFsUmVzdWx0PjtcbiAgZGVzY3JpYmVHbG9iYWwkOiBDYWNoZWRGdW5jdGlvbjwoKSA9PiBQcm9taXNlPERlc2NyaWJlR2xvYmFsUmVzdWx0Pj47XG4gIGRlc2NyaWJlR2xvYmFsJCQ6IENhY2hlZEZ1bmN0aW9uPCgpID0+IERlc2NyaWJlR2xvYmFsUmVzdWx0PjtcblxuICAvLyBBUEkgbGlicyBhcmUgbm90IGluc3RhbnRpYXRlZCBoZXJlIHNvIHRoYXQgY29yZSBtb2R1bGUgdG8gcmVtYWluIHdpdGhvdXQgZGVwZW5kZW5jaWVzIHRvIHRoZW1cbiAgLy8gSXQgaXMgcmVzcG9uc2libGUgZm9yIGRldmVsb3BlcnMgdG8gaW1wb3J0IGFwaSBsaWJzIGV4cGxpY2l0bHkgaWYgdGhleSBhcmUgdXNpbmcgJ2pzZm9yY2UvY29yZScgaW5zdGVhZCBvZiAnanNmb3JjZScuXG4gIGdldCBhbmFseXRpY3MoKTogQW5hbHl0aWNzPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCdhbmFseXRpY3MnKTtcbiAgfVxuXG4gIGdldCBhcGV4KCk6IEFwZXg8Uz4ge1xuICAgIHJldHVybiByYWlzZU5vTW9kdWxlRXJyb3IoJ2FwZXgnKTtcbiAgfVxuXG4gIGdldCBidWxrKCk6IEJ1bGs8Uz4ge1xuICAgIHJldHVybiByYWlzZU5vTW9kdWxlRXJyb3IoJ2J1bGsnKTtcbiAgfVxuXG4gIGdldCBidWxrMigpOiBCdWxrVjI8Uz4ge1xuICAgIHJldHVybiByYWlzZU5vTW9kdWxlRXJyb3IoJ2J1bGsyJyk7XG4gIH1cblxuICBnZXQgY2hhdHRlcigpOiBDaGF0dGVyPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCdjaGF0dGVyJyk7XG4gIH1cblxuICBnZXQgbWV0YWRhdGEoKTogTWV0YWRhdGE8Uz4ge1xuICAgIHJldHVybiByYWlzZU5vTW9kdWxlRXJyb3IoJ21ldGFkYXRhJyk7XG4gIH1cblxuICBnZXQgc29hcCgpOiBTb2FwQXBpPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCdzb2FwJyk7XG4gIH1cblxuICBnZXQgc3RyZWFtaW5nKCk6IFN0cmVhbWluZzxTPiB7XG4gICAgcmV0dXJuIHJhaXNlTm9Nb2R1bGVFcnJvcignc3RyZWFtaW5nJyk7XG4gIH1cblxuICBnZXQgdG9vbGluZygpOiBUb29saW5nPFM+IHtcbiAgICByZXR1cm4gcmFpc2VOb01vZHVsZUVycm9yKCd0b29saW5nJyk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKGNvbmZpZzogQ29ubmVjdGlvbkNvbmZpZzxTPiA9IHt9KSB7XG4gICAgc3VwZXIoKTtcbiAgICBjb25zdCB7XG4gICAgICBsb2dpblVybCxcbiAgICAgIGluc3RhbmNlVXJsLFxuICAgICAgdmVyc2lvbixcbiAgICAgIG9hdXRoMixcbiAgICAgIG1heFJlcXVlc3QsXG4gICAgICBsb2dMZXZlbCxcbiAgICAgIHByb3h5VXJsLFxuICAgICAgaHR0cFByb3h5LFxuICAgIH0gPSBjb25maWc7XG4gICAgdGhpcy5sb2dpblVybCA9IGxvZ2luVXJsIHx8IGRlZmF1bHRDb25uZWN0aW9uQ29uZmlnLmxvZ2luVXJsO1xuICAgIHRoaXMuaW5zdGFuY2VVcmwgPSBpbnN0YW5jZVVybCB8fCBkZWZhdWx0Q29ubmVjdGlvbkNvbmZpZy5pbnN0YW5jZVVybDtcblxuICAgIGlmICh0aGlzLmlzTGlnaHRuaW5nSW5zdGFuY2UoKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdsaWdodG5pbmcgVVJMcyBhcmUgbm90IHZhbGlkIGFzIGluc3RhbmNlIFVSTHMnKTtcbiAgICB9XG5cbiAgICB0aGlzLnZlcnNpb24gPSB2ZXJzaW9uIHx8IGRlZmF1bHRDb25uZWN0aW9uQ29uZmlnLnZlcnNpb247XG4gICAgdGhpcy5vYXV0aDIgPVxuICAgICAgb2F1dGgyIGluc3RhbmNlb2YgT0F1dGgyXG4gICAgICAgID8gb2F1dGgyXG4gICAgICAgIDogbmV3IE9BdXRoMih7XG4gICAgICAgICAgICBsb2dpblVybDogdGhpcy5sb2dpblVybCxcbiAgICAgICAgICAgIHByb3h5VXJsLFxuICAgICAgICAgICAgaHR0cFByb3h5LFxuICAgICAgICAgICAgLi4ub2F1dGgyLFxuICAgICAgICAgIH0pO1xuICAgIGxldCByZWZyZXNoRm4gPSBjb25maWcucmVmcmVzaEZuO1xuICAgIGlmICghcmVmcmVzaEZuICYmIHRoaXMub2F1dGgyLmNsaWVudElkKSB7XG4gICAgICByZWZyZXNoRm4gPSBvYXV0aFJlZnJlc2hGbjtcbiAgICB9ZWxzZSBpZighcmVmcmVzaEZuICYmICF0aGlzLm9hdXRoMi5jbGllbnRJZCl7XG4gICAgICByZWZyZXNoRm4gPSBkZWZhdWx0UmVmcmVzaEZuO1xuICAgIH1cbiAgICBpZiAocmVmcmVzaEZuKSB7XG4gICAgICB0aGlzLl9yZWZyZXNoRGVsZWdhdGUgPSBuZXcgU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZSh0aGlzLCByZWZyZXNoRm4pO1xuICAgIH1cbiAgICB0aGlzLl9tYXhSZXF1ZXN0ID0gbWF4UmVxdWVzdCB8fCBkZWZhdWx0Q29ubmVjdGlvbkNvbmZpZy5tYXhSZXF1ZXN0O1xuICAgIHRoaXMuX2xvZ2dlciA9IGxvZ0xldmVsXG4gICAgICA/IENvbm5lY3Rpb24uX2xvZ2dlci5jcmVhdGVJbnN0YW5jZShsb2dMZXZlbClcbiAgICAgIDogQ29ubmVjdGlvbi5fbG9nZ2VyO1xuICAgIHRoaXMuX2xvZ0xldmVsID0gbG9nTGV2ZWw7XG4gICAgdGhpcy5fdHJhbnNwb3J0ID0gcHJveHlVcmxcbiAgICAgID8gbmV3IFhkUHJveHlUcmFuc3BvcnQocHJveHlVcmwpXG4gICAgICA6IGh0dHBQcm94eVxuICAgICAgPyBuZXcgSHR0cFByb3h5VHJhbnNwb3J0KGh0dHBQcm94eSlcbiAgICAgIDogbmV3IFRyYW5zcG9ydCgpO1xuICAgIHRoaXMuX2NhbGxPcHRpb25zID0gY29uZmlnLmNhbGxPcHRpb25zO1xuICAgIHRoaXMuY2FjaGUgPSBuZXcgQ2FjaGUoKTtcbiAgICBjb25zdCBkZXNjcmliZUNhY2hlS2V5ID0gKHR5cGU/OiBzdHJpbmcpID0+XG4gICAgICB0eXBlID8gYGRlc2NyaWJlLiR7dHlwZX1gIDogJ2Rlc2NyaWJlJztcbiAgICBjb25zdCBkZXNjcmliZSA9IENvbm5lY3Rpb24ucHJvdG90eXBlLmRlc2NyaWJlO1xuICAgIHRoaXMuZGVzY3JpYmUgPSB0aGlzLmNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKGRlc2NyaWJlLCB0aGlzLCB7XG4gICAgICBrZXk6IGRlc2NyaWJlQ2FjaGVLZXksXG4gICAgICBzdHJhdGVneTogJ05PQ0FDSEUnLFxuICAgIH0pO1xuICAgIHRoaXMuZGVzY3JpYmUkID0gdGhpcy5jYWNoZS5jcmVhdGVDYWNoZWRGdW5jdGlvbihkZXNjcmliZSwgdGhpcywge1xuICAgICAga2V5OiBkZXNjcmliZUNhY2hlS2V5LFxuICAgICAgc3RyYXRlZ3k6ICdISVQnLFxuICAgIH0pO1xuICAgIHRoaXMuZGVzY3JpYmUkJCA9IHRoaXMuY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24oZGVzY3JpYmUsIHRoaXMsIHtcbiAgICAgIGtleTogZGVzY3JpYmVDYWNoZUtleSxcbiAgICAgIHN0cmF0ZWd5OiAnSU1NRURJQVRFJyxcbiAgICB9KSBhcyBhbnk7XG4gICAgdGhpcy5kZXNjcmliZVNPYmplY3QgPSB0aGlzLmRlc2NyaWJlO1xuICAgIHRoaXMuZGVzY3JpYmVTT2JqZWN0JCA9IHRoaXMuZGVzY3JpYmUkO1xuICAgIHRoaXMuZGVzY3JpYmVTT2JqZWN0JCQgPSB0aGlzLmRlc2NyaWJlJCQ7XG4gICAgY29uc3QgZGVzY3JpYmVHbG9iYWwgPSBDb25uZWN0aW9uLnByb3RvdHlwZS5kZXNjcmliZUdsb2JhbDtcbiAgICB0aGlzLmRlc2NyaWJlR2xvYmFsID0gdGhpcy5jYWNoZS5jcmVhdGVDYWNoZWRGdW5jdGlvbihcbiAgICAgIGRlc2NyaWJlR2xvYmFsLFxuICAgICAgdGhpcyxcbiAgICAgIHsga2V5OiAnZGVzY3JpYmVHbG9iYWwnLCBzdHJhdGVneTogJ05PQ0FDSEUnIH0sXG4gICAgKTtcbiAgICB0aGlzLmRlc2NyaWJlR2xvYmFsJCA9IHRoaXMuY2FjaGUuY3JlYXRlQ2FjaGVkRnVuY3Rpb24oXG4gICAgICBkZXNjcmliZUdsb2JhbCxcbiAgICAgIHRoaXMsXG4gICAgICB7IGtleTogJ2Rlc2NyaWJlR2xvYmFsJywgc3RyYXRlZ3k6ICdISVQnIH0sXG4gICAgKTtcbiAgICB0aGlzLmRlc2NyaWJlR2xvYmFsJCQgPSB0aGlzLmNhY2hlLmNyZWF0ZUNhY2hlZEZ1bmN0aW9uKFxuICAgICAgZGVzY3JpYmVHbG9iYWwsXG4gICAgICB0aGlzLFxuICAgICAgeyBrZXk6ICdkZXNjcmliZUdsb2JhbCcsIHN0cmF0ZWd5OiAnSU1NRURJQVRFJyB9LFxuICAgICkgYXMgYW55O1xuICAgIGNvbnN0IHtcbiAgICAgIGFjY2Vzc1Rva2VuLFxuICAgICAgcmVmcmVzaFRva2VuLFxuICAgICAgc2Vzc2lvbklkLFxuICAgICAgc2VydmVyVXJsLFxuICAgICAgc2lnbmVkUmVxdWVzdCxcbiAgICB9ID0gY29uZmlnO1xuICAgIHRoaXMuX2VzdGFibGlzaCh7XG4gICAgICBhY2Nlc3NUb2tlbixcbiAgICAgIHJlZnJlc2hUb2tlbixcbiAgICAgIGluc3RhbmNlVXJsLFxuICAgICAgc2Vzc2lvbklkLFxuICAgICAgc2VydmVyVXJsLFxuICAgICAgc2lnbmVkUmVxdWVzdCxcbiAgICB9KTtcblxuICAgIGpzZm9yY2UuZW1pdCgnY29ubmVjdGlvbjpuZXcnLCB0aGlzKTtcbiAgfVxuXG4gIC8qIEBwcml2YXRlICovXG4gIF9lc3RhYmxpc2gob3B0aW9uczogQ29ubmVjdGlvbkVzdGFibGlzaE9wdGlvbnMpIHtcbiAgICBjb25zdCB7XG4gICAgICBhY2Nlc3NUb2tlbixcbiAgICAgIHJlZnJlc2hUb2tlbixcbiAgICAgIGluc3RhbmNlVXJsLFxuICAgICAgc2Vzc2lvbklkLFxuICAgICAgc2VydmVyVXJsLFxuICAgICAgc2lnbmVkUmVxdWVzdCxcbiAgICAgIHVzZXJJbmZvLFxuICAgIH0gPSBvcHRpb25zO1xuICAgIHRoaXMuaW5zdGFuY2VVcmwgPSBzZXJ2ZXJVcmxcbiAgICAgID8gc2VydmVyVXJsLnNwbGl0KCcvJykuc2xpY2UoMCwgMykuam9pbignLycpXG4gICAgICA6IGluc3RhbmNlVXJsIHx8IHRoaXMuaW5zdGFuY2VVcmw7XG4gICAgdGhpcy5hY2Nlc3NUb2tlbiA9IHNlc3Npb25JZCB8fCBhY2Nlc3NUb2tlbiB8fCB0aGlzLmFjY2Vzc1Rva2VuO1xuICAgIHRoaXMucmVmcmVzaFRva2VuID0gcmVmcmVzaFRva2VuIHx8IHRoaXMucmVmcmVzaFRva2VuO1xuICAgIGlmICh0aGlzLnJlZnJlc2hUb2tlbiAmJiAhdGhpcy5fcmVmcmVzaERlbGVnYXRlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdSZWZyZXNoIHRva2VuIGlzIHNwZWNpZmllZCB3aXRob3V0IG9hdXRoMiBjbGllbnQgaW5mb3JtYXRpb24gb3IgcmVmcmVzaCBmdW5jdGlvbicsXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBzaWduZWRSZXF1ZXN0T2JqZWN0ID1cbiAgICAgIHNpZ25lZFJlcXVlc3QgJiYgcGFyc2VTaWduZWRSZXF1ZXN0KHNpZ25lZFJlcXVlc3QpO1xuICAgIGlmIChzaWduZWRSZXF1ZXN0T2JqZWN0KSB7XG4gICAgICB0aGlzLmFjY2Vzc1Rva2VuID0gc2lnbmVkUmVxdWVzdE9iamVjdC5jbGllbnQub2F1dGhUb2tlbjtcbiAgICAgIGlmIChDYW52YXNUcmFuc3BvcnQuc3VwcG9ydGVkKSB7XG4gICAgICAgIHRoaXMuX3RyYW5zcG9ydCA9IG5ldyBDYW52YXNUcmFuc3BvcnQoc2lnbmVkUmVxdWVzdE9iamVjdCk7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMudXNlckluZm8gPSB1c2VySW5mbyB8fCB0aGlzLnVzZXJJbmZvO1xuICAgIHRoaXMuX3Nlc3Npb25UeXBlID0gc2Vzc2lvbklkID8gJ3NvYXAnIDogJ29hdXRoMic7XG4gICAgdGhpcy5fcmVzZXRJbnN0YW5jZSgpO1xuICB9XG5cbiAgLyogQHByaXZlYXRlICovXG4gIF9jbGVhclNlc3Npb24oKSB7XG4gICAgdGhpcy5hY2Nlc3NUb2tlbiA9IG51bGw7XG4gICAgdGhpcy5yZWZyZXNoVG9rZW4gPSBudWxsO1xuICAgIHRoaXMuaW5zdGFuY2VVcmwgPSBkZWZhdWx0Q29ubmVjdGlvbkNvbmZpZy5pbnN0YW5jZVVybDtcbiAgICB0aGlzLnVzZXJJbmZvID0gbnVsbDtcbiAgICB0aGlzLl9zZXNzaW9uVHlwZSA9IG51bGw7XG4gIH1cblxuICAvKiBAcHJpdmVhdGUgKi9cbiAgX3Jlc2V0SW5zdGFuY2UoKSB7XG4gICAgdGhpcy5saW1pdEluZm8gPSB7fTtcbiAgICB0aGlzLnNvYmplY3RzID0ge307XG4gICAgLy8gVE9ETyBpbXBsIGNhY2hlXG4gICAgdGhpcy5jYWNoZS5jbGVhcigpO1xuICAgIHRoaXMuY2FjaGUuZ2V0KCdkZXNjcmliZUdsb2JhbCcpLnJlbW92ZUFsbExpc3RlbmVycygndmFsdWUnKTtcbiAgICB0aGlzLmNhY2hlLmdldCgnZGVzY3JpYmVHbG9iYWwnKS5vbigndmFsdWUnLCAoeyByZXN1bHQgfSkgPT4ge1xuICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICBmb3IgKGNvbnN0IHNvIG9mIHJlc3VsdC5zb2JqZWN0cykge1xuICAgICAgICAgIHRoaXMuc29iamVjdChzby5uYW1lKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICAgIC8qXG4gICAgaWYgKHRoaXMudG9vbGluZykge1xuICAgICAgdGhpcy50b29saW5nLl9yZXNldEluc3RhbmNlKCk7XG4gICAgfVxuICAgICovXG4gIH1cblxuICAvKipcbiAgICogQXV0aG9yaXplIHRoZSBjb25uZWN0aW9uIHVzaW5nIE9BdXRoMiBmbG93LlxuICAgKiBUeXBpY2FsbHksIGp1c3QgcGFzcyB0aGUgY29kZSByZXR1cm5lZCBmcm9tIGF1dGhvcml6YXRpb24gc2VydmVyIGluIHRoZSBmaXJzdCBhcmd1bWVudCB0byBjb21wbGV0ZSBhdXRob3JpemF0aW9uLlxuICAgKiBJZiB5b3Ugd2FudCB0byBhdXRob3JpemUgd2l0aCBncmFudCB0eXBlcyBvdGhlciB0aGFuIGBhdXRob3JpemF0aW9uX2NvZGVgLCB5b3UgY2FuIGFsc28gcGFzcyBwYXJhbXMgb2JqZWN0IHdpdGggdGhlIGdyYW50IHR5cGUuXG4gICAqXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPFVzZXJJbmZvPn0gQW4gb2JqZWN0IHRoYXQgY29udGFpbnMgdGhlIHVzZXIgSUQsIG9yZyBJRCBhbmQgaWRlbnRpdHkgVVJMLlxuICAgKlxuICAgKi9cbiAgYXN5bmMgYXV0aG9yaXplKFxuICAgIGNvZGVPclBhcmFtczogc3RyaW5nIHwgeyBncmFudF90eXBlOiBzdHJpbmc7IFtuYW1lOiBzdHJpbmddOiBzdHJpbmcgfSxcbiAgICBwYXJhbXM6IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9ID0ge30sXG4gICk6IFByb21pc2U8VXNlckluZm8+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLm9hdXRoMi5yZXF1ZXN0VG9rZW4oY29kZU9yUGFyYW1zLCBwYXJhbXMpO1xuICAgIGNvbnN0IHVzZXJJbmZvID0gcGFyc2VJZFVybChyZXMuaWQpO1xuICAgIHRoaXMuX2VzdGFibGlzaCh7XG4gICAgICBpbnN0YW5jZVVybDogcmVzLmluc3RhbmNlX3VybCxcbiAgICAgIGFjY2Vzc1Rva2VuOiByZXMuYWNjZXNzX3Rva2VuLFxuICAgICAgcmVmcmVzaFRva2VuOiByZXMucmVmcmVzaF90b2tlbixcbiAgICAgIHVzZXJJbmZvLFxuICAgIH0pO1xuICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgIGA8bG9naW4+IGNvbXBsZXRlZC4gdXNlciBpZCA9ICR7dXNlckluZm8uaWR9LCBvcmcgaWQgPSAke3VzZXJJbmZvLm9yZ2FuaXphdGlvbklkfWAsXG4gICAgKTtcbiAgICByZXR1cm4gdXNlckluZm87XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGFzeW5jIGxvZ2luKHVzZXJuYW1lOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcpOiBQcm9taXNlPFVzZXJJbmZvPiB7XG4gICAgdGhpcy5fcmVmcmVzaERlbGVnYXRlID0gbmV3IFNlc3Npb25SZWZyZXNoRGVsZWdhdGUoXG4gICAgICB0aGlzLFxuICAgICAgY3JlYXRlVXNlcm5hbWVQYXNzd29yZFJlZnJlc2hGbih1c2VybmFtZSwgcGFzc3dvcmQpLFxuICAgICk7XG4gICAgaWYgKHRoaXMub2F1dGgyPy5jbGllbnRJZCAmJiB0aGlzLm9hdXRoMi5jbGllbnRTZWNyZXQpIHtcbiAgICAgIHJldHVybiB0aGlzLmxvZ2luQnlPQXV0aDIodXNlcm5hbWUsIHBhc3N3b3JkKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubG9naW5CeVNvYXAodXNlcm5hbWUsIHBhc3N3b3JkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBMb2dpbiBieSBPQXV0aDIgdXNlcm5hbWUgJiBwYXNzd29yZCBmbG93XG4gICAqL1xuICBhc3luYyBsb2dpbkJ5T0F1dGgyKHVzZXJuYW1lOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcpOiBQcm9taXNlPFVzZXJJbmZvPiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5vYXV0aDIuYXV0aGVudGljYXRlKHVzZXJuYW1lLCBwYXNzd29yZCk7XG4gICAgY29uc3QgdXNlckluZm8gPSBwYXJzZUlkVXJsKHJlcy5pZCk7XG4gICAgdGhpcy5fZXN0YWJsaXNoKHtcbiAgICAgIGluc3RhbmNlVXJsOiByZXMuaW5zdGFuY2VfdXJsLFxuICAgICAgYWNjZXNzVG9rZW46IHJlcy5hY2Nlc3NfdG9rZW4sXG4gICAgICB1c2VySW5mbyxcbiAgICB9KTtcbiAgICB0aGlzLl9sb2dnZXIuaW5mbyhcbiAgICAgIGA8bG9naW4+IGNvbXBsZXRlZC4gdXNlciBpZCA9ICR7dXNlckluZm8uaWR9LCBvcmcgaWQgPSAke3VzZXJJbmZvLm9yZ2FuaXphdGlvbklkfWAsXG4gICAgKTtcbiAgICByZXR1cm4gdXNlckluZm87XG4gIH1cblxuICAvKipcbiAgICogTG9naW4gYnkgU09BUCBwcm90b2NvbFxuICAgKiBAZGVwcmVjYXRlZCBUaGUgU09BUCBsb2dpbigpIEFQSSB3aWxsIGJlIHJldGlyZWQgaW4gU3VtbWVyICcyNyAoQVBJIHZlcnNpb24gNjUuMCkuIFxuICAgKiBQbGVhc2UgdXNlIE9BdXRoIDIuMCBVc2VybmFtZS1QYXNzd29yZCBGbG93IGluc3RlYWQuIFxuICAgKiBGb3IgbW9yZSBpbmZvcm1hdGlvbiwgc2VlIGh0dHBzOi8vaGVscC5zYWxlc2ZvcmNlLmNvbS9zL2FydGljbGVWaWV3P2lkPXJlbGVhc2Utbm90ZXMucm5fYXBpX3VwY29taW5nX3JldGlyZW1lbnRfMjU4cm4uaHRtJnJlbGVhc2U9MjU4JnR5cGU9NVxuICAgKi9cbiAgYXN5bmMgbG9naW5CeVNvYXAodXNlcm5hbWU6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZyk6IFByb21pc2U8VXNlckluZm8+IHtcbiAgICB0aGlzLl9sb2dnZXIud2FybihcbiAgICAgICdERVBSRUNBVElPTiBXQVJOSU5HOiBUaGUgU09BUCBsb2dpbigpIEFQSSB3aWxsIGJlIHJldGlyZWQgaW4gU3VtbWVyIFxcJzI3IChBUEkgdmVyc2lvbiA2NS4wKS4gJyArXG4gICAgICAnUGxlYXNlIHVzZSBPQXV0aCAyLjAgVXNlcm5hbWUtUGFzc3dvcmQgRmxvdyBpbnN0ZWFkLiAnICtcbiAgICAgICdGb3IgbW9yZSBpbmZvcm1hdGlvbiwgc2VlIGh0dHBzOi8vaGVscC5zYWxlc2ZvcmNlLmNvbS9zL2FydGljbGVWaWV3P2lkPXJlbGVhc2Utbm90ZXMucm5fYXBpX3VwY29taW5nX3JldGlyZW1lbnRfMjU4cm4uaHRtJnJlbGVhc2U9MjU4JnR5cGU9NSdcbiAgICApO1xuICAgIGlmICghdXNlcm5hbWUgfHwgIXBhc3N3b3JkKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKCdubyB1c2VybmFtZSBwYXNzd29yZCBnaXZlbicpKTtcbiAgICB9XG4gICAgY29uc3QgYm9keSA9IFtcbiAgICAgICc8c2U6RW52ZWxvcGUgeG1sbnM6c2U9XCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy9zb2FwL2VudmVsb3BlL1wiPicsXG4gICAgICAnPHNlOkhlYWRlci8+JyxcbiAgICAgICc8c2U6Qm9keT4nLFxuICAgICAgJzxsb2dpbiB4bWxucz1cInVybjpwYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbVwiPicsXG4gICAgICBgPHVzZXJuYW1lPiR7ZXNjKHVzZXJuYW1lKX08L3VzZXJuYW1lPmAsXG4gICAgICBgPHBhc3N3b3JkPiR7ZXNjKHBhc3N3b3JkKX08L3Bhc3N3b3JkPmAsXG4gICAgICAnPC9sb2dpbj4nLFxuICAgICAgJzwvc2U6Qm9keT4nLFxuICAgICAgJzwvc2U6RW52ZWxvcGU+JyxcbiAgICBdLmpvaW4oJycpO1xuXG4gICAgY29uc3Qgc29hcExvZ2luRW5kcG9pbnQgPSBbXG4gICAgICB0aGlzLmxvZ2luVXJsLFxuICAgICAgJ3NlcnZpY2VzL1NvYXAvdScsXG4gICAgICB0aGlzLnZlcnNpb24sXG4gICAgXS5qb2luKCcvJyk7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLl90cmFuc3BvcnQuaHR0cFJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICB1cmw6IHNvYXBMb2dpbkVuZHBvaW50LFxuICAgICAgYm9keSxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICd0ZXh0L3htbCcsXG4gICAgICAgIFNPQVBBY3Rpb246ICdcIlwiJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgbGV0IG07XG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPj0gNDAwKSB7XG4gICAgICBtID0gcmVzcG9uc2UuYm9keS5tYXRjaCgvPGZhdWx0c3RyaW5nPihbXjxdKyk8XFwvZmF1bHRzdHJpbmc+Lyk7XG4gICAgICBjb25zdCBmYXVsdHN0cmluZyA9IG0gJiYgbVsxXTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihmYXVsdHN0cmluZyB8fCByZXNwb25zZS5ib2R5KTtcbiAgICB9XG4gICAgLy8gdGhlIEFQSSB3aWxsIHJldHVybiAyMDAgYW5kIGEgcmVzdHJpY2VkIHRva2VuIHdoZW4gdXNpbmcgYW4gZXhwaXJlZCBwYXNzd29yZDpcbiAgICAvLyBodHRwczovL2RldmVsb3Blci5zYWxlc2ZvcmNlLmNvbS9kb2NzL2F0bGFzLmVuLXVzLmFwaS5tZXRhL2FwaS9zZm9yY2VfYXBpX2NhbGxzX2xvZ2luX2xvZ2lucmVzdWx0Lmh0bVxuICAgIC8vXG4gICAgLy8gd2UgbmVlZCB0byB0aHJvdyBoZXJlIHRvIGF2b2lkIGEgcG9zc2libGUgaW5maW5pdGUgbG9vcCB3aXRoIHNlc3Npb24gcmVmcmVzaCB3aGVyZTpcbiAgICAvLyAgMS4gbG9naW4gaGFwcGVucywgYHRoaXMuYWNjZXNzVG9rZW5gIGlzIHNldCB0byB0aGUgcmVzdHJpY3RlZCB0b2tlblxuICAgIC8vICAyLiByZXF1ZXN0cyBoYXBwZW4sIGdldCBiYWNrIDQwMVxuICAgIC8vICAzLiB0cmlnZ2VyIHNlc3Npb24tcmVmcmVzaCAodXNlcm5hbWUvcGFzc3dvcmQgbG9naW4gaGFzIGEgZGVmYXVsdCBzZXNzaW9uIHJlZnJlc2ggZGVsZWdhdGUgZnVuY3Rpb24pXG4gICAgLy8gIDQuIGdldHMgc3R1Y2sgcmVmcmVzaGluZyBhIHJlc3RyaWN0ZWQgdG9rZW5cbiAgICBpZiAocmVzcG9uc2UuYm9keS5tYXRjaCgvPHBhc3N3b3JkRXhwaXJlZD50cnVlPFxcL3Bhc3N3b3JkRXhwaXJlZD4vZykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignVW5hYmxlIHRvIGxvZ2luIGJlY2F1c2UgdGhlIHVzZWQgcGFzc3dvcmQgaGFzIGV4cGlyZWQuJylcbiAgICB9XG4gICAgdGhpcy5fbG9nZ2VyLmRlYnVnKGBTT0FQIHJlc3BvbnNlID0gJHtyZXNwb25zZS5ib2R5fWApO1xuICAgIG0gPSByZXNwb25zZS5ib2R5Lm1hdGNoKC88c2VydmVyVXJsPihbXjxdKyk8XFwvc2VydmVyVXJsPi8pO1xuICAgIGNvbnN0IHNlcnZlclVybCA9IG0gJiYgbVsxXTtcbiAgICBtID0gcmVzcG9uc2UuYm9keS5tYXRjaCgvPHNlc3Npb25JZD4oW148XSspPFxcL3Nlc3Npb25JZD4vKTtcbiAgICBjb25zdCBzZXNzaW9uSWQgPSBtICYmIG1bMV07XG4gICAgbSA9IHJlc3BvbnNlLmJvZHkubWF0Y2goLzx1c2VySWQ+KFtePF0rKTxcXC91c2VySWQ+Lyk7XG4gICAgY29uc3QgdXNlcklkID0gbSAmJiBtWzFdO1xuICAgIG0gPSByZXNwb25zZS5ib2R5Lm1hdGNoKC88b3JnYW5pemF0aW9uSWQ+KFtePF0rKTxcXC9vcmdhbml6YXRpb25JZD4vKTtcbiAgICBjb25zdCBvcmdhbml6YXRpb25JZCA9IG0gJiYgbVsxXTtcbiAgICBpZiAoIXNlcnZlclVybCB8fCAhc2Vzc2lvbklkIHx8ICF1c2VySWQgfHwgIW9yZ2FuaXphdGlvbklkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdjb3VsZCBub3QgZXh0cmFjdCBzZXNzaW9uIGluZm9ybWF0aW9uIGZyb20gbG9naW4gcmVzcG9uc2UnLFxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgaWRVcmwgPSBbdGhpcy5sb2dpblVybCwgJ2lkJywgb3JnYW5pemF0aW9uSWQsIHVzZXJJZF0uam9pbignLycpO1xuICAgIGNvbnN0IHVzZXJJbmZvID0geyBpZDogdXNlcklkLCBvcmdhbml6YXRpb25JZCwgdXJsOiBpZFVybCB9O1xuICAgIHRoaXMuX2VzdGFibGlzaCh7XG4gICAgICBzZXJ2ZXJVcmw6IHNlcnZlclVybC5zcGxpdCgnLycpLnNsaWNlKDAsIDMpLmpvaW4oJy8nKSxcbiAgICAgIHNlc3Npb25JZCxcbiAgICAgIHVzZXJJbmZvLFxuICAgIH0pO1xuICAgIHRoaXMuX2xvZ2dlci5pbmZvKFxuICAgICAgYDxsb2dpbj4gY29tcGxldGVkLiB1c2VyIGlkID0gJHt1c2VySWR9LCBvcmcgaWQgPSAke29yZ2FuaXphdGlvbklkfWAsXG4gICAgKTtcbiAgICByZXR1cm4gdXNlckluZm87XG4gIH1cblxuICAvKipcbiAgICogTG9nb3V0IHRoZSBjdXJyZW50IHNlc3Npb25cbiAgICovXG4gIGFzeW5jIGxvZ291dChyZXZva2U/OiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy5fcmVmcmVzaERlbGVnYXRlID0gdW5kZWZpbmVkO1xuICAgIGlmICh0aGlzLl9zZXNzaW9uVHlwZSA9PT0gJ29hdXRoMicpIHtcbiAgICAgIHJldHVybiB0aGlzLmxvZ291dEJ5T0F1dGgyKHJldm9rZSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmxvZ291dEJ5U29hcChyZXZva2UpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvZ291dCB0aGUgY3VycmVudCBzZXNzaW9uIGJ5IHJldm9raW5nIGFjY2VzcyB0b2tlbiB2aWEgT0F1dGgyIHNlc3Npb24gcmV2b2tlXG4gICAqL1xuICBhc3luYyBsb2dvdXRCeU9BdXRoMihyZXZva2U/OiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgdG9rZW4gPSByZXZva2UgPyB0aGlzLnJlZnJlc2hUb2tlbiA6IHRoaXMuYWNjZXNzVG9rZW47XG4gICAgaWYgKHRva2VuKSB7XG4gICAgICBhd2FpdCB0aGlzLm9hdXRoMi5yZXZva2VUb2tlbih0b2tlbik7XG4gICAgfVxuICAgIC8vIERlc3Ryb3kgdGhlIHNlc3Npb24gYm91bmQgdG8gdGhpcyBjb25uZWN0aW9uXG4gICAgdGhpcy5fY2xlYXJTZXNzaW9uKCk7XG4gICAgdGhpcy5fcmVzZXRJbnN0YW5jZSgpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvZ291dCB0aGUgc2Vzc2lvbiBieSB1c2luZyBTT0FQIHdlYiBzZXJ2aWNlIEFQSVxuICAgKi9cbiAgYXN5bmMgbG9nb3V0QnlTb2FwKHJldm9rZT86IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBib2R5ID0gW1xuICAgICAgJzxzZTpFbnZlbG9wZSB4bWxuczpzZT1cImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3NvYXAvZW52ZWxvcGUvXCI+JyxcbiAgICAgICc8c2U6SGVhZGVyPicsXG4gICAgICAnPFNlc3Npb25IZWFkZXIgeG1sbnM9XCJ1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb21cIj4nLFxuICAgICAgYDxzZXNzaW9uSWQ+JHtlc2MoXG4gICAgICAgIHJldm9rZSA/IHRoaXMucmVmcmVzaFRva2VuIDogdGhpcy5hY2Nlc3NUb2tlbixcbiAgICAgICl9PC9zZXNzaW9uSWQ+YCxcbiAgICAgICc8L1Nlc3Npb25IZWFkZXI+JyxcbiAgICAgICc8L3NlOkhlYWRlcj4nLFxuICAgICAgJzxzZTpCb2R5PicsXG4gICAgICAnPGxvZ291dCB4bWxucz1cInVybjpwYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbVwiLz4nLFxuICAgICAgJzwvc2U6Qm9keT4nLFxuICAgICAgJzwvc2U6RW52ZWxvcGU+JyxcbiAgICBdLmpvaW4oJycpO1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5fdHJhbnNwb3J0Lmh0dHBSZXF1ZXN0KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsOiBbdGhpcy5pbnN0YW5jZVVybCwgJ3NlcnZpY2VzL1NvYXAvdScsIHRoaXMudmVyc2lvbl0uam9pbignLycpLFxuICAgICAgYm9keSxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICd0ZXh0L3htbCcsXG4gICAgICAgIFNPQVBBY3Rpb246ICdcIlwiJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgdGhpcy5fbG9nZ2VyLmRlYnVnKFxuICAgICAgYFNPQVAgc3RhdHVzQ29kZSA9ICR7cmVzcG9uc2Uuc3RhdHVzQ29kZX0sIHJlc3BvbnNlID0gJHtyZXNwb25zZS5ib2R5fWAsXG4gICAgKTtcbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA+PSA0MDApIHtcbiAgICAgIGNvbnN0IG0gPSByZXNwb25zZS5ib2R5Lm1hdGNoKC88ZmF1bHRzdHJpbmc+KFtePF0rKTxcXC9mYXVsdHN0cmluZz4vKTtcbiAgICAgIGNvbnN0IGZhdWx0c3RyaW5nID0gbSAmJiBtWzFdO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGZhdWx0c3RyaW5nIHx8IHJlc3BvbnNlLmJvZHkpO1xuICAgIH1cbiAgICAvLyBEZXN0cm95IHRoZSBzZXNzaW9uIGJvdW5kIHRvIHRoaXMgY29ubmVjdGlvblxuICAgIHRoaXMuX2NsZWFyU2Vzc2lvbigpO1xuICAgIHRoaXMuX3Jlc2V0SW5zdGFuY2UoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZW5kIFJFU1QgQVBJIHJlcXVlc3Qgd2l0aCBnaXZlbiBIVFRQIHJlcXVlc3QgaW5mbywgd2l0aCBjb25uZWN0ZWQgc2Vzc2lvbiBpbmZvcm1hdGlvbi5cbiAgICpcbiAgICogRW5kcG9pbnQgVVJMIGNhbiBiZSBhYnNvbHV0ZSBVUkwgKCdodHRwczovL25hMS5zYWxlc2ZvcmNlLmNvbS9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIHJlbGF0aXZlIHBhdGggZnJvbSByb290ICgnL3NlcnZpY2VzL2RhdGEvdjMyLjAvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpXG4gICAqICwgb3IgcmVsYXRpdmUgcGF0aCBmcm9tIHZlcnNpb24gcm9vdCAoJy9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJykuXG4gICAqL1xuICByZXF1ZXN0PFIgPSB1bmtub3duPihcbiAgICByZXF1ZXN0OiBzdHJpbmcgfCBIdHRwUmVxdWVzdCxcbiAgICBvcHRpb25zOiBPYmplY3QgPSB7fSxcbiAgKTogU3RyZWFtUHJvbWlzZTxSPiB7XG4gICAgLy8gaWYgcmVxdWVzdCBpcyBzaW1wbGUgc3RyaW5nLCByZWdhcmQgaXQgYXMgdXJsIGluIEdFVCBtZXRob2RcbiAgICBsZXQgcmVxdWVzdF86IEh0dHBSZXF1ZXN0ID1cbiAgICAgIHR5cGVvZiByZXF1ZXN0ID09PSAnc3RyaW5nJyA/IHsgbWV0aG9kOiAnR0VUJywgdXJsOiByZXF1ZXN0IH0gOiByZXF1ZXN0O1xuICAgIC8vIGlmIHVybCBpcyBnaXZlbiBpbiByZWxhdGl2ZSBwYXRoLCBwcmVwZW5kIGJhc2UgdXJsIG9yIGluc3RhbmNlIHVybCBiZWZvcmUuXG4gICAgcmVxdWVzdF8gPSB7XG4gICAgICAuLi5yZXF1ZXN0XyxcbiAgICAgIHVybDogdGhpcy5fbm9ybWFsaXplVXJsKHJlcXVlc3RfLnVybCksXG4gICAgfTtcbiAgICBjb25zdCBodHRwQXBpID0gbmV3IEh0dHBBcGkodGhpcywgb3B0aW9ucyk7XG4gICAgLy8gbG9nIGFwaSB1c2FnZSBhbmQgaXRzIHF1b3RhXG4gICAgaHR0cEFwaS5vbigncmVzcG9uc2UnLCAocmVzcG9uc2U6IEh0dHBSZXNwb25zZSkgPT4ge1xuICAgICAgaWYgKHJlc3BvbnNlLmhlYWRlcnMgJiYgcmVzcG9uc2UuaGVhZGVyc1snc2ZvcmNlLWxpbWl0LWluZm8nXSkge1xuICAgICAgICBjb25zdCBhcGlVc2FnZSA9IHJlc3BvbnNlLmhlYWRlcnNbJ3Nmb3JjZS1saW1pdC1pbmZvJ10ubWF0Y2goXG4gICAgICAgICAgL2FwaS11c2FnZT0oXFxkKylcXC8oXFxkKykvLFxuICAgICAgICApO1xuICAgICAgICBpZiAoYXBpVXNhZ2UpIHtcbiAgICAgICAgICB0aGlzLmxpbWl0SW5mbyA9IHtcbiAgICAgICAgICAgIGFwaVVzYWdlOiB7XG4gICAgICAgICAgICAgIHVzZWQ6IHBhcnNlSW50KGFwaVVzYWdlWzFdLCAxMCksXG4gICAgICAgICAgICAgIGxpbWl0OiBwYXJzZUludChhcGlVc2FnZVsyXSwgMTApLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGh0dHBBcGkucmVxdWVzdDxSPihyZXF1ZXN0Xyk7XG4gIH1cblxuICBodHRwQXBpPFIgPSB1bmtub3duPihyZXF1ZXN0OiBIdHRwUmVxdWVzdCwgb3B0aW9uczogT2JqZWN0KSB7XG4gICAgdmFyIF9vcHRpb25zID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiB7fTtcbiAgICByZXR1cm4gbmV3IEh0dHBBcGkodGhpcywgX29wdGlvbnMpXG4gIH1cblxuICAvKipcbiAgICogU2VuZCBIVFRQIEdFVCByZXF1ZXN0XG4gICAqXG4gICAqIEVuZHBvaW50IFVSTCBjYW4gYmUgYWJzb2x1dGUgVVJMICgnaHR0cHM6Ly9uYTEuc2FsZXNmb3JjZS5jb20vc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCByZWxhdGl2ZSBwYXRoIGZyb20gcm9vdCAoJy9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIG9yIHJlbGF0aXZlIHBhdGggZnJvbSB2ZXJzaW9uIHJvb3QgKCcvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpLlxuICAgKi9cbiAgcmVxdWVzdEdldDxSID0gdW5rbm93bj4odXJsOiBzdHJpbmcsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICBjb25zdCByZXF1ZXN0OiBIdHRwUmVxdWVzdCA9IHsgbWV0aG9kOiAnR0VUJywgdXJsIH07XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdDxSPihyZXF1ZXN0LCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTZW5kIEhUVFAgUE9TVCByZXF1ZXN0IHdpdGggSlNPTiBib2R5LCB3aXRoIGNvbm5lY3RlZCBzZXNzaW9uIGluZm9ybWF0aW9uXG4gICAqXG4gICAqIEVuZHBvaW50IFVSTCBjYW4gYmUgYWJzb2x1dGUgVVJMICgnaHR0cHM6Ly9uYTEuc2FsZXNmb3JjZS5jb20vc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCByZWxhdGl2ZSBwYXRoIGZyb20gcm9vdCAoJy9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIG9yIHJlbGF0aXZlIHBhdGggZnJvbSB2ZXJzaW9uIHJvb3QgKCcvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpLlxuICAgKi9cbiAgcmVxdWVzdFBvc3Q8UiA9IHVua25vd24+KHVybDogc3RyaW5nLCBib2R5OiBPYmplY3QsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICBjb25zdCByZXF1ZXN0OiBIdHRwUmVxdWVzdCA9IHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSksXG4gICAgICBoZWFkZXJzOiB7ICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICB9O1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8Uj4ocmVxdWVzdCwgb3B0aW9ucyk7XG4gIH1cblxuICAvKipcbiAgICogU2VuZCBIVFRQIFBVVCByZXF1ZXN0IHdpdGggSlNPTiBib2R5LCB3aXRoIGNvbm5lY3RlZCBzZXNzaW9uIGluZm9ybWF0aW9uXG4gICAqXG4gICAqIEVuZHBvaW50IFVSTCBjYW4gYmUgYWJzb2x1dGUgVVJMICgnaHR0cHM6Ly9uYTEuc2FsZXNmb3JjZS5jb20vc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCByZWxhdGl2ZSBwYXRoIGZyb20gcm9vdCAoJy9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIG9yIHJlbGF0aXZlIHBhdGggZnJvbSB2ZXJzaW9uIHJvb3QgKCcvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpLlxuICAgKi9cbiAgcmVxdWVzdFB1dDxSPih1cmw6IHN0cmluZywgYm9keTogT2JqZWN0LCBvcHRpb25zPzogT2JqZWN0KSB7XG4gICAgY29uc3QgcmVxdWVzdDogSHR0cFJlcXVlc3QgPSB7XG4gICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgdXJsLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSksXG4gICAgICBoZWFkZXJzOiB7ICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcbiAgICB9O1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8Uj4ocmVxdWVzdCwgb3B0aW9ucyk7XG4gIH1cblxuICAvKipcbiAgICogU2VuZCBIVFRQIFBBVENIIHJlcXVlc3Qgd2l0aCBKU09OIGJvZHlcbiAgICpcbiAgICogRW5kcG9pbnQgVVJMIGNhbiBiZSBhYnNvbHV0ZSBVUkwgKCdodHRwczovL25hMS5zYWxlc2ZvcmNlLmNvbS9zZXJ2aWNlcy9kYXRhL3YzMi4wL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKVxuICAgKiAsIHJlbGF0aXZlIHBhdGggZnJvbSByb290ICgnL3NlcnZpY2VzL2RhdGEvdjMyLjAvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpXG4gICAqICwgb3IgcmVsYXRpdmUgcGF0aCBmcm9tIHZlcnNpb24gcm9vdCAoJy9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJykuXG4gICAqL1xuICByZXF1ZXN0UGF0Y2g8UiA9IHVua25vd24+KHVybDogc3RyaW5nLCBib2R5OiBPYmplY3QsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICBjb25zdCByZXF1ZXN0OiBIdHRwUmVxdWVzdCA9IHtcbiAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpLFxuICAgICAgaGVhZGVyczogeyAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgfTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PFI+KHJlcXVlc3QsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFNlbmQgSFRUUCBERUxFVEUgcmVxdWVzdFxuICAgKlxuICAgKiBFbmRwb2ludCBVUkwgY2FuIGJlIGFic29sdXRlIFVSTCAoJ2h0dHBzOi8vbmExLnNhbGVzZm9yY2UuY29tL3NlcnZpY2VzL2RhdGEvdjMyLjAvc29iamVjdHMvQWNjb3VudC9kZXNjcmliZScpXG4gICAqICwgcmVsYXRpdmUgcGF0aCBmcm9tIHJvb3QgKCcvc2VydmljZXMvZGF0YS92MzIuMC9zb2JqZWN0cy9BY2NvdW50L2Rlc2NyaWJlJylcbiAgICogLCBvciByZWxhdGl2ZSBwYXRoIGZyb20gdmVyc2lvbiByb290ICgnL3NvYmplY3RzL0FjY291bnQvZGVzY3JpYmUnKS5cbiAgICovXG4gIHJlcXVlc3REZWxldGU8Uj4odXJsOiBzdHJpbmcsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICBjb25zdCByZXF1ZXN0OiBIdHRwUmVxdWVzdCA9IHsgbWV0aG9kOiAnREVMRVRFJywgdXJsIH07XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdDxSPihyZXF1ZXN0LCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqKi9cbiAgX2Jhc2VVcmwoKSB7XG4gICAgcmV0dXJuIFt0aGlzLmluc3RhbmNlVXJsLCAnc2VydmljZXMvZGF0YScsIGB2JHt0aGlzLnZlcnNpb259YF0uam9pbignLycpO1xuICB9XG5cbiAgLyoqXG4gICAqIENvbnZlcnQgcGF0aCB0byBhYnNvbHV0ZSB1cmxcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9ub3JtYWxpemVVcmwodXJsOiBzdHJpbmcpIHtcbiAgICBpZiAodXJsLnN0YXJ0c1dpdGgoJy8nKSkge1xuICAgICAgaWYgKHVybC5zdGFydHNXaXRoKHRoaXMuaW5zdGFuY2VVcmwgKyAnL3NlcnZpY2VzLycpKSB7XG4gICAgICAgIHJldHVybiB1cmw7XG4gICAgICB9XG4gICAgICBpZiAodXJsLnN0YXJ0c1dpdGgoJy9zZXJ2aWNlcy8nKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnN0YW5jZVVybCArIHVybDtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLl9iYXNlVXJsKCkgKyB1cmw7XG4gICAgfVxuICAgIHJldHVybiB1cmw7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIHF1ZXJ5PFQgZXh0ZW5kcyBSZWNvcmQ+KFxuICAgIHNvcWw6IHN0cmluZyxcbiAgICBvcHRpb25zPzogUGFydGlhbDxRdWVyeU9wdGlvbnM+LFxuICApOiBRdWVyeTxTLCBTT2JqZWN0TmFtZXM8Uz4sIFQsICdRdWVyeVJlc3VsdCc+IHtcbiAgICByZXR1cm4gbmV3IFF1ZXJ5PFMsIFNPYmplY3ROYW1lczxTPiwgVCwgJ1F1ZXJ5UmVzdWx0Jz4odGhpcywgc29xbCwgb3B0aW9ucyk7XG4gIH1cblxuICAvKipcbiAgICogRXhlY3V0ZSBzZWFyY2ggYnkgU09TTFxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gc29zbCAtIFNPU0wgc3RyaW5nXG4gICAqIEBwYXJhbSB7Q2FsbGJhY2suPEFycmF5LjxSZWNvcmRSZXN1bHQ+Pn0gW2NhbGxiYWNrXSAtIENhbGxiYWNrIGZ1bmN0aW9uXG4gICAqIEByZXR1cm5zIHtQcm9taXNlLjxBcnJheS48UmVjb3JkUmVzdWx0Pj59XG4gICAqL1xuICBzZWFyY2goc29zbDogc3RyaW5nKSB7XG4gICAgY29uc3QgdXJsID0gdGhpcy5fYmFzZVVybCgpICsgJy9zZWFyY2g/cT0nICsgZW5jb2RlVVJJQ29tcG9uZW50KHNvc2wpO1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Q8U2VhcmNoUmVzdWx0Pih1cmwpO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBxdWVyeU1vcmU8VCBleHRlbmRzIFJlY29yZD4obG9jYXRvcjogc3RyaW5nLCBvcHRpb25zPzogUXVlcnlPcHRpb25zKSB7XG4gICAgcmV0dXJuIG5ldyBRdWVyeTxTLCBTT2JqZWN0TmFtZXM8Uz4sIFQsICdRdWVyeVJlc3VsdCc+KFxuICAgICAgdGhpcyxcbiAgICAgIHsgbG9jYXRvciB9LFxuICAgICAgb3B0aW9ucyxcbiAgICApO1xuICB9XG5cbiAgLyogKi9cbiAgX2Vuc3VyZVZlcnNpb24obWFqb3JWZXJzaW9uOiBudW1iZXIpIHtcbiAgICBjb25zdCB2ZXJzaW9ucyA9IHRoaXMudmVyc2lvbi5zcGxpdCgnLicpO1xuICAgIHJldHVybiBwYXJzZUludCh2ZXJzaW9uc1swXSwgMTApID49IG1ham9yVmVyc2lvbjtcbiAgfVxuXG4gIC8qICovXG4gIF9zdXBwb3J0cyhmZWF0dXJlOiBzdHJpbmcpIHtcbiAgICBzd2l0Y2ggKGZlYXR1cmUpIHtcbiAgICAgIGNhc2UgJ3NvYmplY3QtY29sbGVjdGlvbic6IC8vIHNvYmplY3QgY29sbGVjdGlvbiBpcyBhdmFpbGFibGUgb25seSBpbiBBUEkgdmVyIDQyLjArXG4gICAgICAgIHJldHVybiAhdGhpcy50b29saW5nOy8vdGhpcy5fZW5zdXJlVmVyc2lvbig0Mik7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlIHNwZWNpZmllZCByZWNvcmRzXG4gICAqL1xuICByZXRyaWV2ZTxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PihcbiAgICB0eXBlOiBOLFxuICAgIGlkczogc3RyaW5nLFxuICAgIG9wdGlvbnM/OiBSZXRyaWV2ZU9wdGlvbnMsXG4gICk6IFByb21pc2U8UmVjb3JkPjtcbiAgcmV0cmlldmU8TiBleHRlbmRzIFNPYmplY3ROYW1lczxTPj4oXG4gICAgdHlwZTogTixcbiAgICBpZHM6IHN0cmluZ1tdLFxuICAgIG9wdGlvbnM/OiBSZXRyaWV2ZU9wdGlvbnMsXG4gICk6IFByb21pc2U8UmVjb3JkW10+O1xuICByZXRyaWV2ZTxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PihcbiAgICB0eXBlOiBOLFxuICAgIGlkczogc3RyaW5nIHwgc3RyaW5nW10sXG4gICAgb3B0aW9ucz86IFJldHJpZXZlT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxSZWNvcmQgfCBSZWNvcmRbXT47XG4gIGFzeW5jIHJldHJpZXZlKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBpZHM6IHN0cmluZyB8IHN0cmluZ1tdLFxuICAgIG9wdGlvbnM6IFJldHJpZXZlT3B0aW9ucyA9IHt9LFxuICApIHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheShpZHMpXG4gICAgICA/IC8vIGNoZWNrIHRoZSB2ZXJzaW9uIHdoZXRoZXIgU09iamVjdCBjb2xsZWN0aW9uIEFQSSBpcyBzdXBwb3J0ZWQgKDQyLjApXG4gICAgICAgIHRoaXMuX2Vuc3VyZVZlcnNpb24oNDIpXG4gICAgICAgID8gdGhpcy5fcmV0cmlldmVNYW55KHR5cGUsIGlkcywgb3B0aW9ucylcbiAgICAgICAgOiB0aGlzLl9yZXRyaWV2ZVBhcmFsbGVsKHR5cGUsIGlkcywgb3B0aW9ucylcbiAgICAgIDogdGhpcy5fcmV0cmlldmVTaW5nbGUodHlwZSwgaWRzLCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfcmV0cmlldmVTaW5nbGUodHlwZTogc3RyaW5nLCBpZDogc3RyaW5nLCBvcHRpb25zOiBSZXRyaWV2ZU9wdGlvbnMpIHtcbiAgICBpZiAoIWlkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgcmVjb3JkIElELiBTcGVjaWZ5IHZhbGlkIHJlY29yZCBJRCB2YWx1ZScpO1xuICAgIH1cbiAgICBsZXQgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3NvYmplY3RzJywgdHlwZSwgaWRdLmpvaW4oJy8nKTtcbiAgICBjb25zdCB7IGZpZWxkcywgaGVhZGVycyB9ID0gb3B0aW9ucztcbiAgICBpZiAoZmllbGRzKSB7XG4gICAgICB1cmwgKz0gYD9maWVsZHM9JHtmaWVsZHMuam9pbignLCcpfWA7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnJlcXVlc3QoeyBtZXRob2Q6ICdHRVQnLCB1cmwsIGhlYWRlcnMgfSk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX3JldHJpZXZlUGFyYWxsZWwoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIGlkczogc3RyaW5nW10sXG4gICAgb3B0aW9uczogUmV0cmlldmVPcHRpb25zLFxuICApIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA+IHRoaXMuX21heFJlcXVlc3QpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRXhjZWVkZWQgbWF4IGxpbWl0IG9mIGNvbmN1cnJlbnQgY2FsbCcpO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5hbGwoXG4gICAgICBpZHMubWFwKChpZCkgPT5cbiAgICAgICAgdGhpcy5fcmV0cmlldmVTaW5nbGUodHlwZSwgaWQsIG9wdGlvbnMpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICBpZiAob3B0aW9ucy5hbGxPck5vbmUgfHwgZXJyLmVycm9yQ29kZSAhPT0gJ05PVF9GT1VORCcpIHtcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH0pLFxuICAgICAgKSxcbiAgICApO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9yZXRyaWV2ZU1hbnkodHlwZTogc3RyaW5nLCBpZHM6IHN0cmluZ1tdLCBvcHRpb25zOiBSZXRyaWV2ZU9wdGlvbnMpIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnY29tcG9zaXRlJywgJ3NvYmplY3RzJywgdHlwZV0uam9pbignLycpO1xuICAgIGNvbnN0IGZpZWxkcyA9XG4gICAgICBvcHRpb25zLmZpZWxkcyB8fFxuICAgICAgKGF3YWl0IHRoaXMuZGVzY3JpYmUkKHR5cGUpKS5maWVsZHMubWFwKChmaWVsZCkgPT4gZmllbGQubmFtZSk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgaWRzLCBmaWVsZHMgfSksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pLFxuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgcmVjb3Jkc1xuICAgKi9cbiAgY3JlYXRlPFxuICAgIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgSW5wdXRSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4gPSBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj5cbiAgPihcbiAgICB0eXBlOiBOLFxuICAgIHJlY29yZHM6IElucHV0UmVjb3JkW10sXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgY3JlYXRlPFxuICAgIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgSW5wdXRSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4gPSBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj5cbiAgPih0eXBlOiBOLCByZWNvcmQ6IElucHV0UmVjb3JkLCBvcHRpb25zPzogRG1sT3B0aW9ucyk6IFByb21pc2U8U2F2ZVJlc3VsdD47XG4gIGNyZWF0ZTxcbiAgICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICAgIElucHV0UmVjb3JkIGV4dGVuZHMgU09iamVjdElucHV0UmVjb3JkPFMsIE4+ID0gU09iamVjdElucHV0UmVjb3JkPFMsIE4+XG4gID4oXG4gICAgdHlwZTogTixcbiAgICByZWNvcmRzOiBJbnB1dFJlY29yZCB8IElucHV0UmVjb3JkW10sXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT47XG4gIC8qKlxuICAgKiBAcGFyYW0gdHlwZVxuICAgKiBAcGFyYW0gcmVjb3Jkc1xuICAgKiBAcGFyYW0gb3B0aW9uc1xuICAgKi9cbiAgYXN5bmMgY3JlYXRlKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICByZWNvcmRzOiBSZWNvcmQgfCBSZWNvcmRbXSxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zID0ge30sXG4gICkge1xuICAgIGNvbnN0IHJldCA9IEFycmF5LmlzQXJyYXkocmVjb3JkcylcbiAgICAgID8gLy8gY2hlY2sgdGhlIHZlcnNpb24gd2hldGhlciBTT2JqZWN0IGNvbGxlY3Rpb24gQVBJIGlzIHN1cHBvcnRlZCAoNDIuMClcbiAgICAgICAgdGhpcy5fZW5zdXJlVmVyc2lvbig0MilcbiAgICAgICAgPyBhd2FpdCB0aGlzLl9jcmVhdGVNYW55KHR5cGUsIHJlY29yZHMsIG9wdGlvbnMpXG4gICAgICAgIDogYXdhaXQgdGhpcy5fY3JlYXRlUGFyYWxsZWwodHlwZSwgcmVjb3Jkcywgb3B0aW9ucylcbiAgICAgIDogYXdhaXQgdGhpcy5fY3JlYXRlU2luZ2xlKHR5cGUsIHJlY29yZHMsIG9wdGlvbnMpO1xuICAgIHJldHVybiByZXQ7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX2NyZWF0ZVNpbmdsZSh0eXBlOiBzdHJpbmcsIHJlY29yZDogUmVjb3JkLCBvcHRpb25zOiBEbWxPcHRpb25zKSB7XG4gICAgY29uc3QgeyBJZCwgdHlwZTogcnR5cGUsIGF0dHJpYnV0ZXMsIC4uLnJlYyB9ID0gcmVjb3JkO1xuICAgIGNvbnN0IHNvYmplY3RUeXBlID0gdHlwZSB8fCBhdHRyaWJ1dGVzPy50eXBlIHx8IHJ0eXBlO1xuICAgIGlmICghc29iamVjdFR5cGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gU09iamVjdCBUeXBlIGRlZmluZWQgaW4gcmVjb3JkJyk7XG4gICAgfVxuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdzb2JqZWN0cycsIHNvYmplY3RUeXBlXS5qb2luKCcvJyk7XG4gICAgbGV0IGNvbnRlbnRUeXBlLCBib2R5O1xuXG4gICAgaWYgKG9wdGlvbnM/Lm11bHRpcGFydEZpbGVGaWVsZHMpIHtcbiAgICAgIC8vIFNlbmQgdGhlIHJlY29yZCBhcyBhIG11bHRpcGFydC9mb3JtLWRhdGEgcmVxdWVzdC4gVXNlZnVsIGZvciBmaWVsZHMgY29udGFpbmluZyBsYXJnZSBiaW5hcnkgYmxvYnMuXG4gICAgICBjb25zdCBmb3JtID0gbmV3IEZvcm1EYXRhKCk7XG4gICAgICAvLyBFeHRyYWN0IHRoZSBmaWVsZHMgcmVxdWVzdGVkIHRvIGJlIHNlbnQgc2VwYXJhdGVseSBmcm9tIHRoZSBKU09OXG4gICAgICBPYmplY3QuZW50cmllcyhvcHRpb25zLm11bHRpcGFydEZpbGVGaWVsZHMpLmZvckVhY2goXG4gICAgICAgIChbZmllbGROYW1lLCBmaWxlRGV0YWlsc10pID0+IHtcbiAgICAgICAgICBmb3JtLmFwcGVuZChcbiAgICAgICAgICAgIGZpZWxkTmFtZSxcbiAgICAgICAgICAgIEJ1ZmZlci5mcm9tKHJlY1tmaWVsZE5hbWVdLCAnYmFzZTY0JyksXG4gICAgICAgICAgICBmaWxlRGV0YWlscyxcbiAgICAgICAgICApO1xuICAgICAgICAgIGRlbGV0ZSByZWNbZmllbGROYW1lXTtcbiAgICAgICAgfSxcbiAgICAgICk7XG4gICAgICAvLyBTZXJpYWxpemUgdGhlIHJlbWFpbmluZyBmaWVsZHMgYXMgSlNPTlxuICAgICAgZm9ybS5hcHBlbmQodHlwZSwgSlNPTi5zdHJpbmdpZnkocmVjKSwge1xuICAgICAgICBjb250ZW50VHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICBjb250ZW50VHlwZSA9IGZvcm0uZ2V0SGVhZGVycygpWydjb250ZW50LXR5cGUnXTsgLy8gVGhpcyBpcyBuZWNlc3NhcnkgdG8gZW5zdXJlIHRoZSAnYm91bmRhcnknIGlzIHByZXNlbnRcbiAgICAgIGJvZHkgPSBmb3JtO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBEZWZhdWx0IGJlaGF2aW9yOiBzZW5kIHRoZSByZXF1ZXN0IGFzIEpTT05cbiAgICAgIGNvbnRlbnRUeXBlID0gJ2FwcGxpY2F0aW9uL2pzb24nO1xuICAgICAgYm9keSA9IEpTT04uc3RyaW5naWZ5KHJlYyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIHVybCxcbiAgICAgIGJvZHk6IGJvZHksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pLFxuICAgICAgICAnY29udGVudC10eXBlJzogY29udGVudFR5cGUsXG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9jcmVhdGVQYXJhbGxlbCh0eXBlOiBzdHJpbmcsIHJlY29yZHM6IFJlY29yZFtdLCBvcHRpb25zOiBEbWxPcHRpb25zKSB7XG4gICAgaWYgKHJlY29yZHMubGVuZ3RoID4gdGhpcy5fbWF4UmVxdWVzdCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdFeGNlZWRlZCBtYXggbGltaXQgb2YgY29uY3VycmVudCBjYWxsJyk7XG4gICAgfVxuICAgIHJldHVybiBQcm9taXNlLmFsbChcbiAgICAgIHJlY29yZHMubWFwKChyZWNvcmQpID0+XG4gICAgICAgIHRoaXMuX2NyZWF0ZVNpbmdsZSh0eXBlLCByZWNvcmQsIG9wdGlvbnMpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAvLyBiZSBhd2FyZSB0aGF0IGFsbE9yTm9uZSBpbiBwYXJhbGxlbCBtb2RlIHdpbGwgbm90IHJldmVydCB0aGUgb3RoZXIgc3VjY2Vzc2Z1bCByZXF1ZXN0c1xuICAgICAgICAgIC8vIGl0IG9ubHkgcmFpc2VzIGVycm9yIHdoZW4gbWV0IGF0IGxlYXN0IG9uZSBmYWlsZWQgcmVxdWVzdC5cbiAgICAgICAgICBpZiAob3B0aW9ucy5hbGxPck5vbmUgfHwgIWVyci5lcnJvckNvZGUpIHtcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRvU2F2ZVJlc3VsdChlcnIpO1xuICAgICAgICB9KSxcbiAgICAgICksXG4gICAgKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfY3JlYXRlTWFueShcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgcmVjb3JkczogUmVjb3JkW10sXG4gICAgb3B0aW9uczogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+IHtcbiAgICBpZiAocmVjb3Jkcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoW10pO1xuICAgIH1cbiAgICBpZiAocmVjb3Jkcy5sZW5ndGggPiBNQVhfRE1MX0NPVU5UICYmIG9wdGlvbnMuYWxsb3dSZWN1cnNpdmUpIHtcbiAgICAgIHJldHVybiBbXG4gICAgICAgIC4uLihhd2FpdCB0aGlzLl9jcmVhdGVNYW55KFxuICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgcmVjb3Jkcy5zbGljZSgwLCBNQVhfRE1MX0NPVU5UKSxcbiAgICAgICAgICBvcHRpb25zLFxuICAgICAgICApKSxcbiAgICAgICAgLi4uKGF3YWl0IHRoaXMuX2NyZWF0ZU1hbnkoXG4gICAgICAgICAgdHlwZSxcbiAgICAgICAgICByZWNvcmRzLnNsaWNlKE1BWF9ETUxfQ09VTlQpLFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICkpLFxuICAgICAgXTtcbiAgICB9XG4gICAgY29uc3QgX3JlY29yZHMgPSByZWNvcmRzLm1hcCgocmVjb3JkKSA9PiB7XG4gICAgICBjb25zdCB7IElkLCB0eXBlOiBydHlwZSwgYXR0cmlidXRlcywgLi4ucmVjIH0gPSByZWNvcmQ7XG4gICAgICBjb25zdCBzb2JqZWN0VHlwZSA9IHR5cGUgfHwgYXR0cmlidXRlcz8udHlwZSB8fCBydHlwZTtcbiAgICAgIGlmICghc29iamVjdFR5cGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBTT2JqZWN0IFR5cGUgZGVmaW5lZCBpbiByZWNvcmQnKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IGF0dHJpYnV0ZXM6IHsgdHlwZTogc29iamVjdFR5cGUgfSwgLi4ucmVjIH07XG4gICAgfSk7XG4gICAgY29uc3QgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ2NvbXBvc2l0ZScsICdzb2JqZWN0cyddLmpvaW4oJy8nKTtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgdXJsLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBhbGxPck5vbmU6IG9wdGlvbnMuYWxsT3JOb25lIHx8IGZhbHNlLFxuICAgICAgICByZWNvcmRzOiBfcmVjb3JkcyxcbiAgICAgIH0pLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAuLi4ob3B0aW9ucy5oZWFkZXJzIHx8IHt9KSxcbiAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBDb25uZWN0aW9uI2NyZWF0ZSgpXG4gICAqL1xuICBpbnNlcnQgPSB0aGlzLmNyZWF0ZTtcblxuICAvKipcbiAgICogVXBkYXRlIHJlY29yZHNcbiAgICovXG4gIHVwZGF0ZTxcbiAgICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICAgIFVwZGF0ZVJlY29yZCBleHRlbmRzIFNPYmplY3RVcGRhdGVSZWNvcmQ8UywgTj4gPSBTT2JqZWN0VXBkYXRlUmVjb3JkPFMsIE4+XG4gID4oXG4gICAgdHlwZTogTixcbiAgICByZWNvcmRzOiBVcGRhdGVSZWNvcmRbXSxcbiAgICBvcHRpb25zPzogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+O1xuICB1cGRhdGU8XG4gICAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgICBVcGRhdGVSZWNvcmQgZXh0ZW5kcyBTT2JqZWN0VXBkYXRlUmVjb3JkPFMsIE4+ID0gU09iamVjdFVwZGF0ZVJlY29yZDxTLCBOPlxuICA+KHR5cGU6IE4sIHJlY29yZDogVXBkYXRlUmVjb3JkLCBvcHRpb25zPzogRG1sT3B0aW9ucyk6IFByb21pc2U8U2F2ZVJlc3VsdD47XG4gIHVwZGF0ZTxcbiAgICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICAgIFVwZGF0ZVJlY29yZCBleHRlbmRzIFNPYmplY3RVcGRhdGVSZWNvcmQ8UywgTj4gPSBTT2JqZWN0VXBkYXRlUmVjb3JkPFMsIE4+XG4gID4oXG4gICAgdHlwZTogTixcbiAgICByZWNvcmRzOiBVcGRhdGVSZWNvcmQgfCBVcGRhdGVSZWNvcmRbXSxcbiAgICBvcHRpb25zPzogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0IHwgU2F2ZVJlc3VsdFtdPjtcbiAgLyoqXG4gICAqIEBwYXJhbSB0eXBlXG4gICAqIEBwYXJhbSByZWNvcmRzXG4gICAqIEBwYXJhbSBvcHRpb25zXG4gICAqL1xuICB1cGRhdGU8TiBleHRlbmRzIFNPYmplY3ROYW1lczxTPj4oXG4gICAgdHlwZTogTixcbiAgICByZWNvcmRzOiBSZWNvcmQgfCBSZWNvcmRbXSxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zID0ge30sXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT4ge1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KHJlY29yZHMpXG4gICAgICA/IC8vIGNoZWNrIHRoZSB2ZXJzaW9uIHdoZXRoZXIgU09iamVjdCBjb2xsZWN0aW9uIEFQSSBpcyBzdXBwb3J0ZWQgKDQyLjApXG4gICAgICAgIHRoaXMuX2Vuc3VyZVZlcnNpb24oNDIpXG4gICAgICAgID8gdGhpcy5fdXBkYXRlTWFueSh0eXBlLCByZWNvcmRzLCBvcHRpb25zKVxuICAgICAgICA6IHRoaXMuX3VwZGF0ZVBhcmFsbGVsKHR5cGUsIHJlY29yZHMsIG9wdGlvbnMpXG4gICAgICA6IHRoaXMuX3VwZGF0ZVNpbmdsZSh0eXBlLCByZWNvcmRzLCBvcHRpb25zKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfdXBkYXRlU2luZ2xlKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICByZWNvcmQ6IFJlY29yZCxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQ+IHtcbiAgICBjb25zdCB7IElkOiBpZCwgdHlwZTogcnR5cGUsIGF0dHJpYnV0ZXMsIC4uLnJlYyB9ID0gcmVjb3JkO1xuICAgIGlmICghaWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignUmVjb3JkIGlkIGlzIG5vdCBmb3VuZCBpbiByZWNvcmQuJyk7XG4gICAgfVxuICAgIGNvbnN0IHNvYmplY3RUeXBlID0gdHlwZSB8fCBhdHRyaWJ1dGVzPy50eXBlIHx8IHJ0eXBlO1xuICAgIGlmICghc29iamVjdFR5cGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gU09iamVjdCBUeXBlIGRlZmluZWQgaW4gcmVjb3JkJyk7XG4gICAgfVxuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdzb2JqZWN0cycsIHNvYmplY3RUeXBlLCBpZF0uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3QoXG4gICAgICB7XG4gICAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgICAgdXJsLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShyZWMpLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgLi4uKG9wdGlvbnMuaGVhZGVycyB8fCB7fSksXG4gICAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5vQ29udGVudFJlc3BvbnNlOiB7IGlkLCBzdWNjZXNzOiB0cnVlLCBlcnJvcnM6IFtdIH0sXG4gICAgICB9LFxuICAgICk7XG4gIH1cblxuICAvKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX3VwZGF0ZVBhcmFsbGVsKHR5cGU6IHN0cmluZywgcmVjb3JkczogUmVjb3JkW10sIG9wdGlvbnM6IERtbE9wdGlvbnMpIHtcbiAgICBpZiAocmVjb3Jkcy5sZW5ndGggPiB0aGlzLl9tYXhSZXF1ZXN0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0V4Y2VlZGVkIG1heCBsaW1pdCBvZiBjb25jdXJyZW50IGNhbGwnKTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UuYWxsKFxuICAgICAgcmVjb3Jkcy5tYXAoKHJlY29yZCkgPT5cbiAgICAgICAgdGhpcy5fdXBkYXRlU2luZ2xlKHR5cGUsIHJlY29yZCwgb3B0aW9ucykuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgIC8vIGJlIGF3YXJlIHRoYXQgYWxsT3JOb25lIGluIHBhcmFsbGVsIG1vZGUgd2lsbCBub3QgcmV2ZXJ0IHRoZSBvdGhlciBzdWNjZXNzZnVsIHJlcXVlc3RzXG4gICAgICAgICAgLy8gaXQgb25seSByYWlzZXMgZXJyb3Igd2hlbiBtZXQgYXQgbGVhc3Qgb25lIGZhaWxlZCByZXF1ZXN0LlxuICAgICAgICAgIGlmIChvcHRpb25zLmFsbE9yTm9uZSB8fCAhZXJyLmVycm9yQ29kZSkge1xuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdG9TYXZlUmVzdWx0KGVycik7XG4gICAgICAgIH0pLFxuICAgICAgKSxcbiAgICApO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF91cGRhdGVNYW55KFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICByZWNvcmRzOiBSZWNvcmRbXSxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHRbXT4ge1xuICAgIGlmIChyZWNvcmRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBpZiAocmVjb3Jkcy5sZW5ndGggPiBNQVhfRE1MX0NPVU5UICYmIG9wdGlvbnMuYWxsb3dSZWN1cnNpdmUpIHtcbiAgICAgIHJldHVybiBbXG4gICAgICAgIC4uLihhd2FpdCB0aGlzLl91cGRhdGVNYW55KFxuICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgcmVjb3Jkcy5zbGljZSgwLCBNQVhfRE1MX0NPVU5UKSxcbiAgICAgICAgICBvcHRpb25zLFxuICAgICAgICApKSxcbiAgICAgICAgLi4uKGF3YWl0IHRoaXMuX3VwZGF0ZU1hbnkoXG4gICAgICAgICAgdHlwZSxcbiAgICAgICAgICByZWNvcmRzLnNsaWNlKE1BWF9ETUxfQ09VTlQpLFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICkpLFxuICAgICAgXTtcbiAgICB9XG4gICAgY29uc3QgX3JlY29yZHMgPSByZWNvcmRzLm1hcCgocmVjb3JkKSA9PiB7XG4gICAgICBjb25zdCB7IElkOiBpZCwgdHlwZTogcnR5cGUsIGF0dHJpYnV0ZXMsIC4uLnJlYyB9ID0gcmVjb3JkO1xuICAgICAgaWYgKCFpZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1JlY29yZCBpZCBpcyBub3QgZm91bmQgaW4gcmVjb3JkLicpO1xuICAgICAgfVxuICAgICAgY29uc3Qgc29iamVjdFR5cGUgPSB0eXBlIHx8IGF0dHJpYnV0ZXM/LnR5cGUgfHwgcnR5cGU7XG4gICAgICBpZiAoIXNvYmplY3RUeXBlKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gU09iamVjdCBUeXBlIGRlZmluZWQgaW4gcmVjb3JkJyk7XG4gICAgICB9XG4gICAgICByZXR1cm4geyBpZCwgYXR0cmlidXRlczogeyB0eXBlOiBzb2JqZWN0VHlwZSB9LCAuLi5yZWMgfTtcbiAgICB9KTtcbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnY29tcG9zaXRlJywgJ3NvYmplY3RzJ10uam9pbignLycpO1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnUEFUQ0gnLFxuICAgICAgdXJsLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBhbGxPck5vbmU6IG9wdGlvbnMuYWxsT3JOb25lIHx8IGZhbHNlLFxuICAgICAgICByZWNvcmRzOiBfcmVjb3JkcyxcbiAgICAgIH0pLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAuLi4ob3B0aW9ucy5oZWFkZXJzIHx8IHt9KSxcbiAgICAgICAgJ2NvbnRlbnQtdHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVXBzZXJ0IHJlY29yZHNcbiAgICovXG4gIHVwc2VydDxcbiAgICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICAgIElucHV0UmVjb3JkIGV4dGVuZHMgU09iamVjdElucHV0UmVjb3JkPFMsIE4+ID0gU09iamVjdElucHV0UmVjb3JkPFMsIE4+LFxuICAgIEZpZWxkTmFtZXMgZXh0ZW5kcyBTT2JqZWN0RmllbGROYW1lczxTLCBOPiA9IFNPYmplY3RGaWVsZE5hbWVzPFMsIE4+XG4gID4oXG4gICAgdHlwZTogTixcbiAgICByZWNvcmRzOiBJbnB1dFJlY29yZFtdLFxuICAgIGV4dElkRmllbGQ6IEZpZWxkTmFtZXMsXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8VXBzZXJ0UmVzdWx0W10+O1xuICB1cHNlcnQ8XG4gICAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgICBJbnB1dFJlY29yZCBleHRlbmRzIFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPiA9IFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPixcbiAgICBGaWVsZE5hbWVzIGV4dGVuZHMgU09iamVjdEZpZWxkTmFtZXM8UywgTj4gPSBTT2JqZWN0RmllbGROYW1lczxTLCBOPlxuICA+KFxuICAgIHR5cGU6IE4sXG4gICAgcmVjb3JkOiBJbnB1dFJlY29yZCxcbiAgICBleHRJZEZpZWxkOiBGaWVsZE5hbWVzLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFVwc2VydFJlc3VsdD47XG4gIHVwc2VydDxcbiAgICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICAgIElucHV0UmVjb3JkIGV4dGVuZHMgU09iamVjdElucHV0UmVjb3JkPFMsIE4+ID0gU09iamVjdElucHV0UmVjb3JkPFMsIE4+LFxuICAgIEZpZWxkTmFtZXMgZXh0ZW5kcyBTT2JqZWN0RmllbGROYW1lczxTLCBOPiA9IFNPYmplY3RGaWVsZE5hbWVzPFMsIE4+XG4gID4oXG4gICAgdHlwZTogTixcbiAgICByZWNvcmRzOiBJbnB1dFJlY29yZCB8IElucHV0UmVjb3JkW10sXG4gICAgZXh0SWRGaWVsZDogRmllbGROYW1lcyxcbiAgICBvcHRpb25zPzogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxVcHNlcnRSZXN1bHQgfCBVcHNlcnRSZXN1bHRbXT47XG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0gdHlwZVxuICAgKiBAcGFyYW0gcmVjb3Jkc1xuICAgKiBAcGFyYW0gZXh0SWRGaWVsZFxuICAgKiBAcGFyYW0gb3B0aW9uc1xuICAgKi9cbiAgYXN5bmMgdXBzZXJ0KFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICByZWNvcmRzOiBSZWNvcmQgfCBSZWNvcmRbXSxcbiAgICBleHRJZEZpZWxkOiBzdHJpbmcsXG4gICAgb3B0aW9uczogRG1sT3B0aW9ucyA9IHt9LFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+IHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheShyZWNvcmRzKVxuICAgID8gLy8gY2hlY2sgdGhlIHZlcnNpb24gd2hldGhlciBTT2JqZWN0IGNvbGxlY3Rpb24gQVBJIGlzIHN1cHBvcnRlZCAoNDYuMClcbiAgICAgIHRoaXMuX2Vuc3VyZVZlcnNpb24oNDYpXG4gICAgICA/IHRoaXMuX3Vwc2VydE1hbnkodHlwZSwgcmVjb3JkcywgZXh0SWRGaWVsZCwgb3B0aW9ucylcbiAgICAgIDogdGhpcy5fdXBzZXJ0UGFyYWxsZWwodHlwZSwgcmVjb3JkcywgZXh0SWRGaWVsZCwgb3B0aW9ucylcbiAgICA6IHRoaXMuX3Vwc2VydFBhcmFsbGVsKHR5cGUsIHJlY29yZHMsIGV4dElkRmllbGQsIG9wdGlvbnMpO1xufVxuXG4vKiogQHByaXZhdGUgKi9cbiAgYXN5bmMgX3Vwc2VydE1hbnkoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIHJlY29yZHM6IFJlY29yZCB8IFJlY29yZFtdLFxuICAgIGV4dElkRmllbGQ6IHN0cmluZyxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zID0ge30sXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT4ge1xuICAgIGlmIChyZWNvcmRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBpZiAocmVjb3Jkcy5sZW5ndGggPiBNQVhfRE1MX0NPVU5UICYmIG9wdGlvbnMuYWxsb3dSZWN1cnNpdmUpIHtcbiAgICAgIHJldHVybiBbXG4gICAgICAgIC4uLigoYXdhaXQgdGhpcy5fdXBzZXJ0TWFueShcbiAgICAgICAgICB0eXBlLFxuICAgICAgICAgIHJlY29yZHMuc2xpY2UoMCwgTUFYX0RNTF9DT1VOVCksXG4gICAgICAgICAgZXh0SWRGaWVsZCxcbiAgICAgICAgICBvcHRpb25zLFxuICAgICAgICApKSBhcyBTYXZlUmVzdWx0W10pLFxuICAgICAgICAuLi4oKGF3YWl0IHRoaXMuX3Vwc2VydE1hbnkodHlwZSwgcmVjb3Jkcy5zbGljZShNQVhfRE1MX0NPVU5UKSwgZXh0SWRGaWVsZCwgb3B0aW9ucykpIGFzIFNhdmVSZXN1bHRbXSksXG4gICAgICBdO1xuICAgIH1cbiAgICBjb25zdCBfcmVjb3JkcyA9IHJlY29yZHMubWFwKChyZWNvcmRJdGVtOiBSZWNvcmQpID0+IHtcbiAgICAgIGNvbnN0IHsgW2V4dElkRmllbGRdOiBleHRJZCwgdHlwZTogcmVjb3JkVHlwZSwgYXR0cmlidXRlcywgLi4ucmVjIH0gPSByZWNvcmRJdGVtO1xuICAgICAgY29uc3Qgc29iamVjdFR5cGUgPSByZWNvcmRUeXBlIHx8IGF0dHJpYnV0ZXM/LnR5cGUgfHwgdHlwZTtcbiAgICAgIGlmICghZXh0SWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFeHRlcm5hbCBJRCBpcyBub3QgZm91bmQgaW4gcmVjb3JkLicpO1xuICAgICAgfSBcbiAgICAgIGlmICghc29iamVjdFR5cGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBTT2JqZWN0IFR5cGUgZGVmaW5lZCBpbiByZWNvcmQnKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IFtleHRJZEZpZWxkXTogZXh0SWQsIGF0dHJpYnV0ZXM6IHsgdHlwZTogc29iamVjdFR5cGUgfSwgLi4ucmVjIH07XG4gICAgfSk7XG4gICAgY29uc3QgdXJsID1cbiAgICAgIFt0aGlzLl9iYXNlVXJsKCksICdjb21wb3NpdGUnLCAnc29iamVjdHMnLCB0eXBlLCBleHRJZEZpZWxkXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCh7XG4gICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICB1cmwsXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIGFsbE9yTm9uZTogb3B0aW9ucy5hbGxPck5vbmUgfHwgZmFsc2UsXG4gICAgICAgIHJlY29yZHM6IF9yZWNvcmRzLFxuICAgICAgfSksXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pLFxuICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbi8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfdXBzZXJ0UGFyYWxsZWwoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIHJlY29yZHM6IFJlY29yZCB8IFJlY29yZFtdLFxuICAgIGV4dElkRmllbGQ6IHN0cmluZyxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zID0ge30sXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT4ge1xuICAgIGNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5KHJlY29yZHMpO1xuICAgIGNvbnN0IF9yZWNvcmRzID0gQXJyYXkuaXNBcnJheShyZWNvcmRzKSA/IHJlY29yZHMgOiBbcmVjb3Jkc107XG4gICAgaWYgKF9yZWNvcmRzLmxlbmd0aCA+IHRoaXMuX21heFJlcXVlc3QpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRXhjZWVkZWQgbWF4IGxpbWl0IG9mIGNvbmN1cnJlbnQgY2FsbCcpO1xuICAgIH1cbiAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICBfcmVjb3Jkcy5tYXAoKHJlY29yZCkgPT4ge1xuICAgICAgICBjb25zdCB7IFtleHRJZEZpZWxkXTogZXh0SWQsIHR5cGU6IHJ0eXBlLCBhdHRyaWJ1dGVzLCAuLi5yZWMgfSA9IHJlY29yZDtcbiAgICAgICAgY29uc3QgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3NvYmplY3RzJywgdHlwZSwgZXh0SWRGaWVsZCwgZXh0SWRdLmpvaW4oXG4gICAgICAgICAgJy8nLFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0PFNhdmVSZXN1bHQ+KFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgICAgICAgIHVybCxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlYyksXG4gICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgIC4uLihvcHRpb25zLmhlYWRlcnMgfHwge30pLFxuICAgICAgICAgICAgICAnY29udGVudC10eXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIG5vQ29udGVudFJlc3BvbnNlOiB7IHN1Y2Nlc3M6IHRydWUsIGVycm9yczogW10gfSxcbiAgICAgICAgICB9LFxuICAgICAgICApLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAvLyBCZSBhd2FyZSB0aGF0IGBhbGxPck5vbmVgIG9wdGlvbiBpbiB1cHNlcnQgbWV0aG9kXG4gICAgICAgICAgLy8gd2lsbCBub3QgcmV2ZXJ0IHRoZSBvdGhlciBzdWNjZXNzZnVsIHJlcXVlc3RzLlxuICAgICAgICAgIC8vIEl0IG9ubHkgcmFpc2VzIGVycm9yIHdoZW4gbWV0IGF0IGxlYXN0IG9uZSBmYWlsZWQgcmVxdWVzdC5cbiAgICAgICAgICBpZiAoIWlzQXJyYXkgfHwgb3B0aW9ucy5hbGxPck5vbmUgfHwgIWVyci5lcnJvckNvZGUpIHtcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRvU2F2ZVJlc3VsdChlcnIpO1xuICAgICAgICB9KTtcbiAgICAgIH0pLFxuICAgICk7XG4gICAgcmV0dXJuIGlzQXJyYXkgPyByZXN1bHRzIDogcmVzdWx0c1swXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGUgcmVjb3Jkc1xuICAgKi9cbiAgZGVzdHJveTxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PihcbiAgICB0eXBlOiBOLFxuICAgIGlkczogc3RyaW5nW10sXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgZGVzdHJveTxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+PihcbiAgICB0eXBlOiBOLFxuICAgIGlkOiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdD47XG4gIGRlc3Ryb3k8TiBleHRlbmRzIFNPYmplY3ROYW1lczxTPj4oXG4gICAgdHlwZTogTixcbiAgICBpZHM6IHN0cmluZyB8IHN0cmluZ1tdLFxuICAgIG9wdGlvbnM/OiBEbWxPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+O1xuICAvKipcbiAgICogQHBhcmFtIHR5cGVcbiAgICogQHBhcmFtIGlkc1xuICAgKiBAcGFyYW0gb3B0aW9uc1xuICAgKi9cbiAgYXN5bmMgZGVzdHJveShcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgaWRzOiBzdHJpbmcgfCBzdHJpbmdbXSxcbiAgICBvcHRpb25zOiBEbWxPcHRpb25zID0ge30sXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdCB8IFNhdmVSZXN1bHRbXT4ge1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KGlkcylcbiAgICAgID8gLy8gY2hlY2sgdGhlIHZlcnNpb24gd2hldGhlciBTT2JqZWN0IGNvbGxlY3Rpb24gQVBJIGlzIHN1cHBvcnRlZCAoNDIuMClcbiAgICAgICAgdGhpcy5fZW5zdXJlVmVyc2lvbig0MilcbiAgICAgICAgPyB0aGlzLl9kZXN0cm95TWFueSh0eXBlLCBpZHMsIG9wdGlvbnMpXG4gICAgICAgIDogdGhpcy5fZGVzdHJveVBhcmFsbGVsKHR5cGUsIGlkcywgb3B0aW9ucylcbiAgICAgIDogdGhpcy5fZGVzdHJveVNpbmdsZSh0eXBlLCBpZHMsIG9wdGlvbnMpO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9kZXN0cm95U2luZ2xlKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBpZDogc3RyaW5nLFxuICAgIG9wdGlvbnM6IERtbE9wdGlvbnMsXG4gICk6IFByb21pc2U8U2F2ZVJlc3VsdD4ge1xuICAgIGNvbnN0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdzb2JqZWN0cycsIHR5cGUsIGlkXS5qb2luKCcvJyk7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdChcbiAgICAgIHtcbiAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcbiAgICAgICAgdXJsLFxuICAgICAgICBoZWFkZXJzOiBvcHRpb25zLmhlYWRlcnMgfHwge30sXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBub0NvbnRlbnRSZXNwb25zZTogeyBpZCwgc3VjY2VzczogdHJ1ZSwgZXJyb3JzOiBbXSB9LFxuICAgICAgfSxcbiAgICApO1xuICB9XG5cbiAgLyoqIEBwcml2YXRlICovXG4gIGFzeW5jIF9kZXN0cm95UGFyYWxsZWwodHlwZTogc3RyaW5nLCBpZHM6IHN0cmluZ1tdLCBvcHRpb25zOiBEbWxPcHRpb25zKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiB0aGlzLl9tYXhSZXF1ZXN0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0V4Y2VlZGVkIG1heCBsaW1pdCBvZiBjb25jdXJyZW50IGNhbGwnKTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UuYWxsKFxuICAgICAgaWRzLm1hcCgoaWQpID0+XG4gICAgICAgIHRoaXMuX2Rlc3Ryb3lTaW5nbGUodHlwZSwgaWQsIG9wdGlvbnMpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAvLyBCZSBhd2FyZSB0aGF0IGBhbGxPck5vbmVgIG9wdGlvbiBpbiBwYXJhbGxlbCBtb2RlXG4gICAgICAgICAgLy8gd2lsbCBub3QgcmV2ZXJ0IHRoZSBvdGhlciBzdWNjZXNzZnVsIHJlcXVlc3RzLlxuICAgICAgICAgIC8vIEl0IG9ubHkgcmFpc2VzIGVycm9yIHdoZW4gbWV0IGF0IGxlYXN0IG9uZSBmYWlsZWQgcmVxdWVzdC5cbiAgICAgICAgICBpZiAob3B0aW9ucy5hbGxPck5vbmUgfHwgIWVyci5lcnJvckNvZGUpIHtcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRvU2F2ZVJlc3VsdChlcnIpO1xuICAgICAgICB9KSxcbiAgICAgICksXG4gICAgKTtcbiAgfVxuXG4gIC8qKiBAcHJpdmF0ZSAqL1xuICBhc3luYyBfZGVzdHJveU1hbnkoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIGlkczogc3RyaW5nW10sXG4gICAgb3B0aW9uczogRG1sT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+IHtcbiAgICBpZiAoaWRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBpZiAoaWRzLmxlbmd0aCA+IE1BWF9ETUxfQ09VTlQgJiYgb3B0aW9ucy5hbGxvd1JlY3Vyc2l2ZSkge1xuICAgICAgcmV0dXJuIFtcbiAgICAgICAgLi4uKGF3YWl0IHRoaXMuX2Rlc3Ryb3lNYW55KFxuICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgaWRzLnNsaWNlKDAsIE1BWF9ETUxfQ09VTlQpLFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICkpLFxuICAgICAgICAuLi4oYXdhaXQgdGhpcy5fZGVzdHJveU1hbnkodHlwZSwgaWRzLnNsaWNlKE1BWF9ETUxfQ09VTlQpLCBvcHRpb25zKSksXG4gICAgICBdO1xuICAgIH1cbiAgICBsZXQgdXJsID1cbiAgICAgIFt0aGlzLl9iYXNlVXJsKCksICdjb21wb3NpdGUnLCAnc29iamVjdHM/aWRzPSddLmpvaW4oJy8nKSArIGlkcy5qb2luKCcsJyk7XG4gICAgaWYgKG9wdGlvbnMuYWxsT3JOb25lKSB7XG4gICAgICB1cmwgKz0gJyZhbGxPck5vbmU9dHJ1ZSc7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnJlcXVlc3Qoe1xuICAgICAgbWV0aG9kOiAnREVMRVRFJyxcbiAgICAgIHVybCxcbiAgICAgIGhlYWRlcnM6IG9wdGlvbnMuaGVhZGVycyB8fCB7fSxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIENvbm5lY3Rpb24jZGVzdHJveSgpXG4gICAqL1xuICBkZWxldGUgPSB0aGlzLmRlc3Ryb3k7XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgQ29ubmVjdGlvbiNkZXN0cm95KClcbiAgICovXG4gIGRlbCA9IHRoaXMuZGVzdHJveTtcblxuICAvKipcbiAgICogRGVzY3JpYmUgU09iamVjdCBtZXRhZGF0YVxuICAgKi9cbiAgYXN5bmMgZGVzY3JpYmUodHlwZTogc3RyaW5nKTogUHJvbWlzZTxEZXNjcmliZVNPYmplY3RSZXN1bHQ+IHtcbiAgICBjb25zdCB1cmwgPSBbdGhpcy5fYmFzZVVybCgpLCAnc29iamVjdHMnLCB0eXBlLCAnZGVzY3JpYmUnXS5qb2luKCcvJyk7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMucmVxdWVzdCh1cmwpO1xuICAgIHJldHVybiBib2R5IGFzIERlc2NyaWJlU09iamVjdFJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXNjcmliZSBnbG9iYWwgU09iamVjdHNcbiAgICovXG4gIGFzeW5jIGRlc2NyaWJlR2xvYmFsKCkge1xuICAgIGNvbnN0IHVybCA9IGAke3RoaXMuX2Jhc2VVcmwoKX0vc29iamVjdHNgO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLnJlcXVlc3QodXJsKTtcbiAgICByZXR1cm4gYm9keSBhcyBEZXNjcmliZUdsb2JhbFJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgU09iamVjdCBpbnN0YW5jZVxuICAgKi9cbiAgc29iamVjdDxOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+Pih0eXBlOiBzdHJpbmd8Tik6IFNPYmplY3Q8UywgTj47XG4gIHNvYmplY3Q8TiBleHRlbmRzIFNPYmplY3ROYW1lczxTPj4odHlwZTogTiB8IHN0cmluZyk6IFNPYmplY3Q8UywgTj4ge1xuICAgIGNvbnN0IHNvID0gdGhpcy5zb2JqZWN0c1t0eXBlIGFzIE5dIHx8IG5ldyBTT2JqZWN0KHRoaXMsIHR5cGUgYXMgTik7XG4gICAgdGhpcy5zb2JqZWN0c1t0eXBlIGFzIE5dID0gc287XG4gICAgcmV0dXJuIHNvO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBpZGVudGl0eSBpbmZvcm1hdGlvbiBvZiBjdXJyZW50IHVzZXJcbiAgICovXG4gIGFzeW5jIGlkZW50aXR5KG9wdGlvbnM6IHsgaGVhZGVycz86IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9IH0gPSB7fSkge1xuICAgIGxldCB1cmwgPSB0aGlzLnVzZXJJbmZvPy51cmw7XG4gICAgaWYgKCF1cmwpIHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMucmVxdWVzdDx7IGlkZW50aXR5OiBzdHJpbmcgfT4oe1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICB1cmw6IHRoaXMuX2Jhc2VVcmwoKSxcbiAgICAgICAgaGVhZGVyczogb3B0aW9ucy5oZWFkZXJzLFxuICAgICAgfSk7XG4gICAgICB1cmwgPSByZXMuaWRlbnRpdHk7XG4gICAgfVxuICAgIHVybCArPSAnP2Zvcm1hdD1qc29uJztcbiAgICBpZiAodGhpcy5hY2Nlc3NUb2tlbikge1xuICAgICAgdXJsICs9IGAmb2F1dGhfdG9rZW49JHtlbmNvZGVVUklDb21wb25lbnQodGhpcy5hY2Nlc3NUb2tlbil9YDtcbiAgICB9XG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5yZXF1ZXN0PElkZW50aXR5SW5mbz4oeyBtZXRob2Q6ICdHRVQnLCB1cmwgfSk7XG4gICAgdGhpcy51c2VySW5mbyA9IHtcbiAgICAgIGlkOiByZXMudXNlcl9pZCxcbiAgICAgIG9yZ2FuaXphdGlvbklkOiByZXMub3JnYW5pemF0aW9uX2lkLFxuICAgICAgdXJsOiByZXMuaWQsXG4gICAgfTtcbiAgICByZXR1cm4gcmVzO1xuICB9XG5cbiAgLyoqXG4gICAqIExpc3QgcmVjZW50bHkgdmlld2VkIHJlY29yZHNcbiAgICovXG4gIGFzeW5jIHJlY2VudCh0eXBlPzogc3RyaW5nIHwgbnVtYmVyLCBsaW1pdD86IG51bWJlcikge1xuICAgIC8qIGVzbGludC1kaXNhYmxlIG5vLXBhcmFtLXJlYXNzaWduICovXG4gICAgaWYgKHR5cGVvZiB0eXBlID09PSAnbnVtYmVyJykge1xuICAgICAgbGltaXQgPSB0eXBlO1xuICAgICAgdHlwZSA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgbGV0IHVybDtcbiAgICBpZiAodHlwZSkge1xuICAgICAgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3NvYmplY3RzJywgdHlwZV0uam9pbignLycpO1xuICAgICAgY29uc3QgeyByZWNlbnRJdGVtcyB9ID0gYXdhaXQgdGhpcy5yZXF1ZXN0PHsgcmVjZW50SXRlbXM6IFJlY29yZFtdIH0+KFxuICAgICAgICB1cmwsXG4gICAgICApO1xuICAgICAgcmV0dXJuIGxpbWl0ID8gcmVjZW50SXRlbXMuc2xpY2UoMCwgbGltaXQpIDogcmVjZW50SXRlbXM7XG4gICAgfVxuICAgIHVybCA9IGAke3RoaXMuX2Jhc2VVcmwoKX0vcmVjZW50YDtcbiAgICBpZiAobGltaXQpIHtcbiAgICAgIHVybCArPSBgP2xpbWl0PSR7bGltaXR9YDtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdDxSZWNvcmRbXT4odXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZSB1cGRhdGVkIHJlY29yZHNcbiAgICovXG4gIGFzeW5jIHVwZGF0ZWQoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIHN0YXJ0OiBzdHJpbmcgfCBEYXRlLFxuICAgIGVuZDogc3RyaW5nIHwgRGF0ZSxcbiAgKTogUHJvbWlzZTxVcGRhdGVkUmVzdWx0PiB7XG4gICAgLyogZXNsaW50LWRpc2FibGUgbm8tcGFyYW0tcmVhc3NpZ24gKi9cbiAgICBsZXQgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3NvYmplY3RzJywgdHlwZSwgJ3VwZGF0ZWQnXS5qb2luKCcvJyk7XG4gICAgaWYgKHR5cGVvZiBzdGFydCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHN0YXJ0ID0gbmV3IERhdGUoc3RhcnQpO1xuICAgIH1cbiAgICBzdGFydCA9IGZvcm1hdERhdGUoc3RhcnQpO1xuICAgIHVybCArPSBgP3N0YXJ0PSR7ZW5jb2RlVVJJQ29tcG9uZW50KHN0YXJ0KX1gO1xuICAgIGlmICh0eXBlb2YgZW5kID09PSAnc3RyaW5nJykge1xuICAgICAgZW5kID0gbmV3IERhdGUoZW5kKTtcbiAgICB9XG4gICAgZW5kID0gZm9ybWF0RGF0ZShlbmQpO1xuICAgIHVybCArPSBgJmVuZD0ke2VuY29kZVVSSUNvbXBvbmVudChlbmQpfWA7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMucmVxdWVzdCh1cmwpO1xuICAgIHJldHVybiBib2R5IGFzIFVwZGF0ZWRSZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmUgZGVsZXRlZCByZWNvcmRzXG4gICAqL1xuICBhc3luYyBkZWxldGVkKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBzdGFydDogc3RyaW5nIHwgRGF0ZSxcbiAgICBlbmQ6IHN0cmluZyB8IERhdGUsXG4gICk6IFByb21pc2U8RGVsZXRlZFJlc3VsdD4ge1xuICAgIC8qIGVzbGludC1kaXNhYmxlIG5vLXBhcmFtLXJlYXNzaWduICovXG4gICAgbGV0IHVybCA9IFt0aGlzLl9iYXNlVXJsKCksICdzb2JqZWN0cycsIHR5cGUsICdkZWxldGVkJ10uam9pbignLycpO1xuICAgIGlmICh0eXBlb2Ygc3RhcnQgPT09ICdzdHJpbmcnKSB7XG4gICAgICBzdGFydCA9IG5ldyBEYXRlKHN0YXJ0KTtcbiAgICB9XG4gICAgc3RhcnQgPSBmb3JtYXREYXRlKHN0YXJ0KTtcbiAgICB1cmwgKz0gYD9zdGFydD0ke2VuY29kZVVSSUNvbXBvbmVudChzdGFydCl9YDtcblxuICAgIGlmICh0eXBlb2YgZW5kID09PSAnc3RyaW5nJykge1xuICAgICAgZW5kID0gbmV3IERhdGUoZW5kKTtcbiAgICB9XG4gICAgZW5kID0gZm9ybWF0RGF0ZShlbmQpO1xuICAgIHVybCArPSBgJmVuZD0ke2VuY29kZVVSSUNvbXBvbmVudChlbmQpfWA7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMucmVxdWVzdCh1cmwpO1xuICAgIHJldHVybiBib2R5IGFzIERlbGV0ZWRSZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhIGxpc3Qgb2YgYWxsIHRhYnNcbiAgICovXG4gIGFzeW5jIHRhYnMoKTogUHJvbWlzZTxEZXNjcmliZVRhYltdPiB7XG4gICAgY29uc3QgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3RhYnMnXS5qb2luKCcvJyk7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHRoaXMucmVxdWVzdCh1cmwpO1xuICAgIHJldHVybiBib2R5IGFzIERlc2NyaWJlVGFiW107XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBjdXJyZW50IHN5c3RlbSBsaW1pdCBpbiB0aGUgb3JnYW5pemF0aW9uXG4gICAqL1xuICBhc3luYyBsaW1pdHMoKTogUHJvbWlzZTxPcmdhbml6YXRpb25MaW1pdHNJbmZvPiB7XG4gICAgY29uc3QgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ2xpbWl0cyddLmpvaW4oJy8nKTtcbiAgICBjb25zdCBib2R5ID0gYXdhaXQgdGhpcy5yZXF1ZXN0KHVybCk7XG4gICAgcmV0dXJuIGJvZHkgYXMgT3JnYW5pemF0aW9uTGltaXRzSW5mbztcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgdGhlbWUgaW5mb1xuICAgKi9cbiAgYXN5bmMgdGhlbWUoKTogUHJvbWlzZTxEZXNjcmliZVRoZW1lPiB7XG4gICAgY29uc3QgdXJsID0gW3RoaXMuX2Jhc2VVcmwoKSwgJ3RoZW1lJ10uam9pbignLycpO1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLnJlcXVlc3QodXJsKTtcbiAgICByZXR1cm4gYm9keSBhcyBEZXNjcmliZVRoZW1lO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYWxsIHJlZ2lzdGVyZWQgZ2xvYmFsIHF1aWNrIGFjdGlvbnNcbiAgICovXG4gIGFzeW5jIHF1aWNrQWN0aW9ucygpOiBQcm9taXNlPERlc2NyaWJlUXVpY2tBY3Rpb25SZXN1bHRbXT4ge1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCB0aGlzLnJlcXVlc3QoJy9xdWlja0FjdGlvbnMnKTtcbiAgICByZXR1cm4gYm9keSBhcyBEZXNjcmliZVF1aWNrQWN0aW9uUmVzdWx0W107XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlZmVyZW5jZSBmb3Igc3BlY2lmaWVkIGdsb2JhbCBxdWljayBhY3Rpb25cbiAgICovXG4gIHF1aWNrQWN0aW9uKGFjdGlvbk5hbWU6IHN0cmluZyk6IFF1aWNrQWN0aW9uPFM+IHtcbiAgICByZXR1cm4gbmV3IFF1aWNrQWN0aW9uKHRoaXMsIGAvcXVpY2tBY3Rpb25zLyR7YWN0aW9uTmFtZX1gKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBNb2R1bGUgd2hpY2ggbWFuYWdlcyBwcm9jZXNzIHJ1bGVzIGFuZCBhcHByb3ZhbCBwcm9jZXNzZXNcbiAgICovXG4gIHByb2Nlc3MgPSBuZXcgUHJvY2Vzcyh0aGlzKTtcblxuICBwcml2YXRlIGlzTGlnaHRuaW5nSW5zdGFuY2UoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIChcbiAgICAgIHRoaXMuaW5zdGFuY2VVcmwuaW5jbHVkZXMoJy5saWdodG5pbmcuZm9yY2UuY29tJykgfHxcbiAgICAgIHRoaXMuaW5zdGFuY2VVcmwuaW5jbHVkZXMoJy5saWdodG5pbmcuY3JtZm9yY2UubWlsJykgfHxcbiAgICAgIHRoaXMuaW5zdGFuY2VVcmwuaW5jbHVkZXMoJy5saWdodG5pbmcuc2Zjcm1hcHBzLmNuJylcbiAgICApO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IENvbm5lY3Rpb247XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLFlBQVksUUFBUSxRQUFRO0FBQ3JDLE9BQU9DLE9BQU8sTUFBTSxXQUFXO0FBZ0MvQixPQUFPQyxTQUFTLElBQ2RDLGVBQWUsRUFDZkMsZ0JBQWdCLEVBQ2hCQyxrQkFBa0IsUUFDYixhQUFhO0FBQ3BCLFNBQWlCQyxTQUFTLFFBQVEsZUFBZTtBQUVqRCxPQUFPQyxNQUFNLE1BQXlCLFVBQVU7QUFFaEQsT0FBT0MsS0FBSyxNQUEwQixTQUFTO0FBQy9DLE9BQU9DLE9BQU8sTUFBTSxZQUFZO0FBQ2hDLE9BQU9DLHNCQUFzQixNQUV0Qiw0QkFBNEI7QUFDbkMsT0FBT0MsS0FBSyxNQUFNLFNBQVM7QUFFM0IsT0FBT0MsT0FBTyxNQUFNLFdBQVc7QUFDL0IsT0FBT0MsV0FBVyxNQUFNLGdCQUFnQjtBQUN4QyxPQUFPQyxPQUFPLE1BQU0sV0FBVztBQUMvQixTQUFTQyxVQUFVLFFBQVEsa0JBQWtCO0FBVTdDLE9BQU9DLFFBQVEsTUFBTSxXQUFXOztBQUVoQztBQUNBO0FBQ0E7O0FBNkJBO0FBQ0E7QUFDQTtBQUNBLElBQU1DLHVCQU1MLEdBQUc7RUFDRkMsUUFBUSxFQUFFLDhCQUE4QjtFQUN4Q0MsV0FBVyxFQUFFLEVBQUU7RUFDZkMsT0FBTyxFQUFFLE1BQU07RUFDZkMsUUFBUSxFQUFFLE1BQU07RUFDaEJDLFVBQVUsRUFBRTtBQUNkLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsR0FBR0EsQ0FBQ0MsR0FBcUIsRUFBVTtFQUMxQyxPQUFPQyxNQUFNLENBQUNELEdBQUcsSUFBSSxFQUFFLENBQUMsQ0FDckJFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQ3RCQSxPQUFPLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUNyQkEsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FDckJBLE9BQU8sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDO0FBQzVCOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVNDLGtCQUFrQkEsQ0FBQ0MsRUFBbUIsRUFBdUI7RUFDcEUsSUFBSSxPQUFPQSxFQUFFLEtBQUssUUFBUSxFQUFFO0lBQzFCLElBQUlDLDJCQUFBLENBQUFELEVBQUUsRUFBQUUsSUFBQSxDQUFGRixFQUFFLEVBQVksR0FBRyxDQUFDLEVBQUU7TUFDdEI7TUFDQSxPQUFPRyxJQUFJLENBQUNDLEtBQUssQ0FBQ0osRUFBRSxDQUFDO0lBQ3ZCLENBQUMsQ0FBQztJQUNGLElBQU1LLEdBQUcsR0FBR0wsRUFBRSxDQUFDTSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNqQyxJQUFJLENBQUNGLEdBQUcsRUFBRTtNQUNSLE1BQU0sSUFBSUcsS0FBSyxDQUFDLHdCQUF3QixDQUFDO0lBQzNDO0lBQ0EsSUFBTUMsSUFBSSxHQUFHQyxNQUFNLENBQUNDLElBQUksQ0FBQ04sR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDTyxRQUFRLENBQUMsT0FBTyxDQUFDO0lBQ3pELE9BQU9ULElBQUksQ0FBQ0MsS0FBSyxDQUFDSyxJQUFJLENBQUM7RUFDekI7RUFDQSxPQUFPVCxFQUFFO0FBQ1g7O0FBRUE7QUFDQSxTQUFTYSxVQUFVQSxDQUFDQyxHQUFXLEVBQUU7RUFBQSxJQUFBQyxRQUFBO0VBQy9CLElBQUFDLGdCQUFBLEdBQTZCQyxzQkFBQSxDQUFBRixRQUFBLEdBQUFELEdBQUcsQ0FBQ1IsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFBSixJQUFBLENBQUFhLFFBQUEsRUFBTyxDQUFDLENBQUMsQ0FBQztJQUFBRyxpQkFBQSxHQUFBQyxjQUFBLENBQUFILGdCQUFBO0lBQTlDSSxjQUFjLEdBQUFGLGlCQUFBO0lBQUVHLEVBQUUsR0FBQUgsaUJBQUE7RUFDekIsT0FBTztJQUFFRyxFQUFFLEVBQUZBLEVBQUU7SUFBRUQsY0FBYyxFQUFkQSxjQUFjO0lBQUVOLEdBQUcsRUFBSEE7RUFBSSxDQUFDO0FBQ3BDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU1EsZ0JBQWdCQSxDQUN2QkMsSUFBbUIsRUFDbkJDLFFBQXlDLEVBQ3pDO0VBQ0FBLFFBQVEsQ0FBQyxJQUFJaEIsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEVBQUVpQixTQUFTLENBQUM7QUFDcEQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFIQSxTQUllQyxjQUFjQSxDQUFBQyxFQUFBLEVBQUFDLEdBQUE7RUFBQSxPQUFBQyxlQUFBLENBQUFDLEtBQUEsT0FBQUMsU0FBQTtBQUFBO0FBeUI3QjtBQUNBO0FBQ0E7QUFDQTtBQUhBLFNBQUFGLGdCQUFBO0VBQUFBLGVBQUEsR0FBQUcsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQXpCQSxTQUFBQyxVQUNFWixJQUFtQixFQUNuQkMsUUFBeUM7SUFBQSxJQUFBWSxHQUFBLEVBQUFDLFFBQUE7SUFBQSxPQUFBSixtQkFBQSxDQUFBSyxJQUFBLFVBQUFDLFdBQUFDLFVBQUE7TUFBQSxrQkFBQUEsVUFBQSxDQUFBQyxJQUFBLEdBQUFELFVBQUEsQ0FBQUUsSUFBQTtRQUFBO1VBQUFGLFVBQUEsQ0FBQUMsSUFBQTtVQUFBLElBR2xDbEIsSUFBSSxDQUFDb0IsWUFBWTtZQUFBSCxVQUFBLENBQUFFLElBQUE7WUFBQTtVQUFBO1VBQUEsTUFDZCxJQUFJbEMsS0FBSyxDQUFDLDBDQUEwQyxDQUFDO1FBQUE7VUFBQWdDLFVBQUEsQ0FBQUUsSUFBQTtVQUFBLE9BRTNDbkIsSUFBSSxDQUFDcUIsTUFBTSxDQUFDRCxZQUFZLENBQUNwQixJQUFJLENBQUNvQixZQUFZLENBQUM7UUFBQTtVQUF2RFAsR0FBRyxHQUFBSSxVQUFBLENBQUFLLElBQUE7VUFDSFIsUUFBUSxHQUFHeEIsVUFBVSxDQUFDdUIsR0FBRyxDQUFDZixFQUFFLENBQUM7VUFDbkNFLElBQUksQ0FBQ3VCLFVBQVUsQ0FBQztZQUNkdkQsV0FBVyxFQUFFNkMsR0FBRyxDQUFDVyxZQUFZO1lBQzdCQyxXQUFXLEVBQUVaLEdBQUcsQ0FBQ2EsWUFBWTtZQUM3QlosUUFBUSxFQUFSQTtVQUNGLENBQUMsQ0FBQztVQUNGYixRQUFRLENBQUNDLFNBQVMsRUFBRVcsR0FBRyxDQUFDYSxZQUFZLEVBQUViLEdBQUcsQ0FBQztVQUFDSSxVQUFBLENBQUFFLElBQUE7VUFBQTtRQUFBO1VBQUFGLFVBQUEsQ0FBQUMsSUFBQTtVQUFBRCxVQUFBLENBQUFVLEVBQUEsR0FBQVYsVUFBQTtVQUFBLE1BRXZDQSxVQUFBLENBQUFVLEVBQUEsWUFBZTFDLEtBQUs7WUFBQWdDLFVBQUEsQ0FBQUUsSUFBQTtZQUFBO1VBQUE7VUFDdEJsQixRQUFRLENBQUFnQixVQUFBLENBQUFVLEVBQUksQ0FBQztVQUFDVixVQUFBLENBQUFFLElBQUE7VUFBQTtRQUFBO1VBQUEsTUFBQUYsVUFBQSxDQUFBVSxFQUFBO1FBQUE7UUFBQTtVQUFBLE9BQUFWLFVBQUEsQ0FBQVcsSUFBQTtNQUFBO0lBQUEsR0FBQWhCLFNBQUE7RUFBQSxDQUtuQjtFQUFBLE9BQUFOLGVBQUEsQ0FBQUMsS0FBQSxPQUFBQyxTQUFBO0FBQUE7QUFNRCxTQUFTcUIsK0JBQStCQSxDQUN0Q0MsUUFBZ0IsRUFDaEJDLFFBQWdCLEVBQ2hCO0VBQ0E7SUFBQSxJQUFBQyxJQUFBLEdBQUF2QixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQU8sU0FBQXNCLFFBQ0xqQyxJQUFtQixFQUNuQkMsUUFBeUM7TUFBQSxPQUFBUyxtQkFBQSxDQUFBSyxJQUFBLFVBQUFtQixTQUFBQyxTQUFBO1FBQUEsa0JBQUFBLFNBQUEsQ0FBQWpCLElBQUEsR0FBQWlCLFNBQUEsQ0FBQWhCLElBQUE7VUFBQTtZQUFBZ0IsU0FBQSxDQUFBakIsSUFBQTtZQUFBaUIsU0FBQSxDQUFBaEIsSUFBQTtZQUFBLE9BR2pDbkIsSUFBSSxDQUFDb0MsS0FBSyxDQUFDTixRQUFRLEVBQUVDLFFBQVEsQ0FBQztVQUFBO1lBQUEsSUFDL0IvQixJQUFJLENBQUN5QixXQUFXO2NBQUFVLFNBQUEsQ0FBQWhCLElBQUE7Y0FBQTtZQUFBO1lBQUEsTUFDYixJQUFJbEMsS0FBSyxDQUFDLG9DQUFvQyxDQUFDO1VBQUE7WUFFdkRnQixRQUFRLENBQUMsSUFBSSxFQUFFRCxJQUFJLENBQUN5QixXQUFXLENBQUM7WUFBQ1UsU0FBQSxDQUFBaEIsSUFBQTtZQUFBO1VBQUE7WUFBQWdCLFNBQUEsQ0FBQWpCLElBQUE7WUFBQWlCLFNBQUEsQ0FBQVIsRUFBQSxHQUFBUSxTQUFBO1lBQUEsTUFFN0JBLFNBQUEsQ0FBQVIsRUFBQSxZQUFlMUMsS0FBSztjQUFBa0QsU0FBQSxDQUFBaEIsSUFBQTtjQUFBO1lBQUE7WUFDdEJsQixRQUFRLENBQUFrQyxTQUFBLENBQUFSLEVBQUksQ0FBQztZQUFDUSxTQUFBLENBQUFoQixJQUFBO1lBQUE7VUFBQTtZQUFBLE1BQUFnQixTQUFBLENBQUFSLEVBQUE7VUFBQTtVQUFBO1lBQUEsT0FBQVEsU0FBQSxDQUFBUCxJQUFBO1FBQUE7TUFBQSxHQUFBSyxPQUFBO0lBQUEsQ0FLbkI7SUFBQSxpQkFBQUksR0FBQSxFQUFBQyxHQUFBO01BQUEsT0FBQU4sSUFBQSxDQUFBekIsS0FBQSxPQUFBQyxTQUFBO0lBQUE7RUFBQTtBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVMrQixZQUFZQSxDQUFDQyxHQUFjLEVBQWM7RUFDaEQsT0FBTztJQUNMQyxPQUFPLEVBQUUsS0FBSztJQUNkQyxNQUFNLEVBQUUsQ0FBQ0YsR0FBRztFQUNkLENBQUM7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTRyxrQkFBa0JBLENBQUNDLElBQVksRUFBUztFQUFBLElBQUFDLFNBQUE7RUFDL0MsTUFBTSxJQUFJNUQsS0FBSyxDQUFBNkQsdUJBQUEsQ0FBQUQsU0FBQSxrQkFBQUUsTUFBQSxDQUNFSCxJQUFJLDBDQUFBakUsSUFBQSxDQUFBa0UsU0FBQSxFQUFzQ0QsSUFBSSxpQkFDL0QsQ0FBQztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBLElBQU1JLGFBQWEsR0FBRyxHQUFHOztBQUV6QjtBQUNBO0FBQ0E7QUFDQSxXQUFhQyxVQUFVLDBCQUFBQyxhQUFBO0VBNEVyQjtBQUNGO0FBQ0E7RUFDRSxTQUFBRCxXQUFBLEVBQThDO0lBQUEsSUFBQUUsS0FBQTtJQUFBLElBQWxDQyxNQUEyQixHQUFBNUMsU0FBQSxDQUFBNkMsTUFBQSxRQUFBN0MsU0FBQSxRQUFBTixTQUFBLEdBQUFNLFNBQUEsTUFBRyxDQUFDLENBQUM7SUFBQThDLGVBQUEsT0FBQUwsVUFBQTtJQUMxQ0UsS0FBQSxHQUFBSSxVQUFBLE9BQUFOLFVBQUE7SUFBUU8sZUFBQSxDQUFBTCxLQUFBLGVBdkVhLENBQUMsQ0FBQztJQUFBSyxlQUFBLENBQUFMLEtBQUEsY0FFOEIsQ0FBQyxDQUFDO0lBczJCekQ7QUFDRjtBQUNBO0lBRkVLLGVBQUEsQ0FBQUwsS0FBQSxZQUdTQSxLQUFBLENBQUtNLE1BQU07SUEyWXBCO0FBQ0Y7QUFDQTtJQUZFRCxlQUFBLENBQUFMLEtBQUEsWUFHU0EsS0FBQSxDQUFLTyxPQUFPO0lBRXJCO0FBQ0Y7QUFDQTtJQUZFRixlQUFBLENBQUFMLEtBQUEsU0FHTUEsS0FBQSxDQUFLTyxPQUFPO0lBMktsQjtBQUNGO0FBQ0E7SUFGRUYsZUFBQSxDQUFBTCxLQUFBLGFBR1UsSUFBSXhGLE9BQU8sQ0FBQXdGLEtBQUssQ0FBQztJQXAyQ3pCLElBQ0VwRixRQUFRLEdBUU5xRixNQUFNLENBUlJyRixRQUFRO01BQ1JDLFdBQVcsR0FPVG9GLE1BQU0sQ0FQUnBGLFdBQVc7TUFDWEMsT0FBTyxHQU1MbUYsTUFBTSxDQU5SbkYsT0FBTztNQUNQb0QsTUFBTSxHQUtKK0IsTUFBTSxDQUxSL0IsTUFBTTtNQUNObEQsVUFBVSxHQUlSaUYsTUFBTSxDQUpSakYsVUFBVTtNQUNWRCxRQUFRLEdBR05rRixNQUFNLENBSFJsRixRQUFRO01BQ1J5RixRQUFRLEdBRU5QLE1BQU0sQ0FGUk8sUUFBUTtNQUNSQyxTQUFTLEdBQ1BSLE1BQU0sQ0FEUlEsU0FBUztJQUVYVCxLQUFBLENBQUtwRixRQUFRLEdBQUdBLFFBQVEsSUFBSUQsdUJBQXVCLENBQUNDLFFBQVE7SUFDNURvRixLQUFBLENBQUtuRixXQUFXLEdBQUdBLFdBQVcsSUFBSUYsdUJBQXVCLENBQUNFLFdBQVc7SUFFckUsSUFBSW1GLEtBQUEsQ0FBS1UsbUJBQW1CLENBQUMsQ0FBQyxFQUFFO01BQzlCLE1BQU0sSUFBSTVFLEtBQUssQ0FBQywrQ0FBK0MsQ0FBQztJQUNsRTtJQUVBa0UsS0FBQSxDQUFLbEYsT0FBTyxHQUFHQSxPQUFPLElBQUlILHVCQUF1QixDQUFDRyxPQUFPO0lBQ3pEa0YsS0FBQSxDQUFLOUIsTUFBTSxHQUNUQSxNQUFNLFlBQVlqRSxNQUFNLEdBQ3BCaUUsTUFBTSxHQUNOLElBQUlqRSxNQUFNLENBQUEwRyxhQUFBO01BQ1IvRixRQUFRLEVBQUVvRixLQUFBLENBQUtwRixRQUFRO01BQ3ZCNEYsUUFBUSxFQUFSQSxRQUFRO01BQ1JDLFNBQVMsRUFBVEE7SUFBUyxHQUNOdkMsTUFBTSxDQUNWLENBQUM7SUFDUixJQUFJMEMsU0FBUyxHQUFHWCxNQUFNLENBQUNXLFNBQVM7SUFDaEMsSUFBSSxDQUFDQSxTQUFTLElBQUlaLEtBQUEsQ0FBSzlCLE1BQU0sQ0FBQzJDLFFBQVEsRUFBRTtNQUN0Q0QsU0FBUyxHQUFHNUQsY0FBYztJQUM1QixDQUFDLE1BQUssSUFBRyxDQUFDNEQsU0FBUyxJQUFJLENBQUNaLEtBQUEsQ0FBSzlCLE1BQU0sQ0FBQzJDLFFBQVEsRUFBQztNQUMzQ0QsU0FBUyxHQUFHaEUsZ0JBQWdCO0lBQzlCO0lBQ0EsSUFBSWdFLFNBQVMsRUFBRTtNQUNiWixLQUFBLENBQUtjLGdCQUFnQixHQUFHLElBQUkxRyxzQkFBc0IsQ0FBQTRGLEtBQUEsRUFBT1ksU0FBUyxDQUFDO0lBQ3JFO0lBQ0FaLEtBQUEsQ0FBS2UsV0FBVyxHQUFHL0YsVUFBVSxJQUFJTCx1QkFBdUIsQ0FBQ0ssVUFBVTtJQUNuRWdGLEtBQUEsQ0FBS2dCLE9BQU8sR0FBR2pHLFFBQVEsR0FDbkIrRSxVQUFVLENBQUNrQixPQUFPLENBQUNDLGNBQWMsQ0FBQ2xHLFFBQVEsQ0FBQyxHQUMzQytFLFVBQVUsQ0FBQ2tCLE9BQU87SUFDdEJoQixLQUFBLENBQUtrQixTQUFTLEdBQUduRyxRQUFRO0lBQ3pCaUYsS0FBQSxDQUFLbUIsVUFBVSxHQUFHWCxRQUFRLEdBQ3RCLElBQUkxRyxnQkFBZ0IsQ0FBQzBHLFFBQVEsQ0FBQyxHQUM5QkMsU0FBUyxHQUNULElBQUkxRyxrQkFBa0IsQ0FBQzBHLFNBQVMsQ0FBQyxHQUNqQyxJQUFJN0csU0FBUyxDQUFDLENBQUM7SUFDbkJvRyxLQUFBLENBQUtvQixZQUFZLEdBQUduQixNQUFNLENBQUNvQixXQUFXO0lBQ3RDckIsS0FBQSxDQUFLc0IsS0FBSyxHQUFHLElBQUlwSCxLQUFLLENBQUMsQ0FBQztJQUN4QixJQUFNcUgsZ0JBQWdCLEdBQUcsU0FBbkJBLGdCQUFnQkEsQ0FBSUMsSUFBYTtNQUFBLE9BQ3JDQSxJQUFJLGVBQUE1QixNQUFBLENBQWU0QixJQUFJLElBQUssVUFBVTtJQUFBO0lBQ3hDLElBQU1DLFFBQVEsR0FBRzNCLFVBQVUsQ0FBQzRCLFNBQVMsQ0FBQ0QsUUFBUTtJQUM5Q3pCLEtBQUEsQ0FBS3lCLFFBQVEsR0FBR3pCLEtBQUEsQ0FBS3NCLEtBQUssQ0FBQ0ssb0JBQW9CLENBQUNGLFFBQVEsRUFBQXpCLEtBQUEsRUFBUTtNQUM5RDRCLEdBQUcsRUFBRUwsZ0JBQWdCO01BQ3JCTSxRQUFRLEVBQUU7SUFDWixDQUFDLENBQUM7SUFDRjdCLEtBQUEsQ0FBSzhCLFNBQVMsR0FBRzlCLEtBQUEsQ0FBS3NCLEtBQUssQ0FBQ0ssb0JBQW9CLENBQUNGLFFBQVEsRUFBQXpCLEtBQUEsRUFBUTtNQUMvRDRCLEdBQUcsRUFBRUwsZ0JBQWdCO01BQ3JCTSxRQUFRLEVBQUU7SUFDWixDQUFDLENBQUM7SUFDRjdCLEtBQUEsQ0FBSytCLFVBQVUsR0FBRy9CLEtBQUEsQ0FBS3NCLEtBQUssQ0FBQ0ssb0JBQW9CLENBQUNGLFFBQVEsRUFBQXpCLEtBQUEsRUFBUTtNQUNoRTRCLEdBQUcsRUFBRUwsZ0JBQWdCO01BQ3JCTSxRQUFRLEVBQUU7SUFDWixDQUFDLENBQVE7SUFDVDdCLEtBQUEsQ0FBS2dDLGVBQWUsR0FBR2hDLEtBQUEsQ0FBS3lCLFFBQVE7SUFDcEN6QixLQUFBLENBQUtpQyxnQkFBZ0IsR0FBR2pDLEtBQUEsQ0FBSzhCLFNBQVM7SUFDdEM5QixLQUFBLENBQUtrQyxpQkFBaUIsR0FBR2xDLEtBQUEsQ0FBSytCLFVBQVU7SUFDeEMsSUFBTUksY0FBYyxHQUFHckMsVUFBVSxDQUFDNEIsU0FBUyxDQUFDUyxjQUFjO0lBQzFEbkMsS0FBQSxDQUFLbUMsY0FBYyxHQUFHbkMsS0FBQSxDQUFLc0IsS0FBSyxDQUFDSyxvQkFBb0IsQ0FDbkRRLGNBQWMsRUFBQW5DLEtBQUEsRUFFZDtNQUFFNEIsR0FBRyxFQUFFLGdCQUFnQjtNQUFFQyxRQUFRLEVBQUU7SUFBVSxDQUMvQyxDQUFDO0lBQ0Q3QixLQUFBLENBQUtvQyxlQUFlLEdBQUdwQyxLQUFBLENBQUtzQixLQUFLLENBQUNLLG9CQUFvQixDQUNwRFEsY0FBYyxFQUFBbkMsS0FBQSxFQUVkO01BQUU0QixHQUFHLEVBQUUsZ0JBQWdCO01BQUVDLFFBQVEsRUFBRTtJQUFNLENBQzNDLENBQUM7SUFDRDdCLEtBQUEsQ0FBS3FDLGdCQUFnQixHQUFHckMsS0FBQSxDQUFLc0IsS0FBSyxDQUFDSyxvQkFBb0IsQ0FDckRRLGNBQWMsRUFBQW5DLEtBQUEsRUFFZDtNQUFFNEIsR0FBRyxFQUFFLGdCQUFnQjtNQUFFQyxRQUFRLEVBQUU7SUFBWSxDQUNqRCxDQUFRO0lBQ1IsSUFDRXZELFdBQVcsR0FLVDJCLE1BQU0sQ0FMUjNCLFdBQVc7TUFDWEwsWUFBWSxHQUlWZ0MsTUFBTSxDQUpSaEMsWUFBWTtNQUNacUUsU0FBUyxHQUdQckMsTUFBTSxDQUhScUMsU0FBUztNQUNUQyxTQUFTLEdBRVB0QyxNQUFNLENBRlJzQyxTQUFTO01BQ1RDLGFBQWEsR0FDWHZDLE1BQU0sQ0FEUnVDLGFBQWE7SUFFZnhDLEtBQUEsQ0FBSzVCLFVBQVUsQ0FBQztNQUNkRSxXQUFXLEVBQVhBLFdBQVc7TUFDWEwsWUFBWSxFQUFaQSxZQUFZO01BQ1pwRCxXQUFXLEVBQVhBLFdBQVc7TUFDWHlILFNBQVMsRUFBVEEsU0FBUztNQUNUQyxTQUFTLEVBQVRBLFNBQVM7TUFDVEMsYUFBYSxFQUFiQTtJQUNGLENBQUMsQ0FBQztJQUVGN0ksT0FBTyxDQUFDOEksSUFBSSxDQUFDLGdCQUFnQixFQUFBekMsS0FBTSxDQUFDO0lBQUMsT0FBQUEsS0FBQTtFQUN2Qzs7RUFFQTtFQUFBMEMsU0FBQSxDQUFBNUMsVUFBQSxFQUFBQyxhQUFBO0VBQUEsT0FBQTRDLFlBQUEsQ0FBQTdDLFVBQUE7SUFBQThCLEdBQUE7SUFBQWdCLEdBQUE7SUFsS0E7QUFDRjtBQUNBO0FBQ0E7O0lBR0U7O0lBUUE7O0lBSUE7SUFDQTtJQUNBLFNBQUFBLElBQUEsRUFBOEI7TUFDNUIsT0FBT3BELGtCQUFrQixDQUFDLFdBQVcsQ0FBQztJQUN4QztFQUFDO0lBQUFvQyxHQUFBO0lBQUFnQixHQUFBLEVBRUQsU0FBQUEsSUFBQSxFQUFvQjtNQUNsQixPQUFPcEQsa0JBQWtCLENBQUMsTUFBTSxDQUFDO0lBQ25DO0VBQUM7SUFBQW9DLEdBQUE7SUFBQWdCLEdBQUEsRUFFRCxTQUFBQSxJQUFBLEVBQW9CO01BQ2xCLE9BQU9wRCxrQkFBa0IsQ0FBQyxNQUFNLENBQUM7SUFDbkM7RUFBQztJQUFBb0MsR0FBQTtJQUFBZ0IsR0FBQSxFQUVELFNBQUFBLElBQUEsRUFBdUI7TUFDckIsT0FBT3BELGtCQUFrQixDQUFDLE9BQU8sQ0FBQztJQUNwQztFQUFDO0lBQUFvQyxHQUFBO0lBQUFnQixHQUFBLEVBRUQsU0FBQUEsSUFBQSxFQUEwQjtNQUN4QixPQUFPcEQsa0JBQWtCLENBQUMsU0FBUyxDQUFDO0lBQ3RDO0VBQUM7SUFBQW9DLEdBQUE7SUFBQWdCLEdBQUEsRUFFRCxTQUFBQSxJQUFBLEVBQTRCO01BQzFCLE9BQU9wRCxrQkFBa0IsQ0FBQyxVQUFVLENBQUM7SUFDdkM7RUFBQztJQUFBb0MsR0FBQTtJQUFBZ0IsR0FBQSxFQUVELFNBQUFBLElBQUEsRUFBdUI7TUFDckIsT0FBT3BELGtCQUFrQixDQUFDLE1BQU0sQ0FBQztJQUNuQztFQUFDO0lBQUFvQyxHQUFBO0lBQUFnQixHQUFBLEVBRUQsU0FBQUEsSUFBQSxFQUE4QjtNQUM1QixPQUFPcEQsa0JBQWtCLENBQUMsV0FBVyxDQUFDO0lBQ3hDO0VBQUM7SUFBQW9DLEdBQUE7SUFBQWdCLEdBQUEsRUFFRCxTQUFBQSxJQUFBLEVBQTBCO01BQ3hCLE9BQU9wRCxrQkFBa0IsQ0FBQyxTQUFTLENBQUM7SUFDdEM7RUFBQztJQUFBb0MsR0FBQTtJQUFBaUIsS0FBQSxFQTZHRCxTQUFBekUsVUFBVUEsQ0FBQzBFLE9BQW1DLEVBQUU7TUFBQSxJQUFBQyxTQUFBO01BQzlDLElBQ0V6RSxXQUFXLEdBT1R3RSxPQUFPLENBUFR4RSxXQUFXO1FBQ1hMLFlBQVksR0FNVjZFLE9BQU8sQ0FOVDdFLFlBQVk7UUFDWnBELFdBQVcsR0FLVGlJLE9BQU8sQ0FMVGpJLFdBQVc7UUFDWHlILFNBQVMsR0FJUFEsT0FBTyxDQUpUUixTQUFTO1FBQ1RDLFNBQVMsR0FHUE8sT0FBTyxDQUhUUCxTQUFTO1FBQ1RDLGFBQWEsR0FFWE0sT0FBTyxDQUZUTixhQUFhO1FBQ2I3RSxRQUFRLEdBQ05tRixPQUFPLENBRFRuRixRQUFRO01BRVYsSUFBSSxDQUFDOUMsV0FBVyxHQUFHMEgsU0FBUyxHQUN4QmhHLHNCQUFBLENBQUF3RyxTQUFBLEdBQUFSLFNBQVMsQ0FBQzNHLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBQUosSUFBQSxDQUFBdUgsU0FBQSxFQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUMxQ25JLFdBQVcsSUFBSSxJQUFJLENBQUNBLFdBQVc7TUFDbkMsSUFBSSxDQUFDeUQsV0FBVyxHQUFHZ0UsU0FBUyxJQUFJaEUsV0FBVyxJQUFJLElBQUksQ0FBQ0EsV0FBVztNQUMvRCxJQUFJLENBQUNMLFlBQVksR0FBR0EsWUFBWSxJQUFJLElBQUksQ0FBQ0EsWUFBWTtNQUNyRCxJQUFJLElBQUksQ0FBQ0EsWUFBWSxJQUFJLENBQUMsSUFBSSxDQUFDNkMsZ0JBQWdCLEVBQUU7UUFDL0MsTUFBTSxJQUFJaEYsS0FBSyxDQUNiLGtGQUNGLENBQUM7TUFDSDtNQUNBLElBQU1tSCxtQkFBbUIsR0FDdkJULGFBQWEsSUFBSW5ILGtCQUFrQixDQUFDbUgsYUFBYSxDQUFDO01BQ3BELElBQUlTLG1CQUFtQixFQUFFO1FBQ3ZCLElBQUksQ0FBQzNFLFdBQVcsR0FBRzJFLG1CQUFtQixDQUFDQyxNQUFNLENBQUNDLFVBQVU7UUFDeEQsSUFBSXRKLGVBQWUsQ0FBQ3VKLFNBQVMsRUFBRTtVQUM3QixJQUFJLENBQUNqQyxVQUFVLEdBQUcsSUFBSXRILGVBQWUsQ0FBQ29KLG1CQUFtQixDQUFDO1FBQzVEO01BQ0Y7TUFDQSxJQUFJLENBQUN0RixRQUFRLEdBQUdBLFFBQVEsSUFBSSxJQUFJLENBQUNBLFFBQVE7TUFDekMsSUFBSSxDQUFDMEYsWUFBWSxHQUFHZixTQUFTLEdBQUcsTUFBTSxHQUFHLFFBQVE7TUFDakQsSUFBSSxDQUFDZ0IsY0FBYyxDQUFDLENBQUM7SUFDdkI7O0lBRUE7RUFBQTtJQUFBMUIsR0FBQTtJQUFBaUIsS0FBQSxFQUNBLFNBQUFVLGFBQWFBLENBQUEsRUFBRztNQUNkLElBQUksQ0FBQ2pGLFdBQVcsR0FBRyxJQUFJO01BQ3ZCLElBQUksQ0FBQ0wsWUFBWSxHQUFHLElBQUk7TUFDeEIsSUFBSSxDQUFDcEQsV0FBVyxHQUFHRix1QkFBdUIsQ0FBQ0UsV0FBVztNQUN0RCxJQUFJLENBQUM4QyxRQUFRLEdBQUcsSUFBSTtNQUNwQixJQUFJLENBQUMwRixZQUFZLEdBQUcsSUFBSTtJQUMxQjs7SUFFQTtFQUFBO0lBQUF6QixHQUFBO0lBQUFpQixLQUFBLEVBQ0EsU0FBQVMsY0FBY0EsQ0FBQSxFQUFHO01BQUEsSUFBQUUsTUFBQTtNQUNmLElBQUksQ0FBQ0MsU0FBUyxHQUFHLENBQUMsQ0FBQztNQUNuQixJQUFJLENBQUNDLFFBQVEsR0FBRyxDQUFDLENBQUM7TUFDbEI7TUFDQSxJQUFJLENBQUNwQyxLQUFLLENBQUNxQyxLQUFLLENBQUMsQ0FBQztNQUNsQixJQUFJLENBQUNyQyxLQUFLLENBQUNzQixHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQ2dCLGtCQUFrQixDQUFDLE9BQU8sQ0FBQztNQUM1RCxJQUFJLENBQUN0QyxLQUFLLENBQUNzQixHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQ2lCLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBQUMsS0FBQSxFQUFnQjtRQUFBLElBQWJDLE1BQU0sR0FBQUQsS0FBQSxDQUFOQyxNQUFNO1FBQ3BELElBQUlBLE1BQU0sRUFBRTtVQUFBLElBQUFDLFNBQUEsR0FBQUMsMEJBQUEsQ0FDT0YsTUFBTSxDQUFDTCxRQUFRO1lBQUFRLEtBQUE7VUFBQTtZQUFoQyxLQUFBRixTQUFBLENBQUFHLENBQUEsTUFBQUQsS0FBQSxHQUFBRixTQUFBLENBQUFJLENBQUEsSUFBQUMsSUFBQSxHQUFrQztjQUFBLElBQXZCQyxFQUFFLEdBQUFKLEtBQUEsQ0FBQXJCLEtBQUE7Y0FDWFcsTUFBSSxDQUFDZSxPQUFPLENBQUNELEVBQUUsQ0FBQzdFLElBQUksQ0FBQztZQUN2QjtVQUFDLFNBQUFKLEdBQUE7WUFBQTJFLFNBQUEsQ0FBQVEsQ0FBQSxDQUFBbkYsR0FBQTtVQUFBO1lBQUEyRSxTQUFBLENBQUFTLENBQUE7VUFBQTtRQUNIO01BQ0YsQ0FBQyxDQUFDO01BQ0Y7QUFDSjtBQUNBO0FBQ0E7QUFDQTtJQUNFOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFQRTtJQUFBN0MsR0FBQTtJQUFBaUIsS0FBQTtNQUFBLElBQUE2QixVQUFBLEdBQUFwSCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBUUEsU0FBQW1ILFNBQ0VDLFlBQXFFO1FBQUEsSUFBQUMsU0FBQTtRQUFBLElBQUFDLE1BQUE7VUFBQXBILEdBQUE7VUFBQUMsUUFBQTtVQUFBb0gsTUFBQSxHQUFBMUgsU0FBQTtRQUFBLE9BQUFFLG1CQUFBLENBQUFLLElBQUEsVUFBQW9ILFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBbEgsSUFBQSxHQUFBa0gsU0FBQSxDQUFBakgsSUFBQTtZQUFBO2NBQ3JFOEcsTUFBa0MsR0FBQUMsTUFBQSxDQUFBN0UsTUFBQSxRQUFBNkUsTUFBQSxRQUFBaEksU0FBQSxHQUFBZ0ksTUFBQSxNQUFHLENBQUMsQ0FBQztjQUFBRSxTQUFBLENBQUFqSCxJQUFBO2NBQUEsT0FFckIsSUFBSSxDQUFDRSxNQUFNLENBQUNnSCxZQUFZLENBQUNOLFlBQVksRUFBRUUsTUFBTSxDQUFDO1lBQUE7Y0FBMURwSCxHQUFHLEdBQUF1SCxTQUFBLENBQUE5RyxJQUFBO2NBQ0hSLFFBQVEsR0FBR3hCLFVBQVUsQ0FBQ3VCLEdBQUcsQ0FBQ2YsRUFBRSxDQUFDO2NBQ25DLElBQUksQ0FBQ3lCLFVBQVUsQ0FBQztnQkFDZHZELFdBQVcsRUFBRTZDLEdBQUcsQ0FBQ1csWUFBWTtnQkFDN0JDLFdBQVcsRUFBRVosR0FBRyxDQUFDYSxZQUFZO2dCQUM3Qk4sWUFBWSxFQUFFUCxHQUFHLENBQUN5SCxhQUFhO2dCQUMvQnhILFFBQVEsRUFBUkE7Y0FDRixDQUFDLENBQUM7Y0FDRixJQUFJLENBQUNxRCxPQUFPLENBQUNvRSxLQUFLLENBQUF6Rix1QkFBQSxDQUFBa0YsU0FBQSxtQ0FBQWpGLE1BQUEsQ0FDZ0JqQyxRQUFRLENBQUNoQixFQUFFLGtCQUFBbkIsSUFBQSxDQUFBcUosU0FBQSxFQUFjbEgsUUFBUSxDQUFDakIsY0FBYyxDQUNsRixDQUFDO2NBQUMsT0FBQXVJLFNBQUEsQ0FBQUksTUFBQSxXQUNLMUgsUUFBUTtZQUFBO1lBQUE7Y0FBQSxPQUFBc0gsU0FBQSxDQUFBeEcsSUFBQTtVQUFBO1FBQUEsR0FBQWtHLFFBQUE7TUFBQSxDQUNoQjtNQUFBLFNBaEJLVyxTQUFTQSxDQUFBQyxHQUFBO1FBQUEsT0FBQWIsVUFBQSxDQUFBdEgsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFUaUksU0FBUztJQUFBO0lBa0JmO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQTFELEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBMkMsTUFBQSxHQUFBbEksaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUFpSSxTQUFZOUcsUUFBZ0IsRUFBRUMsUUFBZ0I7UUFBQSxJQUFBOEcsV0FBQTtRQUFBLE9BQUFuSSxtQkFBQSxDQUFBSyxJQUFBLFVBQUErSCxVQUFBQyxTQUFBO1VBQUEsa0JBQUFBLFNBQUEsQ0FBQTdILElBQUEsR0FBQTZILFNBQUEsQ0FBQTVILElBQUE7WUFBQTtjQUM1QyxJQUFJLENBQUM4QyxnQkFBZ0IsR0FBRyxJQUFJMUcsc0JBQXNCLENBQ2hELElBQUksRUFDSnNFLCtCQUErQixDQUFDQyxRQUFRLEVBQUVDLFFBQVEsQ0FDcEQsQ0FBQztjQUFDLE1BQ0UsQ0FBQThHLFdBQUEsT0FBSSxDQUFDeEgsTUFBTSxjQUFBd0gsV0FBQSxlQUFYQSxXQUFBLENBQWE3RSxRQUFRLElBQUksSUFBSSxDQUFDM0MsTUFBTSxDQUFDMkgsWUFBWTtnQkFBQUQsU0FBQSxDQUFBNUgsSUFBQTtnQkFBQTtjQUFBO2NBQUEsT0FBQTRILFNBQUEsQ0FBQVAsTUFBQSxXQUM1QyxJQUFJLENBQUNTLGFBQWEsQ0FBQ25ILFFBQVEsRUFBRUMsUUFBUSxDQUFDO1lBQUE7Y0FBQSxPQUFBZ0gsU0FBQSxDQUFBUCxNQUFBLFdBRXhDLElBQUksQ0FBQ1UsV0FBVyxDQUFDcEgsUUFBUSxFQUFFQyxRQUFRLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQWdILFNBQUEsQ0FBQW5ILElBQUE7VUFBQTtRQUFBLEdBQUFnSCxRQUFBO01BQUEsQ0FDNUM7TUFBQSxTQVRLeEcsS0FBS0EsQ0FBQStHLEdBQUEsRUFBQUMsR0FBQTtRQUFBLE9BQUFULE1BQUEsQ0FBQXBJLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBTDRCLEtBQUs7SUFBQTtJQVdYO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQTJDLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBcUQsYUFBQSxHQUFBNUksaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUEySSxTQUFvQnhILFFBQWdCLEVBQUVDLFFBQWdCO1FBQUEsSUFBQXdILFNBQUE7UUFBQSxJQUFBMUksR0FBQSxFQUFBQyxRQUFBO1FBQUEsT0FBQUosbUJBQUEsQ0FBQUssSUFBQSxVQUFBeUksVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUF2SSxJQUFBLEdBQUF1SSxTQUFBLENBQUF0SSxJQUFBO1lBQUE7Y0FBQXNJLFNBQUEsQ0FBQXRJLElBQUE7Y0FBQSxPQUNsQyxJQUFJLENBQUNFLE1BQU0sQ0FBQ3FJLFlBQVksQ0FBQzVILFFBQVEsRUFBRUMsUUFBUSxDQUFDO1lBQUE7Y0FBeERsQixHQUFHLEdBQUE0SSxTQUFBLENBQUFuSSxJQUFBO2NBQ0hSLFFBQVEsR0FBR3hCLFVBQVUsQ0FBQ3VCLEdBQUcsQ0FBQ2YsRUFBRSxDQUFDO2NBQ25DLElBQUksQ0FBQ3lCLFVBQVUsQ0FBQztnQkFDZHZELFdBQVcsRUFBRTZDLEdBQUcsQ0FBQ1csWUFBWTtnQkFDN0JDLFdBQVcsRUFBRVosR0FBRyxDQUFDYSxZQUFZO2dCQUM3QlosUUFBUSxFQUFSQTtjQUNGLENBQUMsQ0FBQztjQUNGLElBQUksQ0FBQ3FELE9BQU8sQ0FBQ3dGLElBQUksQ0FBQTdHLHVCQUFBLENBQUF5RyxTQUFBLG1DQUFBeEcsTUFBQSxDQUNpQmpDLFFBQVEsQ0FBQ2hCLEVBQUUsa0JBQUFuQixJQUFBLENBQUE0SyxTQUFBLEVBQWN6SSxRQUFRLENBQUNqQixjQUFjLENBQ2xGLENBQUM7Y0FBQyxPQUFBNEosU0FBQSxDQUFBakIsTUFBQSxXQUNLMUgsUUFBUTtZQUFBO1lBQUE7Y0FBQSxPQUFBMkksU0FBQSxDQUFBN0gsSUFBQTtVQUFBO1FBQUEsR0FBQTBILFFBQUE7TUFBQSxDQUNoQjtNQUFBLFNBWktMLGFBQWFBLENBQUFXLEdBQUEsRUFBQUMsR0FBQTtRQUFBLE9BQUFSLGFBQUEsQ0FBQTlJLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBYnlJLGFBQWE7SUFBQTtJQWNuQjtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFMRTtFQUFBO0lBQUFsRSxHQUFBO0lBQUFpQixLQUFBO01BQUEsSUFBQThELFlBQUEsR0FBQXJKLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FNQSxTQUFBb0osU0FBa0JqSSxRQUFnQixFQUFFQyxRQUFnQjtRQUFBLElBQUFpSSxVQUFBLEVBQUFDLFVBQUE7UUFBQSxJQUFBQyxJQUFBLEVBQUFDLGlCQUFBLEVBQUFDLFFBQUEsRUFBQUMsQ0FBQSxFQUFBQyxXQUFBLEVBQUE1RSxTQUFBLEVBQUFELFNBQUEsRUFBQThFLE1BQUEsRUFBQTFLLGNBQUEsRUFBQTJLLEtBQUEsRUFBQTFKLFFBQUE7UUFBQSxPQUFBSixtQkFBQSxDQUFBSyxJQUFBLFVBQUEwSixVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXhKLElBQUEsR0FBQXdKLFVBQUEsQ0FBQXZKLElBQUE7WUFBQTtjQUNsRCxJQUFJLENBQUNnRCxPQUFPLENBQUN3RyxJQUFJLENBQ2YsK0ZBQStGLEdBQy9GLHVEQUF1RCxHQUN2RCw4SUFDRixDQUFDO2NBQUMsTUFDRSxDQUFDN0ksUUFBUSxJQUFJLENBQUNDLFFBQVE7Z0JBQUEySSxVQUFBLENBQUF2SixJQUFBO2dCQUFBO2NBQUE7Y0FBQSxPQUFBdUosVUFBQSxDQUFBbEMsTUFBQSxXQUNqQm9DLFFBQUEsQ0FBUUMsTUFBTSxDQUFDLElBQUk1TCxLQUFLLENBQUMsNEJBQTRCLENBQUMsQ0FBQztZQUFBO2NBRTFEaUwsSUFBSSxHQUFHLENBQ1gsb0VBQW9FLEVBQ3BFLGNBQWMsRUFDZCxXQUFXLEVBQ1gsNkNBQTZDLGVBQUFuSCxNQUFBLENBQ2hDM0UsR0FBRyxDQUFDMEQsUUFBUSxDQUFDLCtCQUFBaUIsTUFBQSxDQUNiM0UsR0FBRyxDQUFDMkQsUUFBUSxDQUFDLGtCQUMxQixVQUFVLEVBQ1YsWUFBWSxFQUNaLGdCQUFnQixDQUNqQixDQUFDb0UsSUFBSSxDQUFDLEVBQUUsQ0FBQztjQUVKZ0UsaUJBQWlCLEdBQUcsQ0FDeEIsSUFBSSxDQUFDcE0sUUFBUSxFQUNiLGlCQUFpQixFQUNqQixJQUFJLENBQUNFLE9BQU8sQ0FDYixDQUFDa0ksSUFBSSxDQUFDLEdBQUcsQ0FBQztjQUFBdUUsVUFBQSxDQUFBdkosSUFBQTtjQUFBLE9BQ1ksSUFBSSxDQUFDbUQsVUFBVSxDQUFDd0csV0FBVyxDQUFDO2dCQUNqREMsTUFBTSxFQUFFLE1BQU07Z0JBQ2R4TCxHQUFHLEVBQUU0SyxpQkFBaUI7Z0JBQ3RCRCxJQUFJLEVBQUpBLElBQUk7Z0JBQ0pjLE9BQU8sRUFBRTtrQkFDUCxjQUFjLEVBQUUsVUFBVTtrQkFDMUJDLFVBQVUsRUFBRTtnQkFDZDtjQUNGLENBQUMsQ0FBQztZQUFBO2NBUkliLFFBQVEsR0FBQU0sVUFBQSxDQUFBcEosSUFBQTtjQUFBLE1BVVY4SSxRQUFRLENBQUNjLFVBQVUsSUFBSSxHQUFHO2dCQUFBUixVQUFBLENBQUF2SixJQUFBO2dCQUFBO2NBQUE7Y0FDNUJrSixDQUFDLEdBQUdELFFBQVEsQ0FBQ0YsSUFBSSxDQUFDaUIsS0FBSyxDQUFDLHFDQUFxQyxDQUFDO2NBQ3hEYixXQUFXLEdBQUdELENBQUMsSUFBSUEsQ0FBQyxDQUFDLENBQUMsQ0FBQztjQUFBLE1BQ3ZCLElBQUlwTCxLQUFLLENBQUNxTCxXQUFXLElBQUlGLFFBQVEsQ0FBQ0YsSUFBSSxDQUFDO1lBQUE7Y0FBQSxLQVUzQ0UsUUFBUSxDQUFDRixJQUFJLENBQUNpQixLQUFLLENBQUMsMkNBQTJDLENBQUM7Z0JBQUFULFVBQUEsQ0FBQXZKLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE1BQzVELElBQUlsQyxLQUFLLENBQUMsd0RBQXdELENBQUM7WUFBQTtjQUUzRSxJQUFJLENBQUNrRixPQUFPLENBQUNvRSxLQUFLLG9CQUFBeEYsTUFBQSxDQUFvQnFILFFBQVEsQ0FBQ0YsSUFBSSxDQUFFLENBQUM7Y0FDdERHLENBQUMsR0FBR0QsUUFBUSxDQUFDRixJQUFJLENBQUNpQixLQUFLLENBQUMsaUNBQWlDLENBQUM7Y0FDcER6RixTQUFTLEdBQUcyRSxDQUFDLElBQUlBLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FDM0JBLENBQUMsR0FBR0QsUUFBUSxDQUFDRixJQUFJLENBQUNpQixLQUFLLENBQUMsaUNBQWlDLENBQUM7Y0FDcEQxRixTQUFTLEdBQUc0RSxDQUFDLElBQUlBLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FDM0JBLENBQUMsR0FBR0QsUUFBUSxDQUFDRixJQUFJLENBQUNpQixLQUFLLENBQUMsMkJBQTJCLENBQUM7Y0FDOUNaLE1BQU0sR0FBR0YsQ0FBQyxJQUFJQSxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQ3hCQSxDQUFDLEdBQUdELFFBQVEsQ0FBQ0YsSUFBSSxDQUFDaUIsS0FBSyxDQUFDLDJDQUEyQyxDQUFDO2NBQzlEdEwsY0FBYyxHQUFHd0ssQ0FBQyxJQUFJQSxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQUEsTUFDNUIsQ0FBQzNFLFNBQVMsSUFBSSxDQUFDRCxTQUFTLElBQUksQ0FBQzhFLE1BQU0sSUFBSSxDQUFDMUssY0FBYztnQkFBQTZLLFVBQUEsQ0FBQXZKLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE1BQ2xELElBQUlsQyxLQUFLLENBQ2IsMkRBQ0YsQ0FBQztZQUFBO2NBRUd1TCxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUN6TSxRQUFRLEVBQUUsSUFBSSxFQUFFOEIsY0FBYyxFQUFFMEssTUFBTSxDQUFDLENBQUNwRSxJQUFJLENBQUMsR0FBRyxDQUFDO2NBQy9EckYsUUFBUSxHQUFHO2dCQUFFaEIsRUFBRSxFQUFFeUssTUFBTTtnQkFBRTFLLGNBQWMsRUFBZEEsY0FBYztnQkFBRU4sR0FBRyxFQUFFaUw7Y0FBTSxDQUFDO2NBQzNELElBQUksQ0FBQ2pKLFVBQVUsQ0FBQztnQkFDZG1FLFNBQVMsRUFBRWhHLHNCQUFBLENBQUFzSyxVQUFBLEdBQUF0RSxTQUFTLENBQUMzRyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUFKLElBQUEsQ0FBQXFMLFVBQUEsRUFBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM3RCxJQUFJLENBQUMsR0FBRyxDQUFDO2dCQUNyRFYsU0FBUyxFQUFUQSxTQUFTO2dCQUNUM0UsUUFBUSxFQUFSQTtjQUNGLENBQUMsQ0FBQztjQUNGLElBQUksQ0FBQ3FELE9BQU8sQ0FBQ3dGLElBQUksQ0FBQTdHLHVCQUFBLENBQUFtSCxVQUFBLG1DQUFBbEgsTUFBQSxDQUNpQndILE1BQU0sa0JBQUE1TCxJQUFBLENBQUFzTCxVQUFBLEVBQWNwSyxjQUFjLENBQ3BFLENBQUM7Y0FBQyxPQUFBNkssVUFBQSxDQUFBbEMsTUFBQSxXQUNLMUgsUUFBUTtZQUFBO1lBQUE7Y0FBQSxPQUFBNEosVUFBQSxDQUFBOUksSUFBQTtVQUFBO1FBQUEsR0FBQW1JLFFBQUE7TUFBQSxDQUNoQjtNQUFBLFNBN0VLYixXQUFXQSxDQUFBa0MsSUFBQSxFQUFBQyxJQUFBO1FBQUEsT0FBQXZCLFlBQUEsQ0FBQXZKLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBWDBJLFdBQVc7SUFBQTtJQStFakI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBbkUsR0FBQTtJQUFBaUIsS0FBQTtNQUFBLElBQUFzRixPQUFBLEdBQUE3SyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQTRLLFNBQWFDLE1BQWdCO1FBQUEsT0FBQTlLLG1CQUFBLENBQUFLLElBQUEsVUFBQTBLLFVBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBeEssSUFBQSxHQUFBd0ssVUFBQSxDQUFBdkssSUFBQTtZQUFBO2NBQzNCLElBQUksQ0FBQzhDLGdCQUFnQixHQUFHL0QsU0FBUztjQUFDLE1BQzlCLElBQUksQ0FBQ3NHLFlBQVksS0FBSyxRQUFRO2dCQUFBa0YsVUFBQSxDQUFBdkssSUFBQTtnQkFBQTtjQUFBO2NBQUEsT0FBQXVLLFVBQUEsQ0FBQWxELE1BQUEsV0FDekIsSUFBSSxDQUFDbUQsY0FBYyxDQUFDSCxNQUFNLENBQUM7WUFBQTtjQUFBLE9BQUFFLFVBQUEsQ0FBQWxELE1BQUEsV0FFN0IsSUFBSSxDQUFDb0QsWUFBWSxDQUFDSixNQUFNLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQUUsVUFBQSxDQUFBOUosSUFBQTtVQUFBO1FBQUEsR0FBQTJKLFFBQUE7TUFBQSxDQUNqQztNQUFBLFNBTktNLE1BQU1BLENBQUFDLElBQUE7UUFBQSxPQUFBUixPQUFBLENBQUEvSyxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQU5xTCxNQUFNO0lBQUE7SUFRWjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUE5RyxHQUFBO0lBQUFpQixLQUFBO01BQUEsSUFBQStGLGNBQUEsR0FBQXRMLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBcUwsU0FBcUJSLE1BQWdCO1FBQUEsSUFBQVMsS0FBQTtRQUFBLE9BQUF2TCxtQkFBQSxDQUFBSyxJQUFBLFVBQUFtTCxVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQWpMLElBQUEsR0FBQWlMLFVBQUEsQ0FBQWhMLElBQUE7WUFBQTtjQUM3QjhLLEtBQUssR0FBR1QsTUFBTSxHQUFHLElBQUksQ0FBQ3BLLFlBQVksR0FBRyxJQUFJLENBQUNLLFdBQVc7Y0FBQSxLQUN2RHdLLEtBQUs7Z0JBQUFFLFVBQUEsQ0FBQWhMLElBQUE7Z0JBQUE7Y0FBQTtjQUFBZ0wsVUFBQSxDQUFBaEwsSUFBQTtjQUFBLE9BQ0QsSUFBSSxDQUFDRSxNQUFNLENBQUMrSyxXQUFXLENBQUNILEtBQUssQ0FBQztZQUFBO2NBRXRDO2NBQ0EsSUFBSSxDQUFDdkYsYUFBYSxDQUFDLENBQUM7Y0FDcEIsSUFBSSxDQUFDRCxjQUFjLENBQUMsQ0FBQztZQUFDO1lBQUE7Y0FBQSxPQUFBMEYsVUFBQSxDQUFBdkssSUFBQTtVQUFBO1FBQUEsR0FBQW9LLFFBQUE7TUFBQSxDQUN2QjtNQUFBLFNBUktMLGNBQWNBLENBQUFVLElBQUE7UUFBQSxPQUFBTixjQUFBLENBQUF4TCxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQWRtTCxjQUFjO0lBQUE7SUFVcEI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBNUcsR0FBQTtJQUFBaUIsS0FBQTtNQUFBLElBQUFzRyxhQUFBLEdBQUE3TCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQTRMLFNBQW1CZixNQUFnQjtRQUFBLElBQUFnQixVQUFBO1FBQUEsSUFBQXRDLElBQUEsRUFBQUUsUUFBQSxFQUFBQyxDQUFBLEVBQUFDLFdBQUE7UUFBQSxPQUFBNUosbUJBQUEsQ0FBQUssSUFBQSxVQUFBMEwsVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUF4TCxJQUFBLEdBQUF3TCxVQUFBLENBQUF2TCxJQUFBO1lBQUE7Y0FDM0IrSSxJQUFJLEdBQUcsQ0FDWCxvRUFBb0UsRUFDcEUsYUFBYSxFQUNiLHFEQUFxRCxnQkFBQW5ILE1BQUEsQ0FDdkMzRSxHQUFHLENBQ2ZvTixNQUFNLEdBQUcsSUFBSSxDQUFDcEssWUFBWSxHQUFHLElBQUksQ0FBQ0ssV0FDcEMsQ0FBQyxtQkFDRCxrQkFBa0IsRUFDbEIsY0FBYyxFQUNkLFdBQVcsRUFDWCwrQ0FBK0MsRUFDL0MsWUFBWSxFQUNaLGdCQUFnQixDQUNqQixDQUFDMEUsSUFBSSxDQUFDLEVBQUUsQ0FBQztjQUFBdUcsVUFBQSxDQUFBdkwsSUFBQTtjQUFBLE9BQ2EsSUFBSSxDQUFDbUQsVUFBVSxDQUFDd0csV0FBVyxDQUFDO2dCQUNqREMsTUFBTSxFQUFFLE1BQU07Z0JBQ2R4TCxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUN2QixXQUFXLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxDQUFDQyxPQUFPLENBQUMsQ0FBQ2tJLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQ2xFK0QsSUFBSSxFQUFKQSxJQUFJO2dCQUNKYyxPQUFPLEVBQUU7a0JBQ1AsY0FBYyxFQUFFLFVBQVU7a0JBQzFCQyxVQUFVLEVBQUU7Z0JBQ2Q7Y0FDRixDQUFDLENBQUM7WUFBQTtjQVJJYixRQUFRLEdBQUFzQyxVQUFBLENBQUFwTCxJQUFBO2NBU2QsSUFBSSxDQUFDNkMsT0FBTyxDQUFDb0UsS0FBSyxDQUFBekYsdUJBQUEsQ0FBQTBKLFVBQUEsd0JBQUF6SixNQUFBLENBQ0txSCxRQUFRLENBQUNjLFVBQVUsb0JBQUF2TSxJQUFBLENBQUE2TixVQUFBLEVBQWdCcEMsUUFBUSxDQUFDRixJQUFJLENBQ3ZFLENBQUM7Y0FBQyxNQUNFRSxRQUFRLENBQUNjLFVBQVUsSUFBSSxHQUFHO2dCQUFBd0IsVUFBQSxDQUFBdkwsSUFBQTtnQkFBQTtjQUFBO2NBQ3RCa0osQ0FBQyxHQUFHRCxRQUFRLENBQUNGLElBQUksQ0FBQ2lCLEtBQUssQ0FBQyxxQ0FBcUMsQ0FBQztjQUM5RGIsV0FBVyxHQUFHRCxDQUFDLElBQUlBLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FBQSxNQUN2QixJQUFJcEwsS0FBSyxDQUFDcUwsV0FBVyxJQUFJRixRQUFRLENBQUNGLElBQUksQ0FBQztZQUFBO2NBRS9DO2NBQ0EsSUFBSSxDQUFDeEQsYUFBYSxDQUFDLENBQUM7Y0FDcEIsSUFBSSxDQUFDRCxjQUFjLENBQUMsQ0FBQztZQUFDO1lBQUE7Y0FBQSxPQUFBaUcsVUFBQSxDQUFBOUssSUFBQTtVQUFBO1FBQUEsR0FBQTJLLFFBQUE7TUFBQSxDQUN2QjtNQUFBLFNBbkNLWCxZQUFZQSxDQUFBZSxJQUFBO1FBQUEsT0FBQUwsYUFBQSxDQUFBL0wsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFab0wsWUFBWTtJQUFBO0lBcUNsQjtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQU5FO0VBQUE7SUFBQTdHLEdBQUE7SUFBQWlCLEtBQUEsRUFPQSxTQUFBNEcsT0FBT0EsQ0FDTEEsUUFBNkIsRUFFWDtNQUFBLElBQUFDLE1BQUE7TUFBQSxJQURsQjVHLE9BQWUsR0FBQXpGLFNBQUEsQ0FBQTZDLE1BQUEsUUFBQTdDLFNBQUEsUUFBQU4sU0FBQSxHQUFBTSxTQUFBLE1BQUcsQ0FBQyxDQUFDO01BRXBCO01BQ0EsSUFBSXNNLFFBQXFCLEdBQ3ZCLE9BQU9GLFFBQU8sS0FBSyxRQUFRLEdBQUc7UUFBRTdCLE1BQU0sRUFBRSxLQUFLO1FBQUV4TCxHQUFHLEVBQUVxTjtNQUFRLENBQUMsR0FBR0EsUUFBTztNQUN6RTtNQUNBRSxRQUFRLEdBQUFoSixhQUFBLENBQUFBLGFBQUEsS0FDSGdKLFFBQVE7UUFDWHZOLEdBQUcsRUFBRSxJQUFJLENBQUN3TixhQUFhLENBQUNELFFBQVEsQ0FBQ3ZOLEdBQUc7TUFBQyxFQUN0QztNQUNELElBQU15TixPQUFPLEdBQUcsSUFBSTFQLE9BQU8sQ0FBQyxJQUFJLEVBQUUySSxPQUFPLENBQUM7TUFDMUM7TUFDQStHLE9BQU8sQ0FBQ2hHLEVBQUUsQ0FBQyxVQUFVLEVBQUUsVUFBQ29ELFFBQXNCLEVBQUs7UUFDakQsSUFBSUEsUUFBUSxDQUFDWSxPQUFPLElBQUlaLFFBQVEsQ0FBQ1ksT0FBTyxDQUFDLG1CQUFtQixDQUFDLEVBQUU7VUFDN0QsSUFBTWlDLFFBQVEsR0FBRzdDLFFBQVEsQ0FBQ1ksT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUNHLEtBQUssQ0FDMUQsd0JBQ0YsQ0FBQztVQUNELElBQUk4QixRQUFRLEVBQUU7WUFDWkosTUFBSSxDQUFDakcsU0FBUyxHQUFHO2NBQ2ZxRyxRQUFRLEVBQUU7Z0JBQ1JDLElBQUksRUFBRUMsU0FBQSxDQUFTRixRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO2dCQUMvQkcsS0FBSyxFQUFFRCxTQUFBLENBQVNGLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO2NBQ2pDO1lBQ0YsQ0FBQztVQUNIO1FBQ0Y7TUFDRixDQUFDLENBQUM7TUFDRixPQUFPRCxPQUFPLENBQUNKLE9BQU8sQ0FBSUUsUUFBUSxDQUFDO0lBQ3JDO0VBQUM7SUFBQS9ILEdBQUE7SUFBQWlCLEtBQUEsRUFFRCxTQUFBZ0gsT0FBT0EsQ0FBY0osT0FBb0IsRUFBRTNHLE9BQWUsRUFBRTtNQUMxRCxJQUFJb0gsUUFBUSxHQUFHN00sU0FBUyxDQUFDNkMsTUFBTSxHQUFHLENBQUMsSUFBSTdDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBS04sU0FBUyxHQUFHTSxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO01BQ3JGLE9BQU8sSUFBSWxELE9BQU8sQ0FBQyxJQUFJLEVBQUUrUCxRQUFRLENBQUM7SUFDcEM7O0lBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFORTtJQUFBdEksR0FBQTtJQUFBaUIsS0FBQSxFQU9BLFNBQUFzSCxVQUFVQSxDQUFjL04sR0FBVyxFQUFFMEcsT0FBZ0IsRUFBRTtNQUNyRCxJQUFNMkcsT0FBb0IsR0FBRztRQUFFN0IsTUFBTSxFQUFFLEtBQUs7UUFBRXhMLEdBQUcsRUFBSEE7TUFBSSxDQUFDO01BQ25ELE9BQU8sSUFBSSxDQUFDcU4sT0FBTyxDQUFJQSxPQUFPLEVBQUUzRyxPQUFPLENBQUM7SUFDMUM7O0lBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFORTtJQUFBbEIsR0FBQTtJQUFBaUIsS0FBQSxFQU9BLFNBQUF1SCxXQUFXQSxDQUFjaE8sR0FBVyxFQUFFMkssSUFBWSxFQUFFakUsT0FBZ0IsRUFBRTtNQUNwRSxJQUFNMkcsT0FBb0IsR0FBRztRQUMzQjdCLE1BQU0sRUFBRSxNQUFNO1FBQ2R4TCxHQUFHLEVBQUhBLEdBQUc7UUFDSDJLLElBQUksRUFBRXNELGVBQUEsQ0FBZXRELElBQUksQ0FBQztRQUMxQmMsT0FBTyxFQUFFO1VBQUUsY0FBYyxFQUFFO1FBQW1CO01BQ2hELENBQUM7TUFDRCxPQUFPLElBQUksQ0FBQzRCLE9BQU8sQ0FBSUEsT0FBTyxFQUFFM0csT0FBTyxDQUFDO0lBQzFDOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBTkU7SUFBQWxCLEdBQUE7SUFBQWlCLEtBQUEsRUFPQSxTQUFBeUgsVUFBVUEsQ0FBSWxPLEdBQVcsRUFBRTJLLElBQVksRUFBRWpFLE9BQWdCLEVBQUU7TUFDekQsSUFBTTJHLE9BQW9CLEdBQUc7UUFDM0I3QixNQUFNLEVBQUUsS0FBSztRQUNieEwsR0FBRyxFQUFIQSxHQUFHO1FBQ0gySyxJQUFJLEVBQUVzRCxlQUFBLENBQWV0RCxJQUFJLENBQUM7UUFDMUJjLE9BQU8sRUFBRTtVQUFFLGNBQWMsRUFBRTtRQUFtQjtNQUNoRCxDQUFDO01BQ0QsT0FBTyxJQUFJLENBQUM0QixPQUFPLENBQUlBLE9BQU8sRUFBRTNHLE9BQU8sQ0FBQztJQUMxQzs7SUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQU5FO0lBQUFsQixHQUFBO0lBQUFpQixLQUFBLEVBT0EsU0FBQTBILFlBQVlBLENBQWNuTyxHQUFXLEVBQUUySyxJQUFZLEVBQUVqRSxPQUFnQixFQUFFO01BQ3JFLElBQU0yRyxPQUFvQixHQUFHO1FBQzNCN0IsTUFBTSxFQUFFLE9BQU87UUFDZnhMLEdBQUcsRUFBSEEsR0FBRztRQUNIMkssSUFBSSxFQUFFc0QsZUFBQSxDQUFldEQsSUFBSSxDQUFDO1FBQzFCYyxPQUFPLEVBQUU7VUFBRSxjQUFjLEVBQUU7UUFBbUI7TUFDaEQsQ0FBQztNQUNELE9BQU8sSUFBSSxDQUFDNEIsT0FBTyxDQUFJQSxPQUFPLEVBQUUzRyxPQUFPLENBQUM7SUFDMUM7O0lBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFORTtJQUFBbEIsR0FBQTtJQUFBaUIsS0FBQSxFQU9BLFNBQUEySCxhQUFhQSxDQUFJcE8sR0FBVyxFQUFFMEcsT0FBZ0IsRUFBRTtNQUM5QyxJQUFNMkcsT0FBb0IsR0FBRztRQUFFN0IsTUFBTSxFQUFFLFFBQVE7UUFBRXhMLEdBQUcsRUFBSEE7TUFBSSxDQUFDO01BQ3RELE9BQU8sSUFBSSxDQUFDcU4sT0FBTyxDQUFJQSxPQUFPLEVBQUUzRyxPQUFPLENBQUM7SUFDMUM7O0lBRUE7RUFBQTtJQUFBbEIsR0FBQTtJQUFBaUIsS0FBQSxFQUNBLFNBQUE0SCxRQUFRQSxDQUFBLEVBQUc7TUFDVCxPQUFPLENBQUMsSUFBSSxDQUFDNVAsV0FBVyxFQUFFLGVBQWUsTUFBQStFLE1BQUEsQ0FBTSxJQUFJLENBQUM5RSxPQUFPLEVBQUcsQ0FBQ2tJLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDMUU7O0lBRUE7QUFDRjtBQUNBO0FBQ0E7RUFIRTtJQUFBcEIsR0FBQTtJQUFBaUIsS0FBQSxFQUlBLFNBQUErRyxhQUFhQSxDQUFDeE4sR0FBVyxFQUFFO01BQ3pCLElBQUliLDJCQUFBLENBQUFhLEdBQUcsRUFBQVosSUFBQSxDQUFIWSxHQUFHLEVBQVksR0FBRyxDQUFDLEVBQUU7UUFDdkIsSUFBSWIsMkJBQUEsQ0FBQWEsR0FBRyxFQUFBWixJQUFBLENBQUhZLEdBQUcsRUFBWSxJQUFJLENBQUN2QixXQUFXLEdBQUcsWUFBWSxDQUFDLEVBQUU7VUFDbkQsT0FBT3VCLEdBQUc7UUFDWjtRQUNBLElBQUliLDJCQUFBLENBQUFhLEdBQUcsRUFBQVosSUFBQSxDQUFIWSxHQUFHLEVBQVksWUFBWSxDQUFDLEVBQUU7VUFDaEMsT0FBTyxJQUFJLENBQUN2QixXQUFXLEdBQUd1QixHQUFHO1FBQy9CO1FBQ0EsT0FBTyxJQUFJLENBQUNxTyxRQUFRLENBQUMsQ0FBQyxHQUFHck8sR0FBRztNQUM5QjtNQUNBLE9BQU9BLEdBQUc7SUFDWjs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBd0YsR0FBQTtJQUFBaUIsS0FBQSxFQUdBLFNBQUE2SCxLQUFLQSxDQUNIQyxJQUFZLEVBQ1o3SCxPQUErQixFQUNjO01BQzdDLE9BQU8sSUFBSXpJLEtBQUssQ0FBdUMsSUFBSSxFQUFFc1EsSUFBSSxFQUFFN0gsT0FBTyxDQUFDO0lBQzdFOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBTkU7SUFBQWxCLEdBQUE7SUFBQWlCLEtBQUEsRUFPQSxTQUFBK0gsTUFBTUEsQ0FBQ0MsSUFBWSxFQUFFO01BQ25CLElBQU16TyxHQUFHLEdBQUcsSUFBSSxDQUFDcU8sUUFBUSxDQUFDLENBQUMsR0FBRyxZQUFZLEdBQUdLLGtCQUFrQixDQUFDRCxJQUFJLENBQUM7TUFDckUsT0FBTyxJQUFJLENBQUNwQixPQUFPLENBQWVyTixHQUFHLENBQUM7SUFDeEM7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQXdGLEdBQUE7SUFBQWlCLEtBQUEsRUFHQSxTQUFBa0ksU0FBU0EsQ0FBbUJDLE9BQWUsRUFBRWxJLE9BQXNCLEVBQUU7TUFDbkUsT0FBTyxJQUFJekksS0FBSyxDQUNkLElBQUksRUFDSjtRQUFFMlEsT0FBTyxFQUFQQTtNQUFRLENBQUMsRUFDWGxJLE9BQ0YsQ0FBQztJQUNIOztJQUVBO0VBQUE7SUFBQWxCLEdBQUE7SUFBQWlCLEtBQUEsRUFDQSxTQUFBb0ksY0FBY0EsQ0FBQ0MsWUFBb0IsRUFBRTtNQUNuQyxJQUFNQyxRQUFRLEdBQUcsSUFBSSxDQUFDclEsT0FBTyxDQUFDYyxLQUFLLENBQUMsR0FBRyxDQUFDO01BQ3hDLE9BQU9vTyxTQUFBLENBQVNtQixRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUlELFlBQVk7SUFDbEQ7O0lBRUE7RUFBQTtJQUFBdEosR0FBQTtJQUFBaUIsS0FBQSxFQUNBLFNBQUF1SSxTQUFTQSxDQUFDQyxPQUFlLEVBQUU7TUFDekIsUUFBUUEsT0FBTztRQUNiLEtBQUssb0JBQW9CO1VBQUU7VUFDekIsT0FBTyxDQUFDLElBQUksQ0FBQ0MsT0FBTztRQUFDO1FBQ3ZCO1VBQ0UsT0FBTyxLQUFLO01BQ2hCO0lBQ0Y7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQTFKLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBMEksU0FBQSxHQUFBak8saUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQWtCQSxTQUFBZ08sU0FDRWhLLElBQVksRUFDWmlLLEdBQXNCO1FBQUEsSUFBQTNJLE9BQUE7VUFBQTRJLE1BQUEsR0FBQXJPLFNBQUE7UUFBQSxPQUFBRSxtQkFBQSxDQUFBSyxJQUFBLFVBQUErTixVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTdOLElBQUEsR0FBQTZOLFVBQUEsQ0FBQTVOLElBQUE7WUFBQTtjQUN0QjhFLE9BQXdCLEdBQUE0SSxNQUFBLENBQUF4TCxNQUFBLFFBQUF3TCxNQUFBLFFBQUEzTyxTQUFBLEdBQUEyTyxNQUFBLE1BQUcsQ0FBQyxDQUFDO2NBQUEsT0FBQUUsVUFBQSxDQUFBdkcsTUFBQSxXQUV0QndHLGNBQUEsQ0FBY0osR0FBRyxDQUFDO2NBQ3JCO2NBQ0EsSUFBSSxDQUFDUixjQUFjLENBQUMsRUFBRSxDQUFDLEdBQ3JCLElBQUksQ0FBQ2EsYUFBYSxDQUFDdEssSUFBSSxFQUFFaUssR0FBRyxFQUFFM0ksT0FBTyxDQUFDLEdBQ3RDLElBQUksQ0FBQ2lKLGlCQUFpQixDQUFDdkssSUFBSSxFQUFFaUssR0FBRyxFQUFFM0ksT0FBTyxDQUFDLEdBQzVDLElBQUksQ0FBQ2tKLGVBQWUsQ0FBQ3hLLElBQUksRUFBRWlLLEdBQUcsRUFBRTNJLE9BQU8sQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBOEksVUFBQSxDQUFBbk4sSUFBQTtVQUFBO1FBQUEsR0FBQStNLFFBQUE7TUFBQSxDQUM3QztNQUFBLFNBWEtTLFFBQVFBLENBQUFDLElBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFaLFNBQUEsQ0FBQW5PLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBUjRPLFFBQVE7SUFBQSxJQWFkO0VBQUE7SUFBQXJLLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBdUosZ0JBQUEsR0FBQTlPLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FDQSxTQUFBNk8sVUFBc0I3SyxJQUFZLEVBQUU3RSxFQUFVLEVBQUVtRyxPQUF3QjtRQUFBLElBQUExRyxHQUFBLEVBQUFrUSxNQUFBLEVBQUF6RSxPQUFBO1FBQUEsT0FBQXRLLG1CQUFBLENBQUFLLElBQUEsVUFBQTJPLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBek8sSUFBQSxHQUFBeU8sVUFBQSxDQUFBeE8sSUFBQTtZQUFBO2NBQUEsSUFDakVyQixFQUFFO2dCQUFBNlAsVUFBQSxDQUFBeE8sSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDQyxJQUFJbEMsS0FBSyxDQUFDLGtEQUFrRCxDQUFDO1lBQUE7Y0FFakVNLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQ3FPLFFBQVEsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFakosSUFBSSxFQUFFN0UsRUFBRSxDQUFDLENBQUNxRyxJQUFJLENBQUMsR0FBRyxDQUFDO2NBQ25Ec0osTUFBTSxHQUFjeEosT0FBTyxDQUEzQndKLE1BQU0sRUFBRXpFLE9BQU8sR0FBSy9FLE9BQU8sQ0FBbkIrRSxPQUFPO2NBQ3ZCLElBQUl5RSxNQUFNLEVBQUU7Z0JBQ1ZsUSxHQUFHLGVBQUF3RCxNQUFBLENBQWUwTSxNQUFNLENBQUN0SixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUU7Y0FDdEM7Y0FBQyxPQUFBd0osVUFBQSxDQUFBbkgsTUFBQSxXQUNNLElBQUksQ0FBQ29FLE9BQU8sQ0FBQztnQkFBRTdCLE1BQU0sRUFBRSxLQUFLO2dCQUFFeEwsR0FBRyxFQUFIQSxHQUFHO2dCQUFFeUwsT0FBTyxFQUFQQTtjQUFRLENBQUMsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBMkUsVUFBQSxDQUFBL04sSUFBQTtVQUFBO1FBQUEsR0FBQTROLFNBQUE7TUFBQSxDQUNyRDtNQUFBLFNBVktMLGVBQWVBLENBQUFTLElBQUEsRUFBQUMsSUFBQSxFQUFBQyxJQUFBO1FBQUEsT0FBQVAsZ0JBQUEsQ0FBQWhQLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBZjJPLGVBQWU7SUFBQSxJQVlyQjtFQUFBO0lBQUFwSyxHQUFBO0lBQUFpQixLQUFBO01BQUEsSUFBQStKLGtCQUFBLEdBQUF0UCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQ0EsU0FBQXFQLFVBQ0VyTCxJQUFZLEVBQ1ppSyxHQUFhLEVBQ2IzSSxPQUF3QjtRQUFBLElBQUFnSyxNQUFBO1FBQUEsT0FBQXZQLG1CQUFBLENBQUFLLElBQUEsVUFBQW1QLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBalAsSUFBQSxHQUFBaVAsVUFBQSxDQUFBaFAsSUFBQTtZQUFBO2NBQUEsTUFFcEJ5TixHQUFHLENBQUN2TCxNQUFNLEdBQUcsSUFBSSxDQUFDYSxXQUFXO2dCQUFBaU0sVUFBQSxDQUFBaFAsSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDekIsSUFBSWxDLEtBQUssQ0FBQyx1Q0FBdUMsQ0FBQztZQUFBO2NBQUEsT0FBQWtSLFVBQUEsQ0FBQTNILE1BQUEsV0FFbkRvQyxRQUFBLENBQVF3RixHQUFHLENBQ2hCQyxvQkFBQSxDQUFBekIsR0FBRyxFQUFBalEsSUFBQSxDQUFIaVEsR0FBRyxFQUFLLFVBQUM5TyxFQUFFO2dCQUFBLE9BQ1RtUSxNQUFJLENBQUNkLGVBQWUsQ0FBQ3hLLElBQUksRUFBRTdFLEVBQUUsRUFBRW1HLE9BQU8sQ0FBQyxDQUFDcUssS0FBSyxDQUFDLFVBQUM5TixHQUFHLEVBQUs7a0JBQ3JELElBQUl5RCxPQUFPLENBQUNzSyxTQUFTLElBQUkvTixHQUFHLENBQUNnTyxTQUFTLEtBQUssV0FBVyxFQUFFO29CQUN0RCxNQUFNaE8sR0FBRztrQkFDWDtrQkFDQSxPQUFPLElBQUk7Z0JBQ2IsQ0FBQyxDQUFDO2NBQUEsQ0FDSixDQUNGLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQTJOLFVBQUEsQ0FBQXZPLElBQUE7VUFBQTtRQUFBLEdBQUFvTyxTQUFBO01BQUEsQ0FDRjtNQUFBLFNBbEJLZCxpQkFBaUJBLENBQUF1QixJQUFBLEVBQUFDLElBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFaLGtCQUFBLENBQUF4UCxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQWpCME8saUJBQWlCO0lBQUEsSUFvQnZCO0VBQUE7SUFBQW5LLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBNEssY0FBQSxHQUFBblEsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUNBLFNBQUFrUSxVQUFvQmxNLElBQVksRUFBRWlLLEdBQWEsRUFBRTNJLE9BQXdCO1FBQUEsSUFBQTZLLFVBQUE7UUFBQSxJQUFBdlIsR0FBQSxFQUFBa1EsTUFBQTtRQUFBLE9BQUEvTyxtQkFBQSxDQUFBSyxJQUFBLFVBQUFnUSxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTlQLElBQUEsR0FBQThQLFVBQUEsQ0FBQTdQLElBQUE7WUFBQTtjQUFBLE1BQ25FeU4sR0FBRyxDQUFDdkwsTUFBTSxLQUFLLENBQUM7Z0JBQUEyTixVQUFBLENBQUE3UCxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxPQUFBNlAsVUFBQSxDQUFBeEksTUFBQSxXQUNYLEVBQUU7WUFBQTtjQUVMakosR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDcU8sUUFBUSxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFakosSUFBSSxDQUFDLENBQUN3QixJQUFJLENBQUMsR0FBRyxDQUFDO2NBQUE2SyxVQUFBLENBQUFyUCxFQUFBLEdBRXBFc0UsT0FBTyxDQUFDd0osTUFBTTtjQUFBLElBQUF1QixVQUFBLENBQUFyUCxFQUFBO2dCQUFBcVAsVUFBQSxDQUFBN1AsSUFBQTtnQkFBQTtjQUFBO2NBQUE2UCxVQUFBLENBQUFDLEVBQUEsR0FBQVosb0JBQUE7Y0FBQVcsVUFBQSxDQUFBN1AsSUFBQTtjQUFBLE9BQ1AsSUFBSSxDQUFDOEQsU0FBUyxDQUFDTixJQUFJLENBQUM7WUFBQTtjQUFBcU0sVUFBQSxDQUFBRSxFQUFBLEdBQUFKLFVBQUEsR0FBQUUsVUFBQSxDQUFBMVAsSUFBQSxDQUFFbU8sTUFBTTtjQUFBdUIsVUFBQSxDQUFBclAsRUFBQSxPQUFBcVAsVUFBQSxDQUFBQyxFQUFBLEVBQUFELFVBQUEsQ0FBQUUsRUFBQSxFQUFBdlMsSUFBQSxDQUFBbVMsVUFBQSxFQUFLLFVBQUNLLEtBQUs7Z0JBQUEsT0FBS0EsS0FBSyxDQUFDdk8sSUFBSTtjQUFBO1lBQUE7Y0FGekQ2TSxNQUFNLEdBQUF1QixVQUFBLENBQUFyUCxFQUFBO2NBQUEsT0FBQXFQLFVBQUEsQ0FBQXhJLE1BQUEsV0FHTCxJQUFJLENBQUNvRSxPQUFPLENBQUM7Z0JBQ2xCN0IsTUFBTSxFQUFFLE1BQU07Z0JBQ2R4TCxHQUFHLEVBQUhBLEdBQUc7Z0JBQ0gySyxJQUFJLEVBQUVzRCxlQUFBLENBQWU7a0JBQUVvQixHQUFHLEVBQUhBLEdBQUc7a0JBQUVhLE1BQU0sRUFBTkE7Z0JBQU8sQ0FBQyxDQUFDO2dCQUNyQ3pFLE9BQU8sRUFBQWxILGFBQUEsQ0FBQUEsYUFBQSxLQUNEbUMsT0FBTyxDQUFDK0UsT0FBTyxJQUFJLENBQUMsQ0FBQztrQkFDekIsY0FBYyxFQUFFO2dCQUFrQjtjQUV0QyxDQUFDLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQWdHLFVBQUEsQ0FBQXBQLElBQUE7VUFBQTtRQUFBLEdBQUFpUCxTQUFBO01BQUEsQ0FDSDtNQUFBLFNBakJLNUIsYUFBYUEsQ0FBQW1DLElBQUEsRUFBQUMsSUFBQSxFQUFBQyxJQUFBO1FBQUEsT0FBQVYsY0FBQSxDQUFBclEsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFieU8sYUFBYTtJQUFBO0lBbUJuQjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUFsSyxHQUFBO0lBQUFpQixLQUFBO0lBdUJBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7SUFKRTtNQUFBLElBQUF1TCxPQUFBLEdBQUE5USxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBS0EsU0FBQTZRLFVBQ0U3TSxJQUFZLEVBQ1o4TSxPQUEwQjtRQUFBLElBQUF4TCxPQUFBO1VBQUF5TCxHQUFBO1VBQUFDLE9BQUEsR0FBQW5SLFNBQUE7UUFBQSxPQUFBRSxtQkFBQSxDQUFBSyxJQUFBLFVBQUE2USxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTNRLElBQUEsR0FBQTJRLFVBQUEsQ0FBQTFRLElBQUE7WUFBQTtjQUMxQjhFLE9BQW1CLEdBQUEwTCxPQUFBLENBQUF0TyxNQUFBLFFBQUFzTyxPQUFBLFFBQUF6UixTQUFBLEdBQUF5UixPQUFBLE1BQUcsQ0FBQyxDQUFDO2NBQUEsS0FFWjNDLGNBQUEsQ0FBY3lDLE9BQU8sQ0FBQztnQkFBQUksVUFBQSxDQUFBMVEsSUFBQTtnQkFBQTtjQUFBO2NBQUEsS0FFOUIsSUFBSSxDQUFDaU4sY0FBYyxDQUFDLEVBQUUsQ0FBQztnQkFBQXlELFVBQUEsQ0FBQTFRLElBQUE7Z0JBQUE7Y0FBQTtjQUFBMFEsVUFBQSxDQUFBMVEsSUFBQTtjQUFBLE9BQ2YsSUFBSSxDQUFDMlEsV0FBVyxDQUFDbk4sSUFBSSxFQUFFOE0sT0FBTyxFQUFFeEwsT0FBTyxDQUFDO1lBQUE7Y0FBQTRMLFVBQUEsQ0FBQVosRUFBQSxHQUFBWSxVQUFBLENBQUF2USxJQUFBO2NBQUF1USxVQUFBLENBQUExUSxJQUFBO2NBQUE7WUFBQTtjQUFBMFEsVUFBQSxDQUFBMVEsSUFBQTtjQUFBLE9BQ3hDLElBQUksQ0FBQzRRLGVBQWUsQ0FBQ3BOLElBQUksRUFBRThNLE9BQU8sRUFBRXhMLE9BQU8sQ0FBQztZQUFBO2NBQUE0TCxVQUFBLENBQUFaLEVBQUEsR0FBQVksVUFBQSxDQUFBdlEsSUFBQTtZQUFBO2NBQUF1USxVQUFBLENBQUFsUSxFQUFBLEdBQUFrUSxVQUFBLENBQUFaLEVBQUE7Y0FBQVksVUFBQSxDQUFBMVEsSUFBQTtjQUFBO1lBQUE7Y0FBQTBRLFVBQUEsQ0FBQTFRLElBQUE7Y0FBQSxPQUM5QyxJQUFJLENBQUM2USxhQUFhLENBQUNyTixJQUFJLEVBQUU4TSxPQUFPLEVBQUV4TCxPQUFPLENBQUM7WUFBQTtjQUFBNEwsVUFBQSxDQUFBbFEsRUFBQSxHQUFBa1EsVUFBQSxDQUFBdlEsSUFBQTtZQUFBO2NBTDlDb1EsR0FBRyxHQUFBRyxVQUFBLENBQUFsUSxFQUFBO2NBQUEsT0FBQWtRLFVBQUEsQ0FBQXJKLE1BQUEsV0FNRmtKLEdBQUc7WUFBQTtZQUFBO2NBQUEsT0FBQUcsVUFBQSxDQUFBalEsSUFBQTtVQUFBO1FBQUEsR0FBQTRQLFNBQUE7TUFBQSxDQUNYO01BQUEsU0FaSy9OLE1BQU1BLENBQUF3TyxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBWCxPQUFBLENBQUFoUixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQU5pRCxNQUFNO0lBQUEsSUFjWjtFQUFBO0lBQUFzQixHQUFBO0lBQUFpQixLQUFBO01BQUEsSUFBQW1NLGNBQUEsR0FBQTFSLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FDQSxTQUFBeVIsVUFBb0J6TixJQUFZLEVBQUUwTixNQUFjLEVBQUVwTSxPQUFtQjtRQUFBLElBQUFxTSxFQUFBLEVBQUFDLEtBQUEsRUFBQUMsVUFBQSxFQUFBQyxHQUFBLEVBQUFDLFdBQUEsRUFBQW5ULEdBQUEsRUFBQW9ULFdBQUEsRUFBQXpJLElBQUEsRUFBQTBJLFVBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFuUyxtQkFBQSxDQUFBSyxJQUFBLFVBQUErUixXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTdSLElBQUEsR0FBQTZSLFVBQUEsQ0FBQTVSLElBQUE7WUFBQTtjQUMzRG1SLEVBQUUsR0FBc0NELE1BQU0sQ0FBOUNDLEVBQUUsRUFBUUMsS0FBSyxHQUF5QkYsTUFBTSxDQUExQzFOLElBQUksRUFBUzZOLFVBQVUsR0FBYUgsTUFBTSxDQUE3QkcsVUFBVSxFQUFLQyxHQUFHLEdBQUFPLHdCQUFBLENBQUtYLE1BQU0sRUFBQVksU0FBQTtjQUNoRFAsV0FBVyxHQUFHL04sSUFBSSxLQUFJNk4sVUFBVSxhQUFWQSxVQUFVLHVCQUFWQSxVQUFVLENBQUU3TixJQUFJLEtBQUk0TixLQUFLO2NBQUEsSUFDaERHLFdBQVc7Z0JBQUFLLFVBQUEsQ0FBQTVSLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE1BQ1IsSUFBSWxDLEtBQUssQ0FBQyxtQ0FBbUMsQ0FBQztZQUFBO2NBRWhETSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUNxTyxRQUFRLENBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBRThFLFdBQVcsQ0FBQyxDQUFDdk0sSUFBSSxDQUFDLEdBQUcsQ0FBQztjQUdoRSxJQUFJRixPQUFPLGFBQVBBLE9BQU8sZUFBUEEsT0FBTyxDQUFFaU4sbUJBQW1CLEVBQUU7Z0JBQ2hDO2dCQUNNTCxJQUFJLEdBQUcsSUFBSWhWLFFBQVEsQ0FBQyxDQUFDLEVBQzNCO2dCQUNBc1Ysd0JBQUEsQ0FBQVAsVUFBQSxHQUFBUSxlQUFBLENBQWVuTixPQUFPLENBQUNpTixtQkFBbUIsQ0FBQyxFQUFBdlUsSUFBQSxDQUFBaVUsVUFBQSxFQUN6QyxVQUFBUyxLQUFBLEVBQThCO2tCQUFBLElBQUFDLEtBQUEsR0FBQTFULGNBQUEsQ0FBQXlULEtBQUE7b0JBQTVCRSxTQUFTLEdBQUFELEtBQUE7b0JBQUVFLFdBQVcsR0FBQUYsS0FBQTtrQkFDdEJULElBQUksQ0FBQ1ksTUFBTSxDQUNURixTQUFTLEVBQ1RwVSxNQUFNLENBQUNDLElBQUksQ0FBQ3FULEdBQUcsQ0FBQ2MsU0FBUyxDQUFDLEVBQUUsUUFBUSxDQUFDLEVBQ3JDQyxXQUNGLENBQUM7a0JBQ0QsT0FBT2YsR0FBRyxDQUFDYyxTQUFTLENBQUM7Z0JBQ3ZCLENBQ0YsQ0FBQztnQkFDRDtnQkFDQVYsSUFBSSxDQUFDWSxNQUFNLENBQUM5TyxJQUFJLEVBQUU2SSxlQUFBLENBQWVpRixHQUFHLENBQUMsRUFBRTtrQkFDckNFLFdBQVcsRUFBRTtnQkFDZixDQUFDLENBQUM7Z0JBQ0ZBLFdBQVcsR0FBR0UsSUFBSSxDQUFDYSxVQUFVLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pEeEosSUFBSSxHQUFHMkksSUFBSTtjQUNiLENBQUMsTUFBTTtnQkFDTDtnQkFDQUYsV0FBVyxHQUFHLGtCQUFrQjtnQkFDaEN6SSxJQUFJLEdBQUdzRCxlQUFBLENBQWVpRixHQUFHLENBQUM7Y0FDNUI7Y0FBQyxPQUFBTSxVQUFBLENBQUF2SyxNQUFBLFdBRU0sSUFBSSxDQUFDb0UsT0FBTyxDQUFDO2dCQUNsQjdCLE1BQU0sRUFBRSxNQUFNO2dCQUNkeEwsR0FBRyxFQUFIQSxHQUFHO2dCQUNIMkssSUFBSSxFQUFFQSxJQUFJO2dCQUNWYyxPQUFPLEVBQUFsSCxhQUFBLENBQUFBLGFBQUEsS0FDRG1DLE9BQU8sQ0FBQytFLE9BQU8sSUFBSSxDQUFDLENBQUM7a0JBQ3pCLGNBQWMsRUFBRTJIO2dCQUFXO2NBRS9CLENBQUMsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBSSxVQUFBLENBQUFuUixJQUFBO1VBQUE7UUFBQSxHQUFBd1EsU0FBQTtNQUFBLENBQ0g7TUFBQSxTQTVDS0osYUFBYUEsQ0FBQTJCLElBQUEsRUFBQUMsSUFBQSxFQUFBQyxJQUFBO1FBQUEsT0FBQTFCLGNBQUEsQ0FBQTVSLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBYndSLGFBQWE7SUFBQSxJQThDbkI7RUFBQTtJQUFBak4sR0FBQTtJQUFBaUIsS0FBQTtNQUFBLElBQUE4TixnQkFBQSxHQUFBclQsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUNBLFNBQUFvVCxVQUFzQnBQLElBQVksRUFBRThNLE9BQWlCLEVBQUV4TCxPQUFtQjtRQUFBLElBQUErTixNQUFBO1FBQUEsT0FBQXRULG1CQUFBLENBQUFLLElBQUEsVUFBQWtULFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBaFQsSUFBQSxHQUFBZ1QsVUFBQSxDQUFBL1MsSUFBQTtZQUFBO2NBQUEsTUFDcEVzUSxPQUFPLENBQUNwTyxNQUFNLEdBQUcsSUFBSSxDQUFDYSxXQUFXO2dCQUFBZ1EsVUFBQSxDQUFBL1MsSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDN0IsSUFBSWxDLEtBQUssQ0FBQyx1Q0FBdUMsQ0FBQztZQUFBO2NBQUEsT0FBQWlWLFVBQUEsQ0FBQTFMLE1BQUEsV0FFbkRvQyxRQUFBLENBQVF3RixHQUFHLENBQ2hCQyxvQkFBQSxDQUFBb0IsT0FBTyxFQUFBOVMsSUFBQSxDQUFQOFMsT0FBTyxFQUFLLFVBQUNZLE1BQU07Z0JBQUEsT0FDakIyQixNQUFJLENBQUNoQyxhQUFhLENBQUNyTixJQUFJLEVBQUUwTixNQUFNLEVBQUVwTSxPQUFPLENBQUMsQ0FBQ3FLLEtBQUssQ0FBQyxVQUFDOU4sR0FBRyxFQUFLO2tCQUN2RDtrQkFDQTtrQkFDQSxJQUFJeUQsT0FBTyxDQUFDc0ssU0FBUyxJQUFJLENBQUMvTixHQUFHLENBQUNnTyxTQUFTLEVBQUU7b0JBQ3ZDLE1BQU1oTyxHQUFHO2tCQUNYO2tCQUNBLE9BQU9ELFlBQVksQ0FBQ0MsR0FBRyxDQUFDO2dCQUMxQixDQUFDLENBQUM7Y0FBQSxDQUNKLENBQ0YsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBMFIsVUFBQSxDQUFBdFMsSUFBQTtVQUFBO1FBQUEsR0FBQW1TLFNBQUE7TUFBQSxDQUNGO01BQUEsU0FoQktoQyxlQUFlQSxDQUFBb0MsSUFBQSxFQUFBQyxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBUCxnQkFBQSxDQUFBdlQsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFmdVIsZUFBZTtJQUFBLElBa0JyQjtFQUFBO0lBQUFoTixHQUFBO0lBQUFpQixLQUFBO01BQUEsSUFBQXNPLFlBQUEsR0FBQTdULGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FDQSxTQUFBNFQsVUFDRTVQLElBQVksRUFDWjhNLE9BQWlCLEVBQ2pCeEwsT0FBbUI7UUFBQSxJQUFBdU8sVUFBQSxFQUFBQyxRQUFBLEVBQUFsVixHQUFBO1FBQUEsT0FBQW1CLG1CQUFBLENBQUFLLElBQUEsVUFBQTJULFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBelQsSUFBQSxHQUFBeVQsVUFBQSxDQUFBeFQsSUFBQTtZQUFBO2NBQUEsTUFFZnNRLE9BQU8sQ0FBQ3BPLE1BQU0sS0FBSyxDQUFDO2dCQUFBc1IsVUFBQSxDQUFBeFQsSUFBQTtnQkFBQTtjQUFBO2NBQUEsT0FBQXdULFVBQUEsQ0FBQW5NLE1BQUEsV0FDZm9DLFFBQUEsQ0FBUWdLLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFBQTtjQUFBLE1BRXhCbkQsT0FBTyxDQUFDcE8sTUFBTSxHQUFHTCxhQUFhLElBQUlpRCxPQUFPLENBQUM0TyxjQUFjO2dCQUFBRixVQUFBLENBQUF4VCxJQUFBO2dCQUFBO2NBQUE7Y0FBQXdULFVBQUEsQ0FBQWhULEVBQUEsR0FBQW1CLHVCQUFBLENBQUEwUixVQUFBO2NBQUFHLFVBQUEsQ0FBQTFELEVBQUEsR0FBQXVELFVBQUE7Y0FBQUcsVUFBQSxDQUFBekQsRUFBQSxHQUFBNEQsa0JBQUE7Y0FBQUgsVUFBQSxDQUFBeFQsSUFBQTtjQUFBLE9BRTlDLElBQUksQ0FBQzJRLFdBQVcsQ0FDeEJuTixJQUFJLEVBQ0pqRixzQkFBQSxDQUFBK1IsT0FBTyxFQUFBOVMsSUFBQSxDQUFQOFMsT0FBTyxFQUFPLENBQUMsRUFBRXpPLGFBQWEsQ0FBQyxFQUMvQmlELE9BQ0YsQ0FBQztZQUFBO2NBQUEwTyxVQUFBLENBQUFJLEVBQUEsR0FBQUosVUFBQSxDQUFBclQsSUFBQTtjQUFBcVQsVUFBQSxDQUFBSyxFQUFBLE9BQUFMLFVBQUEsQ0FBQXpELEVBQUEsRUFBQXlELFVBQUEsQ0FBQUksRUFBQTtjQUFBSixVQUFBLENBQUFNLEVBQUEsR0FBQUgsa0JBQUE7Y0FBQUgsVUFBQSxDQUFBeFQsSUFBQTtjQUFBLE9BQ1MsSUFBSSxDQUFDMlEsV0FBVyxDQUN4Qm5OLElBQUksRUFDSmpGLHNCQUFBLENBQUErUixPQUFPLEVBQUE5UyxJQUFBLENBQVA4UyxPQUFPLEVBQU96TyxhQUFhLENBQUMsRUFDNUJpRCxPQUNGLENBQUM7WUFBQTtjQUFBME8sVUFBQSxDQUFBTyxFQUFBLEdBQUFQLFVBQUEsQ0FBQXJULElBQUE7Y0FBQXFULFVBQUEsQ0FBQVEsRUFBQSxPQUFBUixVQUFBLENBQUFNLEVBQUEsRUFBQU4sVUFBQSxDQUFBTyxFQUFBO2NBQUEsT0FBQVAsVUFBQSxDQUFBbk0sTUFBQSxXQUFBbU0sVUFBQSxDQUFBaFQsRUFBQSxDQUFBaEQsSUFBQSxDQUFBQSxJQUFBLENBQUFnVyxVQUFBLENBQUFoVCxFQUFBLEVBQUFnVCxVQUFBLENBQUExRCxFQUFBLEVBQUEwRCxVQUFBLENBQUFLLEVBQUEsRUFBQUwsVUFBQSxDQUFBUSxFQUFBO1lBQUE7Y0FHQ1YsUUFBUSxHQUFHcEUsb0JBQUEsQ0FBQW9CLE9BQU8sRUFBQTlTLElBQUEsQ0FBUDhTLE9BQU8sRUFBSyxVQUFDWSxNQUFNLEVBQUs7Z0JBQ3ZDLElBQVFDLEVBQUUsR0FBc0NELE1BQU0sQ0FBOUNDLEVBQUU7a0JBQVFDLEtBQUssR0FBeUJGLE1BQU0sQ0FBMUMxTixJQUFJO2tCQUFTNk4sVUFBVSxHQUFhSCxNQUFNLENBQTdCRyxVQUFVO2tCQUFLQyxHQUFHLEdBQUFPLHdCQUFBLENBQUtYLE1BQU0sRUFBQStDLFVBQUE7Z0JBQ3RELElBQU0xQyxXQUFXLEdBQUcvTixJQUFJLEtBQUk2TixVQUFVLGFBQVZBLFVBQVUsdUJBQVZBLFVBQVUsQ0FBRTdOLElBQUksS0FBSTROLEtBQUs7Z0JBQ3JELElBQUksQ0FBQ0csV0FBVyxFQUFFO2tCQUNoQixNQUFNLElBQUl6VCxLQUFLLENBQUMsbUNBQW1DLENBQUM7Z0JBQ3REO2dCQUNBLE9BQUE2RSxhQUFBO2tCQUFTME8sVUFBVSxFQUFFO29CQUFFN04sSUFBSSxFQUFFK047a0JBQVk7Z0JBQUMsR0FBS0QsR0FBRztjQUNwRCxDQUFDLENBQUM7Y0FDSWxULEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQ3FPLFFBQVEsQ0FBQyxDQUFDLEVBQUUsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDekgsSUFBSSxDQUFDLEdBQUcsQ0FBQztjQUFBLE9BQUF3TyxVQUFBLENBQUFuTSxNQUFBLFdBQ3pELElBQUksQ0FBQ29FLE9BQU8sQ0FBQztnQkFDbEI3QixNQUFNLEVBQUUsTUFBTTtnQkFDZHhMLEdBQUcsRUFBSEEsR0FBRztnQkFDSDJLLElBQUksRUFBRXNELGVBQUEsQ0FBZTtrQkFDbkIrQyxTQUFTLEVBQUV0SyxPQUFPLENBQUNzSyxTQUFTLElBQUksS0FBSztrQkFDckNrQixPQUFPLEVBQUVnRDtnQkFDWCxDQUFDLENBQUM7Z0JBQ0Z6SixPQUFPLEVBQUFsSCxhQUFBLENBQUFBLGFBQUEsS0FDRG1DLE9BQU8sQ0FBQytFLE9BQU8sSUFBSSxDQUFDLENBQUM7a0JBQ3pCLGNBQWMsRUFBRTtnQkFBa0I7Y0FFdEMsQ0FBQyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUEySixVQUFBLENBQUEvUyxJQUFBO1VBQUE7UUFBQSxHQUFBMlMsU0FBQTtNQUFBLENBQ0g7TUFBQSxTQTNDS3pDLFdBQVdBLENBQUF1RCxJQUFBLEVBQUFDLElBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFqQixZQUFBLENBQUEvVCxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVhzUixXQUFXO0lBQUE7RUFBQTtJQUFBL00sR0FBQTtJQUFBaUIsS0FBQTtJQXlFakI7QUFDRjtBQUNBO0FBQ0E7QUFDQTtJQUNFLFNBQUF3UCxNQUFNQSxDQUNKN1EsSUFBTyxFQUNQOE0sT0FBMEIsRUFFVTtNQUFBLElBRHBDeEwsT0FBbUIsR0FBQXpGLFNBQUEsQ0FBQTZDLE1BQUEsUUFBQTdDLFNBQUEsUUFBQU4sU0FBQSxHQUFBTSxTQUFBLE1BQUcsQ0FBQyxDQUFDO01BRXhCLE9BQU93TyxjQUFBLENBQWN5QyxPQUFPLENBQUM7TUFDekI7TUFDQSxJQUFJLENBQUNyRCxjQUFjLENBQUMsRUFBRSxDQUFDLEdBQ3JCLElBQUksQ0FBQ3FILFdBQVcsQ0FBQzlRLElBQUksRUFBRThNLE9BQU8sRUFBRXhMLE9BQU8sQ0FBQyxHQUN4QyxJQUFJLENBQUN5UCxlQUFlLENBQUMvUSxJQUFJLEVBQUU4TSxPQUFPLEVBQUV4TCxPQUFPLENBQUMsR0FDOUMsSUFBSSxDQUFDMFAsYUFBYSxDQUFDaFIsSUFBSSxFQUFFOE0sT0FBTyxFQUFFeEwsT0FBTyxDQUFDO0lBQ2hEOztJQUVBO0VBQUE7SUFBQWxCLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBNFAsY0FBQSxHQUFBblYsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUNBLFNBQUFrVixVQUNFbFIsSUFBWSxFQUNaME4sTUFBYyxFQUNkcE0sT0FBbUI7UUFBQSxJQUFBbkcsRUFBQSxFQUFBeVMsS0FBQSxFQUFBQyxVQUFBLEVBQUFDLEdBQUEsRUFBQUMsV0FBQSxFQUFBblQsR0FBQTtRQUFBLE9BQUFtQixtQkFBQSxDQUFBSyxJQUFBLFVBQUErVSxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTdVLElBQUEsR0FBQTZVLFVBQUEsQ0FBQTVVLElBQUE7WUFBQTtjQUVQckIsRUFBRSxHQUFzQ3VTLE1BQU0sQ0FBbERDLEVBQUUsRUFBWUMsS0FBSyxHQUF5QkYsTUFBTSxDQUExQzFOLElBQUksRUFBUzZOLFVBQVUsR0FBYUgsTUFBTSxDQUE3QkcsVUFBVSxFQUFLQyxHQUFHLEdBQUFPLHdCQUFBLENBQUtYLE1BQU0sRUFBQTJELFVBQUE7Y0FBQSxJQUNyRGxXLEVBQUU7Z0JBQUFpVyxVQUFBLENBQUE1VSxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUNDLElBQUlsQyxLQUFLLENBQUMsbUNBQW1DLENBQUM7WUFBQTtjQUVoRHlULFdBQVcsR0FBRy9OLElBQUksS0FBSTZOLFVBQVUsYUFBVkEsVUFBVSx1QkFBVkEsVUFBVSxDQUFFN04sSUFBSSxLQUFJNE4sS0FBSztjQUFBLElBQ2hERyxXQUFXO2dCQUFBcUQsVUFBQSxDQUFBNVUsSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDUixJQUFJbEMsS0FBSyxDQUFDLG1DQUFtQyxDQUFDO1lBQUE7Y0FFaERNLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQ3FPLFFBQVEsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFOEUsV0FBVyxFQUFFNVMsRUFBRSxDQUFDLENBQUNxRyxJQUFJLENBQUMsR0FBRyxDQUFDO2NBQUEsT0FBQTRQLFVBQUEsQ0FBQXZOLE1BQUEsV0FDN0QsSUFBSSxDQUFDb0UsT0FBTyxDQUNqQjtnQkFDRTdCLE1BQU0sRUFBRSxPQUFPO2dCQUNmeEwsR0FBRyxFQUFIQSxHQUFHO2dCQUNIMkssSUFBSSxFQUFFc0QsZUFBQSxDQUFlaUYsR0FBRyxDQUFDO2dCQUN6QnpILE9BQU8sRUFBQWxILGFBQUEsQ0FBQUEsYUFBQSxLQUNEbUMsT0FBTyxDQUFDK0UsT0FBTyxJQUFJLENBQUMsQ0FBQztrQkFDekIsY0FBYyxFQUFFO2dCQUFrQjtjQUV0QyxDQUFDLEVBQ0Q7Z0JBQ0VpTCxpQkFBaUIsRUFBRTtrQkFBRW5XLEVBQUUsRUFBRkEsRUFBRTtrQkFBRTJDLE9BQU8sRUFBRSxJQUFJO2tCQUFFQyxNQUFNLEVBQUU7Z0JBQUc7Y0FDckQsQ0FDRixDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUFxVCxVQUFBLENBQUFuVSxJQUFBO1VBQUE7UUFBQSxHQUFBaVUsU0FBQTtNQUFBLENBQ0Y7TUFBQSxTQTVCS0YsYUFBYUEsQ0FBQU8sSUFBQSxFQUFBQyxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBUixjQUFBLENBQUFyVixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQWJtVixhQUFhO0lBQUEsSUE4Qm5CO0VBQUE7SUFBQTVRLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBcVEsZ0JBQUEsR0FBQTVWLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FDQSxTQUFBMlYsVUFBc0IzUixJQUFZLEVBQUU4TSxPQUFpQixFQUFFeEwsT0FBbUI7UUFBQSxJQUFBc1EsTUFBQTtRQUFBLE9BQUE3VixtQkFBQSxDQUFBSyxJQUFBLFVBQUF5VixXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXZWLElBQUEsR0FBQXVWLFVBQUEsQ0FBQXRWLElBQUE7WUFBQTtjQUFBLE1BQ3BFc1EsT0FBTyxDQUFDcE8sTUFBTSxHQUFHLElBQUksQ0FBQ2EsV0FBVztnQkFBQXVTLFVBQUEsQ0FBQXRWLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE1BQzdCLElBQUlsQyxLQUFLLENBQUMsdUNBQXVDLENBQUM7WUFBQTtjQUFBLE9BQUF3WCxVQUFBLENBQUFqTyxNQUFBLFdBRW5Eb0MsUUFBQSxDQUFRd0YsR0FBRyxDQUNoQkMsb0JBQUEsQ0FBQW9CLE9BQU8sRUFBQTlTLElBQUEsQ0FBUDhTLE9BQU8sRUFBSyxVQUFDWSxNQUFNO2dCQUFBLE9BQ2pCa0UsTUFBSSxDQUFDWixhQUFhLENBQUNoUixJQUFJLEVBQUUwTixNQUFNLEVBQUVwTSxPQUFPLENBQUMsQ0FBQ3FLLEtBQUssQ0FBQyxVQUFDOU4sR0FBRyxFQUFLO2tCQUN2RDtrQkFDQTtrQkFDQSxJQUFJeUQsT0FBTyxDQUFDc0ssU0FBUyxJQUFJLENBQUMvTixHQUFHLENBQUNnTyxTQUFTLEVBQUU7b0JBQ3ZDLE1BQU1oTyxHQUFHO2tCQUNYO2tCQUNBLE9BQU9ELFlBQVksQ0FBQ0MsR0FBRyxDQUFDO2dCQUMxQixDQUFDLENBQUM7Y0FBQSxDQUNKLENBQ0YsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBaVUsVUFBQSxDQUFBN1UsSUFBQTtVQUFBO1FBQUEsR0FBQTBVLFNBQUE7TUFBQSxDQUNGO01BQUEsU0FoQktaLGVBQWVBLENBQUFnQixJQUFBLEVBQUFDLElBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFQLGdCQUFBLENBQUE5VixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQWZrVixlQUFlO0lBQUEsSUFrQnJCO0VBQUE7SUFBQTNRLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBNlEsWUFBQSxHQUFBcFcsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUNBLFNBQUFtVyxVQUNFblMsSUFBWSxFQUNaOE0sT0FBaUIsRUFDakJ4TCxPQUFtQjtRQUFBLElBQUE4USxVQUFBLEVBQUF0QyxRQUFBLEVBQUFsVixHQUFBO1FBQUEsT0FBQW1CLG1CQUFBLENBQUFLLElBQUEsVUFBQWlXLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBL1YsSUFBQSxHQUFBK1YsVUFBQSxDQUFBOVYsSUFBQTtZQUFBO2NBQUEsTUFFZnNRLE9BQU8sQ0FBQ3BPLE1BQU0sS0FBSyxDQUFDO2dCQUFBNFQsVUFBQSxDQUFBOVYsSUFBQTtnQkFBQTtjQUFBO2NBQUEsT0FBQThWLFVBQUEsQ0FBQXpPLE1BQUEsV0FDZixFQUFFO1lBQUE7Y0FBQSxNQUVQaUosT0FBTyxDQUFDcE8sTUFBTSxHQUFHTCxhQUFhLElBQUlpRCxPQUFPLENBQUM0TyxjQUFjO2dCQUFBb0MsVUFBQSxDQUFBOVYsSUFBQTtnQkFBQTtjQUFBO2NBQUE4VixVQUFBLENBQUF0VixFQUFBLEdBQUFtQix1QkFBQSxDQUFBaVUsVUFBQTtjQUFBRSxVQUFBLENBQUFoRyxFQUFBLEdBQUE4RixVQUFBO2NBQUFFLFVBQUEsQ0FBQS9GLEVBQUEsR0FBQTRELGtCQUFBO2NBQUFtQyxVQUFBLENBQUE5VixJQUFBO2NBQUEsT0FFOUMsSUFBSSxDQUFDc1UsV0FBVyxDQUN4QjlRLElBQUksRUFDSmpGLHNCQUFBLENBQUErUixPQUFPLEVBQUE5UyxJQUFBLENBQVA4UyxPQUFPLEVBQU8sQ0FBQyxFQUFFek8sYUFBYSxDQUFDLEVBQy9CaUQsT0FDRixDQUFDO1lBQUE7Y0FBQWdSLFVBQUEsQ0FBQWxDLEVBQUEsR0FBQWtDLFVBQUEsQ0FBQTNWLElBQUE7Y0FBQTJWLFVBQUEsQ0FBQWpDLEVBQUEsT0FBQWlDLFVBQUEsQ0FBQS9GLEVBQUEsRUFBQStGLFVBQUEsQ0FBQWxDLEVBQUE7Y0FBQWtDLFVBQUEsQ0FBQWhDLEVBQUEsR0FBQUgsa0JBQUE7Y0FBQW1DLFVBQUEsQ0FBQTlWLElBQUE7Y0FBQSxPQUNTLElBQUksQ0FBQ3NVLFdBQVcsQ0FDeEI5USxJQUFJLEVBQ0pqRixzQkFBQSxDQUFBK1IsT0FBTyxFQUFBOVMsSUFBQSxDQUFQOFMsT0FBTyxFQUFPek8sYUFBYSxDQUFDLEVBQzVCaUQsT0FDRixDQUFDO1lBQUE7Y0FBQWdSLFVBQUEsQ0FBQS9CLEVBQUEsR0FBQStCLFVBQUEsQ0FBQTNWLElBQUE7Y0FBQTJWLFVBQUEsQ0FBQTlCLEVBQUEsT0FBQThCLFVBQUEsQ0FBQWhDLEVBQUEsRUFBQWdDLFVBQUEsQ0FBQS9CLEVBQUE7Y0FBQSxPQUFBK0IsVUFBQSxDQUFBek8sTUFBQSxXQUFBeU8sVUFBQSxDQUFBdFYsRUFBQSxDQUFBaEQsSUFBQSxDQUFBQSxJQUFBLENBQUFzWSxVQUFBLENBQUF0VixFQUFBLEVBQUFzVixVQUFBLENBQUFoRyxFQUFBLEVBQUFnRyxVQUFBLENBQUFqQyxFQUFBLEVBQUFpQyxVQUFBLENBQUE5QixFQUFBO1lBQUE7Y0FHQ1YsUUFBUSxHQUFHcEUsb0JBQUEsQ0FBQW9CLE9BQU8sRUFBQTlTLElBQUEsQ0FBUDhTLE9BQU8sRUFBSyxVQUFDWSxNQUFNLEVBQUs7Z0JBQ3ZDLElBQVl2UyxFQUFFLEdBQXNDdVMsTUFBTSxDQUFsREMsRUFBRTtrQkFBWUMsS0FBSyxHQUF5QkYsTUFBTSxDQUExQzFOLElBQUk7a0JBQVM2TixVQUFVLEdBQWFILE1BQU0sQ0FBN0JHLFVBQVU7a0JBQUtDLEdBQUcsR0FBQU8sd0JBQUEsQ0FBS1gsTUFBTSxFQUFBNkUsVUFBQTtnQkFDMUQsSUFBSSxDQUFDcFgsRUFBRSxFQUFFO2tCQUNQLE1BQU0sSUFBSWIsS0FBSyxDQUFDLG1DQUFtQyxDQUFDO2dCQUN0RDtnQkFDQSxJQUFNeVQsV0FBVyxHQUFHL04sSUFBSSxLQUFJNk4sVUFBVSxhQUFWQSxVQUFVLHVCQUFWQSxVQUFVLENBQUU3TixJQUFJLEtBQUk0TixLQUFLO2dCQUNyRCxJQUFJLENBQUNHLFdBQVcsRUFBRTtrQkFDaEIsTUFBTSxJQUFJelQsS0FBSyxDQUFDLG1DQUFtQyxDQUFDO2dCQUN0RDtnQkFDQSxPQUFBNkUsYUFBQTtrQkFBU2hFLEVBQUUsRUFBRkEsRUFBRTtrQkFBRTBTLFVBQVUsRUFBRTtvQkFBRTdOLElBQUksRUFBRStOO2tCQUFZO2dCQUFDLEdBQUtELEdBQUc7Y0FDeEQsQ0FBQyxDQUFDO2NBQ0lsVCxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUNxTyxRQUFRLENBQUMsQ0FBQyxFQUFFLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQ3pILElBQUksQ0FBQyxHQUFHLENBQUM7Y0FBQSxPQUFBOFEsVUFBQSxDQUFBek8sTUFBQSxXQUN6RCxJQUFJLENBQUNvRSxPQUFPLENBQUM7Z0JBQ2xCN0IsTUFBTSxFQUFFLE9BQU87Z0JBQ2Z4TCxHQUFHLEVBQUhBLEdBQUc7Z0JBQ0gySyxJQUFJLEVBQUVzRCxlQUFBLENBQWU7a0JBQ25CK0MsU0FBUyxFQUFFdEssT0FBTyxDQUFDc0ssU0FBUyxJQUFJLEtBQUs7a0JBQ3JDa0IsT0FBTyxFQUFFZ0Q7Z0JBQ1gsQ0FBQyxDQUFDO2dCQUNGekosT0FBTyxFQUFBbEgsYUFBQSxDQUFBQSxhQUFBLEtBQ0RtQyxPQUFPLENBQUMrRSxPQUFPLElBQUksQ0FBQyxDQUFDO2tCQUN6QixjQUFjLEVBQUU7Z0JBQWtCO2NBRXRDLENBQUMsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBaU0sVUFBQSxDQUFBclYsSUFBQTtVQUFBO1FBQUEsR0FBQWtWLFNBQUE7TUFBQSxDQUNIO01BQUEsU0E5Q0tyQixXQUFXQSxDQUFBMEIsSUFBQSxFQUFBQyxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBUixZQUFBLENBQUF0VyxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVhpVixXQUFXO0lBQUE7SUFnRGpCO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQTFRLEdBQUE7SUFBQWlCLEtBQUE7SUFpQ0E7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFORTtNQUFBLElBQUFzUixPQUFBLEdBQUE3VyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBT0EsU0FBQTRXLFVBQ0U1UyxJQUFZLEVBQ1o4TSxPQUEwQixFQUMxQitGLFVBQWtCO1FBQUEsSUFBQXZSLE9BQUE7VUFBQXdSLE9BQUEsR0FBQWpYLFNBQUE7UUFBQSxPQUFBRSxtQkFBQSxDQUFBSyxJQUFBLFVBQUEyVyxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXpXLElBQUEsR0FBQXlXLFVBQUEsQ0FBQXhXLElBQUE7WUFBQTtjQUNsQjhFLE9BQW1CLEdBQUF3UixPQUFBLENBQUFwVSxNQUFBLFFBQUFvVSxPQUFBLFFBQUF2WCxTQUFBLEdBQUF1WCxPQUFBLE1BQUcsQ0FBQyxDQUFDO2NBQUEsT0FBQUUsVUFBQSxDQUFBblAsTUFBQSxXQUVqQndHLGNBQUEsQ0FBY3lDLE9BQU8sQ0FBQztjQUMzQjtjQUNBLElBQUksQ0FBQ3JELGNBQWMsQ0FBQyxFQUFFLENBQUMsR0FDckIsSUFBSSxDQUFDd0osV0FBVyxDQUFDalQsSUFBSSxFQUFFOE0sT0FBTyxFQUFFK0YsVUFBVSxFQUFFdlIsT0FBTyxDQUFDLEdBQ3BELElBQUksQ0FBQzRSLGVBQWUsQ0FBQ2xULElBQUksRUFBRThNLE9BQU8sRUFBRStGLFVBQVUsRUFBRXZSLE9BQU8sQ0FBQyxHQUMxRCxJQUFJLENBQUM0UixlQUFlLENBQUNsVCxJQUFJLEVBQUU4TSxPQUFPLEVBQUUrRixVQUFVLEVBQUV2UixPQUFPLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQTBSLFVBQUEsQ0FBQS9WLElBQUE7VUFBQTtRQUFBLEdBQUEyVixTQUFBO01BQUEsQ0FDN0Q7TUFBQSxTQVpPTyxNQUFNQSxDQUFBQyxJQUFBLEVBQUFDLElBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFYLE9BQUEsQ0FBQS9XLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBTnNYLE1BQU07SUFBQSxJQWNkO0VBQUE7SUFBQS9TLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBa1MsWUFBQSxHQUFBelgsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUNFLFNBQUF3WCxVQUNFeFQsSUFBWSxFQUNaOE0sT0FBMEIsRUFDMUIrRixVQUFrQjtRQUFBLElBQUF2UixPQUFBO1VBQUFtUyxVQUFBO1VBQUEzRCxRQUFBO1VBQUFsVixHQUFBO1VBQUE4WSxPQUFBLEdBQUE3WCxTQUFBO1FBQUEsT0FBQUUsbUJBQUEsQ0FBQUssSUFBQSxVQUFBdVgsV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUFyWCxJQUFBLEdBQUFxWCxVQUFBLENBQUFwWCxJQUFBO1lBQUE7Y0FDbEI4RSxPQUFtQixHQUFBb1MsT0FBQSxDQUFBaFYsTUFBQSxRQUFBZ1YsT0FBQSxRQUFBblksU0FBQSxHQUFBbVksT0FBQSxNQUFHLENBQUMsQ0FBQztjQUFBLE1BRXBCNUcsT0FBTyxDQUFDcE8sTUFBTSxLQUFLLENBQUM7Z0JBQUFrVixVQUFBLENBQUFwWCxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxPQUFBb1gsVUFBQSxDQUFBL1AsTUFBQSxXQUNmLEVBQUU7WUFBQTtjQUFBLE1BRVBpSixPQUFPLENBQUNwTyxNQUFNLEdBQUdMLGFBQWEsSUFBSWlELE9BQU8sQ0FBQzRPLGNBQWM7Z0JBQUEwRCxVQUFBLENBQUFwWCxJQUFBO2dCQUFBO2NBQUE7Y0FBQW9YLFVBQUEsQ0FBQTVXLEVBQUEsR0FBQW1CLHVCQUFBLENBQUFzVixVQUFBO2NBQUFHLFVBQUEsQ0FBQXRILEVBQUEsR0FBQW1ILFVBQUE7Y0FBQUcsVUFBQSxDQUFBckgsRUFBQSxHQUFBNEQsa0JBQUE7Y0FBQXlELFVBQUEsQ0FBQXBYLElBQUE7Y0FBQSxPQUU3QyxJQUFJLENBQUN5VyxXQUFXLENBQ3pCalQsSUFBSSxFQUNKakYsc0JBQUEsQ0FBQStSLE9BQU8sRUFBQTlTLElBQUEsQ0FBUDhTLE9BQU8sRUFBTyxDQUFDLEVBQUV6TyxhQUFhLENBQUMsRUFDL0J3VSxVQUFVLEVBQ1Z2UixPQUNGLENBQUM7WUFBQTtjQUFBc1MsVUFBQSxDQUFBeEQsRUFBQSxHQUFBd0QsVUFBQSxDQUFBalgsSUFBQTtjQUFBaVgsVUFBQSxDQUFBdkQsRUFBQSxPQUFBdUQsVUFBQSxDQUFBckgsRUFBQSxFQUFBcUgsVUFBQSxDQUFBeEQsRUFBQTtjQUFBd0QsVUFBQSxDQUFBdEQsRUFBQSxHQUFBSCxrQkFBQTtjQUFBeUQsVUFBQSxDQUFBcFgsSUFBQTtjQUFBLE9BQ1UsSUFBSSxDQUFDeVcsV0FBVyxDQUFDalQsSUFBSSxFQUFFakYsc0JBQUEsQ0FBQStSLE9BQU8sRUFBQTlTLElBQUEsQ0FBUDhTLE9BQU8sRUFBT3pPLGFBQWEsQ0FBQyxFQUFFd1UsVUFBVSxFQUFFdlIsT0FBTyxDQUFDO1lBQUE7Y0FBQXNTLFVBQUEsQ0FBQXJELEVBQUEsR0FBQXFELFVBQUEsQ0FBQWpYLElBQUE7Y0FBQWlYLFVBQUEsQ0FBQXBELEVBQUEsT0FBQW9ELFVBQUEsQ0FBQXRELEVBQUEsRUFBQXNELFVBQUEsQ0FBQXJELEVBQUE7Y0FBQSxPQUFBcUQsVUFBQSxDQUFBL1AsTUFBQSxXQUFBK1AsVUFBQSxDQUFBNVcsRUFBQSxDQUFBaEQsSUFBQSxDQUFBQSxJQUFBLENBQUE0WixVQUFBLENBQUE1VyxFQUFBLEVBQUE0VyxVQUFBLENBQUF0SCxFQUFBLEVBQUFzSCxVQUFBLENBQUF2RCxFQUFBLEVBQUF1RCxVQUFBLENBQUFwRCxFQUFBO1lBQUE7Y0FHbEZWLFFBQVEsR0FBR3BFLG9CQUFBLENBQUFvQixPQUFPLEVBQUE5UyxJQUFBLENBQVA4UyxPQUFPLEVBQUssVUFBQytHLFVBQWtCLEVBQUs7Z0JBQUEsSUFBQUMsVUFBQTtnQkFDbkQsSUFBc0JDLEtBQUssR0FBMkNGLFVBQVUsQ0FBdkVoQixVQUFVO2tCQUFnQm1CLFVBQVUsR0FBeUJILFVBQVUsQ0FBbkQ3VCxJQUFJO2tCQUFjNk4sVUFBVSxHQUFhZ0csVUFBVSxDQUFqQ2hHLFVBQVU7a0JBQUtDLEdBQUcsR0FBQU8sd0JBQUEsQ0FBS3dGLFVBQVUsRUFBQW5JLG9CQUFBLENBQUFvSSxVQUFBLElBQXZFakIsVUFBVSx5QkFBQTdZLElBQUEsQ0FBQThaLFVBQUEsRUFBQUcsY0FBQTtnQkFDbkIsSUFBTWxHLFdBQVcsR0FBR2lHLFVBQVUsS0FBSW5HLFVBQVUsYUFBVkEsVUFBVSx1QkFBVkEsVUFBVSxDQUFFN04sSUFBSSxLQUFJQSxJQUFJO2dCQUMxRCxJQUFJLENBQUMrVCxLQUFLLEVBQUU7a0JBQ1YsTUFBTSxJQUFJelosS0FBSyxDQUFDLHFDQUFxQyxDQUFDO2dCQUN4RDtnQkFDQSxJQUFJLENBQUN5VCxXQUFXLEVBQUU7a0JBQ2hCLE1BQU0sSUFBSXpULEtBQUssQ0FBQyxtQ0FBbUMsQ0FBQztnQkFDdEQ7Z0JBQ0EsT0FBQTZFLGFBQUEsQ0FBQU4sZUFBQSxDQUFBQSxlQUFBLEtBQVVnVSxVQUFVLEVBQUdrQixLQUFLLGlCQUFjO2tCQUFFL1QsSUFBSSxFQUFFK047Z0JBQVksQ0FBQyxHQUFLRCxHQUFHO2NBQ3pFLENBQUMsQ0FBQztjQUNJbFQsR0FBRyxHQUNQLENBQUMsSUFBSSxDQUFDcU8sUUFBUSxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFakosSUFBSSxFQUFFNlMsVUFBVSxDQUFDLENBQUNyUixJQUFJLENBQUMsR0FBRyxDQUFDO2NBQUEsT0FBQW9TLFVBQUEsQ0FBQS9QLE1BQUEsV0FDakUsSUFBSSxDQUFDb0UsT0FBTyxDQUFDO2dCQUNsQjdCLE1BQU0sRUFBRSxPQUFPO2dCQUNmeEwsR0FBRyxFQUFIQSxHQUFHO2dCQUNIMkssSUFBSSxFQUFFc0QsZUFBQSxDQUFlO2tCQUNuQitDLFNBQVMsRUFBRXRLLE9BQU8sQ0FBQ3NLLFNBQVMsSUFBSSxLQUFLO2tCQUNyQ2tCLE9BQU8sRUFBRWdEO2dCQUNYLENBQUMsQ0FBQztnQkFDRnpKLE9BQU8sRUFBQWxILGFBQUEsQ0FBQUEsYUFBQSxLQUNEbUMsT0FBTyxDQUFDK0UsT0FBTyxJQUFJLENBQUMsQ0FBQztrQkFDekIsY0FBYyxFQUFFO2dCQUFrQjtjQUV0QyxDQUFDLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQXVOLFVBQUEsQ0FBQTNXLElBQUE7VUFBQTtRQUFBLEdBQUF1VyxTQUFBO01BQUEsQ0FDSDtNQUFBLFNBN0NLUCxXQUFXQSxDQUFBaUIsSUFBQSxFQUFBQyxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBYixZQUFBLENBQUEzWCxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVhvWCxXQUFXO0lBQUEsSUErQ25CO0VBQUE7SUFBQTdTLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBZ1QsZ0JBQUEsR0FBQXZZLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FDRSxTQUFBc1ksVUFDRXRVLElBQVksRUFDWjhNLE9BQTBCLEVBQzFCK0YsVUFBa0I7UUFBQSxJQUFBMEIsTUFBQTtRQUFBLElBQUFqVCxPQUFBO1VBQUFrVCxPQUFBO1VBQUExRSxRQUFBO1VBQUEyRSxPQUFBO1VBQUFDLE9BQUEsR0FBQTdZLFNBQUE7UUFBQSxPQUFBRSxtQkFBQSxDQUFBSyxJQUFBLFVBQUF1WSxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXJZLElBQUEsR0FBQXFZLFVBQUEsQ0FBQXBZLElBQUE7WUFBQTtjQUNsQjhFLE9BQW1CLEdBQUFvVCxPQUFBLENBQUFoVyxNQUFBLFFBQUFnVyxPQUFBLFFBQUFuWixTQUFBLEdBQUFtWixPQUFBLE1BQUcsQ0FBQyxDQUFDO2NBRWxCRixPQUFPLEdBQUduSyxjQUFBLENBQWN5QyxPQUFPLENBQUM7Y0FDaENnRCxRQUFRLEdBQUd6RixjQUFBLENBQWN5QyxPQUFPLENBQUMsR0FBR0EsT0FBTyxHQUFHLENBQUNBLE9BQU8sQ0FBQztjQUFBLE1BQ3pEZ0QsUUFBUSxDQUFDcFIsTUFBTSxHQUFHLElBQUksQ0FBQ2EsV0FBVztnQkFBQXFWLFVBQUEsQ0FBQXBZLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE1BQzlCLElBQUlsQyxLQUFLLENBQUMsdUNBQXVDLENBQUM7WUFBQTtjQUFBc2EsVUFBQSxDQUFBcFksSUFBQTtjQUFBLE9BRXBDeUosUUFBQSxDQUFRd0YsR0FBRyxDQUMvQkMsb0JBQUEsQ0FBQW9FLFFBQVEsRUFBQTlWLElBQUEsQ0FBUjhWLFFBQVEsRUFBSyxVQUFDcEMsTUFBTSxFQUFLO2dCQUFBLElBQUFtSCxVQUFBO2dCQUN2QixJQUFzQmQsS0FBSyxHQUFzQ3JHLE1BQU0sQ0FBOURtRixVQUFVO2tCQUFnQmpGLEtBQUssR0FBeUJGLE1BQU0sQ0FBMUMxTixJQUFJO2tCQUFTNk4sVUFBVSxHQUFhSCxNQUFNLENBQTdCRyxVQUFVO2tCQUFLQyxHQUFHLEdBQUFPLHdCQUFBLENBQUtYLE1BQU0sRUFBQWhDLG9CQUFBLENBQUFtSixVQUFBLElBQTlEaEMsVUFBVSx5QkFBQTdZLElBQUEsQ0FBQTZhLFVBQUEsRUFBQVosY0FBQTtnQkFDbkIsSUFBTXJaLEdBQUcsR0FBRyxDQUFDMlosTUFBSSxDQUFDdEwsUUFBUSxDQUFDLENBQUMsRUFBRSxVQUFVLEVBQUVqSixJQUFJLEVBQUU2UyxVQUFVLEVBQUVrQixLQUFLLENBQUMsQ0FBQ3ZTLElBQUksQ0FDckUsR0FDRixDQUFDO2dCQUNELE9BQU8rUyxNQUFJLENBQUN0TSxPQUFPLENBQ2pCO2tCQUNFN0IsTUFBTSxFQUFFLE9BQU87a0JBQ2Z4TCxHQUFHLEVBQUhBLEdBQUc7a0JBQ0gySyxJQUFJLEVBQUVzRCxlQUFBLENBQWVpRixHQUFHLENBQUM7a0JBQ3pCekgsT0FBTyxFQUFBbEgsYUFBQSxDQUFBQSxhQUFBLEtBQ0RtQyxPQUFPLENBQUMrRSxPQUFPLElBQUksQ0FBQyxDQUFDO29CQUN6QixjQUFjLEVBQUU7a0JBQWtCO2dCQUV0QyxDQUFDLEVBQ0Q7a0JBQ0VpTCxpQkFBaUIsRUFBRTtvQkFBRXhULE9BQU8sRUFBRSxJQUFJO29CQUFFQyxNQUFNLEVBQUU7a0JBQUc7Z0JBQ2pELENBQ0YsQ0FBQyxDQUFDNE4sS0FBSyxDQUFDLFVBQUM5TixHQUFHLEVBQUs7a0JBQ2Y7a0JBQ0E7a0JBQ0E7a0JBQ0EsSUFBSSxDQUFDMlcsT0FBTyxJQUFJbFQsT0FBTyxDQUFDc0ssU0FBUyxJQUFJLENBQUMvTixHQUFHLENBQUNnTyxTQUFTLEVBQUU7b0JBQ25ELE1BQU1oTyxHQUFHO2tCQUNYO2tCQUNBLE9BQU9ELFlBQVksQ0FBQ0MsR0FBRyxDQUFDO2dCQUMxQixDQUFDLENBQUM7Y0FDSixDQUFDLENBQ0gsQ0FBQztZQUFBO2NBN0JLNFcsT0FBTyxHQUFBRyxVQUFBLENBQUFqWSxJQUFBO2NBQUEsT0FBQWlZLFVBQUEsQ0FBQS9RLE1BQUEsV0E4Qk4yUSxPQUFPLEdBQUdDLE9BQU8sR0FBR0EsT0FBTyxDQUFDLENBQUMsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBRyxVQUFBLENBQUEzWCxJQUFBO1VBQUE7UUFBQSxHQUFBcVgsU0FBQTtNQUFBLENBQ3RDO01BQUEsU0ExQ0twQixlQUFlQSxDQUFBNEIsSUFBQSxFQUFBQyxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBWCxnQkFBQSxDQUFBelksS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFmcVgsZUFBZTtJQUFBO0lBNENyQjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUE5UyxHQUFBO0lBQUFpQixLQUFBO0lBa0JBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7SUFKRTtNQUFBLElBQUE0VCxRQUFBLEdBQUFuWixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBS0EsU0FBQWtaLFVBQ0VsVixJQUFZLEVBQ1ppSyxHQUFzQjtRQUFBLElBQUEzSSxPQUFBO1VBQUE2VCxPQUFBLEdBQUF0WixTQUFBO1FBQUEsT0FBQUUsbUJBQUEsQ0FBQUssSUFBQSxVQUFBZ1osV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUE5WSxJQUFBLEdBQUE4WSxVQUFBLENBQUE3WSxJQUFBO1lBQUE7Y0FDdEI4RSxPQUFtQixHQUFBNlQsT0FBQSxDQUFBelcsTUFBQSxRQUFBeVcsT0FBQSxRQUFBNVosU0FBQSxHQUFBNFosT0FBQSxNQUFHLENBQUMsQ0FBQztjQUFBLE9BQUFFLFVBQUEsQ0FBQXhSLE1BQUEsV0FFakJ3RyxjQUFBLENBQWNKLEdBQUcsQ0FBQztjQUNyQjtjQUNBLElBQUksQ0FBQ1IsY0FBYyxDQUFDLEVBQUUsQ0FBQyxHQUNyQixJQUFJLENBQUM2TCxZQUFZLENBQUN0VixJQUFJLEVBQUVpSyxHQUFHLEVBQUUzSSxPQUFPLENBQUMsR0FDckMsSUFBSSxDQUFDaVUsZ0JBQWdCLENBQUN2VixJQUFJLEVBQUVpSyxHQUFHLEVBQUUzSSxPQUFPLENBQUMsR0FDM0MsSUFBSSxDQUFDa1UsY0FBYyxDQUFDeFYsSUFBSSxFQUFFaUssR0FBRyxFQUFFM0ksT0FBTyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUErVCxVQUFBLENBQUFwWSxJQUFBO1VBQUE7UUFBQSxHQUFBaVksU0FBQTtNQUFBLENBQzVDO01BQUEsU0FYS25XLE9BQU9BLENBQUEwVyxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBVCxRQUFBLENBQUFyWixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVBrRCxPQUFPO0lBQUEsSUFhYjtFQUFBO0lBQUFxQixHQUFBO0lBQUFpQixLQUFBO01BQUEsSUFBQXNVLGVBQUEsR0FBQTdaLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FDQSxTQUFBNFosVUFDRTVWLElBQVksRUFDWjdFLEVBQVUsRUFDVm1HLE9BQW1CO1FBQUEsSUFBQTFHLEdBQUE7UUFBQSxPQUFBbUIsbUJBQUEsQ0FBQUssSUFBQSxVQUFBeVosV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUF2WixJQUFBLEdBQUF1WixVQUFBLENBQUF0WixJQUFBO1lBQUE7Y0FFYjVCLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQ3FPLFFBQVEsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFakosSUFBSSxFQUFFN0UsRUFBRSxDQUFDLENBQUNxRyxJQUFJLENBQUMsR0FBRyxDQUFDO2NBQUEsT0FBQXNVLFVBQUEsQ0FBQWpTLE1BQUEsV0FDdEQsSUFBSSxDQUFDb0UsT0FBTyxDQUNqQjtnQkFDRTdCLE1BQU0sRUFBRSxRQUFRO2dCQUNoQnhMLEdBQUcsRUFBSEEsR0FBRztnQkFDSHlMLE9BQU8sRUFBRS9FLE9BQU8sQ0FBQytFLE9BQU8sSUFBSSxDQUFDO2NBQy9CLENBQUMsRUFDRDtnQkFDRWlMLGlCQUFpQixFQUFFO2tCQUFFblcsRUFBRSxFQUFGQSxFQUFFO2tCQUFFMkMsT0FBTyxFQUFFLElBQUk7a0JBQUVDLE1BQU0sRUFBRTtnQkFBRztjQUNyRCxDQUNGLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQStYLFVBQUEsQ0FBQTdZLElBQUE7VUFBQTtRQUFBLEdBQUEyWSxTQUFBO01BQUEsQ0FDRjtNQUFBLFNBaEJLSixjQUFjQSxDQUFBTyxJQUFBLEVBQUFDLElBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFOLGVBQUEsQ0FBQS9aLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBZDJaLGNBQWM7SUFBQSxJQWtCcEI7RUFBQTtJQUFBcFYsR0FBQTtJQUFBaUIsS0FBQTtNQUFBLElBQUE2VSxpQkFBQSxHQUFBcGEsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUNBLFNBQUFtYSxVQUF1Qm5XLElBQVksRUFBRWlLLEdBQWEsRUFBRTNJLE9BQW1CO1FBQUEsSUFBQThVLE1BQUE7UUFBQSxPQUFBcmEsbUJBQUEsQ0FBQUssSUFBQSxVQUFBaWEsV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUEvWixJQUFBLEdBQUErWixVQUFBLENBQUE5WixJQUFBO1lBQUE7Y0FBQSxNQUNqRXlOLEdBQUcsQ0FBQ3ZMLE1BQU0sR0FBRyxJQUFJLENBQUNhLFdBQVc7Z0JBQUErVyxVQUFBLENBQUE5WixJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUN6QixJQUFJbEMsS0FBSyxDQUFDLHVDQUF1QyxDQUFDO1lBQUE7Y0FBQSxPQUFBZ2MsVUFBQSxDQUFBelMsTUFBQSxXQUVuRG9DLFFBQUEsQ0FBUXdGLEdBQUcsQ0FDaEJDLG9CQUFBLENBQUF6QixHQUFHLEVBQUFqUSxJQUFBLENBQUhpUSxHQUFHLEVBQUssVUFBQzlPLEVBQUU7Z0JBQUEsT0FDVGliLE1BQUksQ0FBQ1osY0FBYyxDQUFDeFYsSUFBSSxFQUFFN0UsRUFBRSxFQUFFbUcsT0FBTyxDQUFDLENBQUNxSyxLQUFLLENBQUMsVUFBQzlOLEdBQUcsRUFBSztrQkFDcEQ7a0JBQ0E7a0JBQ0E7a0JBQ0EsSUFBSXlELE9BQU8sQ0FBQ3NLLFNBQVMsSUFBSSxDQUFDL04sR0FBRyxDQUFDZ08sU0FBUyxFQUFFO29CQUN2QyxNQUFNaE8sR0FBRztrQkFDWDtrQkFDQSxPQUFPRCxZQUFZLENBQUNDLEdBQUcsQ0FBQztnQkFDMUIsQ0FBQyxDQUFDO2NBQUEsQ0FDSixDQUNGLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQXlZLFVBQUEsQ0FBQXJaLElBQUE7VUFBQTtRQUFBLEdBQUFrWixTQUFBO01BQUEsQ0FDRjtNQUFBLFNBakJLWixnQkFBZ0JBLENBQUFnQixJQUFBLEVBQUFDLElBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFQLGlCQUFBLENBQUF0YSxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQWhCMFosZ0JBQWdCO0lBQUEsSUFtQnRCO0VBQUE7SUFBQW5WLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBcVYsYUFBQSxHQUFBNWEsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUNBLFNBQUEyYSxVQUNFM1csSUFBWSxFQUNaaUssR0FBYSxFQUNiM0ksT0FBbUI7UUFBQSxJQUFBc1YsVUFBQSxFQUFBaGMsR0FBQTtRQUFBLE9BQUFtQixtQkFBQSxDQUFBSyxJQUFBLFVBQUF5YSxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXZhLElBQUEsR0FBQXVhLFVBQUEsQ0FBQXRhLElBQUE7WUFBQTtjQUFBLE1BRWZ5TixHQUFHLENBQUN2TCxNQUFNLEtBQUssQ0FBQztnQkFBQW9ZLFVBQUEsQ0FBQXRhLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE9BQUFzYSxVQUFBLENBQUFqVCxNQUFBLFdBQ1gsRUFBRTtZQUFBO2NBQUEsTUFFUG9HLEdBQUcsQ0FBQ3ZMLE1BQU0sR0FBR0wsYUFBYSxJQUFJaUQsT0FBTyxDQUFDNE8sY0FBYztnQkFBQTRHLFVBQUEsQ0FBQXRhLElBQUE7Z0JBQUE7Y0FBQTtjQUFBc2EsVUFBQSxDQUFBOVosRUFBQSxHQUFBbUIsdUJBQUEsQ0FBQXlZLFVBQUE7Y0FBQUUsVUFBQSxDQUFBeEssRUFBQSxHQUFBc0ssVUFBQTtjQUFBRSxVQUFBLENBQUF2SyxFQUFBLEdBQUE0RCxrQkFBQTtjQUFBMkcsVUFBQSxDQUFBdGEsSUFBQTtjQUFBLE9BRTFDLElBQUksQ0FBQzhZLFlBQVksQ0FDekJ0VixJQUFJLEVBQ0pqRixzQkFBQSxDQUFBa1AsR0FBRyxFQUFBalEsSUFBQSxDQUFIaVEsR0FBRyxFQUFPLENBQUMsRUFBRTVMLGFBQWEsQ0FBQyxFQUMzQmlELE9BQ0YsQ0FBQztZQUFBO2NBQUF3VixVQUFBLENBQUExRyxFQUFBLEdBQUEwRyxVQUFBLENBQUFuYSxJQUFBO2NBQUFtYSxVQUFBLENBQUF6RyxFQUFBLE9BQUF5RyxVQUFBLENBQUF2SyxFQUFBLEVBQUF1SyxVQUFBLENBQUExRyxFQUFBO2NBQUEwRyxVQUFBLENBQUF4RyxFQUFBLEdBQUFILGtCQUFBO2NBQUEyRyxVQUFBLENBQUF0YSxJQUFBO2NBQUEsT0FDUyxJQUFJLENBQUM4WSxZQUFZLENBQUN0VixJQUFJLEVBQUVqRixzQkFBQSxDQUFBa1AsR0FBRyxFQUFBalEsSUFBQSxDQUFIaVEsR0FBRyxFQUFPNUwsYUFBYSxDQUFDLEVBQUVpRCxPQUFPLENBQUM7WUFBQTtjQUFBd1YsVUFBQSxDQUFBdkcsRUFBQSxHQUFBdUcsVUFBQSxDQUFBbmEsSUFBQTtjQUFBbWEsVUFBQSxDQUFBdEcsRUFBQSxPQUFBc0csVUFBQSxDQUFBeEcsRUFBQSxFQUFBd0csVUFBQSxDQUFBdkcsRUFBQTtjQUFBLE9BQUF1RyxVQUFBLENBQUFqVCxNQUFBLFdBQUFpVCxVQUFBLENBQUE5WixFQUFBLENBQUFoRCxJQUFBLENBQUFBLElBQUEsQ0FBQThjLFVBQUEsQ0FBQTlaLEVBQUEsRUFBQThaLFVBQUEsQ0FBQXhLLEVBQUEsRUFBQXdLLFVBQUEsQ0FBQXpHLEVBQUEsRUFBQXlHLFVBQUEsQ0FBQXRHLEVBQUE7WUFBQTtjQUdwRTVWLEdBQUcsR0FDTCxDQUFDLElBQUksQ0FBQ3FPLFFBQVEsQ0FBQyxDQUFDLEVBQUUsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDekgsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHeUksR0FBRyxDQUFDekksSUFBSSxDQUFDLEdBQUcsQ0FBQztjQUMzRSxJQUFJRixPQUFPLENBQUNzSyxTQUFTLEVBQUU7Z0JBQ3JCaFIsR0FBRyxJQUFJLGlCQUFpQjtjQUMxQjtjQUFDLE9BQUFrYyxVQUFBLENBQUFqVCxNQUFBLFdBQ00sSUFBSSxDQUFDb0UsT0FBTyxDQUFDO2dCQUNsQjdCLE1BQU0sRUFBRSxRQUFRO2dCQUNoQnhMLEdBQUcsRUFBSEEsR0FBRztnQkFDSHlMLE9BQU8sRUFBRS9FLE9BQU8sQ0FBQytFLE9BQU8sSUFBSSxDQUFDO2NBQy9CLENBQUMsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBeVEsVUFBQSxDQUFBN1osSUFBQTtVQUFBO1FBQUEsR0FBQTBaLFNBQUE7TUFBQSxDQUNIO01BQUEsU0E1QktyQixZQUFZQSxDQUFBeUIsSUFBQSxFQUFBQyxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBUCxhQUFBLENBQUE5YSxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVp5WixZQUFZO0lBQUE7RUFBQTtJQUFBbFYsR0FBQTtJQUFBaUIsS0FBQTtJQXdDbEI7QUFDRjtBQUNBO0lBRkU7TUFBQSxJQUFBNlYsU0FBQSxHQUFBcGIsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUFtYixVQUFlblgsSUFBWTtRQUFBLElBQUFwRixHQUFBLEVBQUEySyxJQUFBO1FBQUEsT0FBQXhKLG1CQUFBLENBQUFLLElBQUEsVUFBQWdiLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBOWEsSUFBQSxHQUFBOGEsVUFBQSxDQUFBN2EsSUFBQTtZQUFBO2NBQ25CNUIsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDcU8sUUFBUSxDQUFDLENBQUMsRUFBRSxVQUFVLEVBQUVqSixJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUN3QixJQUFJLENBQUMsR0FBRyxDQUFDO2NBQUE2VixVQUFBLENBQUE3YSxJQUFBO2NBQUEsT0FDbEQsSUFBSSxDQUFDeUwsT0FBTyxDQUFDck4sR0FBRyxDQUFDO1lBQUE7Y0FBOUIySyxJQUFJLEdBQUE4UixVQUFBLENBQUExYSxJQUFBO2NBQUEsT0FBQTBhLFVBQUEsQ0FBQXhULE1BQUEsV0FDSDBCLElBQUk7WUFBQTtZQUFBO2NBQUEsT0FBQThSLFVBQUEsQ0FBQXBhLElBQUE7VUFBQTtRQUFBLEdBQUFrYSxTQUFBO01BQUEsQ0FDWjtNQUFBLFNBSktsWCxRQUFRQSxDQUFBcVgsSUFBQTtRQUFBLE9BQUFKLFNBQUEsQ0FBQXRiLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBUm9FLFFBQVE7SUFBQTtJQU1kO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQUcsR0FBQTtJQUFBaUIsS0FBQTtNQUFBLElBQUFrVyxlQUFBLEdBQUF6YixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQXdiLFVBQUE7UUFBQSxJQUFBNWMsR0FBQSxFQUFBMkssSUFBQTtRQUFBLE9BQUF4SixtQkFBQSxDQUFBSyxJQUFBLFVBQUFxYixXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQW5iLElBQUEsR0FBQW1iLFVBQUEsQ0FBQWxiLElBQUE7WUFBQTtjQUNRNUIsR0FBRyxNQUFBd0QsTUFBQSxDQUFNLElBQUksQ0FBQzZLLFFBQVEsQ0FBQyxDQUFDO2NBQUF5TyxVQUFBLENBQUFsYixJQUFBO2NBQUEsT0FDWCxJQUFJLENBQUN5TCxPQUFPLENBQUNyTixHQUFHLENBQUM7WUFBQTtjQUE5QjJLLElBQUksR0FBQW1TLFVBQUEsQ0FBQS9hLElBQUE7Y0FBQSxPQUFBK2EsVUFBQSxDQUFBN1QsTUFBQSxXQUNIMEIsSUFBSTtZQUFBO1lBQUE7Y0FBQSxPQUFBbVMsVUFBQSxDQUFBemEsSUFBQTtVQUFBO1FBQUEsR0FBQXVhLFNBQUE7TUFBQSxDQUNaO01BQUEsU0FKSzdXLGNBQWNBLENBQUE7UUFBQSxPQUFBNFcsZUFBQSxDQUFBM2IsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFkOEUsY0FBYztJQUFBO0lBTXBCO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQVAsR0FBQTtJQUFBaUIsS0FBQSxFQUlBLFNBQUEwQixPQUFPQSxDQUE0Qi9DLElBQWdCLEVBQWlCO01BQ2xFLElBQU04QyxFQUFFLEdBQUcsSUFBSSxDQUFDWixRQUFRLENBQUNsQyxJQUFJLENBQU0sSUFBSSxJQUFJbEgsT0FBTyxDQUFDLElBQUksRUFBRWtILElBQVMsQ0FBQztNQUNuRSxJQUFJLENBQUNrQyxRQUFRLENBQUNsQyxJQUFJLENBQU0sR0FBRzhDLEVBQUU7TUFDN0IsT0FBT0EsRUFBRTtJQUNYOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUExQyxHQUFBO0lBQUFpQixLQUFBO01BQUEsSUFBQXNXLFNBQUEsR0FBQTdiLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBNGIsVUFBQTtRQUFBLElBQUFDLGNBQUE7UUFBQSxJQUFBdlcsT0FBQTtVQUFBMUcsR0FBQTtVQUFBa2QsSUFBQTtVQUFBNWIsR0FBQTtVQUFBNmIsT0FBQSxHQUFBbGMsU0FBQTtRQUFBLE9BQUFFLG1CQUFBLENBQUFLLElBQUEsVUFBQTRiLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBMWIsSUFBQSxHQUFBMGIsVUFBQSxDQUFBemIsSUFBQTtZQUFBO2NBQWU4RSxPQUFpRCxHQUFBeVcsT0FBQSxDQUFBclosTUFBQSxRQUFBcVosT0FBQSxRQUFBeGMsU0FBQSxHQUFBd2MsT0FBQSxNQUFHLENBQUMsQ0FBQztjQUMvRG5kLEdBQUcsSUFBQWlkLGNBQUEsR0FBRyxJQUFJLENBQUMxYixRQUFRLGNBQUEwYixjQUFBLHVCQUFiQSxjQUFBLENBQWVqZCxHQUFHO2NBQUEsSUFDdkJBLEdBQUc7Z0JBQUFxZCxVQUFBLENBQUF6YixJQUFBO2dCQUFBO2NBQUE7Y0FBQXliLFVBQUEsQ0FBQXpiLElBQUE7Y0FBQSxPQUNZLElBQUksQ0FBQ3lMLE9BQU8sQ0FBdUI7Z0JBQ25EN0IsTUFBTSxFQUFFLEtBQUs7Z0JBQ2J4TCxHQUFHLEVBQUUsSUFBSSxDQUFDcU8sUUFBUSxDQUFDLENBQUM7Z0JBQ3BCNUMsT0FBTyxFQUFFL0UsT0FBTyxDQUFDK0U7Y0FDbkIsQ0FBQyxDQUFDO1lBQUE7Y0FKSW5LLElBQUcsR0FBQStiLFVBQUEsQ0FBQXRiLElBQUE7Y0FLVC9CLEdBQUcsR0FBR3NCLElBQUcsQ0FBQ2djLFFBQVE7WUFBQztjQUVyQnRkLEdBQUcsSUFBSSxjQUFjO2NBQ3JCLElBQUksSUFBSSxDQUFDa0MsV0FBVyxFQUFFO2dCQUNwQmxDLEdBQUcsb0JBQUF3RCxNQUFBLENBQW9Ca0wsa0JBQWtCLENBQUMsSUFBSSxDQUFDeE0sV0FBVyxDQUFDLENBQUU7Y0FDL0Q7Y0FBQ21iLFVBQUEsQ0FBQXpiLElBQUE7Y0FBQSxPQUNpQixJQUFJLENBQUN5TCxPQUFPLENBQWU7Z0JBQUU3QixNQUFNLEVBQUUsS0FBSztnQkFBRXhMLEdBQUcsRUFBSEE7Y0FBSSxDQUFDLENBQUM7WUFBQTtjQUE5RHNCLEdBQUcsR0FBQStiLFVBQUEsQ0FBQXRiLElBQUE7Y0FDVCxJQUFJLENBQUNSLFFBQVEsR0FBRztnQkFDZGhCLEVBQUUsRUFBRWUsR0FBRyxDQUFDaWMsT0FBTztnQkFDZmpkLGNBQWMsRUFBRWdCLEdBQUcsQ0FBQ2tjLGVBQWU7Z0JBQ25DeGQsR0FBRyxFQUFFc0IsR0FBRyxDQUFDZjtjQUNYLENBQUM7Y0FBQyxPQUFBOGMsVUFBQSxDQUFBcFUsTUFBQSxXQUNLM0gsR0FBRztZQUFBO1lBQUE7Y0FBQSxPQUFBK2IsVUFBQSxDQUFBaGIsSUFBQTtVQUFBO1FBQUEsR0FBQTJhLFNBQUE7TUFBQSxDQUNYO01BQUEsU0FyQktNLFFBQVFBLENBQUE7UUFBQSxPQUFBUCxTQUFBLENBQUEvYixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVJxYyxRQUFRO0lBQUE7SUF1QmQ7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBOVgsR0FBQTtJQUFBaUIsS0FBQTtNQUFBLElBQUFnWCxPQUFBLEdBQUF2YyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQXNjLFVBQWF0WSxJQUFzQixFQUFFeUksS0FBYztRQUFBLElBQUE3TixHQUFBLEVBQUEyZCxtQkFBQSxFQUFBQyxXQUFBO1FBQUEsT0FBQXpjLG1CQUFBLENBQUFLLElBQUEsVUFBQXFjLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBbmMsSUFBQSxHQUFBbWMsVUFBQSxDQUFBbGMsSUFBQTtZQUFBO2NBQ2pEO2NBQ0EsSUFBSSxPQUFPd0QsSUFBSSxLQUFLLFFBQVEsRUFBRTtnQkFDNUJ5SSxLQUFLLEdBQUd6SSxJQUFJO2dCQUNaQSxJQUFJLEdBQUd6RSxTQUFTO2NBQ2xCO2NBQUMsS0FFR3lFLElBQUk7Z0JBQUEwWSxVQUFBLENBQUFsYyxJQUFBO2dCQUFBO2NBQUE7Y0FDTjVCLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQ3FPLFFBQVEsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFakosSUFBSSxDQUFDLENBQUN3QixJQUFJLENBQUMsR0FBRyxDQUFDO2NBQUNrWCxVQUFBLENBQUFsYyxJQUFBO2NBQUEsT0FDdEIsSUFBSSxDQUFDeUwsT0FBTyxDQUN4Q3JOLEdBQ0YsQ0FBQztZQUFBO2NBQUEyZCxtQkFBQSxHQUFBRyxVQUFBLENBQUEvYixJQUFBO2NBRk82YixXQUFXLEdBQUFELG1CQUFBLENBQVhDLFdBQVc7Y0FBQSxPQUFBRSxVQUFBLENBQUE3VSxNQUFBLFdBR1o0RSxLQUFLLEdBQUcxTixzQkFBQSxDQUFBeWQsV0FBVyxFQUFBeGUsSUFBQSxDQUFYd2UsV0FBVyxFQUFPLENBQUMsRUFBRS9QLEtBQUssQ0FBQyxHQUFHK1AsV0FBVztZQUFBO2NBRTFENWQsR0FBRyxNQUFBd0QsTUFBQSxDQUFNLElBQUksQ0FBQzZLLFFBQVEsQ0FBQyxDQUFDLFlBQVM7Y0FDakMsSUFBSVIsS0FBSyxFQUFFO2dCQUNUN04sR0FBRyxjQUFBd0QsTUFBQSxDQUFjcUssS0FBSyxDQUFFO2NBQzFCO2NBQUMsT0FBQWlRLFVBQUEsQ0FBQTdVLE1BQUEsV0FDTSxJQUFJLENBQUNvRSxPQUFPLENBQVdyTixHQUFHLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQThkLFVBQUEsQ0FBQXpiLElBQUE7VUFBQTtRQUFBLEdBQUFxYixTQUFBO01BQUEsQ0FDbkM7TUFBQSxTQW5CS0ssTUFBTUEsQ0FBQUMsSUFBQSxFQUFBQyxJQUFBO1FBQUEsT0FBQVIsT0FBQSxDQUFBemMsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFOOGMsTUFBTTtJQUFBO0lBcUJaO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQXZZLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBeVgsUUFBQSxHQUFBaGQsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUErYyxVQUNFL1ksSUFBWSxFQUNaZ1osS0FBb0IsRUFDcEJDLEdBQWtCO1FBQUEsSUFBQXJlLEdBQUEsRUFBQTJLLElBQUE7UUFBQSxPQUFBeEosbUJBQUEsQ0FBQUssSUFBQSxVQUFBOGMsV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUE1YyxJQUFBLEdBQUE0YyxVQUFBLENBQUEzYyxJQUFBO1lBQUE7Y0FFbEI7Y0FDSTVCLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQ3FPLFFBQVEsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFakosSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDd0IsSUFBSSxDQUFDLEdBQUcsQ0FBQztjQUNsRSxJQUFJLE9BQU93WCxLQUFLLEtBQUssUUFBUSxFQUFFO2dCQUM3QkEsS0FBSyxHQUFHLElBQUlJLElBQUksQ0FBQ0osS0FBSyxDQUFDO2NBQ3pCO2NBQ0FBLEtBQUssR0FBRy9mLFVBQVUsQ0FBQytmLEtBQUssQ0FBQztjQUN6QnBlLEdBQUcsY0FBQXdELE1BQUEsQ0FBY2tMLGtCQUFrQixDQUFDMFAsS0FBSyxDQUFDLENBQUU7Y0FDNUMsSUFBSSxPQUFPQyxHQUFHLEtBQUssUUFBUSxFQUFFO2dCQUMzQkEsR0FBRyxHQUFHLElBQUlHLElBQUksQ0FBQ0gsR0FBRyxDQUFDO2NBQ3JCO2NBQ0FBLEdBQUcsR0FBR2hnQixVQUFVLENBQUNnZ0IsR0FBRyxDQUFDO2NBQ3JCcmUsR0FBRyxZQUFBd0QsTUFBQSxDQUFZa0wsa0JBQWtCLENBQUMyUCxHQUFHLENBQUMsQ0FBRTtjQUFDRSxVQUFBLENBQUEzYyxJQUFBO2NBQUEsT0FDdEIsSUFBSSxDQUFDeUwsT0FBTyxDQUFDck4sR0FBRyxDQUFDO1lBQUE7Y0FBOUIySyxJQUFJLEdBQUE0VCxVQUFBLENBQUF4YyxJQUFBO2NBQUEsT0FBQXdjLFVBQUEsQ0FBQXRWLE1BQUEsV0FDSDBCLElBQUk7WUFBQTtZQUFBO2NBQUEsT0FBQTRULFVBQUEsQ0FBQWxjLElBQUE7VUFBQTtRQUFBLEdBQUE4YixTQUFBO01BQUEsQ0FDWjtNQUFBLFNBbkJLTSxPQUFPQSxDQUFBQyxJQUFBLEVBQUFDLElBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFWLFFBQUEsQ0FBQWxkLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBUHdkLE9BQU87SUFBQTtJQXFCYjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUFqWixHQUFBO0lBQUFpQixLQUFBO01BQUEsSUFBQW9ZLFFBQUEsR0FBQTNkLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBMGQsVUFDRTFaLElBQVksRUFDWmdaLEtBQW9CLEVBQ3BCQyxHQUFrQjtRQUFBLElBQUFyZSxHQUFBLEVBQUEySyxJQUFBO1FBQUEsT0FBQXhKLG1CQUFBLENBQUFLLElBQUEsVUFBQXVkLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBcmQsSUFBQSxHQUFBcWQsVUFBQSxDQUFBcGQsSUFBQTtZQUFBO2NBRWxCO2NBQ0k1QixHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUNxTyxRQUFRLENBQUMsQ0FBQyxFQUFFLFVBQVUsRUFBRWpKLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQ3dCLElBQUksQ0FBQyxHQUFHLENBQUM7Y0FDbEUsSUFBSSxPQUFPd1gsS0FBSyxLQUFLLFFBQVEsRUFBRTtnQkFDN0JBLEtBQUssR0FBRyxJQUFJSSxJQUFJLENBQUNKLEtBQUssQ0FBQztjQUN6QjtjQUNBQSxLQUFLLEdBQUcvZixVQUFVLENBQUMrZixLQUFLLENBQUM7Y0FDekJwZSxHQUFHLGNBQUF3RCxNQUFBLENBQWNrTCxrQkFBa0IsQ0FBQzBQLEtBQUssQ0FBQyxDQUFFO2NBRTVDLElBQUksT0FBT0MsR0FBRyxLQUFLLFFBQVEsRUFBRTtnQkFDM0JBLEdBQUcsR0FBRyxJQUFJRyxJQUFJLENBQUNILEdBQUcsQ0FBQztjQUNyQjtjQUNBQSxHQUFHLEdBQUdoZ0IsVUFBVSxDQUFDZ2dCLEdBQUcsQ0FBQztjQUNyQnJlLEdBQUcsWUFBQXdELE1BQUEsQ0FBWWtMLGtCQUFrQixDQUFDMlAsR0FBRyxDQUFDLENBQUU7Y0FBQ1csVUFBQSxDQUFBcGQsSUFBQTtjQUFBLE9BQ3RCLElBQUksQ0FBQ3lMLE9BQU8sQ0FBQ3JOLEdBQUcsQ0FBQztZQUFBO2NBQTlCMkssSUFBSSxHQUFBcVUsVUFBQSxDQUFBamQsSUFBQTtjQUFBLE9BQUFpZCxVQUFBLENBQUEvVixNQUFBLFdBQ0gwQixJQUFJO1lBQUE7WUFBQTtjQUFBLE9BQUFxVSxVQUFBLENBQUEzYyxJQUFBO1VBQUE7UUFBQSxHQUFBeWMsU0FBQTtNQUFBLENBQ1o7TUFBQSxTQXBCS0csT0FBT0EsQ0FBQUMsSUFBQSxFQUFBQyxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBUCxRQUFBLENBQUE3ZCxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVBnZSxPQUFPO0lBQUE7SUFzQmI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBelosR0FBQTtJQUFBaUIsS0FBQTtNQUFBLElBQUE0WSxLQUFBLEdBQUFuZSxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQWtlLFVBQUE7UUFBQSxJQUFBdGYsR0FBQSxFQUFBMkssSUFBQTtRQUFBLE9BQUF4SixtQkFBQSxDQUFBSyxJQUFBLFVBQUErZCxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTdkLElBQUEsR0FBQTZkLFVBQUEsQ0FBQTVkLElBQUE7WUFBQTtjQUNRNUIsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDcU8sUUFBUSxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQ3pILElBQUksQ0FBQyxHQUFHLENBQUM7Y0FBQTRZLFVBQUEsQ0FBQTVkLElBQUE7Y0FBQSxPQUM1QixJQUFJLENBQUN5TCxPQUFPLENBQUNyTixHQUFHLENBQUM7WUFBQTtjQUE5QjJLLElBQUksR0FBQTZVLFVBQUEsQ0FBQXpkLElBQUE7Y0FBQSxPQUFBeWQsVUFBQSxDQUFBdlcsTUFBQSxXQUNIMEIsSUFBSTtZQUFBO1lBQUE7Y0FBQSxPQUFBNlUsVUFBQSxDQUFBbmQsSUFBQTtVQUFBO1FBQUEsR0FBQWlkLFNBQUE7TUFBQSxDQUNaO01BQUEsU0FKS0csSUFBSUEsQ0FBQTtRQUFBLE9BQUFKLEtBQUEsQ0FBQXJlLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBSndlLElBQUk7SUFBQTtJQU1WO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQWphLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBaVosT0FBQSxHQUFBeGUsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUF1ZSxVQUFBO1FBQUEsSUFBQTNmLEdBQUEsRUFBQTJLLElBQUE7UUFBQSxPQUFBeEosbUJBQUEsQ0FBQUssSUFBQSxVQUFBb2UsV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUFsZSxJQUFBLEdBQUFrZSxVQUFBLENBQUFqZSxJQUFBO1lBQUE7Y0FDUTVCLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQ3FPLFFBQVEsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUN6SCxJQUFJLENBQUMsR0FBRyxDQUFDO2NBQUFpWixVQUFBLENBQUFqZSxJQUFBO2NBQUEsT0FDOUIsSUFBSSxDQUFDeUwsT0FBTyxDQUFDck4sR0FBRyxDQUFDO1lBQUE7Y0FBOUIySyxJQUFJLEdBQUFrVixVQUFBLENBQUE5ZCxJQUFBO2NBQUEsT0FBQThkLFVBQUEsQ0FBQTVXLE1BQUEsV0FDSDBCLElBQUk7WUFBQTtZQUFBO2NBQUEsT0FBQWtWLFVBQUEsQ0FBQXhkLElBQUE7VUFBQTtRQUFBLEdBQUFzZCxTQUFBO01BQUEsQ0FDWjtNQUFBLFNBSktHLE1BQU1BLENBQUE7UUFBQSxPQUFBSixPQUFBLENBQUExZSxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQU42ZSxNQUFNO0lBQUE7SUFNWjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUF0YSxHQUFBO0lBQUFpQixLQUFBO01BQUEsSUFBQXNaLE1BQUEsR0FBQTdlLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBNGUsVUFBQTtRQUFBLElBQUFoZ0IsR0FBQSxFQUFBMkssSUFBQTtRQUFBLE9BQUF4SixtQkFBQSxDQUFBSyxJQUFBLFVBQUF5ZSxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXZlLElBQUEsR0FBQXVlLFVBQUEsQ0FBQXRlLElBQUE7WUFBQTtjQUNRNUIsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDcU8sUUFBUSxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQ3pILElBQUksQ0FBQyxHQUFHLENBQUM7Y0FBQXNaLFVBQUEsQ0FBQXRlLElBQUE7Y0FBQSxPQUM3QixJQUFJLENBQUN5TCxPQUFPLENBQUNyTixHQUFHLENBQUM7WUFBQTtjQUE5QjJLLElBQUksR0FBQXVWLFVBQUEsQ0FBQW5lLElBQUE7Y0FBQSxPQUFBbWUsVUFBQSxDQUFBalgsTUFBQSxXQUNIMEIsSUFBSTtZQUFBO1lBQUE7Y0FBQSxPQUFBdVYsVUFBQSxDQUFBN2QsSUFBQTtVQUFBO1FBQUEsR0FBQTJkLFNBQUE7TUFBQSxDQUNaO01BQUEsU0FKS0csS0FBS0EsQ0FBQTtRQUFBLE9BQUFKLE1BQUEsQ0FBQS9lLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBTGtmLEtBQUs7SUFBQTtJQU1YO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQTNhLEdBQUE7SUFBQWlCLEtBQUE7TUFBQSxJQUFBMlosYUFBQSxHQUFBbGYsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUFpZixVQUFBO1FBQUEsSUFBQTFWLElBQUE7UUFBQSxPQUFBeEosbUJBQUEsQ0FBQUssSUFBQSxVQUFBOGUsV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUE1ZSxJQUFBLEdBQUE0ZSxVQUFBLENBQUEzZSxJQUFBO1lBQUE7Y0FBQTJlLFVBQUEsQ0FBQTNlLElBQUE7Y0FBQSxPQUNxQixJQUFJLENBQUN5TCxPQUFPLENBQUMsZUFBZSxDQUFDO1lBQUE7Y0FBMUMxQyxJQUFJLEdBQUE0VixVQUFBLENBQUF4ZSxJQUFBO2NBQUEsT0FBQXdlLFVBQUEsQ0FBQXRYLE1BQUEsV0FDSDBCLElBQUk7WUFBQTtZQUFBO2NBQUEsT0FBQTRWLFVBQUEsQ0FBQWxlLElBQUE7VUFBQTtRQUFBLEdBQUFnZSxTQUFBO01BQUEsQ0FDWjtNQUFBLFNBSEtHLFlBQVlBLENBQUE7UUFBQSxPQUFBSixhQUFBLENBQUFwZixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVp1ZixZQUFZO0lBQUE7SUFLbEI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBaGIsR0FBQTtJQUFBaUIsS0FBQSxFQUdBLFNBQUFnYSxXQUFXQSxDQUFDQyxVQUFrQixFQUFrQjtNQUM5QyxPQUFPLElBQUl2aUIsV0FBVyxDQUFDLElBQUksbUJBQUFxRixNQUFBLENBQW1Ca2QsVUFBVSxDQUFFLENBQUM7SUFDN0Q7RUFBQztJQUFBbGIsR0FBQTtJQUFBaUIsS0FBQSxFQU9ELFNBQVFuQyxtQkFBbUJBLENBQUEsRUFBWTtNQUFBLElBQUFxYyxVQUFBLEVBQUFDLFVBQUEsRUFBQUMsVUFBQTtNQUNyQyxPQUNFQyx5QkFBQSxDQUFBSCxVQUFBLE9BQUksQ0FBQ2xpQixXQUFXLEVBQUFXLElBQUEsQ0FBQXVoQixVQUFBLEVBQVUsc0JBQXNCLENBQUMsSUFDakRHLHlCQUFBLENBQUFGLFVBQUEsT0FBSSxDQUFDbmlCLFdBQVcsRUFBQVcsSUFBQSxDQUFBd2hCLFVBQUEsRUFBVSx5QkFBeUIsQ0FBQyxJQUNwREUseUJBQUEsQ0FBQUQsVUFBQSxPQUFJLENBQUNwaUIsV0FBVyxFQUFBVyxJQUFBLENBQUF5aEIsVUFBQSxFQUFVLHlCQUF5QixDQUFDO0lBRXhEO0VBQUM7QUFBQSxFQTc3Q3dEdmpCLFlBQVk7QUE4N0N0RTJHLGVBQUEsQ0E5N0NZUCxVQUFVLGFBQ0o5RixTQUFTLENBQUMsWUFBWSxDQUFDO0FBKzdDMUMsZUFBZThGLFVBQVUiLCJpZ25vcmVMaXN0IjpbXX0=