import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/es.regexp.to-string.js";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _Set from "@babel/runtime-corejs3/core-js-stable/set";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _endsWithInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/ends-with";
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof _Symbol && _getIteratorMethod(r) || r["@@iterator"]; if (!t) { if (_Array$isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { var _context16; if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = _sliceInstanceProperty(_context16 = {}.toString.call(r)).call(_context16, 8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? _Array$from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import "core-js/modules/es.array.join.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.object.keys.js";
import os from 'os';
import fs from 'node:fs';
import path from 'path';
import { Cli } from '../cli/cli';
import { VERSION } from '..';
import { Command } from 'commander';
function getCacheFileDir() {
  return path.join(os.tmpdir(), 'jsforce-gen-schema-cache');
}
function getCacheFilePath(orgId) {
  return path.join(getCacheFileDir(), orgId, 'describe.json');
}
function readDescribedCache(_x) {
  return _readDescribedCache.apply(this, arguments);
}
function _readDescribedCache() {
  _readDescribedCache = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(orgId) {
    var cacheFile, data;
    return _regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          _context.prev = 0;
          cacheFile = getCacheFilePath(orgId);
          _context.next = 4;
          return fs.promises.readFile(cacheFile, 'utf8');
        case 4:
          data = _context.sent;
          return _context.abrupt("return", JSON.parse(data));
        case 8:
          _context.prev = 8;
          _context.t0 = _context["catch"](0);
          return _context.abrupt("return", null);
        case 11:
        case "end":
          return _context.stop();
      }
    }, _callee, null, [[0, 8]]);
  }));
  return _readDescribedCache.apply(this, arguments);
}
function loadDescribeResult(_x2, _x3, _x4) {
  return _loadDescribeResult.apply(this, arguments);
}
function _loadDescribeResult() {
  _loadDescribeResult = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(conn, orgId, cache) {
    var _yield$conn$describeG, sos, sobjects, _iterator2, _step2, name, so, cacheFile;
    return _regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          console.info('describing global');
          _context2.next = 3;
          return conn.describeGlobal();
        case 3:
          _yield$conn$describeG = _context2.sent;
          sos = _yield$conn$describeG.sobjects;
          sobjects = [];
          _iterator2 = _createForOfIteratorHelper(sos);
          _context2.prev = 7;
          _iterator2.s();
        case 9:
          if ((_step2 = _iterator2.n()).done) {
            _context2.next = 18;
            break;
          }
          name = _step2.value.name;
          console.info('describing ' + name);
          _context2.next = 14;
          return conn.describe(name);
        case 14:
          so = _context2.sent;
          sobjects.push(so);
        case 16:
          _context2.next = 9;
          break;
        case 18:
          _context2.next = 23;
          break;
        case 20:
          _context2.prev = 20;
          _context2.t0 = _context2["catch"](7);
          _iterator2.e(_context2.t0);
        case 23:
          _context2.prev = 23;
          _iterator2.f();
          return _context2.finish(23);
        case 26:
          if (!cache) {
            _context2.next = 32;
            break;
          }
          cacheFile = getCacheFilePath(orgId);
          _context2.next = 30;
          return fs.promises.mkdir(path.dirname(cacheFile), {
            recursive: true
          });
        case 30:
          _context2.next = 32;
          return fs.promises.writeFile(cacheFile, _JSON$stringify(sobjects, null, 2), 'utf8');
        case 32:
          return _context2.abrupt("return", sobjects);
        case 33:
        case "end":
          return _context2.stop();
      }
    }, _callee2, null, [[7, 20, 23, 26]]);
  }));
  return _loadDescribeResult.apply(this, arguments);
}
function getParentReferences(sobject) {
  var parentReferences = [];
  var _iterator = _createForOfIteratorHelper(sobject.fields),
    _step;
  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var _step$value = _step.value,
        type = _step$value.type,
        nillable = _step$value.nillable,
        relationshipName = _step$value.relationshipName,
        referenceTo = _step$value.referenceTo;
      if (type === 'reference' && relationshipName && referenceTo && referenceTo.length > 0) {
        var parentSObject = referenceTo.length > 1 ? 'Name' : referenceTo[0];
        parentReferences.push({
          nillable: nillable,
          parentSObject: parentSObject,
          relationshipName: relationshipName
        });
      }
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }
  return parentReferences;
}
function getTSTypeString(type) {
  return type === 'double' || type === 'int' || type === 'currency' || type === 'percent' ? 'number' : type === 'boolean' ? 'boolean' : type === 'date' || type === 'datetime' || type === 'time' ? 'DateString' : type === 'base64' ? 'BlobString' : type === 'address' ? 'Address' : type === 'complexvalue' ? 'any' : 'string';
}
function dumpSchema(_x5, _x6, _x7, _x8, _x9, _x10) {
  return _dumpSchema.apply(this, arguments);
}
function _dumpSchema() {
  _dumpSchema = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3(conn, orgId, outputFile, schemaName, cache, filterObjects) {
    var sobjects, out;
    return _regeneratorRuntime.wrap(function _callee3$(_context14) {
      while (1) switch (_context14.prev = _context14.next) {
        case 0:
          if (!cache) {
            _context14.next = 6;
            break;
          }
          _context14.next = 3;
          return readDescribedCache(orgId);
        case 3:
          _context14.t1 = _context14.sent;
          _context14.next = 7;
          break;
        case 6:
          _context14.t1 = null;
        case 7:
          _context14.t0 = _context14.t1;
          if (_context14.t0) {
            _context14.next = 12;
            break;
          }
          _context14.next = 11;
          return loadDescribeResult(conn, orgId, cache);
        case 11:
          _context14.t0 = _context14.sent;
        case 12:
          sobjects = _context14.t0;
          if (fs.existsSync(outputFile)) {
            _context14.next = 18;
            break;
          }
          _context14.next = 16;
          return fs.promises.mkdir(path.dirname(outputFile), {
            recursive: true
          });
        case 16:
          _context14.next = 18;
          return fs.promises.writeFile(outputFile, '', 'utf8');
        case 18:
          out = fs.createWriteStream(outputFile, 'utf8');
          return _context14.abrupt("return", new _Promise(function (resolve, reject) {
            out.on('error', function (err) {
              return reject(err);
            });
            out.on('finish', function () {
              return resolve(undefined);
            });
            var writeLine = function writeLine(message) {
              return out.write(message + '\n');
            };
            writeLine("import { Schema, SObjectDefinition, DateString, BlobString, Address } from 'jsforce';");
            writeLine('');
            var _iterator3 = _createForOfIteratorHelper(sobjects),
              _step3;
            try {
              for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                var _context3, _context4, _context5, _context6, _context7;
                var sobject = _step3.value;
                if (filterObjects && !filterObjects.has(sobject.name)) {
                  continue;
                }
                var name = sobject.name,
                  fields = sobject.fields,
                  childRelationships = sobject.childRelationships;
                writeLine("type Fields$".concat(name, " = {"));
                writeLine('  //');
                var _iterator5 = _createForOfIteratorHelper(fields),
                  _step5;
                try {
                  for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
                    var _context8, _context9;
                    var _step5$value = _step5.value,
                      _name = _step5$value.name,
                      type = _step5$value.type,
                      nillable = _step5$value.nillable;
                    var tsType = getTSTypeString(type);
                    var orNull = nillable ? ' | null' : '';
                    writeLine(_concatInstanceProperty(_context8 = _concatInstanceProperty(_context9 = "  ".concat(_name, ": ")).call(_context9, tsType)).call(_context8, orNull, ";"));
                  }
                } catch (err) {
                  _iterator5.e(err);
                } finally {
                  _iterator5.f();
                }
                writeLine('};');
                writeLine('');
                writeLine("type ParentReferences$".concat(name, " = {"));
                writeLine('  //');
                var parentReferences = getParentReferences(sobject);
                var _iterator6 = _createForOfIteratorHelper(parentReferences),
                  _step6;
                try {
                  for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
                    var _context10, _context11;
                    var _step6$value = _step6.value,
                      _nillable = _step6$value.nillable,
                      parentSObject = _step6$value.parentSObject,
                      relationshipName = _step6$value.relationshipName;
                    if (filterObjects && !filterObjects.has(parentSObject)) {
                      continue;
                    }
                    var _orNull = _nillable ? ' | null' : '';
                    writeLine(_concatInstanceProperty(_context10 = _concatInstanceProperty(_context11 = "  ".concat(relationshipName, ": SObjectDefinition$")).call(_context11, parentSObject)).call(_context10, _orNull, ";"));
                  }
                } catch (err) {
                  _iterator6.e(err);
                } finally {
                  _iterator6.f();
                }
                writeLine('};');
                writeLine('');
                writeLine("type ChildRelationships$".concat(name, " = {"));
                writeLine('  //');
                var _iterator7 = _createForOfIteratorHelper(childRelationships),
                  _step7;
                try {
                  for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
                    var _step7$value = _step7.value,
                      field = _step7$value.field,
                      childSObject = _step7$value.childSObject,
                      _relationshipName = _step7$value.relationshipName;
                    if (filterObjects && !filterObjects.has(childSObject)) {
                      continue;
                    }
                    if (field && childSObject && _relationshipName && !_endsWithInstanceProperty(field).call(field, '__c')) {
                      var _context12;
                      writeLine(_concatInstanceProperty(_context12 = "  ".concat(_relationshipName, ": SObjectDefinition$")).call(_context12, childSObject, ";"));
                    }
                  }
                } catch (err) {
                  _iterator7.e(err);
                } finally {
                  _iterator7.f();
                }
                writeLine('};');
                writeLine('');
                writeLine(_concatInstanceProperty(_context3 = _concatInstanceProperty(_context4 = _concatInstanceProperty(_context5 = _concatInstanceProperty(_context6 = _concatInstanceProperty(_context7 = "interface SObjectDefinition$".concat(name, " extends SObjectDefinition<'")).call(_context7, name, "'> {\n    Name: '")).call(_context6, name, "';\n    Fields: Fields$")).call(_context5, name, ";\n    ParentReferences: ParentReferences$")).call(_context4, name, ";\n    ChildRelationships: ChildRelationships$")).call(_context3, name, ";\n  }"));
                writeLine('');
              }
            } catch (err) {
              _iterator3.e(err);
            } finally {
              _iterator3.f();
            }
            writeLine('');
            writeLine("export interface ".concat(schemaName, " extends Schema {"));
            writeLine('  SObjects: {');
            var _iterator4 = _createForOfIteratorHelper(sobjects),
              _step4;
            try {
              for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
                var _context13;
                var _name2 = _step4.value.name;
                if (filterObjects && !filterObjects.has(_name2)) {
                  continue;
                }
                writeLine(_concatInstanceProperty(_context13 = "    ".concat(_name2, ": SObjectDefinition$")).call(_context13, _name2, ";"));
              }
            } catch (err) {
              _iterator4.e(err);
            } finally {
              _iterator4.f();
            }
            writeLine('  };');
            writeLine('}');
            out.end();
          }));
        case 20:
        case "end":
          return _context14.stop();
      }
    }, _callee3);
  }));
  return _dumpSchema.apply(this, arguments);
}
function commaSeparatedList(value, _dummyPrevious) {
  return new _Set(value.split(','));
}

/**
 *
 */
function readCommand() {
  return new Command().option('-u, --username [username]', 'Salesforce username').option('-p, --password [password]', 'Salesforce password (and security token, if available)').option('-c, --connection [connection]', 'Connection name stored in connection registry').option('-l, --loginUrl [loginUrl]', 'Salesforce login url').option('-n, --schemaName [schemaName]', 'Name of schema type', 'MySchema').requiredOption('-o, --outputFile <outputFile>', 'Generated schema file path', './schema.d.ts').option('--sandbox', 'Login to Salesforce sandbox').option('--no-cache', 'Do not generate cache file for described result in tmp directory').option('--clearCache', 'Clear all existing described cache files').option('--filterObjects <filterObjects>', 'Only output schema for specified objects', commaSeparatedList).version(VERSION).parse(process.argv);
}

/**
 *
 */
export default function main() {
  return _main.apply(this, arguments);
}
function _main() {
  _main = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4() {
    var program, cli, conn;
    return _regeneratorRuntime.wrap(function _callee4$(_context15) {
      while (1) switch (_context15.prev = _context15.next) {
        case 0:
          program = readCommand();
          cli = new Cli();
          _context15.next = 4;
          return cli.connect(program);
        case 4:
          conn = cli.getCurrentConnection();
          if (conn.userInfo) {
            _context15.next = 8;
            break;
          }
          console.error('Cannot connect to Salesforce');
          return _context15.abrupt("return");
        case 8:
          _context15.next = 10;
          return dumpSchema(conn, conn.userInfo.organizationId, program.outputFile, program.schemaName, program.cache, program.filterObjects);
        case 10:
          if (!program.clearCache) {
            _context15.next = 14;
            break;
          }
          console.log('removing cache files');
          _context15.next = 14;
          return fs.promises.rm(getCacheFileDir(), {
            recursive: true
          });
        case 14:
          console.log("Dumped to: ".concat(program.outputFile));
        case 15:
        case "end":
          return _context15.stop();
      }
    }, _callee4);
  }));
  return _main.apply(this, arguments);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJvcyIsImZzIiwicGF0aCIsIkNsaSIsIlZFUlNJT04iLCJDb21tYW5kIiwiZ2V0Q2FjaGVGaWxlRGlyIiwiam9pbiIsInRtcGRpciIsImdldENhY2hlRmlsZVBhdGgiLCJvcmdJZCIsInJlYWREZXNjcmliZWRDYWNoZSIsIl94IiwiX3JlYWREZXNjcmliZWRDYWNoZSIsImFwcGx5IiwiYXJndW1lbnRzIiwiX2FzeW5jVG9HZW5lcmF0b3IiLCJfcmVnZW5lcmF0b3JSdW50aW1lIiwibWFyayIsIl9jYWxsZWUiLCJjYWNoZUZpbGUiLCJkYXRhIiwid3JhcCIsIl9jYWxsZWUkIiwiX2NvbnRleHQiLCJwcmV2IiwibmV4dCIsInByb21pc2VzIiwicmVhZEZpbGUiLCJzZW50IiwiYWJydXB0IiwiSlNPTiIsInBhcnNlIiwidDAiLCJzdG9wIiwibG9hZERlc2NyaWJlUmVzdWx0IiwiX3gyIiwiX3gzIiwiX3g0IiwiX2xvYWREZXNjcmliZVJlc3VsdCIsIl9jYWxsZWUyIiwiY29ubiIsImNhY2hlIiwiX3lpZWxkJGNvbm4kZGVzY3JpYmVHIiwic29zIiwic29iamVjdHMiLCJfaXRlcmF0b3IyIiwiX3N0ZXAyIiwibmFtZSIsInNvIiwiX2NhbGxlZTIkIiwiX2NvbnRleHQyIiwiY29uc29sZSIsImluZm8iLCJkZXNjcmliZUdsb2JhbCIsIl9jcmVhdGVGb3JPZkl0ZXJhdG9ySGVscGVyIiwicyIsIm4iLCJkb25lIiwidmFsdWUiLCJkZXNjcmliZSIsInB1c2giLCJlIiwiZiIsImZpbmlzaCIsIm1rZGlyIiwiZGlybmFtZSIsInJlY3Vyc2l2ZSIsIndyaXRlRmlsZSIsIl9KU09OJHN0cmluZ2lmeSIsImdldFBhcmVudFJlZmVyZW5jZXMiLCJzb2JqZWN0IiwicGFyZW50UmVmZXJlbmNlcyIsIl9pdGVyYXRvciIsImZpZWxkcyIsIl9zdGVwIiwiX3N0ZXAkdmFsdWUiLCJ0eXBlIiwibmlsbGFibGUiLCJyZWxhdGlvbnNoaXBOYW1lIiwicmVmZXJlbmNlVG8iLCJsZW5ndGgiLCJwYXJlbnRTT2JqZWN0IiwiZXJyIiwiZ2V0VFNUeXBlU3RyaW5nIiwiZHVtcFNjaGVtYSIsIl94NSIsIl94NiIsIl94NyIsIl94OCIsIl94OSIsIl94MTAiLCJfZHVtcFNjaGVtYSIsIl9jYWxsZWUzIiwib3V0cHV0RmlsZSIsInNjaGVtYU5hbWUiLCJmaWx0ZXJPYmplY3RzIiwib3V0IiwiX2NhbGxlZTMkIiwiX2NvbnRleHQxNCIsInQxIiwiZXhpc3RzU3luYyIsImNyZWF0ZVdyaXRlU3RyZWFtIiwiX1Byb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0Iiwib24iLCJ1bmRlZmluZWQiLCJ3cml0ZUxpbmUiLCJtZXNzYWdlIiwid3JpdGUiLCJfaXRlcmF0b3IzIiwiX3N0ZXAzIiwiX2NvbnRleHQzIiwiX2NvbnRleHQ0IiwiX2NvbnRleHQ1IiwiX2NvbnRleHQ2IiwiX2NvbnRleHQ3IiwiaGFzIiwiY2hpbGRSZWxhdGlvbnNoaXBzIiwiY29uY2F0IiwiX2l0ZXJhdG9yNSIsIl9zdGVwNSIsIl9jb250ZXh0OCIsIl9jb250ZXh0OSIsIl9zdGVwNSR2YWx1ZSIsInRzVHlwZSIsIm9yTnVsbCIsIl9jb25jYXRJbnN0YW5jZVByb3BlcnR5IiwiY2FsbCIsIl9pdGVyYXRvcjYiLCJfc3RlcDYiLCJfY29udGV4dDEwIiwiX2NvbnRleHQxMSIsIl9zdGVwNiR2YWx1ZSIsIl9pdGVyYXRvcjciLCJfc3RlcDciLCJfc3RlcDckdmFsdWUiLCJmaWVsZCIsImNoaWxkU09iamVjdCIsIl9lbmRzV2l0aEluc3RhbmNlUHJvcGVydHkiLCJfY29udGV4dDEyIiwiX2l0ZXJhdG9yNCIsIl9zdGVwNCIsIl9jb250ZXh0MTMiLCJlbmQiLCJjb21tYVNlcGFyYXRlZExpc3QiLCJfZHVtbXlQcmV2aW91cyIsIl9TZXQiLCJzcGxpdCIsInJlYWRDb21tYW5kIiwib3B0aW9uIiwicmVxdWlyZWRPcHRpb24iLCJ2ZXJzaW9uIiwicHJvY2VzcyIsImFyZ3YiLCJtYWluIiwiX21haW4iLCJfY2FsbGVlNCIsInByb2dyYW0iLCJjbGkiLCJfY2FsbGVlNCQiLCJfY29udGV4dDE1IiwiY29ubmVjdCIsImdldEN1cnJlbnRDb25uZWN0aW9uIiwidXNlckluZm8iLCJlcnJvciIsIm9yZ2FuaXphdGlvbklkIiwiY2xlYXJDYWNoZSIsImxvZyIsInJtIl0sInNvdXJjZXMiOlsiLi4vLi4vc3JjL3NjaGVtYS9nZW5lcmF0b3IudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG9zIGZyb20gJ29zJztcbmltcG9ydCBmcyBmcm9tICdub2RlOmZzJztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IHsgRGVzY3JpYmVTT2JqZWN0UmVzdWx0IH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgQ2xpIH0gZnJvbSAnLi4vY2xpL2NsaSc7XG5pbXBvcnQgeyBDb25uZWN0aW9uLCBWRVJTSU9OIH0gZnJvbSAnLi4nO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gJ2NvbW1hbmRlcic7XG5pbXBvcnQgeyBta2RpciB9IGZyb20gJ2ZzJztcblxudHlwZSBVbndyYXBQcm9taXNlPFQ+ID0gVCBleHRlbmRzIFByb21pc2U8aW5mZXIgVT4gPyBVIDogbmV2ZXI7XG5cbmZ1bmN0aW9uIGdldENhY2hlRmlsZURpcigpIHtcbiAgcmV0dXJuIHBhdGguam9pbihvcy50bXBkaXIoKSwgJ2pzZm9yY2UtZ2VuLXNjaGVtYS1jYWNoZScpO1xufVxuXG5mdW5jdGlvbiBnZXRDYWNoZUZpbGVQYXRoKG9yZ0lkOiBzdHJpbmcpIHtcbiAgcmV0dXJuIHBhdGguam9pbihnZXRDYWNoZUZpbGVEaXIoKSwgb3JnSWQsICdkZXNjcmliZS5qc29uJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlYWREZXNjcmliZWRDYWNoZShcbiAgb3JnSWQ6IHN0cmluZyxcbik6IFByb21pc2U8VW53cmFwUHJvbWlzZTxSZXR1cm5UeXBlPHR5cGVvZiBsb2FkRGVzY3JpYmVSZXN1bHQ+PiB8IG51bGw+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBjYWNoZUZpbGUgPSBnZXRDYWNoZUZpbGVQYXRoKG9yZ0lkKTtcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgZnMucHJvbWlzZXMucmVhZEZpbGUoY2FjaGVGaWxlLCAndXRmOCcpO1xuICAgIHJldHVybiBKU09OLnBhcnNlKGRhdGEpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZERlc2NyaWJlUmVzdWx0KFxuICBjb25uOiBDb25uZWN0aW9uLFxuICBvcmdJZDogc3RyaW5nLFxuICBjYWNoZT86IGJvb2xlYW4sXG4pIHtcbiAgY29uc29sZS5pbmZvKCdkZXNjcmliaW5nIGdsb2JhbCcpO1xuICBjb25zdCB7IHNvYmplY3RzOiBzb3MgfSA9IGF3YWl0IGNvbm4uZGVzY3JpYmVHbG9iYWwoKTtcbiAgY29uc3Qgc29iamVjdHMgPSBbXTtcbiAgZm9yIChjb25zdCB7IG5hbWUgfSBvZiBzb3MpIHtcbiAgICBjb25zb2xlLmluZm8oJ2Rlc2NyaWJpbmcgJyArIG5hbWUpO1xuICAgIGNvbnN0IHNvID0gYXdhaXQgY29ubi5kZXNjcmliZShuYW1lKTtcbiAgICBzb2JqZWN0cy5wdXNoKHNvKTtcbiAgfVxuICBpZiAoY2FjaGUpIHtcbiAgICBjb25zdCBjYWNoZUZpbGUgPSBnZXRDYWNoZUZpbGVQYXRoKG9yZ0lkKTtcbiAgICBhd2FpdCBmcy5wcm9taXNlcy5ta2RpcihwYXRoLmRpcm5hbWUoY2FjaGVGaWxlKSwgeyByZWN1cnNpdmU6IHRydWUgfSk7XG4gICAgYXdhaXQgZnMucHJvbWlzZXMud3JpdGVGaWxlKFxuICAgICAgY2FjaGVGaWxlLFxuICAgICAgSlNPTi5zdHJpbmdpZnkoc29iamVjdHMsIG51bGwsIDIpLFxuICAgICAgJ3V0ZjgnLFxuICAgICk7XG4gIH1cbiAgcmV0dXJuIHNvYmplY3RzO1xufVxuXG5mdW5jdGlvbiBnZXRQYXJlbnRSZWZlcmVuY2VzKHNvYmplY3Q6IERlc2NyaWJlU09iamVjdFJlc3VsdCkge1xuICBjb25zdCBwYXJlbnRSZWZlcmVuY2VzID0gW107XG4gIGZvciAoY29uc3Qge1xuICAgIHR5cGUsXG4gICAgbmlsbGFibGUsXG4gICAgcmVsYXRpb25zaGlwTmFtZSxcbiAgICByZWZlcmVuY2VUbyxcbiAgfSBvZiBzb2JqZWN0LmZpZWxkcykge1xuICAgIGlmIChcbiAgICAgIHR5cGUgPT09ICdyZWZlcmVuY2UnICYmXG4gICAgICByZWxhdGlvbnNoaXBOYW1lICYmXG4gICAgICByZWZlcmVuY2VUbyAmJlxuICAgICAgcmVmZXJlbmNlVG8ubGVuZ3RoID4gMFxuICAgICkge1xuICAgICAgY29uc3QgcGFyZW50U09iamVjdCA9IHJlZmVyZW5jZVRvLmxlbmd0aCA+IDEgPyAnTmFtZScgOiByZWZlcmVuY2VUb1swXTtcbiAgICAgIHBhcmVudFJlZmVyZW5jZXMucHVzaCh7IG5pbGxhYmxlLCBwYXJlbnRTT2JqZWN0LCByZWxhdGlvbnNoaXBOYW1lIH0pO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcGFyZW50UmVmZXJlbmNlcztcbn1cblxuZnVuY3Rpb24gZ2V0VFNUeXBlU3RyaW5nKHR5cGU6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiB0eXBlID09PSAnZG91YmxlJyB8fFxuICAgIHR5cGUgPT09ICdpbnQnIHx8XG4gICAgdHlwZSA9PT0gJ2N1cnJlbmN5JyB8fFxuICAgIHR5cGUgPT09ICdwZXJjZW50J1xuICAgID8gJ251bWJlcidcbiAgICA6IHR5cGUgPT09ICdib29sZWFuJ1xuICAgID8gJ2Jvb2xlYW4nXG4gICAgOiB0eXBlID09PSAnZGF0ZScgfHwgdHlwZSA9PT0gJ2RhdGV0aW1lJyB8fCB0eXBlID09PSAndGltZSdcbiAgICA/ICdEYXRlU3RyaW5nJ1xuICAgIDogdHlwZSA9PT0gJ2Jhc2U2NCdcbiAgICA/ICdCbG9iU3RyaW5nJ1xuICAgIDogdHlwZSA9PT0gJ2FkZHJlc3MnXG4gICAgPyAnQWRkcmVzcydcbiAgICA6IHR5cGUgPT09ICdjb21wbGV4dmFsdWUnXG4gICAgPyAnYW55J1xuICAgIDogJ3N0cmluZyc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGR1bXBTY2hlbWEoXG4gIGNvbm46IENvbm5lY3Rpb24sXG4gIG9yZ0lkOiBzdHJpbmcsXG4gIG91dHB1dEZpbGU6IHN0cmluZyxcbiAgc2NoZW1hTmFtZTogc3RyaW5nLFxuICBjYWNoZT86IGJvb2xlYW4sXG4gIGZpbHRlck9iamVjdHM/OiBTZXQ8c3RyaW5nPixcbikge1xuICBjb25zdCBzb2JqZWN0cyA9XG4gICAgKGNhY2hlID8gYXdhaXQgcmVhZERlc2NyaWJlZENhY2hlKG9yZ0lkKSA6IG51bGwpIHx8XG4gICAgKGF3YWl0IGxvYWREZXNjcmliZVJlc3VsdChjb25uLCBvcmdJZCwgY2FjaGUpKTtcbiAgaWYgKCFmcy5leGlzdHNTeW5jKG91dHB1dEZpbGUpKSB7XG4gICAgYXdhaXQgZnMucHJvbWlzZXMubWtkaXIocGF0aC5kaXJuYW1lKG91dHB1dEZpbGUpLCB7IHJlY3Vyc2l2ZTogdHJ1ZSB9KTtcbiAgICBhd2FpdCBmcy5wcm9taXNlcy53cml0ZUZpbGUob3V0cHV0RmlsZSwgJycsICd1dGY4Jyk7XG4gIH1cbiAgY29uc3Qgb3V0ID0gZnMuY3JlYXRlV3JpdGVTdHJlYW0ob3V0cHV0RmlsZSwgJ3V0ZjgnKTtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBvdXQub24oJ2Vycm9yJywgKGVycikgPT4gcmVqZWN0KGVycikpO1xuICAgIG91dC5vbignZmluaXNoJywgKCkgPT4gcmVzb2x2ZSh1bmRlZmluZWQpKTtcbiAgICBjb25zdCB3cml0ZUxpbmUgPSAobWVzc2FnZTogc3RyaW5nKSA9PiBvdXQud3JpdGUobWVzc2FnZSArICdcXG4nKTtcbiAgICB3cml0ZUxpbmUoXG4gICAgICBcImltcG9ydCB7IFNjaGVtYSwgU09iamVjdERlZmluaXRpb24sIERhdGVTdHJpbmcsIEJsb2JTdHJpbmcsIEFkZHJlc3MgfSBmcm9tICdqc2ZvcmNlJztcIixcbiAgICApO1xuICAgIHdyaXRlTGluZSgnJyk7XG4gICAgZm9yIChjb25zdCBzb2JqZWN0IG9mIHNvYmplY3RzKSB7XG4gICAgICBpZiAoZmlsdGVyT2JqZWN0cyAmJiAhZmlsdGVyT2JqZWN0cy5oYXMoc29iamVjdC5uYW1lKSkge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgbmFtZSwgZmllbGRzLCBjaGlsZFJlbGF0aW9uc2hpcHMgfSA9IHNvYmplY3Q7XG4gICAgICB3cml0ZUxpbmUoYHR5cGUgRmllbGRzJCR7bmFtZX0gPSB7YCk7XG4gICAgICB3cml0ZUxpbmUoJyAgLy8nKTtcbiAgICAgIGZvciAoY29uc3QgeyBuYW1lLCB0eXBlLCBuaWxsYWJsZSB9IG9mIGZpZWxkcykge1xuICAgICAgICBjb25zdCB0c1R5cGUgPSBnZXRUU1R5cGVTdHJpbmcodHlwZSk7XG4gICAgICAgIGNvbnN0IG9yTnVsbCA9IG5pbGxhYmxlID8gJyB8IG51bGwnIDogJyc7XG4gICAgICAgIHdyaXRlTGluZShgICAke25hbWV9OiAke3RzVHlwZX0ke29yTnVsbH07YCk7XG4gICAgICB9XG4gICAgICB3cml0ZUxpbmUoJ307Jyk7XG4gICAgICB3cml0ZUxpbmUoJycpO1xuICAgICAgd3JpdGVMaW5lKGB0eXBlIFBhcmVudFJlZmVyZW5jZXMkJHtuYW1lfSA9IHtgKTtcbiAgICAgIHdyaXRlTGluZSgnICAvLycpO1xuICAgICAgY29uc3QgcGFyZW50UmVmZXJlbmNlcyA9IGdldFBhcmVudFJlZmVyZW5jZXMoc29iamVjdCk7XG4gICAgICBmb3IgKGNvbnN0IHtcbiAgICAgICAgbmlsbGFibGUsXG4gICAgICAgIHBhcmVudFNPYmplY3QsXG4gICAgICAgIHJlbGF0aW9uc2hpcE5hbWUsXG4gICAgICB9IG9mIHBhcmVudFJlZmVyZW5jZXMpIHtcbiAgICAgICAgaWYgKGZpbHRlck9iamVjdHMgJiYgIWZpbHRlck9iamVjdHMuaGFzKHBhcmVudFNPYmplY3QpKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgb3JOdWxsID0gbmlsbGFibGUgPyAnIHwgbnVsbCcgOiAnJztcbiAgICAgICAgd3JpdGVMaW5lKFxuICAgICAgICAgIGAgICR7cmVsYXRpb25zaGlwTmFtZX06IFNPYmplY3REZWZpbml0aW9uJCR7cGFyZW50U09iamVjdH0ke29yTnVsbH07YCxcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHdyaXRlTGluZSgnfTsnKTtcbiAgICAgIHdyaXRlTGluZSgnJyk7XG4gICAgICB3cml0ZUxpbmUoYHR5cGUgQ2hpbGRSZWxhdGlvbnNoaXBzJCR7bmFtZX0gPSB7YCk7XG4gICAgICB3cml0ZUxpbmUoJyAgLy8nKTtcbiAgICAgIGZvciAoY29uc3Qge1xuICAgICAgICBmaWVsZCxcbiAgICAgICAgY2hpbGRTT2JqZWN0LFxuICAgICAgICByZWxhdGlvbnNoaXBOYW1lLFxuICAgICAgfSBvZiBjaGlsZFJlbGF0aW9uc2hpcHMpIHtcbiAgICAgICAgaWYgKGZpbHRlck9iamVjdHMgJiYgIWZpbHRlck9iamVjdHMuaGFzKGNoaWxkU09iamVjdCkpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoXG4gICAgICAgICAgZmllbGQgJiZcbiAgICAgICAgICBjaGlsZFNPYmplY3QgJiZcbiAgICAgICAgICByZWxhdGlvbnNoaXBOYW1lICYmXG4gICAgICAgICAgIWZpZWxkLmVuZHNXaXRoKCdfX2MnKVxuICAgICAgICApIHtcbiAgICAgICAgICB3cml0ZUxpbmUoXG4gICAgICAgICAgICBgICAke3JlbGF0aW9uc2hpcE5hbWV9OiBTT2JqZWN0RGVmaW5pdGlvbiQke2NoaWxkU09iamVjdH07YCxcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB3cml0ZUxpbmUoJ307Jyk7XG4gICAgICB3cml0ZUxpbmUoJycpO1xuICAgICAgd3JpdGVMaW5lKFxuICAgICAgICBgaW50ZXJmYWNlIFNPYmplY3REZWZpbml0aW9uJCR7bmFtZX0gZXh0ZW5kcyBTT2JqZWN0RGVmaW5pdGlvbjwnJHtuYW1lfSc+IHtcbiAgICBOYW1lOiAnJHtuYW1lfSc7XG4gICAgRmllbGRzOiBGaWVsZHMkJHtuYW1lfTtcbiAgICBQYXJlbnRSZWZlcmVuY2VzOiBQYXJlbnRSZWZlcmVuY2VzJCR7bmFtZX07XG4gICAgQ2hpbGRSZWxhdGlvbnNoaXBzOiBDaGlsZFJlbGF0aW9uc2hpcHMkJHtuYW1lfTtcbiAgfWAsXG4gICAgICApO1xuICAgICAgd3JpdGVMaW5lKCcnKTtcbiAgICB9XG4gICAgd3JpdGVMaW5lKCcnKTtcbiAgICB3cml0ZUxpbmUoYGV4cG9ydCBpbnRlcmZhY2UgJHtzY2hlbWFOYW1lfSBleHRlbmRzIFNjaGVtYSB7YCk7XG4gICAgd3JpdGVMaW5lKCcgIFNPYmplY3RzOiB7Jyk7XG4gICAgZm9yIChjb25zdCB7IG5hbWUgfSBvZiBzb2JqZWN0cykge1xuICAgICAgaWYgKGZpbHRlck9iamVjdHMgJiYgIWZpbHRlck9iamVjdHMuaGFzKG5hbWUpKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgd3JpdGVMaW5lKGAgICAgJHtuYW1lfTogU09iamVjdERlZmluaXRpb24kJHtuYW1lfTtgKTtcbiAgICB9XG4gICAgd3JpdGVMaW5lKCcgIH07Jyk7XG4gICAgd3JpdGVMaW5lKCd9Jyk7XG4gICAgb3V0LmVuZCgpO1xuICB9KTtcbn1cblxudHlwZSBHZW5lcmF0b3JDb21tYW5kID0ge1xuICBjb25uZWN0aW9uPzogc3RyaW5nO1xuICB1c2VybmFtZT86IHN0cmluZztcbiAgcGFzc3dvcmQ/OiBzdHJpbmc7XG4gIGxvZ2luVXJsPzogc3RyaW5nO1xuICBzYW5kYm94PzogYm9vbGVhbjtcbiAgb3V0cHV0RmlsZTogc3RyaW5nO1xuICBjYWNoZT86IGJvb2xlYW47XG4gIGNsZWFyQ2FjaGU/OiBib29sZWFuO1xuICBmaWx0ZXJPYmplY3RzPzogU2V0PHN0cmluZz47XG59ICYgQ29tbWFuZDtcblxuZnVuY3Rpb24gY29tbWFTZXBhcmF0ZWRMaXN0KHZhbHVlOiBzdHJpbmcsIF9kdW1teVByZXZpb3VzOiB1bmtub3duKSB7XG4gIHJldHVybiBuZXcgU2V0KHZhbHVlLnNwbGl0KCcsJykpO1xufVxuXG4vKipcbiAqXG4gKi9cbmZ1bmN0aW9uIHJlYWRDb21tYW5kKCk6IEdlbmVyYXRvckNvbW1hbmQge1xuICByZXR1cm4gbmV3IENvbW1hbmQoKVxuICAgIC5vcHRpb24oJy11LCAtLXVzZXJuYW1lIFt1c2VybmFtZV0nLCAnU2FsZXNmb3JjZSB1c2VybmFtZScpXG4gICAgLm9wdGlvbihcbiAgICAgICctcCwgLS1wYXNzd29yZCBbcGFzc3dvcmRdJyxcbiAgICAgICdTYWxlc2ZvcmNlIHBhc3N3b3JkIChhbmQgc2VjdXJpdHkgdG9rZW4sIGlmIGF2YWlsYWJsZSknLFxuICAgIClcbiAgICAub3B0aW9uKFxuICAgICAgJy1jLCAtLWNvbm5lY3Rpb24gW2Nvbm5lY3Rpb25dJyxcbiAgICAgICdDb25uZWN0aW9uIG5hbWUgc3RvcmVkIGluIGNvbm5lY3Rpb24gcmVnaXN0cnknLFxuICAgIClcbiAgICAub3B0aW9uKCctbCwgLS1sb2dpblVybCBbbG9naW5VcmxdJywgJ1NhbGVzZm9yY2UgbG9naW4gdXJsJylcbiAgICAub3B0aW9uKCctbiwgLS1zY2hlbWFOYW1lIFtzY2hlbWFOYW1lXScsICdOYW1lIG9mIHNjaGVtYSB0eXBlJywgJ015U2NoZW1hJylcbiAgICAucmVxdWlyZWRPcHRpb24oXG4gICAgICAnLW8sIC0tb3V0cHV0RmlsZSA8b3V0cHV0RmlsZT4nLFxuICAgICAgJ0dlbmVyYXRlZCBzY2hlbWEgZmlsZSBwYXRoJyxcbiAgICAgICcuL3NjaGVtYS5kLnRzJyxcbiAgICApXG4gICAgLm9wdGlvbignLS1zYW5kYm94JywgJ0xvZ2luIHRvIFNhbGVzZm9yY2Ugc2FuZGJveCcpXG4gICAgLm9wdGlvbihcbiAgICAgICctLW5vLWNhY2hlJyxcbiAgICAgICdEbyBub3QgZ2VuZXJhdGUgY2FjaGUgZmlsZSBmb3IgZGVzY3JpYmVkIHJlc3VsdCBpbiB0bXAgZGlyZWN0b3J5JyxcbiAgICApXG4gICAgLm9wdGlvbignLS1jbGVhckNhY2hlJywgJ0NsZWFyIGFsbCBleGlzdGluZyBkZXNjcmliZWQgY2FjaGUgZmlsZXMnKVxuICAgIC5vcHRpb24oXG4gICAgICAnLS1maWx0ZXJPYmplY3RzIDxmaWx0ZXJPYmplY3RzPicsXG4gICAgICAnT25seSBvdXRwdXQgc2NoZW1hIGZvciBzcGVjaWZpZWQgb2JqZWN0cycsXG4gICAgICBjb21tYVNlcGFyYXRlZExpc3QsXG4gICAgKVxuICAgIC52ZXJzaW9uKFZFUlNJT04pXG4gICAgLnBhcnNlKHByb2Nlc3MuYXJndikgYXMgR2VuZXJhdG9yQ29tbWFuZDtcbn1cblxuLyoqXG4gKlxuICovXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBtYWluKCkge1xuICBjb25zdCBwcm9ncmFtID0gcmVhZENvbW1hbmQoKTtcbiAgY29uc3QgY2xpID0gbmV3IENsaSgpO1xuICBhd2FpdCBjbGkuY29ubmVjdChwcm9ncmFtKTtcbiAgY29uc3QgY29ubiA9IGNsaS5nZXRDdXJyZW50Q29ubmVjdGlvbigpO1xuICBpZiAoIWNvbm4udXNlckluZm8pIHtcbiAgICBjb25zb2xlLmVycm9yKCdDYW5ub3QgY29ubmVjdCB0byBTYWxlc2ZvcmNlJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGF3YWl0IGR1bXBTY2hlbWEoXG4gICAgY29ubixcbiAgICBjb25uLnVzZXJJbmZvLm9yZ2FuaXphdGlvbklkLFxuICAgIHByb2dyYW0ub3V0cHV0RmlsZSxcbiAgICBwcm9ncmFtLnNjaGVtYU5hbWUsXG4gICAgcHJvZ3JhbS5jYWNoZSxcbiAgICBwcm9ncmFtLmZpbHRlck9iamVjdHMsXG4gICk7XG4gIGlmIChwcm9ncmFtLmNsZWFyQ2FjaGUpIHtcbiAgICBjb25zb2xlLmxvZygncmVtb3ZpbmcgY2FjaGUgZmlsZXMnKTtcbiAgICBhd2FpdCBmcy5wcm9taXNlcy5ybShnZXRDYWNoZUZpbGVEaXIoKSwgeyByZWN1cnNpdmU6IHRydWUgfSk7XG4gIH1cbiAgY29uc29sZS5sb2coYER1bXBlZCB0bzogJHtwcm9ncmFtLm91dHB1dEZpbGV9YCk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLE9BQU9BLEVBQUUsTUFBTSxJQUFJO0FBQ25CLE9BQU9DLEVBQUUsTUFBTSxTQUFTO0FBQ3hCLE9BQU9DLElBQUksTUFBTSxNQUFNO0FBRXZCLFNBQVNDLEdBQUcsUUFBUSxZQUFZO0FBQ2hDLFNBQXFCQyxPQUFPLFFBQVEsSUFBSTtBQUN4QyxTQUFTQyxPQUFPLFFBQVEsV0FBVztBQUtuQyxTQUFTQyxlQUFlQSxDQUFBLEVBQUc7RUFDekIsT0FBT0osSUFBSSxDQUFDSyxJQUFJLENBQUNQLEVBQUUsQ0FBQ1EsTUFBTSxDQUFDLENBQUMsRUFBRSwwQkFBMEIsQ0FBQztBQUMzRDtBQUVBLFNBQVNDLGdCQUFnQkEsQ0FBQ0MsS0FBYSxFQUFFO0VBQ3ZDLE9BQU9SLElBQUksQ0FBQ0ssSUFBSSxDQUFDRCxlQUFlLENBQUMsQ0FBQyxFQUFFSSxLQUFLLEVBQUUsZUFBZSxDQUFDO0FBQzdEO0FBQUMsU0FFY0Msa0JBQWtCQSxDQUFBQyxFQUFBO0VBQUEsT0FBQUMsbUJBQUEsQ0FBQUMsS0FBQSxPQUFBQyxTQUFBO0FBQUE7QUFBQSxTQUFBRixvQkFBQTtFQUFBQSxtQkFBQSxHQUFBRyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQWpDLFNBQUFDLFFBQ0VULEtBQWE7SUFBQSxJQUFBVSxTQUFBLEVBQUFDLElBQUE7SUFBQSxPQUFBSixtQkFBQSxDQUFBSyxJQUFBLFVBQUFDLFNBQUFDLFFBQUE7TUFBQSxrQkFBQUEsUUFBQSxDQUFBQyxJQUFBLEdBQUFELFFBQUEsQ0FBQUUsSUFBQTtRQUFBO1VBQUFGLFFBQUEsQ0FBQUMsSUFBQTtVQUdMTCxTQUFTLEdBQUdYLGdCQUFnQixDQUFDQyxLQUFLLENBQUM7VUFBQWMsUUFBQSxDQUFBRSxJQUFBO1VBQUEsT0FDdEJ6QixFQUFFLENBQUMwQixRQUFRLENBQUNDLFFBQVEsQ0FBQ1IsU0FBUyxFQUFFLE1BQU0sQ0FBQztRQUFBO1VBQXBEQyxJQUFJLEdBQUFHLFFBQUEsQ0FBQUssSUFBQTtVQUFBLE9BQUFMLFFBQUEsQ0FBQU0sTUFBQSxXQUNIQyxJQUFJLENBQUNDLEtBQUssQ0FBQ1gsSUFBSSxDQUFDO1FBQUE7VUFBQUcsUUFBQSxDQUFBQyxJQUFBO1VBQUFELFFBQUEsQ0FBQVMsRUFBQSxHQUFBVCxRQUFBO1VBQUEsT0FBQUEsUUFBQSxDQUFBTSxNQUFBLFdBRWhCLElBQUk7UUFBQTtRQUFBO1VBQUEsT0FBQU4sUUFBQSxDQUFBVSxJQUFBO01BQUE7SUFBQSxHQUFBZixPQUFBO0VBQUEsQ0FFZDtFQUFBLE9BQUFOLG1CQUFBLENBQUFDLEtBQUEsT0FBQUMsU0FBQTtBQUFBO0FBQUEsU0FFY29CLGtCQUFrQkEsQ0FBQUMsR0FBQSxFQUFBQyxHQUFBLEVBQUFDLEdBQUE7RUFBQSxPQUFBQyxtQkFBQSxDQUFBekIsS0FBQSxPQUFBQyxTQUFBO0FBQUE7QUFBQSxTQUFBd0Isb0JBQUE7RUFBQUEsbUJBQUEsR0FBQXZCLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FBakMsU0FBQXNCLFNBQ0VDLElBQWdCLEVBQ2hCL0IsS0FBYSxFQUNiZ0MsS0FBZTtJQUFBLElBQUFDLHFCQUFBLEVBQUFDLEdBQUEsRUFBQUMsUUFBQSxFQUFBQyxVQUFBLEVBQUFDLE1BQUEsRUFBQUMsSUFBQSxFQUFBQyxFQUFBLEVBQUE3QixTQUFBO0lBQUEsT0FBQUgsbUJBQUEsQ0FBQUssSUFBQSxVQUFBNEIsVUFBQUMsU0FBQTtNQUFBLGtCQUFBQSxTQUFBLENBQUExQixJQUFBLEdBQUEwQixTQUFBLENBQUF6QixJQUFBO1FBQUE7VUFFZjBCLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLG1CQUFtQixDQUFDO1VBQUNGLFNBQUEsQ0FBQXpCLElBQUE7VUFBQSxPQUNGZSxJQUFJLENBQUNhLGNBQWMsQ0FBQyxDQUFDO1FBQUE7VUFBQVgscUJBQUEsR0FBQVEsU0FBQSxDQUFBdEIsSUFBQTtVQUFuQ2UsR0FBRyxHQUFBRCxxQkFBQSxDQUFiRSxRQUFRO1VBQ1ZBLFFBQVEsR0FBRyxFQUFFO1VBQUFDLFVBQUEsR0FBQVMsMEJBQUEsQ0FDSVgsR0FBRztVQUFBTyxTQUFBLENBQUExQixJQUFBO1VBQUFxQixVQUFBLENBQUFVLENBQUE7UUFBQTtVQUFBLEtBQUFULE1BQUEsR0FBQUQsVUFBQSxDQUFBVyxDQUFBLElBQUFDLElBQUE7WUFBQVAsU0FBQSxDQUFBekIsSUFBQTtZQUFBO1VBQUE7VUFBYnNCLElBQUksR0FBQUQsTUFBQSxDQUFBWSxLQUFBLENBQUpYLElBQUk7VUFDZkksT0FBTyxDQUFDQyxJQUFJLENBQUMsYUFBYSxHQUFHTCxJQUFJLENBQUM7VUFBQ0csU0FBQSxDQUFBekIsSUFBQTtVQUFBLE9BQ2xCZSxJQUFJLENBQUNtQixRQUFRLENBQUNaLElBQUksQ0FBQztRQUFBO1VBQTlCQyxFQUFFLEdBQUFFLFNBQUEsQ0FBQXRCLElBQUE7VUFDUmdCLFFBQVEsQ0FBQ2dCLElBQUksQ0FBQ1osRUFBRSxDQUFDO1FBQUM7VUFBQUUsU0FBQSxDQUFBekIsSUFBQTtVQUFBO1FBQUE7VUFBQXlCLFNBQUEsQ0FBQXpCLElBQUE7VUFBQTtRQUFBO1VBQUF5QixTQUFBLENBQUExQixJQUFBO1VBQUEwQixTQUFBLENBQUFsQixFQUFBLEdBQUFrQixTQUFBO1VBQUFMLFVBQUEsQ0FBQWdCLENBQUEsQ0FBQVgsU0FBQSxDQUFBbEIsRUFBQTtRQUFBO1VBQUFrQixTQUFBLENBQUExQixJQUFBO1VBQUFxQixVQUFBLENBQUFpQixDQUFBO1VBQUEsT0FBQVosU0FBQSxDQUFBYSxNQUFBO1FBQUE7VUFBQSxLQUVoQnRCLEtBQUs7WUFBQVMsU0FBQSxDQUFBekIsSUFBQTtZQUFBO1VBQUE7VUFDRE4sU0FBUyxHQUFHWCxnQkFBZ0IsQ0FBQ0MsS0FBSyxDQUFDO1VBQUF5QyxTQUFBLENBQUF6QixJQUFBO1VBQUEsT0FDbkN6QixFQUFFLENBQUMwQixRQUFRLENBQUNzQyxLQUFLLENBQUMvRCxJQUFJLENBQUNnRSxPQUFPLENBQUM5QyxTQUFTLENBQUMsRUFBRTtZQUFFK0MsU0FBUyxFQUFFO1VBQUssQ0FBQyxDQUFDO1FBQUE7VUFBQWhCLFNBQUEsQ0FBQXpCLElBQUE7VUFBQSxPQUMvRHpCLEVBQUUsQ0FBQzBCLFFBQVEsQ0FBQ3lDLFNBQVMsQ0FDekJoRCxTQUFTLEVBQ1RpRCxlQUFBLENBQWV4QixRQUFRLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxFQUNqQyxNQUNGLENBQUM7UUFBQTtVQUFBLE9BQUFNLFNBQUEsQ0FBQXJCLE1BQUEsV0FFSWUsUUFBUTtRQUFBO1FBQUE7VUFBQSxPQUFBTSxTQUFBLENBQUFqQixJQUFBO01BQUE7SUFBQSxHQUFBTSxRQUFBO0VBQUEsQ0FDaEI7RUFBQSxPQUFBRCxtQkFBQSxDQUFBekIsS0FBQSxPQUFBQyxTQUFBO0FBQUE7QUFFRCxTQUFTdUQsbUJBQW1CQSxDQUFDQyxPQUE4QixFQUFFO0VBQzNELElBQU1DLGdCQUFnQixHQUFHLEVBQUU7RUFBQyxJQUFBQyxTQUFBLEdBQUFsQiwwQkFBQSxDQU12QmdCLE9BQU8sQ0FBQ0csTUFBTTtJQUFBQyxLQUFBO0VBQUE7SUFMbkIsS0FBQUYsU0FBQSxDQUFBakIsQ0FBQSxNQUFBbUIsS0FBQSxHQUFBRixTQUFBLENBQUFoQixDQUFBLElBQUFDLElBQUEsR0FLcUI7TUFBQSxJQUFBa0IsV0FBQSxHQUFBRCxLQUFBLENBQUFoQixLQUFBO1FBSm5Ca0IsSUFBSSxHQUFBRCxXQUFBLENBQUpDLElBQUk7UUFDSkMsUUFBUSxHQUFBRixXQUFBLENBQVJFLFFBQVE7UUFDUkMsZ0JBQWdCLEdBQUFILFdBQUEsQ0FBaEJHLGdCQUFnQjtRQUNoQkMsV0FBVyxHQUFBSixXQUFBLENBQVhJLFdBQVc7TUFFWCxJQUNFSCxJQUFJLEtBQUssV0FBVyxJQUNwQkUsZ0JBQWdCLElBQ2hCQyxXQUFXLElBQ1hBLFdBQVcsQ0FBQ0MsTUFBTSxHQUFHLENBQUMsRUFDdEI7UUFDQSxJQUFNQyxhQUFhLEdBQUdGLFdBQVcsQ0FBQ0MsTUFBTSxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUdELFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFDdEVSLGdCQUFnQixDQUFDWCxJQUFJLENBQUM7VUFBRWlCLFFBQVEsRUFBUkEsUUFBUTtVQUFFSSxhQUFhLEVBQWJBLGFBQWE7VUFBRUgsZ0JBQWdCLEVBQWhCQTtRQUFpQixDQUFDLENBQUM7TUFDdEU7SUFDRjtFQUFDLFNBQUFJLEdBQUE7SUFBQVYsU0FBQSxDQUFBWCxDQUFBLENBQUFxQixHQUFBO0VBQUE7SUFBQVYsU0FBQSxDQUFBVixDQUFBO0VBQUE7RUFDRCxPQUFPUyxnQkFBZ0I7QUFDekI7QUFFQSxTQUFTWSxlQUFlQSxDQUFDUCxJQUFZLEVBQVU7RUFDN0MsT0FBT0EsSUFBSSxLQUFLLFFBQVEsSUFDdEJBLElBQUksS0FBSyxLQUFLLElBQ2RBLElBQUksS0FBSyxVQUFVLElBQ25CQSxJQUFJLEtBQUssU0FBUyxHQUNoQixRQUFRLEdBQ1JBLElBQUksS0FBSyxTQUFTLEdBQ2xCLFNBQVMsR0FDVEEsSUFBSSxLQUFLLE1BQU0sSUFBSUEsSUFBSSxLQUFLLFVBQVUsSUFBSUEsSUFBSSxLQUFLLE1BQU0sR0FDekQsWUFBWSxHQUNaQSxJQUFJLEtBQUssUUFBUSxHQUNqQixZQUFZLEdBQ1pBLElBQUksS0FBSyxTQUFTLEdBQ2xCLFNBQVMsR0FDVEEsSUFBSSxLQUFLLGNBQWMsR0FDdkIsS0FBSyxHQUNMLFFBQVE7QUFDZDtBQUFDLFNBRWNRLFVBQVVBLENBQUFDLEdBQUEsRUFBQUMsR0FBQSxFQUFBQyxHQUFBLEVBQUFDLEdBQUEsRUFBQUMsR0FBQSxFQUFBQyxJQUFBO0VBQUEsT0FBQUMsV0FBQSxDQUFBOUUsS0FBQSxPQUFBQyxTQUFBO0FBQUE7QUFBQSxTQUFBNkUsWUFBQTtFQUFBQSxXQUFBLEdBQUE1RSxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQXpCLFNBQUEyRSxTQUNFcEQsSUFBZ0IsRUFDaEIvQixLQUFhLEVBQ2JvRixVQUFrQixFQUNsQkMsVUFBa0IsRUFDbEJyRCxLQUFlLEVBQ2ZzRCxhQUEyQjtJQUFBLElBQUFuRCxRQUFBLEVBQUFvRCxHQUFBO0lBQUEsT0FBQWhGLG1CQUFBLENBQUFLLElBQUEsVUFBQTRFLFVBQUFDLFVBQUE7TUFBQSxrQkFBQUEsVUFBQSxDQUFBMUUsSUFBQSxHQUFBMEUsVUFBQSxDQUFBekUsSUFBQTtRQUFBO1VBQUEsS0FHeEJnQixLQUFLO1lBQUF5RCxVQUFBLENBQUF6RSxJQUFBO1lBQUE7VUFBQTtVQUFBeUUsVUFBQSxDQUFBekUsSUFBQTtVQUFBLE9BQVNmLGtCQUFrQixDQUFDRCxLQUFLLENBQUM7UUFBQTtVQUFBeUYsVUFBQSxDQUFBQyxFQUFBLEdBQUFELFVBQUEsQ0FBQXRFLElBQUE7VUFBQXNFLFVBQUEsQ0FBQXpFLElBQUE7VUFBQTtRQUFBO1VBQUF5RSxVQUFBLENBQUFDLEVBQUEsR0FBRyxJQUFJO1FBQUE7VUFBQUQsVUFBQSxDQUFBbEUsRUFBQSxHQUFBa0UsVUFBQSxDQUFBQyxFQUFBO1VBQUEsSUFBQUQsVUFBQSxDQUFBbEUsRUFBQTtZQUFBa0UsVUFBQSxDQUFBekUsSUFBQTtZQUFBO1VBQUE7VUFBQXlFLFVBQUEsQ0FBQXpFLElBQUE7VUFBQSxPQUN4Q1Msa0JBQWtCLENBQUNNLElBQUksRUFBRS9CLEtBQUssRUFBRWdDLEtBQUssQ0FBQztRQUFBO1VBQUF5RCxVQUFBLENBQUFsRSxFQUFBLEdBQUFrRSxVQUFBLENBQUF0RSxJQUFBO1FBQUE7VUFGekNnQixRQUFRLEdBQUFzRCxVQUFBLENBQUFsRSxFQUFBO1VBQUEsSUFHVGhDLEVBQUUsQ0FBQ29HLFVBQVUsQ0FBQ1AsVUFBVSxDQUFDO1lBQUFLLFVBQUEsQ0FBQXpFLElBQUE7WUFBQTtVQUFBO1VBQUF5RSxVQUFBLENBQUF6RSxJQUFBO1VBQUEsT0FDdEJ6QixFQUFFLENBQUMwQixRQUFRLENBQUNzQyxLQUFLLENBQUMvRCxJQUFJLENBQUNnRSxPQUFPLENBQUM0QixVQUFVLENBQUMsRUFBRTtZQUFFM0IsU0FBUyxFQUFFO1VBQUssQ0FBQyxDQUFDO1FBQUE7VUFBQWdDLFVBQUEsQ0FBQXpFLElBQUE7VUFBQSxPQUNoRXpCLEVBQUUsQ0FBQzBCLFFBQVEsQ0FBQ3lDLFNBQVMsQ0FBQzBCLFVBQVUsRUFBRSxFQUFFLEVBQUUsTUFBTSxDQUFDO1FBQUE7VUFFL0NHLEdBQUcsR0FBR2hHLEVBQUUsQ0FBQ3FHLGlCQUFpQixDQUFDUixVQUFVLEVBQUUsTUFBTSxDQUFDO1VBQUEsT0FBQUssVUFBQSxDQUFBckUsTUFBQSxXQUM3QyxJQUFBeUUsUUFBQSxDQUFZLFVBQUNDLE9BQU8sRUFBRUMsTUFBTSxFQUFLO1lBQ3RDUixHQUFHLENBQUNTLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBQ3ZCLEdBQUc7Y0FBQSxPQUFLc0IsTUFBTSxDQUFDdEIsR0FBRyxDQUFDO1lBQUEsRUFBQztZQUNyQ2MsR0FBRyxDQUFDUyxFQUFFLENBQUMsUUFBUSxFQUFFO2NBQUEsT0FBTUYsT0FBTyxDQUFDRyxTQUFTLENBQUM7WUFBQSxFQUFDO1lBQzFDLElBQU1DLFNBQVMsR0FBRyxTQUFaQSxTQUFTQSxDQUFJQyxPQUFlO2NBQUEsT0FBS1osR0FBRyxDQUFDYSxLQUFLLENBQUNELE9BQU8sR0FBRyxJQUFJLENBQUM7WUFBQTtZQUNoRUQsU0FBUyxDQUNQLHVGQUNGLENBQUM7WUFDREEsU0FBUyxDQUFDLEVBQUUsQ0FBQztZQUFDLElBQUFHLFVBQUEsR0FBQXhELDBCQUFBLENBQ1FWLFFBQVE7Y0FBQW1FLE1BQUE7WUFBQTtjQUE5QixLQUFBRCxVQUFBLENBQUF2RCxDQUFBLE1BQUF3RCxNQUFBLEdBQUFELFVBQUEsQ0FBQXRELENBQUEsSUFBQUMsSUFBQSxHQUFnQztnQkFBQSxJQUFBdUQsU0FBQSxFQUFBQyxTQUFBLEVBQUFDLFNBQUEsRUFBQUMsU0FBQSxFQUFBQyxTQUFBO2dCQUFBLElBQXJCOUMsT0FBTyxHQUFBeUMsTUFBQSxDQUFBckQsS0FBQTtnQkFDaEIsSUFBSXFDLGFBQWEsSUFBSSxDQUFDQSxhQUFhLENBQUNzQixHQUFHLENBQUMvQyxPQUFPLENBQUN2QixJQUFJLENBQUMsRUFBRTtrQkFDckQ7Z0JBQ0Y7Z0JBQ0EsSUFBUUEsSUFBSSxHQUFpQ3VCLE9BQU8sQ0FBNUN2QixJQUFJO2tCQUFFMEIsTUFBTSxHQUF5QkgsT0FBTyxDQUF0Q0csTUFBTTtrQkFBRTZDLGtCQUFrQixHQUFLaEQsT0FBTyxDQUE5QmdELGtCQUFrQjtnQkFDeENYLFNBQVMsZ0JBQUFZLE1BQUEsQ0FBZ0J4RSxJQUFJLFNBQU0sQ0FBQztnQkFDcEM0RCxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUFDLElBQUFhLFVBQUEsR0FBQWxFLDBCQUFBLENBQ3FCbUIsTUFBTTtrQkFBQWdELE1BQUE7Z0JBQUE7a0JBQTdDLEtBQUFELFVBQUEsQ0FBQWpFLENBQUEsTUFBQWtFLE1BQUEsR0FBQUQsVUFBQSxDQUFBaEUsQ0FBQSxJQUFBQyxJQUFBLEdBQStDO29CQUFBLElBQUFpRSxTQUFBLEVBQUFDLFNBQUE7b0JBQUEsSUFBQUMsWUFBQSxHQUFBSCxNQUFBLENBQUEvRCxLQUFBO3NCQUFsQ1gsS0FBSSxHQUFBNkUsWUFBQSxDQUFKN0UsSUFBSTtzQkFBRTZCLElBQUksR0FBQWdELFlBQUEsQ0FBSmhELElBQUk7c0JBQUVDLFFBQVEsR0FBQStDLFlBQUEsQ0FBUi9DLFFBQVE7b0JBQy9CLElBQU1nRCxNQUFNLEdBQUcxQyxlQUFlLENBQUNQLElBQUksQ0FBQztvQkFDcEMsSUFBTWtELE1BQU0sR0FBR2pELFFBQVEsR0FBRyxTQUFTLEdBQUcsRUFBRTtvQkFDeEM4QixTQUFTLENBQUFvQix1QkFBQSxDQUFBTCxTQUFBLEdBQUFLLHVCQUFBLENBQUFKLFNBQUEsUUFBQUosTUFBQSxDQUFNeEUsS0FBSSxTQUFBaUYsSUFBQSxDQUFBTCxTQUFBLEVBQUtFLE1BQU0sR0FBQUcsSUFBQSxDQUFBTixTQUFBLEVBQUdJLE1BQU0sTUFBRyxDQUFDO2tCQUM3QztnQkFBQyxTQUFBNUMsR0FBQTtrQkFBQXNDLFVBQUEsQ0FBQTNELENBQUEsQ0FBQXFCLEdBQUE7Z0JBQUE7a0JBQUFzQyxVQUFBLENBQUExRCxDQUFBO2dCQUFBO2dCQUNENkMsU0FBUyxDQUFDLElBQUksQ0FBQztnQkFDZkEsU0FBUyxDQUFDLEVBQUUsQ0FBQztnQkFDYkEsU0FBUywwQkFBQVksTUFBQSxDQUEwQnhFLElBQUksU0FBTSxDQUFDO2dCQUM5QzRELFNBQVMsQ0FBQyxNQUFNLENBQUM7Z0JBQ2pCLElBQU1wQyxnQkFBZ0IsR0FBR0YsbUJBQW1CLENBQUNDLE9BQU8sQ0FBQztnQkFBQyxJQUFBMkQsVUFBQSxHQUFBM0UsMEJBQUEsQ0FLakRpQixnQkFBZ0I7a0JBQUEyRCxNQUFBO2dCQUFBO2tCQUpyQixLQUFBRCxVQUFBLENBQUExRSxDQUFBLE1BQUEyRSxNQUFBLEdBQUFELFVBQUEsQ0FBQXpFLENBQUEsSUFBQUMsSUFBQSxHQUl1QjtvQkFBQSxJQUFBMEUsVUFBQSxFQUFBQyxVQUFBO29CQUFBLElBQUFDLFlBQUEsR0FBQUgsTUFBQSxDQUFBeEUsS0FBQTtzQkFIckJtQixTQUFRLEdBQUF3RCxZQUFBLENBQVJ4RCxRQUFRO3NCQUNSSSxhQUFhLEdBQUFvRCxZQUFBLENBQWJwRCxhQUFhO3NCQUNiSCxnQkFBZ0IsR0FBQXVELFlBQUEsQ0FBaEJ2RCxnQkFBZ0I7b0JBRWhCLElBQUlpQixhQUFhLElBQUksQ0FBQ0EsYUFBYSxDQUFDc0IsR0FBRyxDQUFDcEMsYUFBYSxDQUFDLEVBQUU7c0JBQ3REO29CQUNGO29CQUNBLElBQU02QyxPQUFNLEdBQUdqRCxTQUFRLEdBQUcsU0FBUyxHQUFHLEVBQUU7b0JBQ3hDOEIsU0FBUyxDQUFBb0IsdUJBQUEsQ0FBQUksVUFBQSxHQUFBSix1QkFBQSxDQUFBSyxVQUFBLFFBQUFiLE1BQUEsQ0FDRnpDLGdCQUFnQiwyQkFBQWtELElBQUEsQ0FBQUksVUFBQSxFQUF1Qm5ELGFBQWEsR0FBQStDLElBQUEsQ0FBQUcsVUFBQSxFQUFHTCxPQUFNLE1BQ3BFLENBQUM7a0JBQ0g7Z0JBQUMsU0FBQTVDLEdBQUE7a0JBQUErQyxVQUFBLENBQUFwRSxDQUFBLENBQUFxQixHQUFBO2dCQUFBO2tCQUFBK0MsVUFBQSxDQUFBbkUsQ0FBQTtnQkFBQTtnQkFDRDZDLFNBQVMsQ0FBQyxJQUFJLENBQUM7Z0JBQ2ZBLFNBQVMsQ0FBQyxFQUFFLENBQUM7Z0JBQ2JBLFNBQVMsNEJBQUFZLE1BQUEsQ0FBNEJ4RSxJQUFJLFNBQU0sQ0FBQztnQkFDaEQ0RCxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUFDLElBQUEyQixVQUFBLEdBQUFoRiwwQkFBQSxDQUtiZ0Usa0JBQWtCO2tCQUFBaUIsTUFBQTtnQkFBQTtrQkFKdkIsS0FBQUQsVUFBQSxDQUFBL0UsQ0FBQSxNQUFBZ0YsTUFBQSxHQUFBRCxVQUFBLENBQUE5RSxDQUFBLElBQUFDLElBQUEsR0FJeUI7b0JBQUEsSUFBQStFLFlBQUEsR0FBQUQsTUFBQSxDQUFBN0UsS0FBQTtzQkFIdkIrRSxLQUFLLEdBQUFELFlBQUEsQ0FBTEMsS0FBSztzQkFDTEMsWUFBWSxHQUFBRixZQUFBLENBQVpFLFlBQVk7c0JBQ1o1RCxpQkFBZ0IsR0FBQTBELFlBQUEsQ0FBaEIxRCxnQkFBZ0I7b0JBRWhCLElBQUlpQixhQUFhLElBQUksQ0FBQ0EsYUFBYSxDQUFDc0IsR0FBRyxDQUFDcUIsWUFBWSxDQUFDLEVBQUU7c0JBQ3JEO29CQUNGO29CQUNBLElBQ0VELEtBQUssSUFDTEMsWUFBWSxJQUNaNUQsaUJBQWdCLElBQ2hCLENBQUM2RCx5QkFBQSxDQUFBRixLQUFLLEVBQUFULElBQUEsQ0FBTFMsS0FBSyxFQUFVLEtBQUssQ0FBQyxFQUN0QjtzQkFBQSxJQUFBRyxVQUFBO3NCQUNBakMsU0FBUyxDQUFBb0IsdUJBQUEsQ0FBQWEsVUFBQSxRQUFBckIsTUFBQSxDQUNGekMsaUJBQWdCLDJCQUFBa0QsSUFBQSxDQUFBWSxVQUFBLEVBQXVCRixZQUFZLE1BQzFELENBQUM7b0JBQ0g7a0JBQ0Y7Z0JBQUMsU0FBQXhELEdBQUE7a0JBQUFvRCxVQUFBLENBQUF6RSxDQUFBLENBQUFxQixHQUFBO2dCQUFBO2tCQUFBb0QsVUFBQSxDQUFBeEUsQ0FBQTtnQkFBQTtnQkFDRDZDLFNBQVMsQ0FBQyxJQUFJLENBQUM7Z0JBQ2ZBLFNBQVMsQ0FBQyxFQUFFLENBQUM7Z0JBQ2JBLFNBQVMsQ0FBQW9CLHVCQUFBLENBQUFmLFNBQUEsR0FBQWUsdUJBQUEsQ0FBQWQsU0FBQSxHQUFBYyx1QkFBQSxDQUFBYixTQUFBLEdBQUFhLHVCQUFBLENBQUFaLFNBQUEsR0FBQVksdUJBQUEsQ0FBQVgsU0FBQSxrQ0FBQUcsTUFBQSxDQUN3QnhFLElBQUksbUNBQUFpRixJQUFBLENBQUFaLFNBQUEsRUFBK0JyRSxJQUFJLHdCQUFBaUYsSUFBQSxDQUFBYixTQUFBLEVBQ2pFcEUsSUFBSSw4QkFBQWlGLElBQUEsQ0FBQWQsU0FBQSxFQUNJbkUsSUFBSSxpREFBQWlGLElBQUEsQ0FBQWYsU0FBQSxFQUNnQmxFLElBQUkscURBQUFpRixJQUFBLENBQUFoQixTQUFBLEVBQ0FqRSxJQUFJLFdBRTNDLENBQUM7Z0JBQ0Q0RCxTQUFTLENBQUMsRUFBRSxDQUFDO2NBQ2Y7WUFBQyxTQUFBekIsR0FBQTtjQUFBNEIsVUFBQSxDQUFBakQsQ0FBQSxDQUFBcUIsR0FBQTtZQUFBO2NBQUE0QixVQUFBLENBQUFoRCxDQUFBO1lBQUE7WUFDRDZDLFNBQVMsQ0FBQyxFQUFFLENBQUM7WUFDYkEsU0FBUyxxQkFBQVksTUFBQSxDQUFxQnpCLFVBQVUsc0JBQW1CLENBQUM7WUFDNURhLFNBQVMsQ0FBQyxlQUFlLENBQUM7WUFBQyxJQUFBa0MsVUFBQSxHQUFBdkYsMEJBQUEsQ0FDSlYsUUFBUTtjQUFBa0csTUFBQTtZQUFBO2NBQS9CLEtBQUFELFVBQUEsQ0FBQXRGLENBQUEsTUFBQXVGLE1BQUEsR0FBQUQsVUFBQSxDQUFBckYsQ0FBQSxJQUFBQyxJQUFBLEdBQWlDO2dCQUFBLElBQUFzRixVQUFBO2dCQUFBLElBQXBCaEcsTUFBSSxHQUFBK0YsTUFBQSxDQUFBcEYsS0FBQSxDQUFKWCxJQUFJO2dCQUNmLElBQUlnRCxhQUFhLElBQUksQ0FBQ0EsYUFBYSxDQUFDc0IsR0FBRyxDQUFDdEUsTUFBSSxDQUFDLEVBQUU7a0JBQzdDO2dCQUNGO2dCQUNBNEQsU0FBUyxDQUFBb0IsdUJBQUEsQ0FBQWdCLFVBQUEsVUFBQXhCLE1BQUEsQ0FBUXhFLE1BQUksMkJBQUFpRixJQUFBLENBQUFlLFVBQUEsRUFBdUJoRyxNQUFJLE1BQUcsQ0FBQztjQUN0RDtZQUFDLFNBQUFtQyxHQUFBO2NBQUEyRCxVQUFBLENBQUFoRixDQUFBLENBQUFxQixHQUFBO1lBQUE7Y0FBQTJELFVBQUEsQ0FBQS9FLENBQUE7WUFBQTtZQUNENkMsU0FBUyxDQUFDLE1BQU0sQ0FBQztZQUNqQkEsU0FBUyxDQUFDLEdBQUcsQ0FBQztZQUNkWCxHQUFHLENBQUNnRCxHQUFHLENBQUMsQ0FBQztVQUNYLENBQUMsQ0FBQztRQUFBO1FBQUE7VUFBQSxPQUFBOUMsVUFBQSxDQUFBakUsSUFBQTtNQUFBO0lBQUEsR0FBQTJELFFBQUE7RUFBQSxDQUNIO0VBQUEsT0FBQUQsV0FBQSxDQUFBOUUsS0FBQSxPQUFBQyxTQUFBO0FBQUE7QUFjRCxTQUFTbUksa0JBQWtCQSxDQUFDdkYsS0FBYSxFQUFFd0YsY0FBdUIsRUFBRTtFQUNsRSxPQUFPLElBQUFDLElBQUEsQ0FBUXpGLEtBQUssQ0FBQzBGLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNsQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQyxXQUFXQSxDQUFBLEVBQXFCO0VBQ3ZDLE9BQU8sSUFBSWpKLE9BQU8sQ0FBQyxDQUFDLENBQ2pCa0osTUFBTSxDQUFDLDJCQUEyQixFQUFFLHFCQUFxQixDQUFDLENBQzFEQSxNQUFNLENBQ0wsMkJBQTJCLEVBQzNCLHdEQUNGLENBQUMsQ0FDQUEsTUFBTSxDQUNMLCtCQUErQixFQUMvQiwrQ0FDRixDQUFDLENBQ0FBLE1BQU0sQ0FBQywyQkFBMkIsRUFBRSxzQkFBc0IsQ0FBQyxDQUMzREEsTUFBTSxDQUFDLCtCQUErQixFQUFFLHFCQUFxQixFQUFFLFVBQVUsQ0FBQyxDQUMxRUMsY0FBYyxDQUNiLCtCQUErQixFQUMvQiw0QkFBNEIsRUFDNUIsZUFDRixDQUFDLENBQ0FELE1BQU0sQ0FBQyxXQUFXLEVBQUUsNkJBQTZCLENBQUMsQ0FDbERBLE1BQU0sQ0FDTCxZQUFZLEVBQ1osa0VBQ0YsQ0FBQyxDQUNBQSxNQUFNLENBQUMsY0FBYyxFQUFFLDBDQUEwQyxDQUFDLENBQ2xFQSxNQUFNLENBQ0wsaUNBQWlDLEVBQ2pDLDBDQUEwQyxFQUMxQ0wsa0JBQ0YsQ0FBQyxDQUNBTyxPQUFPLENBQUNySixPQUFPLENBQUMsQ0FDaEI0QixLQUFLLENBQUMwSCxPQUFPLENBQUNDLElBQUksQ0FBQztBQUN4Qjs7QUFFQTtBQUNBO0FBQ0E7QUFDQSx3QkFBOEJDLElBQUlBLENBQUE7RUFBQSxPQUFBQyxLQUFBLENBQUEvSSxLQUFBLE9BQUFDLFNBQUE7QUFBQTtBQXNCakMsU0FBQThJLE1BQUE7RUFBQUEsS0FBQSxHQUFBN0ksaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQXRCYyxTQUFBNEksU0FBQTtJQUFBLElBQUFDLE9BQUEsRUFBQUMsR0FBQSxFQUFBdkgsSUFBQTtJQUFBLE9BQUF4QixtQkFBQSxDQUFBSyxJQUFBLFVBQUEySSxVQUFBQyxVQUFBO01BQUEsa0JBQUFBLFVBQUEsQ0FBQXpJLElBQUEsR0FBQXlJLFVBQUEsQ0FBQXhJLElBQUE7UUFBQTtVQUNQcUksT0FBTyxHQUFHVCxXQUFXLENBQUMsQ0FBQztVQUN2QlUsR0FBRyxHQUFHLElBQUk3SixHQUFHLENBQUMsQ0FBQztVQUFBK0osVUFBQSxDQUFBeEksSUFBQTtVQUFBLE9BQ2ZzSSxHQUFHLENBQUNHLE9BQU8sQ0FBQ0osT0FBTyxDQUFDO1FBQUE7VUFDcEJ0SCxJQUFJLEdBQUd1SCxHQUFHLENBQUNJLG9CQUFvQixDQUFDLENBQUM7VUFBQSxJQUNsQzNILElBQUksQ0FBQzRILFFBQVE7WUFBQUgsVUFBQSxDQUFBeEksSUFBQTtZQUFBO1VBQUE7VUFDaEIwQixPQUFPLENBQUNrSCxLQUFLLENBQUMsOEJBQThCLENBQUM7VUFBQyxPQUFBSixVQUFBLENBQUFwSSxNQUFBO1FBQUE7VUFBQW9JLFVBQUEsQ0FBQXhJLElBQUE7VUFBQSxPQUcxQzJELFVBQVUsQ0FDZDVDLElBQUksRUFDSkEsSUFBSSxDQUFDNEgsUUFBUSxDQUFDRSxjQUFjLEVBQzVCUixPQUFPLENBQUNqRSxVQUFVLEVBQ2xCaUUsT0FBTyxDQUFDaEUsVUFBVSxFQUNsQmdFLE9BQU8sQ0FBQ3JILEtBQUssRUFDYnFILE9BQU8sQ0FBQy9ELGFBQ1YsQ0FBQztRQUFBO1VBQUEsS0FDRytELE9BQU8sQ0FBQ1MsVUFBVTtZQUFBTixVQUFBLENBQUF4SSxJQUFBO1lBQUE7VUFBQTtVQUNwQjBCLE9BQU8sQ0FBQ3FILEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQztVQUFDUCxVQUFBLENBQUF4SSxJQUFBO1VBQUEsT0FDOUJ6QixFQUFFLENBQUMwQixRQUFRLENBQUMrSSxFQUFFLENBQUNwSyxlQUFlLENBQUMsQ0FBQyxFQUFFO1lBQUU2RCxTQUFTLEVBQUU7VUFBSyxDQUFDLENBQUM7UUFBQTtVQUU5RGYsT0FBTyxDQUFDcUgsR0FBRyxlQUFBakQsTUFBQSxDQUFldUMsT0FBTyxDQUFDakUsVUFBVSxDQUFFLENBQUM7UUFBQztRQUFBO1VBQUEsT0FBQW9FLFVBQUEsQ0FBQWhJLElBQUE7TUFBQTtJQUFBLEdBQUE0SCxRQUFBO0VBQUEsQ0FDakQ7RUFBQSxPQUFBRCxLQUFBLENBQUEvSSxLQUFBLE9BQUFDLFNBQUE7QUFBQSIsImlnbm9yZUxpc3QiOltdfQ==