import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";
import _toConsumableArray from "@babel/runtime-corejs3/helpers/toConsumableArray";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
var _excluded = ["fields", "includes", "sort"],
  _excluded2 = ["conditions", "fields"];
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof _Symbol && _getIteratorMethod(r) || r["@@iterator"]; if (!t) { if (_Array$isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { var _context38; if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = _sliceInstanceProperty(_context38 = {}.toString.call(r)).call(_context38, 8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? _Array$from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.includes.js";
import "core-js/modules/es.array.join.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.array.sort.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/es.regexp.to-string.js";
import "core-js/modules/es.string.includes.js";
import "core-js/modules/es.string.split.js";
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context36, _context37; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context36 = ownKeys(Object(t), !0)).call(_context36, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context37 = ownKeys(Object(t))).call(_context37, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
import _reduceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reduce";
import _sortInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/sort";
import _includesInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/includes";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Object$entries from "@babel/runtime-corejs3/core-js-stable/object/entries";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
/**
 * @file Manages query for records in Salesforce
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import { getLogger } from './util/logger';
import RecordStream, { Serializable } from './record-stream';
import { createSOQL } from './soql-builder';

/**
 *
 */

/**
 *
 */

/**
 *
 */

var ResponseTargetValues = ['QueryResult', 'Records', 'SingleRecord', 'Count'];
export var ResponseTargets = _reduceInstanceProperty(ResponseTargetValues).call(ResponseTargetValues, function (values, target) {
  return _objectSpread(_objectSpread({}, values), {}, _defineProperty({}, target, target));
}, {});

// QRT extends 'Count'

/**
 *
 */
var DEFAULT_BULK_THRESHOLD = 200;
var DEFAULT_BULK_API_VERSION = 1;

/**
 * Query
 */
export var Query = /*#__PURE__*/function (_EventEmitter) {
  /**
   *
   */
  function Query(conn, config, options) {
    var _this;
    _classCallCheck(this, Query);
    _this = _callSuper(this, Query);
    _defineProperty(_this, "_config", {});
    _defineProperty(_this, "_children", []);
    _defineProperty(_this, "_executed", false);
    _defineProperty(_this, "_finished", false);
    _defineProperty(_this, "_chaining", false);
    _defineProperty(_this, "totalSize", 0);
    _defineProperty(_this, "totalFetched", 0);
    _defineProperty(_this, "records", []);
    /**
     * Synonym of Query#skip()
     */
    _defineProperty(_this, "offset", _this.skip);
    /**
     * Synonym of Query#sort()
     */
    _defineProperty(_this, "orderby", _sortInstanceProperty(_this));
    /**
     * Synonym of Query#execute()
     */
    _defineProperty(_this, "exec", _this.execute);
    /**
     * Synonym of Query#execute()
     */
    _defineProperty(_this, "run", _this.execute);
    /**
     * Synonym of Query#destroy()
     */
    _defineProperty(_this, "delete", _this.destroy);
    /**
     * Synonym of Query#destroy()
     */
    _defineProperty(_this, "del", _this.destroy);
    _this._conn = conn;
    _this._logger = conn._logLevel ? Query._logger.createInstance(conn._logLevel) : Query._logger;
    if (typeof config === 'string') {
      _this._soql = config;
      _this._logger.debug("config is soql: ".concat(config));
    } else if (typeof config.locator === 'string') {
      var locator = config.locator;
      _this._logger.debug("config is locator: ".concat(locator));
      _this._locator = _includesInstanceProperty(locator).call(locator, '/') ? _this.urlToLocator(locator) : locator;
    } else {
      _this._logger.debug("config is QueryConfig: ".concat(_JSON$stringify(config)));
      var _ref = config,
        _fields = _ref.fields,
        includes = _includesInstanceProperty(_ref),
        _sort2 = _sortInstanceProperty(_ref),
        _config = _objectWithoutProperties(_ref, _excluded);
      _this._config = _config;
      _this.select(_fields);
      if (includes) {
        _this.includeChildren(includes);
      }
      if (_sort2) {
        _sortInstanceProperty(_this).call(_this, _sort2);
      }
    }
    _this._options = _objectSpread({
      headers: {},
      maxFetch: 10000,
      autoFetch: false,
      scanAll: false,
      responseTarget: 'QueryResult'
    }, options || {});
    // promise instance
    _this._promise = new _Promise(function (resolve, reject) {
      _this.on('response', resolve);
      _this.on('error', reject);
    });
    _this._stream = new Serializable();
    _this.on('record', function (record) {
      return _this._stream.push(record);
    });
    _this.on('end', function () {
      return _this._stream.push(null);
    });
    _this.on('error', function (err) {
      try {
        _this._stream.emit('error', err);
      } catch (e) {
        // eslint-disable-line no-empty
      }
    });
    return _this;
  }

  /**
   * Select fields to include in the returning result
   */
  _inherits(Query, _EventEmitter);
  return _createClass(Query, [{
    key: "select",
    value: function select() {
      var fields = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '*';
      if (this._soql) {
        throw Error('Cannot set select fields for the query which has already built SOQL.');
      }
      function toFieldArray(fields) {
        var _context, _context2, _context4, _context5;
        return typeof fields === 'string' ? fields.split(/\s*,\s*/) : _Array$isArray(fields) ? _reduceInstanceProperty(_context = _mapInstanceProperty(_context2 = fields).call(_context2, toFieldArray)).call(_context, function (fs, f) {
          var _context3;
          return _concatInstanceProperty(_context3 = []).call(_context3, _toConsumableArray(fs), _toConsumableArray(f));
        }, []) : _reduceInstanceProperty(_context4 = _mapInstanceProperty(_context5 = _Object$entries(fields)).call(_context5, function (_ref2) {
          var _ref3 = _slicedToArray(_ref2, 2),
            f = _ref3[0],
            v = _ref3[1];
          if (typeof v === 'number' || typeof v === 'boolean') {
            return v ? [f] : [];
          } else {
            var _context6;
            return _mapInstanceProperty(_context6 = toFieldArray(v)).call(_context6, function (p) {
              var _context7;
              return _concatInstanceProperty(_context7 = "".concat(f, ".")).call(_context7, p);
            });
          }
        })).call(_context4, function (fs, f) {
          var _context8;
          return _concatInstanceProperty(_context8 = []).call(_context8, _toConsumableArray(fs), _toConsumableArray(f));
        }, []);
      }
      if (fields) {
        this._config.fields = toFieldArray(fields);
      }
      // force convert query record type without changing instance;
      return this;
    }

    /**
     * Set query conditions to filter the result records
     */
  }, {
    key: "where",
    value: function where(conditions) {
      if (this._soql) {
        throw Error('Cannot set where conditions for the query which has already built SOQL.');
      }
      this._config.conditions = conditions;
      return this;
    }

    /**
     * Limit the returning result
     */
  }, {
    key: "limit",
    value: function limit(_limit) {
      if (this._soql) {
        throw Error('Cannot set limit for the query which has already built SOQL.');
      }
      this._config.limit = _limit;
      return this;
    }

    /**
     * Skip records
     */
  }, {
    key: "skip",
    value: function skip(offset) {
      if (this._soql) {
        throw Error('Cannot set skip/offset for the query which has already built SOQL.');
      }
      this._config.offset = offset;
      return this;
    }
  }, {
    key: "sort",
    value: function (_sort) {
      function sort(_x, _x2) {
        return _sort.apply(this, arguments);
      }
      sort.toString = function () {
        return _sort.toString();
      };
      return sort;
    }(function (sort, dir) {
      if (this._soql) {
        throw Error('Cannot set sort for the query which has already built SOQL.');
      }
      if (typeof sort === 'string' && typeof dir !== 'undefined') {
        this._config.sort = [[sort, dir]];
      } else {
        this._config.sort = sort;
      }
      return this;
    })
  }, {
    key: "include",
    value: function include(childRelName, conditions, fields) {
      var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
      if (this._soql) {
        throw Error('Cannot include child relationship into the query which has already built SOQL.');
      }
      var childConfig = {
        fields: fields === null ? undefined : fields,
        table: childRelName,
        conditions: conditions === null ? undefined : conditions,
        limit: options.limit,
        offset: options.offset,
        sort: _sortInstanceProperty(options)
      };
      // eslint-disable-next-line no-use-before-define
      var childQuery = new SubQuery(this._conn, childRelName, childConfig, this);
      this._children.push(childQuery);
      return childQuery;
    }

    /**
     * Include child relationship queries, but not moving down to the children context
     */
  }, {
    key: "includeChildren",
    value: function includeChildren(includes) {
      if (this._soql) {
        throw Error('Cannot include child relationship into the query which has already built SOQL.');
      }
      for (var _i = 0, _arr = _Object$keys(includes); _i < _arr.length; _i++) {
        var crname = _arr[_i];
        var _ref4 = includes[crname],
          _conditions = _ref4.conditions,
          _fields2 = _ref4.fields,
          _options = _objectWithoutProperties(_ref4, _excluded2);
        this.include(crname, _conditions, _fields2, _options);
      }
      return this;
    }

    /**
     * Setting maxFetch query option
     */
  }, {
    key: "maxFetch",
    value: function maxFetch(_maxFetch) {
      this._options.maxFetch = _maxFetch;
      return this;
    }

    /**
     * Switching auto fetch mode
     */
  }, {
    key: "autoFetch",
    value: function autoFetch(_autoFetch) {
      this._options.autoFetch = _autoFetch;
      return this;
    }

    /**
     * Set flag to scan all records including deleted and archived.
     */
  }, {
    key: "scanAll",
    value: function scanAll(_scanAll) {
      this._options.scanAll = _scanAll;
      return this;
    }

    /**
     *
     */
  }, {
    key: "setResponseTarget",
    value: function setResponseTarget(responseTarget) {
      if (responseTarget in ResponseTargets) {
        this._options.responseTarget = responseTarget;
      }
      // force change query response target without changing instance
      return this;
    }

    /**
     * Execute query and fetch records from server.
     */
  }, {
    key: "execute",
    value: function execute() {
      var _this2 = this;
      var options_ = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      if (this._executed) {
        throw new Error('re-executing already executed query');
      }
      if (this._finished) {
        throw new Error('executing already closed query');
      }
      var options = {
        headers: options_.headers || this._options.headers,
        responseTarget: options_.responseTarget || this._options.responseTarget,
        autoFetch: options_.autoFetch || this._options.autoFetch,
        maxFetch: options_.maxFetch || this._options.maxFetch,
        scanAll: options_.scanAll || this._options.scanAll
      };

      // collect fetched records in array
      // only when response target is Records and
      // either callback or chaining promises are available to this query.
      this.once('fetch', function () {
        if (options.responseTarget === ResponseTargets.Records && _this2._chaining) {
          _this2._logger.debug('--- collecting all fetched records ---');
          var records = [];
          var onRecord = function onRecord(record) {
            return records.push(record);
          };
          _this2.on('record', onRecord);
          _this2.once('end', function () {
            _this2.removeListener('record', onRecord);
            _this2.emit('response', records, _this2);
          });
        }
      });

      // flag to prevent re-execution
      this._executed = true;
      _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
        return _regeneratorRuntime.wrap(function _callee$(_context9) {
          while (1) switch (_context9.prev = _context9.next) {
            case 0:
              // start actual query
              _this2._logger.debug('>>> Query start >>>');
              _context9.prev = 1;
              _context9.next = 4;
              return _this2._execute(options);
            case 4:
              _this2._logger.debug('*** Query finished ***');
              _context9.next = 11;
              break;
            case 7:
              _context9.prev = 7;
              _context9.t0 = _context9["catch"](1);
              _this2._logger.debug('--- Query error ---', _context9.t0);
              _this2.emit('error', _context9.t0);
            case 11:
            case "end":
              return _context9.stop();
          }
        }, _callee, null, [[1, 7]]);
      }))();

      // return Query instance for chaining
      return this;
    }
  }, {
    key: "locatorToUrl",
    value: function locatorToUrl() {
      return this._locator ? [this._conn._baseUrl(), '/query/', this._locator].join('') : '';
    }
  }, {
    key: "urlToLocator",
    value: function urlToLocator(url) {
      return url.split('/').pop();
    }
  }, {
    key: "constructResponse",
    value: function constructResponse(rawDone, responseTarget) {
      var _this$records$, _this$records;
      switch (responseTarget) {
        case 'Count':
          return this.totalSize;
        case 'SingleRecord':
          return (_this$records$ = (_this$records = this.records) === null || _this$records === void 0 ? void 0 : _this$records[0]) !== null && _this$records$ !== void 0 ? _this$records$ : null;
        case 'Records':
          return this.records;
        // QueryResult is default response target
        default:
          return _objectSpread(_objectSpread({}, {
            records: this.records,
            totalSize: this.totalSize,
            done: rawDone !== null && rawDone !== void 0 ? rawDone : true // when no records, done is omitted
          }), this._locator ? {
            nextRecordsUrl: this.locatorToUrl()
          } : {});
      }
    }
    /**
     * @private
     */
  }, {
    key: "_execute",
    value: (function () {
      var _execute2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(options) {
        var _this$records2, _context10, _data$records$length, _data$records;
        var headers, responseTarget, autoFetch, maxFetch, scanAll, url, soql, data, recordKeys, _iterator, _step, record, _iterator2, _step2, key, _field, numRecords, totalFetched, i, _record, response;
        return _regeneratorRuntime.wrap(function _callee2$(_context11) {
          while (1) switch (_context11.prev = _context11.next) {
            case 0:
              headers = options.headers, responseTarget = options.responseTarget, autoFetch = options.autoFetch, maxFetch = options.maxFetch, scanAll = options.scanAll;
              this._logger.debug('execute with options', options);
              if (!this._locator) {
                _context11.next = 6;
                break;
              }
              url = this.locatorToUrl();
              _context11.next = 11;
              break;
            case 6:
              _context11.next = 8;
              return this.toSOQL();
            case 8:
              soql = _context11.sent;
              this._logger.debug("SOQL = ".concat(soql));
              url = [this._conn._baseUrl(), '/', scanAll ? 'queryAll' : 'query', '?q=', encodeURIComponent(soql)].join('');
            case 11:
              _context11.next = 13;
              return this._conn.request({
                method: 'GET',
                url: url,
                headers: headers
              });
            case 13:
              data = _context11.sent;
              this.emit('fetch');
              this.totalSize = data.totalSize;

              // If autoFetch is true, fetch all records for any subqueries
              if (!(autoFetch && data.records.length > 0)) {
                _context11.next = 59;
                break;
              }
              recordKeys = _Object$keys(data.records[0]);
              _iterator = _createForOfIteratorHelper(data.records);
              _context11.prev = 19;
              _iterator.s();
            case 21:
              if ((_step = _iterator.n()).done) {
                _context11.next = 51;
                break;
              }
              record = _step.value;
              _iterator2 = _createForOfIteratorHelper(recordKeys);
              _context11.prev = 24;
              _iterator2.s();
            case 26:
              if ((_step2 = _iterator2.n()).done) {
                _context11.next = 41;
                break;
              }
              key = _step2.value;
              _field = record[key];
              if (!(_field && _typeof(_field) === 'object' && 'records' in _field && 'nextRecordsUrl' in _field)) {
                _context11.next = 39;
                break;
              }
              _context11.t0 = _objectSpread;
              _context11.t1 = _objectSpread({}, _field);
              _context11.t2 = {};
              _context11.next = 35;
              return this._fetchAllSubqueryRecords(record, key, headers);
            case 35:
              _context11.t3 = _context11.sent;
              _context11.t4 = undefined;
              _context11.t5 = {
                records: _context11.t3,
                done: true,
                nextRecordsUrl: _context11.t4
              };
              record[key] = (0, _context11.t0)(_context11.t1, _context11.t2, _context11.t5);
            case 39:
              _context11.next = 26;
              break;
            case 41:
              _context11.next = 46;
              break;
            case 43:
              _context11.prev = 43;
              _context11.t6 = _context11["catch"](24);
              _iterator2.e(_context11.t6);
            case 46:
              _context11.prev = 46;
              _iterator2.f();
              return _context11.finish(46);
            case 49:
              _context11.next = 21;
              break;
            case 51:
              _context11.next = 56;
              break;
            case 53:
              _context11.prev = 53;
              _context11.t7 = _context11["catch"](19);
              _iterator.e(_context11.t7);
            case 56:
              _context11.prev = 56;
              _iterator.f();
              return _context11.finish(56);
            case 59:
              this.records = (_this$records2 = this.records) === null || _this$records2 === void 0 ? void 0 : _concatInstanceProperty(_this$records2).call(_this$records2, maxFetch - this.records.length > data.records.length ? data.records : _sliceInstanceProperty(_context10 = data.records).call(_context10, 0, maxFetch - this.records.length));
              this._locator = data.nextRecordsUrl ? this.urlToLocator(data.nextRecordsUrl) : undefined;
              this._finished = this._finished || data.done || !autoFetch || this.records.length === maxFetch ||
              // this is what the response looks like when there are no results
              data.records.length === 0 && data.done === undefined;

              // streaming record instances
              numRecords = (_data$records$length = (_data$records = data.records) === null || _data$records === void 0 ? void 0 : _data$records.length) !== null && _data$records$length !== void 0 ? _data$records$length : 0;
              totalFetched = this.totalFetched;
              i = 0;
            case 65:
              if (!(i < numRecords)) {
                _context11.next = 75;
                break;
              }
              if (!(totalFetched >= maxFetch)) {
                _context11.next = 69;
                break;
              }
              this._finished = true;
              return _context11.abrupt("break", 75);
            case 69:
              _record = data.records[i];
              this.emit('record', _record, totalFetched, this);
              totalFetched += 1;
            case 72:
              i++;
              _context11.next = 65;
              break;
            case 75:
              this.totalFetched = totalFetched;
              if (!this._finished) {
                _context11.next = 83;
                break;
              }
              response = this.constructResponse(data.done, responseTarget); // only fire response event when it should be notified per fetch
              if (responseTarget !== ResponseTargets.Records) {
                this.emit('response', response, this);
              }
              this.emit('end');
              return _context11.abrupt("return", response);
            case 83:
              return _context11.abrupt("return", this._execute(options));
            case 84:
            case "end":
              return _context11.stop();
          }
        }, _callee2, this, [[19, 53, 56, 59], [24, 43, 46, 49]]);
      }));
      function _execute(_x3) {
        return _execute2.apply(this, arguments);
      }
      return _execute;
    }()
    /**
     * Obtain readable stream instance
     */
    )
  }, {
    key: "stream",
    value: function stream() {
      var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'csv';
      if (!this._finished && !this._executed) {
        this.execute({
          autoFetch: true
        });
      }
      return type === 'record' ? this._stream : this._stream.stream(type);
    }

    /**
     * Pipe the queried records to another stream
     * This is for backward compatibility; Query is not a record stream instance anymore in 2.0.
     * If you want a record stream instance, use `Query#stream('record')`.
     */
  }, {
    key: "pipe",
    value: function pipe(stream) {
      return this.stream('record').pipe(stream);
    }

    /**
     * @protected
     */
  }, {
    key: "_expandFields",
    value: (function () {
      var _expandFields2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4(sobject_) {
        var _context12, _context13, _context14, _context16, _context17;
        var _this$_config, _this$_config$fields, fields, _this$_config$table, table, sobject, _yield$Promise$all, _yield$Promise$all2, efields;
        return _regeneratorRuntime.wrap(function _callee4$(_context18) {
          while (1) switch (_context18.prev = _context18.next) {
            case 0:
              if (!this._soql) {
                _context18.next = 2;
                break;
              }
              throw new Error('Cannot expand fields for the query which has already built SOQL.');
            case 2:
              _this$_config = this._config, _this$_config$fields = _this$_config.fields, fields = _this$_config$fields === void 0 ? [] : _this$_config$fields, _this$_config$table = _this$_config.table, table = _this$_config$table === void 0 ? '' : _this$_config$table;
              sobject = sobject_ || table;
              this._logger.debug(_concatInstanceProperty(_context12 = "_expandFields: sobject = ".concat(sobject, ", fields = ")).call(_context12, fields.join(', ')));
              _context18.next = 7;
              return _Promise.all(_concatInstanceProperty(_context13 = [this._expandAsteriskFields(sobject, fields)]).call(_context13, _toConsumableArray(_mapInstanceProperty(_context14 = this._children).call(_context14, /*#__PURE__*/function () {
                var _ref6 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3(childQuery) {
                  return _regeneratorRuntime.wrap(function _callee3$(_context15) {
                    while (1) switch (_context15.prev = _context15.next) {
                      case 0:
                        _context15.next = 2;
                        return childQuery._expandFields();
                      case 2:
                        return _context15.abrupt("return", []);
                      case 3:
                      case "end":
                        return _context15.stop();
                    }
                  }, _callee3);
                }));
                return function (_x5) {
                  return _ref6.apply(this, arguments);
                };
              }()))));
            case 7:
              _yield$Promise$all = _context18.sent;
              _yield$Promise$all2 = _slicedToArray(_yield$Promise$all, 1);
              efields = _yield$Promise$all2[0];
              this._config.fields = efields;
              this._config.includes = _reduceInstanceProperty(_context16 = _mapInstanceProperty(_context17 = this._children).call(_context17, function (cquery) {
                var cconfig = cquery._query._config;
                return [cconfig.table, cconfig];
              })).call(_context16, function (includes, _ref7) {
                var _ref8 = _slicedToArray(_ref7, 2),
                  ctable = _ref8[0],
                  cconfig = _ref8[1];
                return _objectSpread(_objectSpread({}, includes), {}, _defineProperty({}, ctable, cconfig));
              }, {});
            case 12:
            case "end":
              return _context18.stop();
          }
        }, _callee4, this);
      }));
      function _expandFields(_x4) {
        return _expandFields2.apply(this, arguments);
      }
      return _expandFields;
    }()
    /**
     *
     */
    )
  }, {
    key: "_findRelationObject",
    value: (function () {
      var _findRelationObject2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee5(relName) {
        var _context19;
        var table, sobject, upperRname, _iterator3, _step3, cr;
        return _regeneratorRuntime.wrap(function _callee5$(_context20) {
          while (1) switch (_context20.prev = _context20.next) {
            case 0:
              table = this._config.table;
              if (table) {
                _context20.next = 3;
                break;
              }
              throw new Error('No table information provided in the query');
            case 3:
              this._logger.debug(_concatInstanceProperty(_context19 = "finding table for relation \"".concat(relName, "\" in \"")).call(_context19, table, "\"..."));
              _context20.next = 6;
              return this._conn.describe$(table);
            case 6:
              sobject = _context20.sent;
              upperRname = relName.toUpperCase();
              _iterator3 = _createForOfIteratorHelper(sobject.childRelationships);
              _context20.prev = 9;
              _iterator3.s();
            case 11:
              if ((_step3 = _iterator3.n()).done) {
                _context20.next = 17;
                break;
              }
              cr = _step3.value;
              if (!((cr.relationshipName || '').toUpperCase() === upperRname && cr.childSObject)) {
                _context20.next = 15;
                break;
              }
              return _context20.abrupt("return", cr.childSObject);
            case 15:
              _context20.next = 11;
              break;
            case 17:
              _context20.next = 22;
              break;
            case 19:
              _context20.prev = 19;
              _context20.t0 = _context20["catch"](9);
              _iterator3.e(_context20.t0);
            case 22:
              _context20.prev = 22;
              _iterator3.f();
              return _context20.finish(22);
            case 25:
              throw new Error("No child relationship found: ".concat(relName));
            case 26:
            case "end":
              return _context20.stop();
          }
        }, _callee5, this, [[9, 19, 22, 25]]);
      }));
      function _findRelationObject(_x6) {
        return _findRelationObject2.apply(this, arguments);
      }
      return _findRelationObject;
    }()
    /**
     *
     */
    )
  }, {
    key: "_expandAsteriskFields",
    value: (function () {
      var _expandAsteriskFields2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee7(sobject, fields) {
        var _this3 = this;
        var expandedFields;
        return _regeneratorRuntime.wrap(function _callee7$(_context23) {
          while (1) switch (_context23.prev = _context23.next) {
            case 0:
              _context23.next = 2;
              return _Promise.all(_mapInstanceProperty(fields).call(fields, /*#__PURE__*/function () {
                var _ref9 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee6(field) {
                  return _regeneratorRuntime.wrap(function _callee6$(_context21) {
                    while (1) switch (_context21.prev = _context21.next) {
                      case 0:
                        return _context21.abrupt("return", _this3._expandAsteriskField(sobject, field));
                      case 1:
                      case "end":
                        return _context21.stop();
                    }
                  }, _callee6);
                }));
                return function (_x9) {
                  return _ref9.apply(this, arguments);
                };
              }()));
            case 2:
              expandedFields = _context23.sent;
              return _context23.abrupt("return", _reduceInstanceProperty(expandedFields).call(expandedFields, function (eflds, flds) {
                var _context22;
                return _concatInstanceProperty(_context22 = []).call(_context22, _toConsumableArray(eflds), _toConsumableArray(flds));
              }, []));
            case 4:
            case "end":
              return _context23.stop();
          }
        }, _callee7);
      }));
      function _expandAsteriskFields(_x7, _x8) {
        return _expandAsteriskFields2.apply(this, arguments);
      }
      return _expandAsteriskFields;
    }()
    /**
     *
     */
    )
  }, {
    key: "_expandAsteriskField",
    value: (function () {
      var _expandAsteriskField2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee8(sobject, field) {
        var _context24;
        var fpath, _context26, so, rname, _iterator4, _step4, f, rfield, referenceTo, rtable, fpaths;
        return _regeneratorRuntime.wrap(function _callee8$(_context27) {
          while (1) switch (_context27.prev = _context27.next) {
            case 0:
              this._logger.debug(_concatInstanceProperty(_context24 = "expanding field \"".concat(field, "\" in \"")).call(_context24, sobject, "\"..."));
              fpath = field.split('.');
              if (!(fpath[fpath.length - 1] === '*')) {
                _context27.next = 34;
                break;
              }
              _context27.next = 5;
              return this._conn.describe$(sobject);
            case 5:
              so = _context27.sent;
              this._logger.debug("table ".concat(sobject, " has been described"));
              if (!(fpath.length > 1)) {
                _context27.next = 33;
                break;
              }
              rname = fpath.shift();
              _iterator4 = _createForOfIteratorHelper(so.fields);
              _context27.prev = 10;
              _iterator4.s();
            case 12:
              if ((_step4 = _iterator4.n()).done) {
                _context27.next = 24;
                break;
              }
              f = _step4.value;
              if (!(f.relationshipName && rname && f.relationshipName.toUpperCase() === rname.toUpperCase())) {
                _context27.next = 22;
                break;
              }
              rfield = f;
              referenceTo = rfield.referenceTo || [];
              rtable = referenceTo.length === 1 ? referenceTo[0] : 'Name';
              _context27.next = 20;
              return this._expandAsteriskField(rtable, fpath.join('.'));
            case 20:
              fpaths = _context27.sent;
              return _context27.abrupt("return", _mapInstanceProperty(fpaths).call(fpaths, function (fp) {
                var _context25;
                return _concatInstanceProperty(_context25 = "".concat(rname, ".")).call(_context25, fp);
              }));
            case 22:
              _context27.next = 12;
              break;
            case 24:
              _context27.next = 29;
              break;
            case 26:
              _context27.prev = 26;
              _context27.t0 = _context27["catch"](10);
              _iterator4.e(_context27.t0);
            case 29:
              _context27.prev = 29;
              _iterator4.f();
              return _context27.finish(29);
            case 32:
              return _context27.abrupt("return", []);
            case 33:
              return _context27.abrupt("return", _mapInstanceProperty(_context26 = so.fields).call(_context26, function (f) {
                return f.name;
              }));
            case 34:
              return _context27.abrupt("return", [field]);
            case 35:
            case "end":
              return _context27.stop();
          }
        }, _callee8, this, [[10, 26, 29, 32]]);
      }));
      function _expandAsteriskField(_x10, _x11) {
        return _expandAsteriskField2.apply(this, arguments);
      }
      return _expandAsteriskField;
    }()
    /**
     * Explain plan for executing query
     */
    )
  }, {
    key: "explain",
    value: (function () {
      var _explain = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee9() {
        var soql, url;
        return _regeneratorRuntime.wrap(function _callee9$(_context28) {
          while (1) switch (_context28.prev = _context28.next) {
            case 0:
              _context28.next = 2;
              return this.toSOQL();
            case 2:
              soql = _context28.sent;
              this._logger.debug("SOQL = ".concat(soql));
              url = "/query/?explain=".concat(encodeURIComponent(soql));
              return _context28.abrupt("return", this._conn.request(url));
            case 6:
            case "end":
              return _context28.stop();
          }
        }, _callee9, this);
      }));
      function explain() {
        return _explain.apply(this, arguments);
      }
      return explain;
    }()
    /**
     * Return SOQL expression for the query
     */
    )
  }, {
    key: "toSOQL",
    value: (function () {
      var _toSOQL = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee10() {
        return _regeneratorRuntime.wrap(function _callee10$(_context29) {
          while (1) switch (_context29.prev = _context29.next) {
            case 0:
              if (!this._soql) {
                _context29.next = 2;
                break;
              }
              return _context29.abrupt("return", this._soql);
            case 2:
              _context29.next = 4;
              return this._expandFields();
            case 4:
              return _context29.abrupt("return", createSOQL(this._config));
            case 5:
            case "end":
              return _context29.stop();
          }
        }, _callee10, this);
      }));
      function toSOQL() {
        return _toSOQL.apply(this, arguments);
      }
      return toSOQL;
    }()
    /**
     * Promise/A+ interface
     * http://promises-aplus.github.io/promises-spec/
     *
     * Delegate to deferred promise, return promise instance for query result
     */
    )
  }, {
    key: "then",
    value: function then(onResolve, onReject) {
      this._chaining = true;
      if (!this._finished && !this._executed) {
        this.execute();
      }
      if (!this._promise) {
        throw new Error('invalid state: promise is not set after query execution');
      }
      return this._promise.then(onResolve, onReject);
    }
  }, {
    key: "catch",
    value: function _catch(onReject) {
      return this.then(null, onReject);
    }
  }, {
    key: "promise",
    value: function promise() {
      // TODO(cristian): verify this is correct
      return _Promise.resolve(this);
    }

    /**
     * Bulk delete queried records
     */
  }, {
    key: "destroy",
    value: function destroy(type, options) {
      var _options$bulkApiVersi,
        _this4 = this;
      if (_typeof(type) === 'object' && type !== null) {
        options = type;
        type = undefined;
      }
      options = options || {};
      var type_ = type || this._config.table;
      if (!type_) {
        throw new Error('SOQL based query needs SObject type information to bulk delete.');
      }
      // Set the threshold number to pass to bulk API
      var thresholdNum = options.allowBulk === false ? -1 : typeof options.bulkThreshold === 'number' ? options.bulkThreshold :
      // determine threshold if the connection version supports SObject collection API or not
      this._conn._ensureVersion(42) ? DEFAULT_BULK_THRESHOLD : this._conn._maxRequest / 2;
      var bulkApiVersion = (_options$bulkApiVersi = options.bulkApiVersion) !== null && _options$bulkApiVersi !== void 0 ? _options$bulkApiVersi : DEFAULT_BULK_API_VERSION;
      return new _Promise(function (resolve, reject) {
        var createBatch = function createBatch() {
          return _this4._conn.sobject(type_).deleteBulk().on('response', resolve).on('error', reject);
        };
        var records = [];
        var batch = null;
        var handleRecord = function handleRecord(rec) {
          if (!rec.Id) {
            var err = new Error('Queried record does not include Salesforce record ID.');
            _this4.emit('error', err);
            return;
          }
          var record = {
            Id: rec.Id
          };
          if (batch) {
            batch.write(record);
          } else {
            records.push(record);
            if (thresholdNum >= 0 && records.length > thresholdNum && bulkApiVersion === 1) {
              // Use bulk delete instead of SObject REST API
              batch = createBatch();
              for (var _i2 = 0, _records = records; _i2 < _records.length; _i2++) {
                var _record2 = _records[_i2];
                batch.write(_record2);
              }
              records = [];
            }
          }
        };
        var handleEnd = function handleEnd() {
          if (batch) {
            batch.end();
          } else {
            var ids = _mapInstanceProperty(records).call(records, function (record) {
              return record.Id;
            });
            if (records.length > thresholdNum && bulkApiVersion === 2) {
              _this4._conn.bulk2.loadAndWaitForResults({
                object: type_,
                operation: 'delete',
                input: records
              }).then(function (allResults) {
                return resolve(_this4.mapBulkV2ResultsToSaveResults(allResults));
              }, reject);
            } else {
              _this4._conn.sobject(type_).destroy(ids, {
                allowRecursive: true
              }).then(resolve, reject);
            }
          }
        };
        _this4.stream('record').on('data', handleRecord).on('end', handleEnd).on('error', reject);
      });
    }
  }, {
    key: "update",
    value: function update(mapping, type, options) {
      var _options$bulkApiVersi2,
        _this5 = this;
      if (_typeof(type) === 'object' && type !== null) {
        options = type;
        type = undefined;
      }
      options = options || {};
      var type_ = type || this._config && this._config.table;
      if (!type_) {
        throw new Error('SOQL based query needs SObject type information to bulk update.');
      }
      var updateStream = typeof mapping === 'function' ? _mapInstanceProperty(RecordStream).call(RecordStream, mapping) : RecordStream.recordMapStream(mapping, options.skipRecordTemplateEval);
      // Set the threshold number to pass to bulk API
      var thresholdNum = options.allowBulk === false ? -1 : typeof options.bulkThreshold === 'number' ? options.bulkThreshold :
      // determine threshold if the connection version supports SObject collection API or not
      this._conn._ensureVersion(42) ? DEFAULT_BULK_THRESHOLD : this._conn._maxRequest / 2;
      var bulkApiVersion = (_options$bulkApiVersi2 = options.bulkApiVersion) !== null && _options$bulkApiVersi2 !== void 0 ? _options$bulkApiVersi2 : DEFAULT_BULK_API_VERSION;
      return new _Promise(function (resolve, reject) {
        var createBatch = function createBatch() {
          return _this5._conn.sobject(type_).updateBulk().on('response', resolve).on('error', reject);
        };
        var records = [];
        var batch = null;
        var handleRecord = function handleRecord(record) {
          if (batch) {
            batch.write(record);
          } else {
            records.push(record);
          }
          if (thresholdNum >= 0 && records.length > thresholdNum && bulkApiVersion === 1) {
            // Use bulk update instead of SObject REST API
            batch = createBatch();
            for (var _i3 = 0, _records2 = records; _i3 < _records2.length; _i3++) {
              var _record3 = _records2[_i3];
              batch.write(_record3);
            }
            records = [];
          }
        };
        var handleEnd = function handleEnd() {
          if (batch) {
            batch.end();
          } else {
            if (records.length > thresholdNum && bulkApiVersion === 2) {
              _this5._conn.bulk2.loadAndWaitForResults({
                object: type_,
                operation: 'update',
                input: records
              }).then(function (allResults) {
                return resolve(_this5.mapBulkV2ResultsToSaveResults(allResults));
              }, reject);
            } else {
              _this5._conn.sobject(type_).update(records, {
                allowRecursive: true
              }).then(resolve, reject);
            }
          }
        };
        _this5.stream('record').on('error', reject).pipe(updateStream).on('data', handleRecord).on('end', handleEnd).on('error', reject);
      });
    }
  }, {
    key: "mapBulkV2ResultsToSaveResults",
    value: function mapBulkV2ResultsToSaveResults(bulkJobAllResults) {
      var _context30, _context31, _context32;
      var successSaveResults = _mapInstanceProperty(_context30 = bulkJobAllResults.successfulResults).call(_context30, function (r) {
        var saveResult = {
          id: r.sf__Id,
          success: true,
          errors: []
        };
        return saveResult;
      });
      var failedSaveResults = _mapInstanceProperty(_context31 = bulkJobAllResults.failedResults).call(_context31, function (r) {
        var saveResult = {
          success: false,
          errors: [{
            errorCode: r.sf__Error,
            message: r.sf__Error
          }]
        };
        return saveResult;
      });
      return _concatInstanceProperty(_context32 = []).call(_context32, _toConsumableArray(successSaveResults), _toConsumableArray(failedSaveResults));
    }

    /**
     * Fetches all records for a subquery field by following nextRecordsUrl
     * @private
     */
  }, {
    key: "_fetchAllSubqueryRecords",
    value: (function () {
      var _fetchAllSubqueryRecords2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee11(record, fieldName, headers) {
        var subqueryField, allRecords, nextRecordsUrl, data;
        return _regeneratorRuntime.wrap(function _callee11$(_context33) {
          while (1) switch (_context33.prev = _context33.next) {
            case 0:
              subqueryField = record[fieldName];
              if (!(!subqueryField || !subqueryField.records)) {
                _context33.next = 3;
                break;
              }
              return _context33.abrupt("return", []);
            case 3:
              allRecords = _toConsumableArray(subqueryField.records);
              nextRecordsUrl = subqueryField.nextRecordsUrl;
            case 5:
              if (!nextRecordsUrl) {
                _context33.next = 13;
                break;
              }
              _context33.next = 8;
              return this._conn.request({
                method: 'GET',
                url: nextRecordsUrl,
                // Use the full URL as provided by Salesforce
                headers: headers
              });
            case 8:
              data = _context33.sent;
              allRecords = _concatInstanceProperty(allRecords).call(allRecords, data.records);
              nextRecordsUrl = data.nextRecordsUrl;
              _context33.next = 5;
              break;
            case 13:
              return _context33.abrupt("return", allRecords);
            case 14:
            case "end":
              return _context33.stop();
          }
        }, _callee11, this);
      }));
      function _fetchAllSubqueryRecords(_x12, _x13, _x14) {
        return _fetchAllSubqueryRecords2.apply(this, arguments);
      }
      return _fetchAllSubqueryRecords;
    }())
  }]);
}(EventEmitter);

/*--------------------------------------------*/

/**
 * SubQuery object for representing child relationship query
 */
_defineProperty(Query, "_logger", getLogger('query'));
export var SubQuery = /*#__PURE__*/function () {
  /**
   *
   */
  function SubQuery(conn, relName, config, parent) {
    _classCallCheck(this, SubQuery);
    /**
     * Synonym of SubQuery#skip()
     */
    _defineProperty(this, "offset", this.skip);
    /**
     * Synonym of SubQuery#sort()
     */
    _defineProperty(this, "orderby", _sortInstanceProperty(this));
    this._relName = relName;
    this._query = new Query(conn, config);
    this._parent = parent;
  }

  /**
   *
   */
  return _createClass(SubQuery, [{
    key: "select",
    value: function select(fields) {
      // force convert query record type without changing instance
      this._query = this._query.select(fields);
      return this;
    }

    /**
     *
     */
  }, {
    key: "where",
    value: function where(conditions) {
      this._query = this._query.where(conditions);
      return this;
    }

    /**
     * Limit the returning result
     */
  }, {
    key: "limit",
    value: function limit(_limit2) {
      this._query = this._query.limit(_limit2);
      return this;
    }

    /**
     * Skip records
     */
  }, {
    key: "skip",
    value: function skip(offset) {
      this._query = this._query.skip(offset);
      return this;
    }
  }, {
    key: "sort",
    value: function (_sort3) {
      function sort(_x15, _x16) {
        return _sort3.apply(this, arguments);
      }
      sort.toString = function () {
        return _sort3.toString();
      };
      return sort;
    }(function (sort, dir) {
      var _context34;
      this._query = _sortInstanceProperty(_context34 = this._query).call(_context34, sort, dir);
      return this;
    })
  }, {
    key: "_expandFields",
    value: (
    /**
     *
     */
    function () {
      var _expandFields3 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee12() {
        var sobject;
        return _regeneratorRuntime.wrap(function _callee12$(_context35) {
          while (1) switch (_context35.prev = _context35.next) {
            case 0:
              _context35.next = 2;
              return this._parent._findRelationObject(this._relName);
            case 2:
              sobject = _context35.sent;
              return _context35.abrupt("return", this._query._expandFields(sobject));
            case 4:
            case "end":
              return _context35.stop();
          }
        }, _callee12, this);
      }));
      function _expandFields() {
        return _expandFields3.apply(this, arguments);
      }
      return _expandFields;
    }()
    /**
     * Back the context to parent query object
     */
    )
  }, {
    key: "end",
    value: function end() {
      return this._parent;
    }
  }]);
}();
export default Query;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJnZXRMb2dnZXIiLCJSZWNvcmRTdHJlYW0iLCJTZXJpYWxpemFibGUiLCJjcmVhdGVTT1FMIiwiUmVzcG9uc2VUYXJnZXRWYWx1ZXMiLCJSZXNwb25zZVRhcmdldHMiLCJfcmVkdWNlSW5zdGFuY2VQcm9wZXJ0eSIsImNhbGwiLCJ2YWx1ZXMiLCJ0YXJnZXQiLCJfb2JqZWN0U3ByZWFkIiwiX2RlZmluZVByb3BlcnR5IiwiREVGQVVMVF9CVUxLX1RIUkVTSE9MRCIsIkRFRkFVTFRfQlVMS19BUElfVkVSU0lPTiIsIlF1ZXJ5IiwiX0V2ZW50RW1pdHRlciIsImNvbm4iLCJjb25maWciLCJvcHRpb25zIiwiX3RoaXMiLCJfY2xhc3NDYWxsQ2hlY2siLCJfY2FsbFN1cGVyIiwic2tpcCIsIl9zb3J0SW5zdGFuY2VQcm9wZXJ0eSIsImV4ZWN1dGUiLCJkZXN0cm95IiwiX2Nvbm4iLCJfbG9nZ2VyIiwiX2xvZ0xldmVsIiwiY3JlYXRlSW5zdGFuY2UiLCJfc29xbCIsImRlYnVnIiwiY29uY2F0IiwibG9jYXRvciIsIl9sb2NhdG9yIiwiX2luY2x1ZGVzSW5zdGFuY2VQcm9wZXJ0eSIsInVybFRvTG9jYXRvciIsIl9KU09OJHN0cmluZ2lmeSIsIl9yZWYiLCJmaWVsZHMiLCJpbmNsdWRlcyIsInNvcnQiLCJfY29uZmlnIiwiX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzIiwiX2V4Y2x1ZGVkIiwic2VsZWN0IiwiaW5jbHVkZUNoaWxkcmVuIiwiX29wdGlvbnMiLCJoZWFkZXJzIiwibWF4RmV0Y2giLCJhdXRvRmV0Y2giLCJzY2FuQWxsIiwicmVzcG9uc2VUYXJnZXQiLCJfcHJvbWlzZSIsIl9Qcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsIm9uIiwiX3N0cmVhbSIsInJlY29yZCIsInB1c2giLCJlcnIiLCJlbWl0IiwiZSIsIl9pbmhlcml0cyIsIl9jcmVhdGVDbGFzcyIsImtleSIsInZhbHVlIiwiYXJndW1lbnRzIiwibGVuZ3RoIiwidW5kZWZpbmVkIiwiRXJyb3IiLCJ0b0ZpZWxkQXJyYXkiLCJfY29udGV4dCIsIl9jb250ZXh0MiIsIl9jb250ZXh0NCIsIl9jb250ZXh0NSIsInNwbGl0IiwiX0FycmF5JGlzQXJyYXkiLCJfbWFwSW5zdGFuY2VQcm9wZXJ0eSIsImZzIiwiZiIsIl9jb250ZXh0MyIsIl9jb25jYXRJbnN0YW5jZVByb3BlcnR5IiwiX3RvQ29uc3VtYWJsZUFycmF5IiwiX09iamVjdCRlbnRyaWVzIiwiX3JlZjIiLCJfcmVmMyIsIl9zbGljZWRUb0FycmF5IiwidiIsIl9jb250ZXh0NiIsInAiLCJfY29udGV4dDciLCJfY29udGV4dDgiLCJ3aGVyZSIsImNvbmRpdGlvbnMiLCJsaW1pdCIsIm9mZnNldCIsIl9zb3J0IiwiX3giLCJfeDIiLCJhcHBseSIsInRvU3RyaW5nIiwiZGlyIiwiaW5jbHVkZSIsImNoaWxkUmVsTmFtZSIsImNoaWxkQ29uZmlnIiwidGFibGUiLCJjaGlsZFF1ZXJ5IiwiU3ViUXVlcnkiLCJfY2hpbGRyZW4iLCJfaSIsIl9hcnIiLCJfT2JqZWN0JGtleXMiLCJjcm5hbWUiLCJfcmVmNCIsIl9leGNsdWRlZDIiLCJzZXRSZXNwb25zZVRhcmdldCIsIl90aGlzMiIsIm9wdGlvbnNfIiwiX2V4ZWN1dGVkIiwiX2ZpbmlzaGVkIiwib25jZSIsIlJlY29yZHMiLCJfY2hhaW5pbmciLCJyZWNvcmRzIiwib25SZWNvcmQiLCJyZW1vdmVMaXN0ZW5lciIsIl9hc3luY1RvR2VuZXJhdG9yIiwiX3JlZ2VuZXJhdG9yUnVudGltZSIsIm1hcmsiLCJfY2FsbGVlIiwid3JhcCIsIl9jYWxsZWUkIiwiX2NvbnRleHQ5IiwicHJldiIsIm5leHQiLCJfZXhlY3V0ZSIsInQwIiwic3RvcCIsImxvY2F0b3JUb1VybCIsIl9iYXNlVXJsIiwiam9pbiIsInVybCIsInBvcCIsImNvbnN0cnVjdFJlc3BvbnNlIiwicmF3RG9uZSIsIl90aGlzJHJlY29yZHMkIiwiX3RoaXMkcmVjb3JkcyIsInRvdGFsU2l6ZSIsImRvbmUiLCJuZXh0UmVjb3Jkc1VybCIsIl9leGVjdXRlMiIsIl9jYWxsZWUyIiwiX3RoaXMkcmVjb3JkczIiLCJfY29udGV4dDEwIiwiX2RhdGEkcmVjb3JkcyRsZW5ndGgiLCJfZGF0YSRyZWNvcmRzIiwic29xbCIsImRhdGEiLCJyZWNvcmRLZXlzIiwiX2l0ZXJhdG9yIiwiX3N0ZXAiLCJfaXRlcmF0b3IyIiwiX3N0ZXAyIiwiX2ZpZWxkIiwibnVtUmVjb3JkcyIsInRvdGFsRmV0Y2hlZCIsImkiLCJfcmVjb3JkIiwicmVzcG9uc2UiLCJfY2FsbGVlMiQiLCJfY29udGV4dDExIiwidG9TT1FMIiwic2VudCIsImVuY29kZVVSSUNvbXBvbmVudCIsInJlcXVlc3QiLCJtZXRob2QiLCJfY3JlYXRlRm9yT2ZJdGVyYXRvckhlbHBlciIsInMiLCJuIiwiZmllbGQiLCJfdHlwZW9mIiwidDEiLCJ0MiIsIl9mZXRjaEFsbFN1YnF1ZXJ5UmVjb3JkcyIsInQzIiwidDQiLCJ0NSIsInQ2IiwiZmluaXNoIiwidDciLCJfc2xpY2VJbnN0YW5jZVByb3BlcnR5IiwiYWJydXB0IiwiX3gzIiwic3RyZWFtIiwidHlwZSIsInBpcGUiLCJfZXhwYW5kRmllbGRzMiIsIl9jYWxsZWU0Iiwic29iamVjdF8iLCJfY29udGV4dDEyIiwiX2NvbnRleHQxMyIsIl9jb250ZXh0MTQiLCJfY29udGV4dDE2IiwiX2NvbnRleHQxNyIsIl90aGlzJF9jb25maWciLCJfdGhpcyRfY29uZmlnJGZpZWxkcyIsIl90aGlzJF9jb25maWckdGFibGUiLCJzb2JqZWN0IiwiX3lpZWxkJFByb21pc2UkYWxsIiwiX3lpZWxkJFByb21pc2UkYWxsMiIsImVmaWVsZHMiLCJfY2FsbGVlNCQiLCJfY29udGV4dDE4IiwiYWxsIiwiX2V4cGFuZEFzdGVyaXNrRmllbGRzIiwiX3JlZjYiLCJfY2FsbGVlMyIsIl9jYWxsZWUzJCIsIl9jb250ZXh0MTUiLCJfZXhwYW5kRmllbGRzIiwiX3g1IiwiY3F1ZXJ5IiwiY2NvbmZpZyIsIl9xdWVyeSIsIl9yZWY3IiwiX3JlZjgiLCJjdGFibGUiLCJfeDQiLCJfZmluZFJlbGF0aW9uT2JqZWN0MiIsIl9jYWxsZWU1IiwicmVsTmFtZSIsIl9jb250ZXh0MTkiLCJ1cHBlclJuYW1lIiwiX2l0ZXJhdG9yMyIsIl9zdGVwMyIsImNyIiwiX2NhbGxlZTUkIiwiX2NvbnRleHQyMCIsImRlc2NyaWJlJCIsInRvVXBwZXJDYXNlIiwiY2hpbGRSZWxhdGlvbnNoaXBzIiwicmVsYXRpb25zaGlwTmFtZSIsImNoaWxkU09iamVjdCIsIl9maW5kUmVsYXRpb25PYmplY3QiLCJfeDYiLCJfZXhwYW5kQXN0ZXJpc2tGaWVsZHMyIiwiX2NhbGxlZTciLCJfdGhpczMiLCJleHBhbmRlZEZpZWxkcyIsIl9jYWxsZWU3JCIsIl9jb250ZXh0MjMiLCJfcmVmOSIsIl9jYWxsZWU2IiwiX2NhbGxlZTYkIiwiX2NvbnRleHQyMSIsIl9leHBhbmRBc3Rlcmlza0ZpZWxkIiwiX3g5IiwiZWZsZHMiLCJmbGRzIiwiX2NvbnRleHQyMiIsIl94NyIsIl94OCIsIl9leHBhbmRBc3Rlcmlza0ZpZWxkMiIsIl9jYWxsZWU4IiwiX2NvbnRleHQyNCIsImZwYXRoIiwiX2NvbnRleHQyNiIsInNvIiwicm5hbWUiLCJfaXRlcmF0b3I0IiwiX3N0ZXA0IiwicmZpZWxkIiwicmVmZXJlbmNlVG8iLCJydGFibGUiLCJmcGF0aHMiLCJfY2FsbGVlOCQiLCJfY29udGV4dDI3Iiwic2hpZnQiLCJmcCIsIl9jb250ZXh0MjUiLCJuYW1lIiwiX3gxMCIsIl94MTEiLCJfZXhwbGFpbiIsIl9jYWxsZWU5IiwiX2NhbGxlZTkkIiwiX2NvbnRleHQyOCIsImV4cGxhaW4iLCJfdG9TT1FMIiwiX2NhbGxlZTEwIiwiX2NhbGxlZTEwJCIsIl9jb250ZXh0MjkiLCJ0aGVuIiwib25SZXNvbHZlIiwib25SZWplY3QiLCJjYXRjaCIsInByb21pc2UiLCJfb3B0aW9ucyRidWxrQXBpVmVyc2kiLCJfdGhpczQiLCJ0eXBlXyIsInRocmVzaG9sZE51bSIsImFsbG93QnVsayIsImJ1bGtUaHJlc2hvbGQiLCJfZW5zdXJlVmVyc2lvbiIsIl9tYXhSZXF1ZXN0IiwiYnVsa0FwaVZlcnNpb24iLCJjcmVhdGVCYXRjaCIsImRlbGV0ZUJ1bGsiLCJiYXRjaCIsImhhbmRsZVJlY29yZCIsInJlYyIsIklkIiwid3JpdGUiLCJfaTIiLCJfcmVjb3JkcyIsImhhbmRsZUVuZCIsImVuZCIsImlkcyIsImJ1bGsyIiwibG9hZEFuZFdhaXRGb3JSZXN1bHRzIiwib2JqZWN0Iiwib3BlcmF0aW9uIiwiaW5wdXQiLCJhbGxSZXN1bHRzIiwibWFwQnVsa1YyUmVzdWx0c1RvU2F2ZVJlc3VsdHMiLCJhbGxvd1JlY3Vyc2l2ZSIsInVwZGF0ZSIsIm1hcHBpbmciLCJfb3B0aW9ucyRidWxrQXBpVmVyc2kyIiwiX3RoaXM1IiwidXBkYXRlU3RyZWFtIiwicmVjb3JkTWFwU3RyZWFtIiwic2tpcFJlY29yZFRlbXBsYXRlRXZhbCIsInVwZGF0ZUJ1bGsiLCJfaTMiLCJfcmVjb3JkczIiLCJidWxrSm9iQWxsUmVzdWx0cyIsIl9jb250ZXh0MzAiLCJfY29udGV4dDMxIiwiX2NvbnRleHQzMiIsInN1Y2Nlc3NTYXZlUmVzdWx0cyIsInN1Y2Nlc3NmdWxSZXN1bHRzIiwiciIsInNhdmVSZXN1bHQiLCJpZCIsInNmX19JZCIsInN1Y2Nlc3MiLCJlcnJvcnMiLCJmYWlsZWRTYXZlUmVzdWx0cyIsImZhaWxlZFJlc3VsdHMiLCJlcnJvckNvZGUiLCJzZl9fRXJyb3IiLCJtZXNzYWdlIiwiX2ZldGNoQWxsU3VicXVlcnlSZWNvcmRzMiIsIl9jYWxsZWUxMSIsImZpZWxkTmFtZSIsInN1YnF1ZXJ5RmllbGQiLCJhbGxSZWNvcmRzIiwiX2NhbGxlZTExJCIsIl9jb250ZXh0MzMiLCJfeDEyIiwiX3gxMyIsIl94MTQiLCJwYXJlbnQiLCJfcmVsTmFtZSIsIl9wYXJlbnQiLCJfc29ydDMiLCJfeDE1IiwiX3gxNiIsIl9jb250ZXh0MzQiLCJfZXhwYW5kRmllbGRzMyIsIl9jYWxsZWUxMiIsIl9jYWxsZWUxMiQiLCJfY29udGV4dDM1Il0sInNvdXJjZXMiOlsiLi4vc3JjL3F1ZXJ5LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgTWFuYWdlcyBxdWVyeSBmb3IgcmVjb3JkcyBpbiBTYWxlc2ZvcmNlXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJztcbmltcG9ydCB7IExvZ2dlciwgZ2V0TG9nZ2VyIH0gZnJvbSAnLi91dGlsL2xvZ2dlcic7XG5pbXBvcnQgUmVjb3JkU3RyZWFtLCB7IFNlcmlhbGl6YWJsZSB9IGZyb20gJy4vcmVjb3JkLXN0cmVhbSc7XG5pbXBvcnQgQ29ubmVjdGlvbiBmcm9tICcuL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHsgY3JlYXRlU09RTCB9IGZyb20gJy4vc29xbC1idWlsZGVyJztcbmltcG9ydCB7IFF1ZXJ5Q29uZmlnIGFzIFNPUUxRdWVyeUNvbmZpZywgU29ydERpciB9IGZyb20gJy4vc29xbC1idWlsZGVyJztcbmltcG9ydCB7XG4gIFJlY29yZCxcbiAgT3B0aW9uYWwsXG4gIFNjaGVtYSxcbiAgU09iamVjdE5hbWVzLFxuICBDaGlsZFJlbGF0aW9uc2hpcE5hbWVzLFxuICBDaGlsZFJlbGF0aW9uc2hpcFNPYmplY3ROYW1lLFxuICBGaWVsZFByb2plY3Rpb25Db25maWcsXG4gIEZpZWxkUGF0aFNwZWNpZmllcixcbiAgRmllbGRQYXRoU2NvcGVkUHJvamVjdGlvbixcbiAgU09iamVjdFJlY29yZCxcbiAgU09iamVjdElucHV0UmVjb3JkLFxuICBTT2JqZWN0VXBkYXRlUmVjb3JkLFxuICBTYXZlUmVzdWx0LFxuICBEYXRlU3RyaW5nLFxuICBTT2JqZWN0Q2hpbGRSZWxhdGlvbnNoaXBQcm9wLFxuICBTT2JqZWN0RmllbGROYW1lcyxcbn0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBSZWFkYWJsZSB9IGZyb20gJ3N0cmVhbSc7XG5pbXBvcnQgU2ZEYXRlIGZyb20gJy4vZGF0ZSc7XG5pbXBvcnQgeyBJbmdlc3RKb2JWMlJlc3VsdHMgfSBmcm9tICcuL2FwaS9idWxrMic7XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IHR5cGUgUXVlcnlGaWVsZDxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgRlAgZXh0ZW5kcyBGaWVsZFBhdGhTcGVjaWZpZXI8UywgTj4gPSBGaWVsZFBhdGhTcGVjaWZpZXI8UywgTj5cbj4gPSBGUCB8IEZQW10gfCBzdHJpbmcgfCBzdHJpbmdbXSB8IHsgW2ZpZWxkOiBzdHJpbmddOiBudW1iZXIgfCBib29sZWFuIH07XG5cbi8qKlxuICpcbiAqL1xudHlwZSBDVmFsdWU8VD4gPSBUIGV4dGVuZHMgRGF0ZVN0cmluZ1xuICA/IFNmRGF0ZVxuICA6IFQgZXh0ZW5kcyBzdHJpbmcgfCBudW1iZXIgfCBib29sZWFuXG4gID8gVFxuICA6IG5ldmVyO1xuXG50eXBlIENvbmRPcDxUPiA9XG4gIHwgWyckZXEnLCBDVmFsdWU8VD4gfCBudWxsXVxuICB8IFsnJG5lJywgQ1ZhbHVlPFQ+IHwgbnVsbF1cbiAgfCBbJyRndCcsIENWYWx1ZTxUPl1cbiAgfCBbJyRndGUnLCBDVmFsdWU8VD5dXG4gIHwgWyckbHQnLCBDVmFsdWU8VD5dXG4gIHwgWyckbHRlJywgQ1ZhbHVlPFQ+XVxuICB8IFsnJGxpa2UnLCBUIGV4dGVuZHMgc3RyaW5nID8gVCA6IG5ldmVyXVxuICB8IFsnJG5saWtlJywgVCBleHRlbmRzIHN0cmluZyA/IFQgOiBuZXZlcl1cbiAgfCBbJyRpbicsIEFycmF5PENWYWx1ZTxUPj5dXG4gIHwgWyckbmluJywgQXJyYXk8Q1ZhbHVlPFQ+Pl1cbiAgfCBbJyRpbmNsdWRlcycsIFQgZXh0ZW5kcyBzdHJpbmcgPyBUW10gOiBuZXZlcl1cbiAgfCBbJyRleGNsdWRlcycsIFQgZXh0ZW5kcyBzdHJpbmcgPyBUW10gOiBuZXZlcl1cbiAgfCBbJyRleGlzdHMnLCBib29sZWFuXTtcblxudHlwZSBDb25kVmFsdWVPYmo8VCwgT3AgPSBDb25kT3A8VD5bMF0+ID0gT3AgZXh0ZW5kcyBDb25kT3A8VD5bMF1cbiAgPyBPcCBleHRlbmRzIHN0cmluZ1xuICAgID8geyBbSyBpbiBPcF06IEV4dHJhY3Q8Q29uZE9wPFQ+LCBbT3AsIGFueV0+WzFdIH1cbiAgICA6IG5ldmVyXG4gIDogbmV2ZXI7XG5cbnR5cGUgQ29uZFZhbHVlPFQ+ID0gQ1ZhbHVlPFQ+IHwgQXJyYXk8Q1ZhbHVlPFQ+PiB8IG51bGwgfCBDb25kVmFsdWVPYmo8VD47XG5cbnR5cGUgQ29uZGl0aW9uU2V0PFIgZXh0ZW5kcyBSZWNvcmQ+ID0ge1xuICBbSyBpbiBrZXlvZiBSXT86IENvbmRWYWx1ZTxSW0tdPjtcbn07XG5cbmV4cG9ydCB0eXBlIFF1ZXJ5Q29uZGl0aW9uPFMgZXh0ZW5kcyBTY2hlbWEsIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4+ID1cbiAgfCB7XG4gICAgICAkb3I6IEFycmF5PFF1ZXJ5Q29uZGl0aW9uPFMsIE4+PjtcbiAgICB9XG4gIHwge1xuICAgICAgJGFuZDogQXJyYXk8UXVlcnlDb25kaXRpb248UywgTj4+O1xuICAgIH1cbiAgfCBDb25kaXRpb25TZXQ8U09iamVjdFJlY29yZDxTLCBOPj47XG5cbmV4cG9ydCB0eXBlIFF1ZXJ5U29ydDxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgUiBleHRlbmRzIFNPYmplY3RSZWNvcmQ8UywgTj4gPSBTT2JqZWN0UmVjb3JkPFMsIE4+XG4+ID1cbiAgfCB7XG4gICAgICBbSyBpbiBrZXlvZiBSXT86IFNvcnREaXI7XG4gICAgfVxuICB8IEFycmF5PFtrZXlvZiBSLCBTb3J0RGlyXT47XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IHR5cGUgUXVlcnlDb25maWc8XG4gIFMgZXh0ZW5kcyBTY2hlbWEsXG4gIE4gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gIEZQIGV4dGVuZHMgRmllbGRQYXRoU3BlY2lmaWVyPFMsIE4+ID0gRmllbGRQYXRoU3BlY2lmaWVyPFMsIE4+XG4+ID0ge1xuICBmaWVsZHM/OiBRdWVyeUZpZWxkPFMsIE4sIEZQPjtcbiAgaW5jbHVkZXM/OiB7XG4gICAgW0NSTiBpbiBDaGlsZFJlbGF0aW9uc2hpcE5hbWVzPFMsIE4+XT86IFF1ZXJ5Q29uZmlnPFxuICAgICAgUyxcbiAgICAgIENoaWxkUmVsYXRpb25zaGlwU09iamVjdE5hbWU8UywgTiwgQ1JOPlxuICAgID47XG4gIH07XG4gIHRhYmxlPzogc3RyaW5nO1xuICBjb25kaXRpb25zPzogUXVlcnlDb25kaXRpb248UywgTj47XG4gIHNvcnQ/OiBRdWVyeVNvcnQ8UywgTj47XG4gIGxpbWl0PzogbnVtYmVyO1xuICBvZmZzZXQ/OiBudW1iZXI7XG59O1xuXG5leHBvcnQgdHlwZSBRdWVyeU9wdGlvbnMgPSB7XG4gIGhlYWRlcnM6IHsgW25hbWU6IHN0cmluZ106IHN0cmluZyB9O1xuICBtYXhGZXRjaDogbnVtYmVyO1xuICBhdXRvRmV0Y2g6IGJvb2xlYW47XG4gIHNjYW5BbGw6IGJvb2xlYW47XG4gIHJlc3BvbnNlVGFyZ2V0OiBRdWVyeVJlc3BvbnNlVGFyZ2V0O1xufTtcblxuZXhwb3J0IHR5cGUgUXVlcnlSZXN1bHQ8UiBleHRlbmRzIFJlY29yZD4gPSB7XG4gIGRvbmU6IGJvb2xlYW47XG4gIHRvdGFsU2l6ZTogbnVtYmVyO1xuICByZWNvcmRzOiBSW107XG4gIG5leHRSZWNvcmRzVXJsPzogc3RyaW5nO1xufTtcblxuZXhwb3J0IHR5cGUgUXVlcnlFeHBsYWluUmVzdWx0ID0ge1xuICBwbGFuczogQXJyYXk8e1xuICAgIGNhcmRpbmFsaXR5OiBudW1iZXI7XG4gICAgZmllbGRzOiBzdHJpbmdbXTtcbiAgICBsZWFkaW5nT3BlcmF0aW9uVHlwZTogJ0luZGV4JyB8ICdPdGhlcicgfCAnU2hhcmluZycgfCAnVGFibGVTY2FuJztcbiAgICBub3RlczogQXJyYXk8e1xuICAgICAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgICAgIGZpZWxkczogc3RyaW5nW107XG4gICAgICB0YWJsZUVudW1PcklkOiBzdHJpbmc7XG4gICAgfT47XG4gICAgcmVsYXRpdmVDb3N0OiBudW1iZXI7XG4gICAgc29iamVjdENhcmRpbmFsaXR5OiBudW1iZXI7XG4gICAgc29iamVjdFR5cGU6IHN0cmluZztcbiAgfT47XG59O1xuXG5jb25zdCBSZXNwb25zZVRhcmdldFZhbHVlcyA9IFtcbiAgJ1F1ZXJ5UmVzdWx0JyxcbiAgJ1JlY29yZHMnLFxuICAnU2luZ2xlUmVjb3JkJyxcbiAgJ0NvdW50Jyxcbl0gYXMgY29uc3Q7XG5cbmV4cG9ydCB0eXBlIFF1ZXJ5UmVzcG9uc2VUYXJnZXQgPSB0eXBlb2YgUmVzcG9uc2VUYXJnZXRWYWx1ZXNbbnVtYmVyXTtcblxuZXhwb3J0IGNvbnN0IFJlc3BvbnNlVGFyZ2V0czoge1xuICBbSyBpbiBRdWVyeVJlc3BvbnNlVGFyZ2V0XTogSztcbn0gPSBSZXNwb25zZVRhcmdldFZhbHVlcy5yZWR1Y2UoXG4gICh2YWx1ZXMsIHRhcmdldCkgPT4gKHsgLi4udmFsdWVzLCBbdGFyZ2V0XTogdGFyZ2V0IH0pLFxuICB7fSBhcyB7XG4gICAgW0sgaW4gUXVlcnlSZXNwb25zZVRhcmdldF06IEs7XG4gIH0sXG4pO1xuXG5leHBvcnQgdHlwZSBRdWVyeVJlc3BvbnNlPFxuICBSIGV4dGVuZHMgUmVjb3JkLFxuICBRUlQgZXh0ZW5kcyBRdWVyeVJlc3BvbnNlVGFyZ2V0ID0gUXVlcnlSZXNwb25zZVRhcmdldFxuPiA9IFFSVCBleHRlbmRzICdRdWVyeVJlc3VsdCdcbiAgPyBRdWVyeVJlc3VsdDxSPlxuICA6IFFSVCBleHRlbmRzICdSZWNvcmRzJ1xuICA/IFJbXVxuICA6IFFSVCBleHRlbmRzICdTaW5nbGVSZWNvcmQnXG4gID8gUiB8IG51bGxcbiAgOiBudW1iZXI7IC8vIFFSVCBleHRlbmRzICdDb3VudCdcblxuZXhwb3J0IHR5cGUgQnVsa0FwaVZlcnNpb24gPSAxIHwgMjtcblxuZXhwb3J0IHR5cGUgUXVlcnlEZXN0cm95T3B0aW9ucyA9IHtcbiAgYWxsb3dCdWxrPzogYm9vbGVhbjtcbiAgYnVsa1RocmVzaG9sZD86IG51bWJlcjtcbiAgYnVsa0FwaVZlcnNpb24/OiBCdWxrQXBpVmVyc2lvbjtcbn07XG5cbmV4cG9ydCB0eXBlIFF1ZXJ5VXBkYXRlT3B0aW9ucyA9IHtcbiAgYWxsb3dCdWxrPzogYm9vbGVhbjtcbiAgYnVsa1RocmVzaG9sZD86IG51bWJlcjtcbiAgYnVsa0FwaVZlcnNpb24/OiBCdWxrQXBpVmVyc2lvbjtcbiAgLyoqXG4gICAqIFNraXAgcmVjb3JkIHRlbXBsYXRlIGV2YWx1YXRpb24uXG4gICAqL1xuICBza2lwUmVjb3JkVGVtcGxhdGVFdmFsPzogYm9vbGVhbjtcbn07XG5cbi8qKlxuICpcbiAqL1xuY29uc3QgREVGQVVMVF9CVUxLX1RIUkVTSE9MRCA9IDIwMDtcbmNvbnN0IERFRkFVTFRfQlVMS19BUElfVkVSU0lPTiA9IDE7XG5cbi8qKlxuICogUXVlcnlcbiAqL1xuZXhwb3J0IGNsYXNzIFF1ZXJ5PFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBOIGV4dGVuZHMgU09iamVjdE5hbWVzPFM+LFxuICBSIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkLFxuICBRUlQgZXh0ZW5kcyBRdWVyeVJlc3BvbnNlVGFyZ2V0ID0gUXVlcnlSZXNwb25zZVRhcmdldFxuPiBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIHN0YXRpYyBfbG9nZ2VyID0gZ2V0TG9nZ2VyKCdxdWVyeScpO1xuXG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuICBfbG9nZ2VyOiBMb2dnZXI7XG4gIF9zb3FsOiBPcHRpb25hbDxzdHJpbmc+O1xuICBfbG9jYXRvcjogT3B0aW9uYWw8c3RyaW5nPjtcbiAgX2NvbmZpZzogU09RTFF1ZXJ5Q29uZmlnID0ge307XG4gIF9jaGlsZHJlbjogQXJyYXk8U3ViUXVlcnk8UywgTiwgUiwgUVJULCBhbnksIGFueSwgYW55Pj4gPSBbXTtcbiAgX29wdGlvbnM6IFF1ZXJ5T3B0aW9ucztcbiAgX2V4ZWN1dGVkOiBib29sZWFuID0gZmFsc2U7XG4gIF9maW5pc2hlZDogYm9vbGVhbiA9IGZhbHNlO1xuICBfY2hhaW5pbmc6IGJvb2xlYW4gPSBmYWxzZTtcbiAgX3Byb21pc2U6IFByb21pc2U8UXVlcnlSZXNwb25zZTxSLCBRUlQ+PjtcbiAgX3N0cmVhbTogU2VyaWFsaXphYmxlPFI+O1xuXG4gIHRvdGFsU2l6ZSA9IDA7XG4gIHRvdGFsRmV0Y2hlZCA9IDA7XG4gIHJlY29yZHM6IFJbXSA9IFtdO1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoXG4gICAgY29ubjogQ29ubmVjdGlvbjxTPixcbiAgICBjb25maWc6IHN0cmluZyB8IFF1ZXJ5Q29uZmlnPFMsIE4+IHwgeyBsb2NhdG9yOiBzdHJpbmcgfSxcbiAgICBvcHRpb25zPzogUGFydGlhbDxRdWVyeU9wdGlvbnM+LFxuICApIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICAgIHRoaXMuX2xvZ2dlciA9IGNvbm4uX2xvZ0xldmVsXG4gICAgICA/IFF1ZXJ5Ll9sb2dnZXIuY3JlYXRlSW5zdGFuY2UoY29ubi5fbG9nTGV2ZWwpXG4gICAgICA6IFF1ZXJ5Ll9sb2dnZXI7XG4gICAgaWYgKHR5cGVvZiBjb25maWcgPT09ICdzdHJpbmcnKSB7XG4gICAgICB0aGlzLl9zb3FsID0gY29uZmlnO1xuICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKGBjb25maWcgaXMgc29xbDogJHtjb25maWd9YCk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgKGNvbmZpZyBhcyBhbnkpLmxvY2F0b3IgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25zdCBsb2NhdG9yOiBzdHJpbmcgPSAoY29uZmlnIGFzIGFueSkubG9jYXRvcjtcbiAgICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhgY29uZmlnIGlzIGxvY2F0b3I6ICR7bG9jYXRvcn1gKTtcbiAgICAgIHRoaXMuX2xvY2F0b3IgPSBsb2NhdG9yLmluY2x1ZGVzKCcvJylcbiAgICAgICAgPyB0aGlzLnVybFRvTG9jYXRvcihsb2NhdG9yKVxuICAgICAgICA6IGxvY2F0b3I7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhgY29uZmlnIGlzIFF1ZXJ5Q29uZmlnOiAke0pTT04uc3RyaW5naWZ5KGNvbmZpZyl9YCk7XG4gICAgICBjb25zdCB7IGZpZWxkcywgaW5jbHVkZXMsIHNvcnQsIC4uLl9jb25maWcgfSA9IGNvbmZpZyBhcyBRdWVyeUNvbmZpZzxcbiAgICAgICAgUyxcbiAgICAgICAgTlxuICAgICAgPjtcbiAgICAgIHRoaXMuX2NvbmZpZyA9IF9jb25maWc7XG4gICAgICB0aGlzLnNlbGVjdChmaWVsZHMpO1xuICAgICAgaWYgKGluY2x1ZGVzKSB7XG4gICAgICAgIHRoaXMuaW5jbHVkZUNoaWxkcmVuKGluY2x1ZGVzKTtcbiAgICAgIH1cbiAgICAgIGlmIChzb3J0KSB7XG4gICAgICAgIHRoaXMuc29ydChzb3J0KTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5fb3B0aW9ucyA9IHtcbiAgICAgIGhlYWRlcnM6IHt9LFxuICAgICAgbWF4RmV0Y2g6IDEwMDAwLFxuICAgICAgYXV0b0ZldGNoOiBmYWxzZSxcbiAgICAgIHNjYW5BbGw6IGZhbHNlLFxuICAgICAgcmVzcG9uc2VUYXJnZXQ6ICdRdWVyeVJlc3VsdCcsXG4gICAgICAuLi4ob3B0aW9ucyB8fCB7fSksXG4gICAgfSBhcyBRdWVyeU9wdGlvbnM7XG4gICAgLy8gcHJvbWlzZSBpbnN0YW5jZVxuICAgIHRoaXMuX3Byb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLm9uKCdyZXNwb25zZScsIHJlc29sdmUpO1xuICAgICAgdGhpcy5vbignZXJyb3InLCByZWplY3QpO1xuICAgIH0pO1xuICAgIHRoaXMuX3N0cmVhbSA9IG5ldyBTZXJpYWxpemFibGUoKTtcbiAgICB0aGlzLm9uKCdyZWNvcmQnLCAocmVjb3JkKSA9PiB0aGlzLl9zdHJlYW0ucHVzaChyZWNvcmQpKTtcbiAgICB0aGlzLm9uKCdlbmQnLCAoKSA9PiB0aGlzLl9zdHJlYW0ucHVzaChudWxsKSk7XG4gICAgdGhpcy5vbignZXJyb3InLCAoZXJyKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICB0aGlzLl9zdHJlYW0uZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLWVtcHR5XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogU2VsZWN0IGZpZWxkcyB0byBpbmNsdWRlIGluIHRoZSByZXR1cm5pbmcgcmVzdWx0XG4gICAqL1xuICBzZWxlY3Q8XG4gICAgUiBleHRlbmRzIFJlY29yZCA9IFJlY29yZCxcbiAgICBGUCBleHRlbmRzIEZpZWxkUGF0aFNwZWNpZmllcjxTLCBOPiA9IEZpZWxkUGF0aFNwZWNpZmllcjxTLCBOPixcbiAgICBGUEMgZXh0ZW5kcyBGaWVsZFByb2plY3Rpb25Db25maWcgPSBGaWVsZFBhdGhTY29wZWRQcm9qZWN0aW9uPFMsIE4sIEZQPixcbiAgICBSMiBleHRlbmRzIFNPYmplY3RSZWNvcmQ8UywgTiwgRlBDLCBSPiA9IFNPYmplY3RSZWNvcmQ8UywgTiwgRlBDLCBSPlxuICA+KGZpZWxkczogUXVlcnlGaWVsZDxTLCBOLCBGUD4gPSAnKicpOiBRdWVyeTxTLCBOLCBSMiwgUVJUPiB7XG4gICAgaWYgKHRoaXMuX3NvcWwpIHtcbiAgICAgIHRocm93IEVycm9yKFxuICAgICAgICAnQ2Fubm90IHNldCBzZWxlY3QgZmllbGRzIGZvciB0aGUgcXVlcnkgd2hpY2ggaGFzIGFscmVhZHkgYnVpbHQgU09RTC4nLFxuICAgICAgKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gdG9GaWVsZEFycmF5KGZpZWxkczogUXVlcnlGaWVsZDxTLCBOLCBGUD4pOiBzdHJpbmdbXSB7XG4gICAgICByZXR1cm4gdHlwZW9mIGZpZWxkcyA9PT0gJ3N0cmluZydcbiAgICAgICAgPyBmaWVsZHMuc3BsaXQoL1xccyosXFxzKi8pXG4gICAgICAgIDogQXJyYXkuaXNBcnJheShmaWVsZHMpXG4gICAgICAgID8gKGZpZWxkcyBhcyBBcnJheTxzdHJpbmcgfCBGUD4pXG4gICAgICAgICAgICAubWFwKHRvRmllbGRBcnJheSlcbiAgICAgICAgICAgIC5yZWR1Y2U8c3RyaW5nW10+KChmcywgZikgPT4gWy4uLmZzLCAuLi5mXSwgW10pXG4gICAgICAgIDogT2JqZWN0LmVudHJpZXMoZmllbGRzIGFzIHsgW25hbWU6IHN0cmluZ106IFF1ZXJ5RmllbGQ8UywgTiwgRlA+IH0pXG4gICAgICAgICAgICAubWFwKChbZiwgdl0pID0+IHtcbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHYgPyBbZl0gOiBbXTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdG9GaWVsZEFycmF5KHYpLm1hcCgocCkgPT4gYCR7Zn0uJHtwfWApO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnJlZHVjZTxzdHJpbmdbXT4oKGZzLCBmKSA9PiBbLi4uZnMsIC4uLmZdLCBbXSk7XG4gICAgfVxuICAgIGlmIChmaWVsZHMpIHtcbiAgICAgIHRoaXMuX2NvbmZpZy5maWVsZHMgPSB0b0ZpZWxkQXJyYXkoZmllbGRzKTtcbiAgICB9XG4gICAgLy8gZm9yY2UgY29udmVydCBxdWVyeSByZWNvcmQgdHlwZSB3aXRob3V0IGNoYW5naW5nIGluc3RhbmNlO1xuICAgIHJldHVybiAodGhpcyBhcyBhbnkpIGFzIFF1ZXJ5PFMsIE4sIFIyLCBRUlQ+O1xuICB9XG5cbiAgLyoqXG4gICAqIFNldCBxdWVyeSBjb25kaXRpb25zIHRvIGZpbHRlciB0aGUgcmVzdWx0IHJlY29yZHNcbiAgICovXG4gIHdoZXJlKGNvbmRpdGlvbnM6IFF1ZXJ5Q29uZGl0aW9uPFMsIE4+IHwgc3RyaW5nKSB7XG4gICAgaWYgKHRoaXMuX3NvcWwpIHtcbiAgICAgIHRocm93IEVycm9yKFxuICAgICAgICAnQ2Fubm90IHNldCB3aGVyZSBjb25kaXRpb25zIGZvciB0aGUgcXVlcnkgd2hpY2ggaGFzIGFscmVhZHkgYnVpbHQgU09RTC4nLFxuICAgICAgKTtcbiAgICB9XG4gICAgdGhpcy5fY29uZmlnLmNvbmRpdGlvbnMgPSBjb25kaXRpb25zO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIExpbWl0IHRoZSByZXR1cm5pbmcgcmVzdWx0XG4gICAqL1xuICBsaW1pdChsaW1pdDogbnVtYmVyKSB7XG4gICAgaWYgKHRoaXMuX3NvcWwpIHtcbiAgICAgIHRocm93IEVycm9yKFxuICAgICAgICAnQ2Fubm90IHNldCBsaW1pdCBmb3IgdGhlIHF1ZXJ5IHdoaWNoIGhhcyBhbHJlYWR5IGJ1aWx0IFNPUUwuJyxcbiAgICAgICk7XG4gICAgfVxuICAgIHRoaXMuX2NvbmZpZy5saW1pdCA9IGxpbWl0O1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFNraXAgcmVjb3Jkc1xuICAgKi9cbiAgc2tpcChvZmZzZXQ6IG51bWJlcikge1xuICAgIGlmICh0aGlzLl9zb3FsKSB7XG4gICAgICB0aHJvdyBFcnJvcihcbiAgICAgICAgJ0Nhbm5vdCBzZXQgc2tpcC9vZmZzZXQgZm9yIHRoZSBxdWVyeSB3aGljaCBoYXMgYWxyZWFkeSBidWlsdCBTT1FMLicsXG4gICAgICApO1xuICAgIH1cbiAgICB0aGlzLl9jb25maWcub2Zmc2V0ID0gb2Zmc2V0O1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgUXVlcnkjc2tpcCgpXG4gICAqL1xuICBvZmZzZXQgPSB0aGlzLnNraXA7XG5cbiAgLyoqXG4gICAqIFNldCBxdWVyeSBzb3J0IHdpdGggZGlyZWN0aW9uXG4gICAqL1xuICBzb3J0KHNvcnQ6IFF1ZXJ5U29ydDxTLCBOPnxzdHJpbmcpOiB0aGlzO1xuICBzb3J0KHNvcnQ6IFNPYmplY3RGaWVsZE5hbWVzPFMsIE4+fHN0cmluZywgZGlyOiBTb3J0RGlyKTogdGhpcztcbiAgc29ydChcbiAgICBzb3J0OiBRdWVyeVNvcnQ8UywgTj4gfCBTT2JqZWN0RmllbGROYW1lczxTLCBOPiB8IHN0cmluZyxcbiAgICBkaXI/OiBTb3J0RGlyLFxuICApIHtcbiAgICBpZiAodGhpcy5fc29xbCkge1xuICAgICAgdGhyb3cgRXJyb3IoXG4gICAgICAgICdDYW5ub3Qgc2V0IHNvcnQgZm9yIHRoZSBxdWVyeSB3aGljaCBoYXMgYWxyZWFkeSBidWlsdCBTT1FMLicsXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHNvcnQgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBkaXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICB0aGlzLl9jb25maWcuc29ydCA9IFtbc29ydCwgZGlyXV07XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2NvbmZpZy5zb3J0ID0gc29ydCBhcyBzdHJpbmcgfCB7IFtmaWVsZDogc3RyaW5nXTogU29ydERpciB9O1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIFF1ZXJ5I3NvcnQoKVxuICAgKi9cbiAgb3JkZXJieTogdHlwZW9mIFF1ZXJ5LnByb3RvdHlwZS5zb3J0ID0gdGhpcy5zb3J0O1xuXG4gIC8qKlxuICAgKiBJbmNsdWRlIGNoaWxkIHJlbGF0aW9uc2hpcCBxdWVyeSBhbmQgbW92ZSBkb3duIHRvIHRoZSBjaGlsZCBxdWVyeSBjb250ZXh0XG4gICAqL1xuICBpbmNsdWRlPFxuICAgIENSTiBleHRlbmRzIENoaWxkUmVsYXRpb25zaGlwTmFtZXM8UywgTj4sXG4gICAgQ04gZXh0ZW5kcyBDaGlsZFJlbGF0aW9uc2hpcFNPYmplY3ROYW1lPFMsIE4sIENSTj4sXG4gICAgQ0ZQIGV4dGVuZHMgRmllbGRQYXRoU3BlY2lmaWVyPFMsIENOPiA9IEZpZWxkUGF0aFNwZWNpZmllcjxTLCBDTj4sXG4gICAgQ0ZQQyBleHRlbmRzIEZpZWxkUHJvamVjdGlvbkNvbmZpZyA9IEZpZWxkUGF0aFNjb3BlZFByb2plY3Rpb248UywgQ04sIENGUD4sXG4gICAgQ1IgZXh0ZW5kcyBSZWNvcmQgPSBTT2JqZWN0UmVjb3JkPFMsIENOLCBDRlBDPlxuICA+KFxuICAgIGNoaWxkUmVsTmFtZTogQ1JOLFxuICAgIGNvbmRpdGlvbnM/OiBPcHRpb25hbDxRdWVyeUNvbmRpdGlvbjxTLCBDTj4+LFxuICAgIGZpZWxkcz86IE9wdGlvbmFsPFF1ZXJ5RmllbGQ8UywgQ04sIENGUD4+LFxuICAgIG9wdGlvbnM/OiB7IGxpbWl0PzogbnVtYmVyOyBvZmZzZXQ/OiBudW1iZXI7IHNvcnQ/OiBRdWVyeVNvcnQ8UywgQ04+IH0sXG4gICk6IFN1YlF1ZXJ5PFMsIE4sIFIsIFFSVCwgQ1JOLCBDTiwgQ1I+O1xuICBpbmNsdWRlPFxuICAgIENSTiBleHRlbmRzIENoaWxkUmVsYXRpb25zaGlwTmFtZXM8UywgTj4sXG4gICAgQ04gZXh0ZW5kcyBTT2JqZWN0TmFtZXM8Uz4sXG4gICAgQ1IgZXh0ZW5kcyBSZWNvcmQgPSBTT2JqZWN0UmVjb3JkPFMsIENOPlxuICA+KFxuICAgIGNoaWxkUmVsTmFtZTogc3RyaW5nLFxuICAgIGNvbmRpdGlvbnM/OiBPcHRpb25hbDxRdWVyeUNvbmRpdGlvbjxTLCBDTj4+LFxuICAgIGZpZWxkcz86IE9wdGlvbmFsPFF1ZXJ5RmllbGQ8UywgQ04+PixcbiAgICBvcHRpb25zPzogeyBsaW1pdD86IG51bWJlcjsgb2Zmc2V0PzogbnVtYmVyOyBzb3J0PzogUXVlcnlTb3J0PFMsIENOPiB9LFxuICApOiBTdWJRdWVyeTxTLCBOLCBSLCBRUlQsIENSTiwgQ04sIENSPjtcblxuICBpbmNsdWRlPFxuICAgIENSTiBleHRlbmRzIENoaWxkUmVsYXRpb25zaGlwTmFtZXM8UywgTj4sXG4gICAgQ04gZXh0ZW5kcyBDaGlsZFJlbGF0aW9uc2hpcFNPYmplY3ROYW1lPFMsIE4sIENSTj4sXG4gICAgQ0ZQIGV4dGVuZHMgRmllbGRQYXRoU3BlY2lmaWVyPFMsIENOPiA9IEZpZWxkUGF0aFNwZWNpZmllcjxTLCBDTj4sXG4gICAgQ0ZQQyBleHRlbmRzIEZpZWxkUHJvamVjdGlvbkNvbmZpZyA9IEZpZWxkUGF0aFNjb3BlZFByb2plY3Rpb248UywgQ04sIENGUD4sXG4gICAgQ1IgZXh0ZW5kcyBSZWNvcmQgPSBTT2JqZWN0UmVjb3JkPFMsIENOLCBDRlBDPlxuICA+KFxuICAgIGNoaWxkUmVsTmFtZTogQ1JOIHwgc3RyaW5nLFxuICAgIGNvbmRpdGlvbnM/OiBPcHRpb25hbDxRdWVyeUNvbmRpdGlvbjxTLCBDTj4+LFxuICAgIGZpZWxkcz86IE9wdGlvbmFsPFF1ZXJ5RmllbGQ8UywgQ04sIENGUD4+LFxuICAgIG9wdGlvbnM6IHsgbGltaXQ/OiBudW1iZXI7IG9mZnNldD86IG51bWJlcjsgc29ydD86IFF1ZXJ5U29ydDxTLCBDTj4gfSA9IHt9LFxuICApOiBTdWJRdWVyeTxTLCBOLCBSLCBRUlQsIENSTiwgQ04sIENSPiB7XG4gICAgaWYgKHRoaXMuX3NvcWwpIHtcbiAgICAgIHRocm93IEVycm9yKFxuICAgICAgICAnQ2Fubm90IGluY2x1ZGUgY2hpbGQgcmVsYXRpb25zaGlwIGludG8gdGhlIHF1ZXJ5IHdoaWNoIGhhcyBhbHJlYWR5IGJ1aWx0IFNPUUwuJyxcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IGNoaWxkQ29uZmlnOiBRdWVyeUNvbmZpZzxTLCBDTiwgQ0ZQPiA9IHtcbiAgICAgIGZpZWxkczogZmllbGRzID09PSBudWxsID8gdW5kZWZpbmVkIDogZmllbGRzLFxuICAgICAgdGFibGU6IGNoaWxkUmVsTmFtZSxcbiAgICAgIGNvbmRpdGlvbnM6IGNvbmRpdGlvbnMgPT09IG51bGwgPyB1bmRlZmluZWQgOiBjb25kaXRpb25zLFxuICAgICAgbGltaXQ6IG9wdGlvbnMubGltaXQsXG4gICAgICBvZmZzZXQ6IG9wdGlvbnMub2Zmc2V0LFxuICAgICAgc29ydDogb3B0aW9ucy5zb3J0LFxuICAgIH07XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZS1iZWZvcmUtZGVmaW5lXG4gICAgY29uc3QgY2hpbGRRdWVyeSA9IG5ldyBTdWJRdWVyeTxTLCBOLCBSLCBRUlQsIENSTiwgQ04sIENSPihcbiAgICAgIHRoaXMuX2Nvbm4sXG4gICAgICBjaGlsZFJlbE5hbWUgYXMgQ1JOLFxuICAgICAgY2hpbGRDb25maWcsXG4gICAgICB0aGlzLFxuICAgICk7XG4gICAgdGhpcy5fY2hpbGRyZW4ucHVzaChjaGlsZFF1ZXJ5KTtcbiAgICByZXR1cm4gY2hpbGRRdWVyeTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbmNsdWRlIGNoaWxkIHJlbGF0aW9uc2hpcCBxdWVyaWVzLCBidXQgbm90IG1vdmluZyBkb3duIHRvIHRoZSBjaGlsZHJlbiBjb250ZXh0XG4gICAqL1xuICBpbmNsdWRlQ2hpbGRyZW4oXG4gICAgaW5jbHVkZXM6IHtcbiAgICAgIFtDUk4gaW4gQ2hpbGRSZWxhdGlvbnNoaXBOYW1lczxTLCBOPl0/OiBRdWVyeUNvbmZpZzxcbiAgICAgICAgUyxcbiAgICAgICAgQ2hpbGRSZWxhdGlvbnNoaXBTT2JqZWN0TmFtZTxTLCBOLCBDUk4+XG4gICAgICA+O1xuICAgIH0sXG4gICkge1xuICAgIHR5cGUgQ1JOID0gQ2hpbGRSZWxhdGlvbnNoaXBOYW1lczxTLCBOPjtcbiAgICBpZiAodGhpcy5fc29xbCkge1xuICAgICAgdGhyb3cgRXJyb3IoXG4gICAgICAgICdDYW5ub3QgaW5jbHVkZSBjaGlsZCByZWxhdGlvbnNoaXAgaW50byB0aGUgcXVlcnkgd2hpY2ggaGFzIGFscmVhZHkgYnVpbHQgU09RTC4nLFxuICAgICAgKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBjcm5hbWUgb2YgT2JqZWN0LmtleXMoaW5jbHVkZXMpIGFzIENSTltdKSB7XG4gICAgICBjb25zdCB7IGNvbmRpdGlvbnMsIGZpZWxkcywgLi4ub3B0aW9ucyB9ID0gaW5jbHVkZXNbXG4gICAgICAgIGNybmFtZVxuICAgICAgXSBhcyBRdWVyeUNvbmZpZzxTLCBDaGlsZFJlbGF0aW9uc2hpcFNPYmplY3ROYW1lPFMsIE4sIENSTj4+O1xuICAgICAgdGhpcy5pbmNsdWRlKGNybmFtZSwgY29uZGl0aW9ucywgZmllbGRzLCBvcHRpb25zKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogU2V0dGluZyBtYXhGZXRjaCBxdWVyeSBvcHRpb25cbiAgICovXG4gIG1heEZldGNoKG1heEZldGNoOiBudW1iZXIpIHtcbiAgICB0aGlzLl9vcHRpb25zLm1heEZldGNoID0gbWF4RmV0Y2g7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogU3dpdGNoaW5nIGF1dG8gZmV0Y2ggbW9kZVxuICAgKi9cbiAgYXV0b0ZldGNoKGF1dG9GZXRjaDogYm9vbGVhbikge1xuICAgIHRoaXMuX29wdGlvbnMuYXV0b0ZldGNoID0gYXV0b0ZldGNoO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFNldCBmbGFnIHRvIHNjYW4gYWxsIHJlY29yZHMgaW5jbHVkaW5nIGRlbGV0ZWQgYW5kIGFyY2hpdmVkLlxuICAgKi9cbiAgc2NhbkFsbChzY2FuQWxsOiBib29sZWFuKSB7XG4gICAgdGhpcy5fb3B0aW9ucy5zY2FuQWxsID0gc2NhbkFsbDtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgc2V0UmVzcG9uc2VUYXJnZXQ8UVJUMSBleHRlbmRzIFF1ZXJ5UmVzcG9uc2VUYXJnZXQ+KFxuICAgIHJlc3BvbnNlVGFyZ2V0OiBRUlQxLFxuICApOiBRdWVyeTxTLCBOLCBSLCBRUlQxPiB7XG4gICAgaWYgKHJlc3BvbnNlVGFyZ2V0IGluIFJlc3BvbnNlVGFyZ2V0cykge1xuICAgICAgdGhpcy5fb3B0aW9ucy5yZXNwb25zZVRhcmdldCA9IHJlc3BvbnNlVGFyZ2V0O1xuICAgIH1cbiAgICAvLyBmb3JjZSBjaGFuZ2UgcXVlcnkgcmVzcG9uc2UgdGFyZ2V0IHdpdGhvdXQgY2hhbmdpbmcgaW5zdGFuY2VcbiAgICByZXR1cm4gKHRoaXMgYXMgUXVlcnk8UywgTiwgUj4pIGFzIFF1ZXJ5PFMsIE4sIFIsIFFSVDE+O1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGUgcXVlcnkgYW5kIGZldGNoIHJlY29yZHMgZnJvbSBzZXJ2ZXIuXG4gICAqL1xuICBleGVjdXRlPFFSVDEgZXh0ZW5kcyBRdWVyeVJlc3BvbnNlVGFyZ2V0ID0gUVJUPihcbiAgICBvcHRpb25zXzogUGFydGlhbDxRdWVyeU9wdGlvbnM+ICYgeyByZXNwb25zZVRhcmdldD86IFFSVDEgfSA9IHt9LFxuICApOiBRdWVyeTxTLCBOLCBSLCBRUlQxPiB7XG4gICAgaWYgKHRoaXMuX2V4ZWN1dGVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ3JlLWV4ZWN1dGluZyBhbHJlYWR5IGV4ZWN1dGVkIHF1ZXJ5Jyk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX2ZpbmlzaGVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2V4ZWN1dGluZyBhbHJlYWR5IGNsb3NlZCBxdWVyeScpO1xuICAgIH1cblxuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICBoZWFkZXJzOiBvcHRpb25zXy5oZWFkZXJzIHx8IHRoaXMuX29wdGlvbnMuaGVhZGVycyxcbiAgICAgIHJlc3BvbnNlVGFyZ2V0OiBvcHRpb25zXy5yZXNwb25zZVRhcmdldCB8fCB0aGlzLl9vcHRpb25zLnJlc3BvbnNlVGFyZ2V0LFxuICAgICAgYXV0b0ZldGNoOiBvcHRpb25zXy5hdXRvRmV0Y2ggfHwgdGhpcy5fb3B0aW9ucy5hdXRvRmV0Y2gsXG4gICAgICBtYXhGZXRjaDogb3B0aW9uc18ubWF4RmV0Y2ggfHwgdGhpcy5fb3B0aW9ucy5tYXhGZXRjaCxcbiAgICAgIHNjYW5BbGw6IG9wdGlvbnNfLnNjYW5BbGwgfHwgdGhpcy5fb3B0aW9ucy5zY2FuQWxsLFxuICAgIH07XG5cbiAgICAvLyBjb2xsZWN0IGZldGNoZWQgcmVjb3JkcyBpbiBhcnJheVxuICAgIC8vIG9ubHkgd2hlbiByZXNwb25zZSB0YXJnZXQgaXMgUmVjb3JkcyBhbmRcbiAgICAvLyBlaXRoZXIgY2FsbGJhY2sgb3IgY2hhaW5pbmcgcHJvbWlzZXMgYXJlIGF2YWlsYWJsZSB0byB0aGlzIHF1ZXJ5LlxuICAgIHRoaXMub25jZSgnZmV0Y2gnLCAoKSA9PiB7XG4gICAgICBpZiAoXG4gICAgICAgIG9wdGlvbnMucmVzcG9uc2VUYXJnZXQgPT09IFJlc3BvbnNlVGFyZ2V0cy5SZWNvcmRzICYmXG4gICAgICAgIHRoaXMuX2NoYWluaW5nXG4gICAgICApIHtcbiAgICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKCctLS0gY29sbGVjdGluZyBhbGwgZmV0Y2hlZCByZWNvcmRzIC0tLScpO1xuICAgICAgICBjb25zdCByZWNvcmRzOiBSZWNvcmRbXSA9IFtdO1xuICAgICAgICBjb25zdCBvblJlY29yZCA9IChyZWNvcmQ6IFJlY29yZCkgPT4gcmVjb3Jkcy5wdXNoKHJlY29yZCk7XG4gICAgICAgIHRoaXMub24oJ3JlY29yZCcsIG9uUmVjb3JkKTtcbiAgICAgICAgdGhpcy5vbmNlKCdlbmQnLCAoKSA9PiB7XG4gICAgICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcigncmVjb3JkJywgb25SZWNvcmQpO1xuICAgICAgICAgIHRoaXMuZW1pdCgncmVzcG9uc2UnLCByZWNvcmRzLCB0aGlzKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBmbGFnIHRvIHByZXZlbnQgcmUtZXhlY3V0aW9uXG4gICAgdGhpcy5fZXhlY3V0ZWQgPSB0cnVlO1xuXG4gICAgKGFzeW5jICgpID0+IHtcbiAgICAgIC8vIHN0YXJ0IGFjdHVhbCBxdWVyeVxuICAgICAgdGhpcy5fbG9nZ2VyLmRlYnVnKCc+Pj4gUXVlcnkgc3RhcnQgPj4+Jyk7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCB0aGlzLl9leGVjdXRlKG9wdGlvbnMpO1xuICAgICAgICB0aGlzLl9sb2dnZXIuZGVidWcoJyoqKiBRdWVyeSBmaW5pc2hlZCAqKionKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZygnLS0tIFF1ZXJ5IGVycm9yIC0tLScsIGVycm9yKTtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9KSgpO1xuXG4gICAgLy8gcmV0dXJuIFF1ZXJ5IGluc3RhbmNlIGZvciBjaGFpbmluZ1xuICAgIHJldHVybiAodGhpcyBhcyBRdWVyeTxTLCBOLCBSPikgYXMgUXVlcnk8UywgTiwgUiwgUVJUMT47XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBRdWVyeSNleGVjdXRlKClcbiAgICovXG4gIGV4ZWMgPSB0aGlzLmV4ZWN1dGU7XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgUXVlcnkjZXhlY3V0ZSgpXG4gICAqL1xuICBydW4gPSB0aGlzLmV4ZWN1dGU7XG5cbiAgcHJpdmF0ZSBsb2NhdG9yVG9VcmwoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvY2F0b3JcbiAgICAgID8gW3RoaXMuX2Nvbm4uX2Jhc2VVcmwoKSwgJy9xdWVyeS8nLCB0aGlzLl9sb2NhdG9yXS5qb2luKCcnKVxuICAgICAgOiAnJztcbiAgfVxuXG4gIHByaXZhdGUgdXJsVG9Mb2NhdG9yKHVybDogc3RyaW5nKSB7XG4gICAgcmV0dXJuIHVybC5zcGxpdCgnLycpLnBvcCgpO1xuICB9XG5cbiAgcHJpdmF0ZSBjb25zdHJ1Y3RSZXNwb25zZShcbiAgICByYXdEb25lOiBib29sZWFuLFxuICAgIHJlc3BvbnNlVGFyZ2V0OiBRdWVyeVJlc3BvbnNlVGFyZ2V0WzNdLFxuICApOiBudW1iZXI7XG4gIHByaXZhdGUgY29uc3RydWN0UmVzcG9uc2UoXG4gICAgcmF3RG9uZTogYm9vbGVhbixcbiAgICByZXNwb25zZVRhcmdldDogUXVlcnlSZXNwb25zZVRhcmdldFsyXSxcbiAgKTogUjtcbiAgcHJpdmF0ZSBjb25zdHJ1Y3RSZXNwb25zZShcbiAgICByYXdEb25lOiBib29sZWFuLFxuICAgIHJlc3BvbnNlVGFyZ2V0OiBRdWVyeVJlc3BvbnNlVGFyZ2V0WzFdLFxuICApOiBSW107XG4gIHByaXZhdGUgY29uc3RydWN0UmVzcG9uc2UoXG4gICAgcmF3RG9uZTogYm9vbGVhbixcbiAgICByZXNwb25zZVRhcmdldDogUXVlcnlSZXNwb25zZVRhcmdldFswXSxcbiAgKTogUXVlcnlSZXN1bHQ8Uj47XG4gIHByaXZhdGUgY29uc3RydWN0UmVzcG9uc2UoXG4gICAgcmF3RG9uZTogYm9vbGVhbixcbiAgICByZXNwb25zZVRhcmdldDogUXVlcnlSZXNwb25zZVRhcmdldCxcbiAgKTogUXVlcnlSZXN1bHQ8Uj4gfCBSW10gfCBudW1iZXIgfCBSIHtcbiAgICBzd2l0Y2ggKHJlc3BvbnNlVGFyZ2V0KSB7XG4gICAgICBjYXNlICdDb3VudCc6XG4gICAgICAgIHJldHVybiB0aGlzLnRvdGFsU2l6ZTtcbiAgICAgIGNhc2UgJ1NpbmdsZVJlY29yZCc6XG4gICAgICAgIHJldHVybiB0aGlzLnJlY29yZHM/LlswXSA/PyBudWxsO1xuICAgICAgY2FzZSAnUmVjb3Jkcyc6XG4gICAgICAgIHJldHVybiB0aGlzLnJlY29yZHM7XG4gICAgICAvLyBRdWVyeVJlc3VsdCBpcyBkZWZhdWx0IHJlc3BvbnNlIHRhcmdldFxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAuLi57XG4gICAgICAgICAgICByZWNvcmRzOiB0aGlzLnJlY29yZHMsXG4gICAgICAgICAgICB0b3RhbFNpemU6IHRoaXMudG90YWxTaXplLFxuICAgICAgICAgICAgZG9uZTogcmF3RG9uZSA/PyB0cnVlLCAvLyB3aGVuIG5vIHJlY29yZHMsIGRvbmUgaXMgb21pdHRlZFxuICAgICAgICAgIH0sXG4gICAgICAgICAgLi4uKHRoaXMuX2xvY2F0b3IgPyB7IG5leHRSZWNvcmRzVXJsOiB0aGlzLmxvY2F0b3JUb1VybCgpIH0gOiB7fSksXG4gICAgICAgIH07XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgYXN5bmMgX2V4ZWN1dGUob3B0aW9uczogUXVlcnlPcHRpb25zKTogUHJvbWlzZTxRdWVyeVJlc3BvbnNlPFI+PiB7XG4gICAgY29uc3QgeyBoZWFkZXJzLCByZXNwb25zZVRhcmdldCwgYXV0b0ZldGNoLCBtYXhGZXRjaCwgc2NhbkFsbCB9ID0gb3B0aW9ucztcbiAgICB0aGlzLl9sb2dnZXIuZGVidWcoJ2V4ZWN1dGUgd2l0aCBvcHRpb25zJywgb3B0aW9ucyk7XG4gICAgbGV0IHVybDtcbiAgICBpZiAodGhpcy5fbG9jYXRvcikge1xuICAgICAgdXJsID0gdGhpcy5sb2NhdG9yVG9VcmwoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgc29xbCA9IGF3YWl0IHRoaXMudG9TT1FMKCk7XG4gICAgICB0aGlzLl9sb2dnZXIuZGVidWcoYFNPUUwgPSAke3NvcWx9YCk7XG4gICAgICB1cmwgPSBbXG4gICAgICAgIHRoaXMuX2Nvbm4uX2Jhc2VVcmwoKSxcbiAgICAgICAgJy8nLFxuICAgICAgICBzY2FuQWxsID8gJ3F1ZXJ5QWxsJyA6ICdxdWVyeScsXG4gICAgICAgICc/cT0nLFxuICAgICAgICBlbmNvZGVVUklDb21wb25lbnQoc29xbCksXG4gICAgICBdLmpvaW4oJycpO1xuICAgIH1cbiAgICBjb25zdCBkYXRhID0gYXdhaXQgdGhpcy5fY29ubi5yZXF1ZXN0PFI+KHsgbWV0aG9kOiAnR0VUJywgdXJsLCBoZWFkZXJzIH0pO1xuICAgIHRoaXMuZW1pdCgnZmV0Y2gnKTtcbiAgICB0aGlzLnRvdGFsU2l6ZSA9IGRhdGEudG90YWxTaXplO1xuXG4gICAgLy8gSWYgYXV0b0ZldGNoIGlzIHRydWUsIGZldGNoIGFsbCByZWNvcmRzIGZvciBhbnkgc3VicXVlcmllc1xuICAgIGlmIChhdXRvRmV0Y2ggJiYgZGF0YS5yZWNvcmRzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IHJlY29yZEtleXMgPSBPYmplY3Qua2V5cyhkYXRhLnJlY29yZHNbMF0pO1xuICAgICAgZm9yIChjb25zdCByZWNvcmQgb2YgZGF0YS5yZWNvcmRzKSB7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IG9mIHJlY29yZEtleXMpIHtcbiAgICAgICAgICBjb25zdCBmaWVsZCA9IHJlY29yZFtrZXldO1xuICAgICAgICAgIGlmIChmaWVsZCAmJiB0eXBlb2YgZmllbGQgPT09ICdvYmplY3QnICYmICdyZWNvcmRzJyBpbiBmaWVsZCAmJiAnbmV4dFJlY29yZHNVcmwnIGluIGZpZWxkKSB7XG4gICAgICAgICAgICByZWNvcmRba2V5XSA9IHtcbiAgICAgICAgICAgICAgLi4uZmllbGQsXG4gICAgICAgICAgICAgIHJlY29yZHM6IGF3YWl0IHRoaXMuX2ZldGNoQWxsU3VicXVlcnlSZWNvcmRzKHJlY29yZCwga2V5LCBoZWFkZXJzKSxcbiAgICAgICAgICAgICAgZG9uZTogdHJ1ZSxcbiAgICAgICAgICAgICAgbmV4dFJlY29yZHNVcmw6IHVuZGVmaW5lZFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICB0aGlzLnJlY29yZHMgPSB0aGlzLnJlY29yZHM/LmNvbmNhdChcbiAgICAgIG1heEZldGNoIC0gdGhpcy5yZWNvcmRzLmxlbmd0aCA+IGRhdGEucmVjb3Jkcy5sZW5ndGhcbiAgICAgICAgPyBkYXRhLnJlY29yZHNcbiAgICAgICAgOiBkYXRhLnJlY29yZHMuc2xpY2UoMCwgbWF4RmV0Y2ggLSB0aGlzLnJlY29yZHMubGVuZ3RoKSxcbiAgICApO1xuICAgIHRoaXMuX2xvY2F0b3IgPSBkYXRhLm5leHRSZWNvcmRzVXJsXG4gICAgICA/IHRoaXMudXJsVG9Mb2NhdG9yKGRhdGEubmV4dFJlY29yZHNVcmwpXG4gICAgICA6IHVuZGVmaW5lZDtcbiAgICB0aGlzLl9maW5pc2hlZCA9XG4gICAgICB0aGlzLl9maW5pc2hlZCB8fFxuICAgICAgZGF0YS5kb25lIHx8XG4gICAgICAhYXV0b0ZldGNoIHx8XG4gICAgICB0aGlzLnJlY29yZHMubGVuZ3RoID09PSBtYXhGZXRjaCB8fFxuICAgICAgLy8gdGhpcyBpcyB3aGF0IHRoZSByZXNwb25zZSBsb29rcyBsaWtlIHdoZW4gdGhlcmUgYXJlIG5vIHJlc3VsdHNcbiAgICAgIChkYXRhLnJlY29yZHMubGVuZ3RoID09PSAwICYmIGRhdGEuZG9uZSA9PT0gdW5kZWZpbmVkKTtcblxuICAgIC8vIHN0cmVhbWluZyByZWNvcmQgaW5zdGFuY2VzXG4gICAgY29uc3QgbnVtUmVjb3JkcyA9IGRhdGEucmVjb3Jkcz8ubGVuZ3RoID8/IDA7XG4gICAgbGV0IHRvdGFsRmV0Y2hlZCA9IHRoaXMudG90YWxGZXRjaGVkO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbnVtUmVjb3JkczsgaSsrKSB7XG4gICAgICBpZiAodG90YWxGZXRjaGVkID49IG1heEZldGNoKSB7XG4gICAgICAgIHRoaXMuX2ZpbmlzaGVkID0gdHJ1ZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjb25zdCByZWNvcmQgPSBkYXRhLnJlY29yZHNbaV07XG4gICAgICB0aGlzLmVtaXQoJ3JlY29yZCcsIHJlY29yZCwgdG90YWxGZXRjaGVkLCB0aGlzKTtcbiAgICAgIHRvdGFsRmV0Y2hlZCArPSAxO1xuICAgIH1cbiAgICB0aGlzLnRvdGFsRmV0Y2hlZCA9IHRvdGFsRmV0Y2hlZDtcblxuICAgIGlmICh0aGlzLl9maW5pc2hlZCkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSB0aGlzLmNvbnN0cnVjdFJlc3BvbnNlKGRhdGEuZG9uZSwgcmVzcG9uc2VUYXJnZXQpO1xuICAgICAgLy8gb25seSBmaXJlIHJlc3BvbnNlIGV2ZW50IHdoZW4gaXQgc2hvdWxkIGJlIG5vdGlmaWVkIHBlciBmZXRjaFxuICAgICAgaWYgKHJlc3BvbnNlVGFyZ2V0ICE9PSBSZXNwb25zZVRhcmdldHMuUmVjb3Jkcykge1xuICAgICAgICB0aGlzLmVtaXQoJ3Jlc3BvbnNlJywgcmVzcG9uc2UsIHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhpcy5lbWl0KCdlbmQnKTtcbiAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRoaXMuX2V4ZWN1dGUob3B0aW9ucyk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIE9idGFpbiByZWFkYWJsZSBzdHJlYW0gaW5zdGFuY2VcbiAgICovXG4gIHN0cmVhbSh0eXBlOiAncmVjb3JkJyk6IFNlcmlhbGl6YWJsZTxSPjtcbiAgc3RyZWFtKHR5cGU6ICdjc3YnKTogUmVhZGFibGU7XG4gIHN0cmVhbSh0eXBlOiAncmVjb3JkJyB8ICdjc3YnID0gJ2NzdicpIHtcbiAgICBpZiAoIXRoaXMuX2ZpbmlzaGVkICYmICF0aGlzLl9leGVjdXRlZCkge1xuICAgICAgdGhpcy5leGVjdXRlKHsgYXV0b0ZldGNoOiB0cnVlIH0pO1xuICAgIH1cbiAgICByZXR1cm4gdHlwZSA9PT0gJ3JlY29yZCcgPyB0aGlzLl9zdHJlYW0gOiB0aGlzLl9zdHJlYW0uc3RyZWFtKHR5cGUpO1xuICB9XG5cbiAgLyoqXG4gICAqIFBpcGUgdGhlIHF1ZXJpZWQgcmVjb3JkcyB0byBhbm90aGVyIHN0cmVhbVxuICAgKiBUaGlzIGlzIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5OyBRdWVyeSBpcyBub3QgYSByZWNvcmQgc3RyZWFtIGluc3RhbmNlIGFueW1vcmUgaW4gMi4wLlxuICAgKiBJZiB5b3Ugd2FudCBhIHJlY29yZCBzdHJlYW0gaW5zdGFuY2UsIHVzZSBgUXVlcnkjc3RyZWFtKCdyZWNvcmQnKWAuXG4gICAqL1xuICBwaXBlKHN0cmVhbTogTm9kZUpTLldyaXRhYmxlU3RyZWFtKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RyZWFtKCdyZWNvcmQnKS5waXBlKHN0cmVhbSk7XG4gIH1cblxuICAvKipcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgYXN5bmMgX2V4cGFuZEZpZWxkcyhzb2JqZWN0Xz86IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGlmICh0aGlzLl9zb3FsKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdDYW5ub3QgZXhwYW5kIGZpZWxkcyBmb3IgdGhlIHF1ZXJ5IHdoaWNoIGhhcyBhbHJlYWR5IGJ1aWx0IFNPUUwuJyxcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IHsgZmllbGRzID0gW10sIHRhYmxlID0gJycgfSA9IHRoaXMuX2NvbmZpZztcbiAgICBjb25zdCBzb2JqZWN0ID0gc29iamVjdF8gfHwgdGFibGU7XG4gICAgdGhpcy5fbG9nZ2VyLmRlYnVnKFxuICAgICAgYF9leHBhbmRGaWVsZHM6IHNvYmplY3QgPSAke3NvYmplY3R9LCBmaWVsZHMgPSAke2ZpZWxkcy5qb2luKCcsICcpfWAsXG4gICAgKTtcbiAgICBjb25zdCBbZWZpZWxkc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICB0aGlzLl9leHBhbmRBc3Rlcmlza0ZpZWxkcyhzb2JqZWN0LCBmaWVsZHMpLFxuICAgICAgLi4udGhpcy5fY2hpbGRyZW4ubWFwKGFzeW5jIChjaGlsZFF1ZXJ5KSA9PiB7XG4gICAgICAgIGF3YWl0IGNoaWxkUXVlcnkuX2V4cGFuZEZpZWxkcygpO1xuICAgICAgICByZXR1cm4gW10gYXMgc3RyaW5nW107XG4gICAgICB9KSxcbiAgICBdKTtcbiAgICB0aGlzLl9jb25maWcuZmllbGRzID0gZWZpZWxkcztcbiAgICB0aGlzLl9jb25maWcuaW5jbHVkZXMgPSB0aGlzLl9jaGlsZHJlblxuICAgICAgLm1hcCgoY3F1ZXJ5KSA9PiB7XG4gICAgICAgIGNvbnN0IGNjb25maWcgPSBjcXVlcnkuX3F1ZXJ5Ll9jb25maWc7XG4gICAgICAgIHJldHVybiBbY2NvbmZpZy50YWJsZSwgY2NvbmZpZ10gYXMgW3N0cmluZywgU09RTFF1ZXJ5Q29uZmlnXTtcbiAgICAgIH0pXG4gICAgICAucmVkdWNlPHsgW25hbWU6IHN0cmluZ106IFNPUUxRdWVyeUNvbmZpZyB9PihcbiAgICAgICAgKGluY2x1ZGVzLCBbY3RhYmxlLCBjY29uZmlnXSkgPT4gKHtcbiAgICAgICAgICAuLi5pbmNsdWRlcyxcbiAgICAgICAgICBbY3RhYmxlXTogY2NvbmZpZyxcbiAgICAgICAgfSksXG4gICAgICAgIHt9LFxuICAgICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgX2ZpbmRSZWxhdGlvbk9iamVjdChyZWxOYW1lOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHRhYmxlID0gdGhpcy5fY29uZmlnLnRhYmxlO1xuICAgIGlmICghdGFibGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gdGFibGUgaW5mb3JtYXRpb24gcHJvdmlkZWQgaW4gdGhlIHF1ZXJ5Jyk7XG4gICAgfVxuICAgIHRoaXMuX2xvZ2dlci5kZWJ1ZyhcbiAgICAgIGBmaW5kaW5nIHRhYmxlIGZvciByZWxhdGlvbiBcIiR7cmVsTmFtZX1cIiBpbiBcIiR7dGFibGV9XCIuLi5gLFxuICAgICk7XG4gICAgY29uc3Qgc29iamVjdCA9IGF3YWl0IHRoaXMuX2Nvbm4uZGVzY3JpYmUkKHRhYmxlKTtcbiAgICBjb25zdCB1cHBlclJuYW1lID0gcmVsTmFtZS50b1VwcGVyQ2FzZSgpO1xuICAgIGZvciAoY29uc3QgY3Igb2Ygc29iamVjdC5jaGlsZFJlbGF0aW9uc2hpcHMpIHtcbiAgICAgIGlmIChcbiAgICAgICAgKGNyLnJlbGF0aW9uc2hpcE5hbWUgfHwgJycpLnRvVXBwZXJDYXNlKCkgPT09IHVwcGVyUm5hbWUgJiZcbiAgICAgICAgY3IuY2hpbGRTT2JqZWN0XG4gICAgICApIHtcbiAgICAgICAgcmV0dXJuIGNyLmNoaWxkU09iamVjdDtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGBObyBjaGlsZCByZWxhdGlvbnNoaXAgZm91bmQ6ICR7cmVsTmFtZX1gKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgX2V4cGFuZEFzdGVyaXNrRmllbGRzKFxuICAgIHNvYmplY3Q6IHN0cmluZyxcbiAgICBmaWVsZHM6IHN0cmluZ1tdLFxuICApOiBQcm9taXNlPHN0cmluZ1tdPiB7XG4gICAgY29uc3QgZXhwYW5kZWRGaWVsZHMgPSBhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgIGZpZWxkcy5tYXAoYXN5bmMgKGZpZWxkKSA9PiB0aGlzLl9leHBhbmRBc3Rlcmlza0ZpZWxkKHNvYmplY3QsIGZpZWxkKSksXG4gICAgKTtcbiAgICByZXR1cm4gZXhwYW5kZWRGaWVsZHMucmVkdWNlKFxuICAgICAgKGVmbGRzOiBzdHJpbmdbXSwgZmxkczogc3RyaW5nW10pOiBzdHJpbmdbXSA9PiBbLi4uZWZsZHMsIC4uLmZsZHNdLFxuICAgICAgW10sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgX2V4cGFuZEFzdGVyaXNrRmllbGQoXG4gICAgc29iamVjdDogc3RyaW5nLFxuICAgIGZpZWxkOiBzdHJpbmcsXG4gICk6IFByb21pc2U8c3RyaW5nW10+IHtcbiAgICB0aGlzLl9sb2dnZXIuZGVidWcoYGV4cGFuZGluZyBmaWVsZCBcIiR7ZmllbGR9XCIgaW4gXCIke3NvYmplY3R9XCIuLi5gKTtcbiAgICBjb25zdCBmcGF0aCA9IGZpZWxkLnNwbGl0KCcuJyk7XG4gICAgaWYgKGZwYXRoW2ZwYXRoLmxlbmd0aCAtIDFdID09PSAnKicpIHtcbiAgICAgIGNvbnN0IHNvID0gYXdhaXQgdGhpcy5fY29ubi5kZXNjcmliZSQoc29iamVjdCk7XG4gICAgICB0aGlzLl9sb2dnZXIuZGVidWcoYHRhYmxlICR7c29iamVjdH0gaGFzIGJlZW4gZGVzY3JpYmVkYCk7XG4gICAgICBpZiAoZnBhdGgubGVuZ3RoID4gMSkge1xuICAgICAgICBjb25zdCBybmFtZSA9IGZwYXRoLnNoaWZ0KCk7XG4gICAgICAgIGZvciAoY29uc3QgZiBvZiBzby5maWVsZHMpIHtcbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICBmLnJlbGF0aW9uc2hpcE5hbWUgJiZcbiAgICAgICAgICAgIHJuYW1lICYmXG4gICAgICAgICAgICBmLnJlbGF0aW9uc2hpcE5hbWUudG9VcHBlckNhc2UoKSA9PT0gcm5hbWUudG9VcHBlckNhc2UoKVxuICAgICAgICAgICkge1xuICAgICAgICAgICAgY29uc3QgcmZpZWxkID0gZjtcbiAgICAgICAgICAgIGNvbnN0IHJlZmVyZW5jZVRvID0gcmZpZWxkLnJlZmVyZW5jZVRvIHx8IFtdO1xuICAgICAgICAgICAgY29uc3QgcnRhYmxlID0gcmVmZXJlbmNlVG8ubGVuZ3RoID09PSAxID8gcmVmZXJlbmNlVG9bMF0gOiAnTmFtZSc7XG4gICAgICAgICAgICBjb25zdCBmcGF0aHMgPSBhd2FpdCB0aGlzLl9leHBhbmRBc3Rlcmlza0ZpZWxkKFxuICAgICAgICAgICAgICBydGFibGUsXG4gICAgICAgICAgICAgIGZwYXRoLmpvaW4oJy4nKSxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByZXR1cm4gZnBhdGhzLm1hcCgoZnApID0+IGAke3JuYW1lfS4ke2ZwfWApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gW107XG4gICAgICB9XG4gICAgICByZXR1cm4gc28uZmllbGRzLm1hcCgoZikgPT4gZi5uYW1lKTtcbiAgICB9XG4gICAgcmV0dXJuIFtmaWVsZF07XG4gIH1cblxuICAvKipcbiAgICogRXhwbGFpbiBwbGFuIGZvciBleGVjdXRpbmcgcXVlcnlcbiAgICovXG4gIGFzeW5jIGV4cGxhaW4oKSB7XG4gICAgY29uc3Qgc29xbCA9IGF3YWl0IHRoaXMudG9TT1FMKCk7XG4gICAgdGhpcy5fbG9nZ2VyLmRlYnVnKGBTT1FMID0gJHtzb3FsfWApO1xuICAgIGNvbnN0IHVybCA9IGAvcXVlcnkvP2V4cGxhaW49JHtlbmNvZGVVUklDb21wb25lbnQoc29xbCl9YDtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFF1ZXJ5RXhwbGFpblJlc3VsdD4odXJsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm4gU09RTCBleHByZXNzaW9uIGZvciB0aGUgcXVlcnlcbiAgICovXG4gIGFzeW5jIHRvU09RTCgpIHtcbiAgICBpZiAodGhpcy5fc29xbCkge1xuICAgICAgcmV0dXJuIHRoaXMuX3NvcWw7XG4gICAgfVxuICAgIGF3YWl0IHRoaXMuX2V4cGFuZEZpZWxkcygpO1xuICAgIHJldHVybiBjcmVhdGVTT1FMKHRoaXMuX2NvbmZpZyk7XG4gIH1cblxuICAvKipcbiAgICogUHJvbWlzZS9BKyBpbnRlcmZhY2VcbiAgICogaHR0cDovL3Byb21pc2VzLWFwbHVzLmdpdGh1Yi5pby9wcm9taXNlcy1zcGVjL1xuICAgKlxuICAgKiBEZWxlZ2F0ZSB0byBkZWZlcnJlZCBwcm9taXNlLCByZXR1cm4gcHJvbWlzZSBpbnN0YW5jZSBmb3IgcXVlcnkgcmVzdWx0XG4gICAqL1xuICB0aGVuPFUsIFY+KFxuICAgIG9uUmVzb2x2ZT86XG4gICAgICB8ICgocXI6IFF1ZXJ5UmVzcG9uc2U8UiwgUVJUPikgPT4gVSB8IFByb21pc2U8VT4pXG4gICAgICB8IG51bGxcbiAgICAgIHwgdW5kZWZpbmVkLFxuICAgIG9uUmVqZWN0PzogKChlcnI6IEVycm9yKSA9PiBWIHwgUHJvbWlzZTxWPikgfCBudWxsIHwgdW5kZWZpbmVkLFxuICApOiBQcm9taXNlPFUgfCBWPiB7XG4gICAgdGhpcy5fY2hhaW5pbmcgPSB0cnVlO1xuICAgIGlmICghdGhpcy5fZmluaXNoZWQgJiYgIXRoaXMuX2V4ZWN1dGVkKSB7XG4gICAgICB0aGlzLmV4ZWN1dGUoKTtcbiAgICB9XG4gICAgaWYgKCF0aGlzLl9wcm9taXNlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdpbnZhbGlkIHN0YXRlOiBwcm9taXNlIGlzIG5vdCBzZXQgYWZ0ZXIgcXVlcnkgZXhlY3V0aW9uJyxcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9wcm9taXNlLnRoZW4ob25SZXNvbHZlLCBvblJlamVjdCk7XG4gIH1cblxuICBjYXRjaChcbiAgICBvblJlamVjdDogKFxuICAgICAgZXJyOiBFcnJvcixcbiAgICApID0+IFF1ZXJ5UmVzcG9uc2U8UiwgUVJUPiB8IFByb21pc2U8UXVlcnlSZXNwb25zZTxSLCBRUlQ+PixcbiAgKTogUHJvbWlzZTxRdWVyeVJlc3BvbnNlPFIsIFFSVD4+IHtcbiAgICByZXR1cm4gdGhpcy50aGVuKG51bGwsIG9uUmVqZWN0KTtcbiAgfVxuXG4gIHByb21pc2UoKTogUHJvbWlzZTxRdWVyeVJlc3BvbnNlPFIsIFFSVD4+IHtcbiAgICAvLyBUT0RPKGNyaXN0aWFuKTogdmVyaWZ5IHRoaXMgaXMgY29ycmVjdFxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKHRoaXMgYXMgdW5rbm93bikgYXMgUXVlcnlSZXNwb25zZTxSLCBRUlQ+KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWxrIGRlbGV0ZSBxdWVyaWVkIHJlY29yZHNcbiAgICovXG4gIGRlc3Ryb3kob3B0aW9ucz86IFF1ZXJ5RGVzdHJveU9wdGlvbnMpOiBQcm9taXNlPFNhdmVSZXN1bHRbXT47XG4gIGRlc3Ryb3kodHlwZTogTiwgb3B0aW9ucz86IFF1ZXJ5RGVzdHJveU9wdGlvbnMpOiBQcm9taXNlPFNhdmVSZXN1bHRbXT47XG4gIGRlc3Ryb3kodHlwZT86IE4gfCBRdWVyeURlc3Ryb3lPcHRpb25zLCBvcHRpb25zPzogUXVlcnlEZXN0cm95T3B0aW9ucykge1xuICAgIGlmICh0eXBlb2YgdHlwZSA9PT0gJ29iamVjdCcgJiYgdHlwZSAhPT0gbnVsbCkge1xuICAgICAgb3B0aW9ucyA9IHR5cGU7XG4gICAgICB0eXBlID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgICBjb25zdCB0eXBlXzogT3B0aW9uYWw8Tj4gPSB0eXBlIHx8ICh0aGlzLl9jb25maWcudGFibGUgYXMgT3B0aW9uYWw8Tj4pO1xuICAgIGlmICghdHlwZV8pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgJ1NPUUwgYmFzZWQgcXVlcnkgbmVlZHMgU09iamVjdCB0eXBlIGluZm9ybWF0aW9uIHRvIGJ1bGsgZGVsZXRlLicsXG4gICAgICApO1xuICAgIH1cbiAgICAvLyBTZXQgdGhlIHRocmVzaG9sZCBudW1iZXIgdG8gcGFzcyB0byBidWxrIEFQSVxuICAgIGNvbnN0IHRocmVzaG9sZE51bSA9XG4gICAgICBvcHRpb25zLmFsbG93QnVsayA9PT0gZmFsc2VcbiAgICAgICAgPyAtMVxuICAgICAgICA6IHR5cGVvZiBvcHRpb25zLmJ1bGtUaHJlc2hvbGQgPT09ICdudW1iZXInXG4gICAgICAgID8gb3B0aW9ucy5idWxrVGhyZXNob2xkXG4gICAgICAgIDogLy8gZGV0ZXJtaW5lIHRocmVzaG9sZCBpZiB0aGUgY29ubmVjdGlvbiB2ZXJzaW9uIHN1cHBvcnRzIFNPYmplY3QgY29sbGVjdGlvbiBBUEkgb3Igbm90XG4gICAgICAgIHRoaXMuX2Nvbm4uX2Vuc3VyZVZlcnNpb24oNDIpXG4gICAgICAgID8gREVGQVVMVF9CVUxLX1RIUkVTSE9MRFxuICAgICAgICA6IHRoaXMuX2Nvbm4uX21heFJlcXVlc3QgLyAyO1xuXG4gICAgY29uc3QgYnVsa0FwaVZlcnNpb24gPSBvcHRpb25zLmJ1bGtBcGlWZXJzaW9uID8/IERFRkFVTFRfQlVMS19BUElfVkVSU0lPTjtcblxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBjb25zdCBjcmVhdGVCYXRjaCA9ICgpID0+XG4gICAgICAgIHRoaXMuX2Nvbm5cbiAgICAgICAgICAuc29iamVjdCh0eXBlXylcbiAgICAgICAgICAuZGVsZXRlQnVsaygpXG4gICAgICAgICAgLm9uKCdyZXNwb25zZScsIHJlc29sdmUpXG4gICAgICAgICAgLm9uKCdlcnJvcicsIHJlamVjdCk7XG4gICAgICBsZXQgcmVjb3JkczogUmVjb3JkW10gPSBbXTtcbiAgICAgIGxldCBiYXRjaDogUmV0dXJuVHlwZTx0eXBlb2YgY3JlYXRlQmF0Y2g+IHwgbnVsbCA9IG51bGw7XG4gICAgICBjb25zdCBoYW5kbGVSZWNvcmQgPSAocmVjOiBSZWNvcmQpID0+IHtcbiAgICAgICAgaWYgKCFyZWMuSWQpIHtcbiAgICAgICAgICBjb25zdCBlcnIgPSBuZXcgRXJyb3IoXG4gICAgICAgICAgICAnUXVlcmllZCByZWNvcmQgZG9lcyBub3QgaW5jbHVkZSBTYWxlc2ZvcmNlIHJlY29yZCBJRC4nLFxuICAgICAgICAgICk7XG4gICAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlY29yZDogUmVjb3JkID0geyBJZDogcmVjLklkIH07XG4gICAgICAgIGlmIChiYXRjaCkge1xuICAgICAgICAgIGJhdGNoLndyaXRlKHJlY29yZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVjb3Jkcy5wdXNoKHJlY29yZCk7XG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgdGhyZXNob2xkTnVtID49IDAgJiZcbiAgICAgICAgICAgIHJlY29yZHMubGVuZ3RoID4gdGhyZXNob2xkTnVtICYmXG4gICAgICAgICAgICBidWxrQXBpVmVyc2lvbiA9PT0gMVxuICAgICAgICAgICkge1xuICAgICAgICAgICAgLy8gVXNlIGJ1bGsgZGVsZXRlIGluc3RlYWQgb2YgU09iamVjdCBSRVNUIEFQSVxuICAgICAgICAgICAgYmF0Y2ggPSBjcmVhdGVCYXRjaCgpO1xuICAgICAgICAgICAgZm9yIChjb25zdCByZWNvcmQgb2YgcmVjb3Jkcykge1xuICAgICAgICAgICAgICBiYXRjaC53cml0ZShyZWNvcmQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVjb3JkcyA9IFtdO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IGhhbmRsZUVuZCA9ICgpID0+IHtcbiAgICAgICAgaWYgKGJhdGNoKSB7XG4gICAgICAgICAgYmF0Y2guZW5kKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgaWRzID0gcmVjb3Jkcy5tYXAoKHJlY29yZCkgPT4gcmVjb3JkLklkIGFzIHN0cmluZyk7XG4gICAgICAgICAgaWYgKHJlY29yZHMubGVuZ3RoID4gdGhyZXNob2xkTnVtICYmIGJ1bGtBcGlWZXJzaW9uID09PSAyKSB7XG4gICAgICAgICAgICB0aGlzLl9jb25uLmJ1bGsyXG4gICAgICAgICAgICAgIC5sb2FkQW5kV2FpdEZvclJlc3VsdHMoe1xuICAgICAgICAgICAgICAgIG9iamVjdDogdHlwZV8sXG4gICAgICAgICAgICAgICAgb3BlcmF0aW9uOiAnZGVsZXRlJyxcbiAgICAgICAgICAgICAgICBpbnB1dDogcmVjb3JkcyxcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLnRoZW4oXG4gICAgICAgICAgICAgICAgKGFsbFJlc3VsdHMpID0+XG4gICAgICAgICAgICAgICAgICByZXNvbHZlKHRoaXMubWFwQnVsa1YyUmVzdWx0c1RvU2F2ZVJlc3VsdHMoYWxsUmVzdWx0cykpLFxuICAgICAgICAgICAgICAgIHJlamVjdCxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5fY29ublxuICAgICAgICAgICAgICAuc29iamVjdCh0eXBlXylcbiAgICAgICAgICAgICAgLmRlc3Ryb3koaWRzLCB7IGFsbG93UmVjdXJzaXZlOiB0cnVlIH0pXG4gICAgICAgICAgICAgIC50aGVuKHJlc29sdmUsIHJlamVjdCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgdGhpcy5zdHJlYW0oJ3JlY29yZCcpXG4gICAgICAgIC5vbignZGF0YScsIGhhbmRsZVJlY29yZClcbiAgICAgICAgLm9uKCdlbmQnLCBoYW5kbGVFbmQpXG4gICAgICAgIC5vbignZXJyb3InLCByZWplY3QpO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgUXVlcnkjZGVzdHJveSgpXG4gICAqL1xuICBkZWxldGUgPSB0aGlzLmRlc3Ryb3k7XG5cbiAgLyoqXG4gICAqIFN5bm9ueW0gb2YgUXVlcnkjZGVzdHJveSgpXG4gICAqL1xuICBkZWwgPSB0aGlzLmRlc3Ryb3k7XG5cbiAgLyoqXG4gICAqIEJ1bGsgdXBkYXRlIHF1ZXJpZWQgcmVjb3JkcywgdXNpbmcgZ2l2ZW4gbWFwcGluZyBmdW5jdGlvbi9vYmplY3RcbiAgICovXG4gIHVwZGF0ZTxVUiBleHRlbmRzIFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPj4oXG4gICAgbWFwcGluZzogKChyZWM6IFIpID0+IFVSKSB8IFVSLFxuICAgIHR5cGU6IE4sXG4gICAgb3B0aW9ucz86IFF1ZXJ5VXBkYXRlT3B0aW9ucyxcbiAgKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+O1xuICB1cGRhdGU8VVIgZXh0ZW5kcyBTT2JqZWN0SW5wdXRSZWNvcmQ8UywgTj4+KFxuICAgIG1hcHBpbmc6ICgocmVjOiBSKSA9PiBVUikgfCBVUixcbiAgICBvcHRpb25zPzogUXVlcnlVcGRhdGVPcHRpb25zLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHRbXT47XG4gIHVwZGF0ZTxVUiBleHRlbmRzIFNPYmplY3RJbnB1dFJlY29yZDxTLCBOPj4oXG4gICAgbWFwcGluZzogKChyZWM6IFIpID0+IFVSKSB8IFVSLFxuICAgIHR5cGU/OiBOIHwgUXVlcnlVcGRhdGVPcHRpb25zLFxuICAgIG9wdGlvbnM/OiBRdWVyeVVwZGF0ZU9wdGlvbnMsXG4gICkge1xuICAgIGlmICh0eXBlb2YgdHlwZSA9PT0gJ29iamVjdCcgJiYgdHlwZSAhPT0gbnVsbCkge1xuICAgICAgb3B0aW9ucyA9IHR5cGU7XG4gICAgICB0eXBlID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgICBjb25zdCB0eXBlXzogT3B0aW9uYWw8Tj4gPVxuICAgICAgdHlwZSB8fCAodGhpcy5fY29uZmlnICYmICh0aGlzLl9jb25maWcudGFibGUgYXMgT3B0aW9uYWw8Tj4pKTtcbiAgICBpZiAoIXR5cGVfKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdTT1FMIGJhc2VkIHF1ZXJ5IG5lZWRzIFNPYmplY3QgdHlwZSBpbmZvcm1hdGlvbiB0byBidWxrIHVwZGF0ZS4nLFxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgdXBkYXRlU3RyZWFtID1cbiAgICAgIHR5cGVvZiBtYXBwaW5nID09PSAnZnVuY3Rpb24nXG4gICAgICAgID8gUmVjb3JkU3RyZWFtLm1hcChtYXBwaW5nKVxuICAgICAgICA6IFJlY29yZFN0cmVhbS5yZWNvcmRNYXBTdHJlYW0obWFwcGluZywgb3B0aW9ucy5za2lwUmVjb3JkVGVtcGxhdGVFdmFsKTtcbiAgICAvLyBTZXQgdGhlIHRocmVzaG9sZCBudW1iZXIgdG8gcGFzcyB0byBidWxrIEFQSVxuICAgIGNvbnN0IHRocmVzaG9sZE51bSA9XG4gICAgICBvcHRpb25zLmFsbG93QnVsayA9PT0gZmFsc2VcbiAgICAgICAgPyAtMVxuICAgICAgICA6IHR5cGVvZiBvcHRpb25zLmJ1bGtUaHJlc2hvbGQgPT09ICdudW1iZXInXG4gICAgICAgID8gb3B0aW9ucy5idWxrVGhyZXNob2xkXG4gICAgICAgIDogLy8gZGV0ZXJtaW5lIHRocmVzaG9sZCBpZiB0aGUgY29ubmVjdGlvbiB2ZXJzaW9uIHN1cHBvcnRzIFNPYmplY3QgY29sbGVjdGlvbiBBUEkgb3Igbm90XG4gICAgICAgIHRoaXMuX2Nvbm4uX2Vuc3VyZVZlcnNpb24oNDIpXG4gICAgICAgID8gREVGQVVMVF9CVUxLX1RIUkVTSE9MRFxuICAgICAgICA6IHRoaXMuX2Nvbm4uX21heFJlcXVlc3QgLyAyO1xuICAgIGNvbnN0IGJ1bGtBcGlWZXJzaW9uID0gb3B0aW9ucy5idWxrQXBpVmVyc2lvbiA/PyBERUZBVUxUX0JVTEtfQVBJX1ZFUlNJT047XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IGNyZWF0ZUJhdGNoID0gKCkgPT5cbiAgICAgICAgdGhpcy5fY29ublxuICAgICAgICAgIC5zb2JqZWN0KHR5cGVfKVxuICAgICAgICAgIC51cGRhdGVCdWxrKClcbiAgICAgICAgICAub24oJ3Jlc3BvbnNlJywgcmVzb2x2ZSlcbiAgICAgICAgICAub24oJ2Vycm9yJywgcmVqZWN0KTtcbiAgICAgIGxldCByZWNvcmRzOiBBcnJheTxTT2JqZWN0VXBkYXRlUmVjb3JkPFMsIE4+PiA9IFtdO1xuICAgICAgbGV0IGJhdGNoOiBSZXR1cm5UeXBlPHR5cGVvZiBjcmVhdGVCYXRjaD4gfCBudWxsID0gbnVsbDtcbiAgICAgIGNvbnN0IGhhbmRsZVJlY29yZCA9IChyZWNvcmQ6IFJlY29yZCkgPT4ge1xuICAgICAgICBpZiAoYmF0Y2gpIHtcbiAgICAgICAgICBiYXRjaC53cml0ZShyZWNvcmQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlY29yZHMucHVzaChyZWNvcmQgYXMgU09iamVjdFVwZGF0ZVJlY29yZDxTLCBOPik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKFxuICAgICAgICAgIHRocmVzaG9sZE51bSA+PSAwICYmXG4gICAgICAgICAgcmVjb3Jkcy5sZW5ndGggPiB0aHJlc2hvbGROdW0gJiZcbiAgICAgICAgICBidWxrQXBpVmVyc2lvbiA9PT0gMVxuICAgICAgICApIHtcbiAgICAgICAgICAvLyBVc2UgYnVsayB1cGRhdGUgaW5zdGVhZCBvZiBTT2JqZWN0IFJFU1QgQVBJXG4gICAgICAgICAgYmF0Y2ggPSBjcmVhdGVCYXRjaCgpO1xuICAgICAgICAgIGZvciAoY29uc3QgcmVjb3JkIG9mIHJlY29yZHMpIHtcbiAgICAgICAgICAgIGJhdGNoLndyaXRlKHJlY29yZCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJlY29yZHMgPSBbXTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IGhhbmRsZUVuZCA9ICgpID0+IHtcbiAgICAgICAgaWYgKGJhdGNoKSB7XG4gICAgICAgICAgYmF0Y2guZW5kKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKHJlY29yZHMubGVuZ3RoID4gdGhyZXNob2xkTnVtICYmIGJ1bGtBcGlWZXJzaW9uID09PSAyKSB7XG4gICAgICAgICAgICB0aGlzLl9jb25uLmJ1bGsyXG4gICAgICAgICAgICAgIC5sb2FkQW5kV2FpdEZvclJlc3VsdHMoe1xuICAgICAgICAgICAgICAgIG9iamVjdDogdHlwZV8sXG4gICAgICAgICAgICAgICAgb3BlcmF0aW9uOiAndXBkYXRlJyxcbiAgICAgICAgICAgICAgICBpbnB1dDogcmVjb3JkcyxcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLnRoZW4oXG4gICAgICAgICAgICAgICAgKGFsbFJlc3VsdHMpID0+XG4gICAgICAgICAgICAgICAgICByZXNvbHZlKHRoaXMubWFwQnVsa1YyUmVzdWx0c1RvU2F2ZVJlc3VsdHMoYWxsUmVzdWx0cykpLFxuICAgICAgICAgICAgICAgIHJlamVjdCxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5fY29ublxuICAgICAgICAgICAgICAuc29iamVjdCh0eXBlXylcbiAgICAgICAgICAgICAgLnVwZGF0ZShyZWNvcmRzLCB7IGFsbG93UmVjdXJzaXZlOiB0cnVlIH0pXG4gICAgICAgICAgICAgIC50aGVuKHJlc29sdmUsIHJlamVjdCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgdGhpcy5zdHJlYW0oJ3JlY29yZCcpXG4gICAgICAgIC5vbignZXJyb3InLCByZWplY3QpXG4gICAgICAgIC5waXBlKHVwZGF0ZVN0cmVhbSlcbiAgICAgICAgLm9uKCdkYXRhJywgaGFuZGxlUmVjb3JkKVxuICAgICAgICAub24oJ2VuZCcsIGhhbmRsZUVuZClcbiAgICAgICAgLm9uKCdlcnJvcicsIHJlamVjdCk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIG1hcEJ1bGtWMlJlc3VsdHNUb1NhdmVSZXN1bHRzKFxuICAgIGJ1bGtKb2JBbGxSZXN1bHRzOiBJbmdlc3RKb2JWMlJlc3VsdHM8Uz4sXG4gICk6IFNhdmVSZXN1bHRbXSB7XG4gICAgY29uc3Qgc3VjY2Vzc1NhdmVSZXN1bHRzOiBTYXZlUmVzdWx0W10gPSBidWxrSm9iQWxsUmVzdWx0cy5zdWNjZXNzZnVsUmVzdWx0cy5tYXAoXG4gICAgICAocikgPT4ge1xuICAgICAgICBjb25zdCBzYXZlUmVzdWx0OiBTYXZlUmVzdWx0ID0ge1xuICAgICAgICAgIGlkOiByLnNmX19JZCxcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgIGVycm9yczogW10sXG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBzYXZlUmVzdWx0O1xuICAgICAgfSxcbiAgICApO1xuXG4gICAgY29uc3QgZmFpbGVkU2F2ZVJlc3VsdHMgPSBidWxrSm9iQWxsUmVzdWx0cy5mYWlsZWRSZXN1bHRzLm1hcCgocikgPT4ge1xuICAgICAgY29uc3Qgc2F2ZVJlc3VsdDogU2F2ZVJlc3VsdCA9IHtcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIGVycm9yczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGVycm9yQ29kZTogci5zZl9fRXJyb3IsXG4gICAgICAgICAgICBtZXNzYWdlOiByLnNmX19FcnJvcixcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfTtcbiAgICAgIHJldHVybiBzYXZlUmVzdWx0O1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIFsuLi5zdWNjZXNzU2F2ZVJlc3VsdHMsIC4uLmZhaWxlZFNhdmVSZXN1bHRzXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBGZXRjaGVzIGFsbCByZWNvcmRzIGZvciBhIHN1YnF1ZXJ5IGZpZWxkIGJ5IGZvbGxvd2luZyBuZXh0UmVjb3Jkc1VybFxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBfZmV0Y2hBbGxTdWJxdWVyeVJlY29yZHMoXG4gICAgcmVjb3JkOiBSZWNvcmQsXG4gICAgZmllbGROYW1lOiBzdHJpbmcsXG4gICAgaGVhZGVyczogeyBbbmFtZTogc3RyaW5nXTogc3RyaW5nIH0sXG4gICk6IFByb21pc2U8UmVjb3JkW10+IHtcbiAgICBjb25zdCBzdWJxdWVyeUZpZWxkID0gcmVjb3JkW2ZpZWxkTmFtZV0gYXMgUXVlcnlSZXN1bHQ8UmVjb3JkPjtcbiAgICBpZiAoIXN1YnF1ZXJ5RmllbGQgfHwgIXN1YnF1ZXJ5RmllbGQucmVjb3Jkcykge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cblxuICAgIGxldCBhbGxSZWNvcmRzID0gWy4uLnN1YnF1ZXJ5RmllbGQucmVjb3Jkc107XG4gICAgbGV0IG5leHRSZWNvcmRzVXJsID0gc3VicXVlcnlGaWVsZC5uZXh0UmVjb3Jkc1VybDtcblxuICAgIHdoaWxlIChuZXh0UmVjb3Jkc1VybCkge1xuICAgICAgLy8gV2hlbiBmb2xsb3dpbmcgbmV4dFJlY29yZHNVcmwgZm9yIGEgc3VicXVlcnksIHdlIG5lZWQgdG8gcHJlc2VydmUgdGhlIHJlbGF0aW9uc2hpcCBjb250ZXh0XG4gICAgICAvLyBieSB1c2luZyB0aGUgZnVsbCBVUkwgYXMtaXMgcmF0aGVyIHRoYW4gdHJ5aW5nIHRvIHJlY29uc3RydWN0IGl0XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgdGhpcy5fY29ubi5yZXF1ZXN0PFF1ZXJ5UmVzdWx0PFJlY29yZD4+KHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgdXJsOiBuZXh0UmVjb3Jkc1VybCwgLy8gVXNlIHRoZSBmdWxsIFVSTCBhcyBwcm92aWRlZCBieSBTYWxlc2ZvcmNlXG4gICAgICAgIGhlYWRlcnNcbiAgICAgIH0pO1xuXG4gICAgICBhbGxSZWNvcmRzID0gYWxsUmVjb3Jkcy5jb25jYXQoZGF0YS5yZWNvcmRzKTtcbiAgICAgIG5leHRSZWNvcmRzVXJsID0gZGF0YS5uZXh0UmVjb3Jkc1VybDtcbiAgICB9XG5cbiAgICByZXR1cm4gYWxsUmVjb3JkcztcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBTdWJRdWVyeSBvYmplY3QgZm9yIHJlcHJlc2VudGluZyBjaGlsZCByZWxhdGlvbnNoaXAgcXVlcnlcbiAqL1xuZXhwb3J0IGNsYXNzIFN1YlF1ZXJ5PFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBQTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPixcbiAgUFIgZXh0ZW5kcyBSZWNvcmQsXG4gIFBRUlQgZXh0ZW5kcyBRdWVyeVJlc3BvbnNlVGFyZ2V0LFxuICBDUk4gZXh0ZW5kcyBDaGlsZFJlbGF0aW9uc2hpcE5hbWVzPFMsIFBOPiA9IENoaWxkUmVsYXRpb25zaGlwTmFtZXM8UywgUE4+LFxuICBDTiBleHRlbmRzIFNPYmplY3ROYW1lczxTPiA9IENoaWxkUmVsYXRpb25zaGlwU09iamVjdE5hbWU8UywgUE4sIENSTj4sXG4gIENSIGV4dGVuZHMgUmVjb3JkID0gUmVjb3JkXG4+IHtcbiAgX3JlbE5hbWU6IENSTjtcbiAgX3F1ZXJ5OiBRdWVyeTxTLCBDTiwgQ1I+O1xuICBfcGFyZW50OiBRdWVyeTxTLCBQTiwgUFIsIFBRUlQ+O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoXG4gICAgY29ubjogQ29ubmVjdGlvbjxTPixcbiAgICByZWxOYW1lOiBDUk4sXG4gICAgY29uZmlnOiBRdWVyeUNvbmZpZzxTLCBDTj4sXG4gICAgcGFyZW50OiBRdWVyeTxTLCBQTiwgUFIsIFBRUlQ+LFxuICApIHtcbiAgICB0aGlzLl9yZWxOYW1lID0gcmVsTmFtZTtcbiAgICB0aGlzLl9xdWVyeSA9IG5ldyBRdWVyeShjb25uLCBjb25maWcpO1xuICAgIHRoaXMuX3BhcmVudCA9IHBhcmVudDtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgc2VsZWN0PFxuICAgIFIgZXh0ZW5kcyBSZWNvcmQgPSBSZWNvcmQsXG4gICAgRlAgZXh0ZW5kcyBGaWVsZFBhdGhTcGVjaWZpZXI8UywgQ04+ID0gRmllbGRQYXRoU3BlY2lmaWVyPFMsIENOPixcbiAgICBGUEMgZXh0ZW5kcyBGaWVsZFByb2plY3Rpb25Db25maWcgPSBGaWVsZFBhdGhTY29wZWRQcm9qZWN0aW9uPFMsIENOLCBGUD5cbiAgPihcbiAgICBmaWVsZHM6IFF1ZXJ5RmllbGQ8UywgQ04sIEZQPixcbiAgKTogU3ViUXVlcnk8UywgUE4sIFBSLCBQUVJULCBDUk4sIENOLCBTT2JqZWN0UmVjb3JkPFMsIENOLCBGUEMsIFI+PiB7XG4gICAgLy8gZm9yY2UgY29udmVydCBxdWVyeSByZWNvcmQgdHlwZSB3aXRob3V0IGNoYW5naW5nIGluc3RhbmNlXG4gICAgdGhpcy5fcXVlcnkgPSB0aGlzLl9xdWVyeS5zZWxlY3QoZmllbGRzKSBhcyBhbnk7XG4gICAgcmV0dXJuICh0aGlzIGFzIGFueSkgYXMgU3ViUXVlcnk8XG4gICAgICBTLFxuICAgICAgUE4sXG4gICAgICBQUixcbiAgICAgIFBRUlQsXG4gICAgICBDUk4sXG4gICAgICBDTixcbiAgICAgIFNPYmplY3RSZWNvcmQ8UywgQ04sIEZQQywgUj5cbiAgICA+O1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICB3aGVyZShjb25kaXRpb25zOiBRdWVyeUNvbmRpdGlvbjxTLCBDTj4gfCBzdHJpbmcpOiB0aGlzIHtcbiAgICB0aGlzLl9xdWVyeSA9IHRoaXMuX3F1ZXJ5LndoZXJlKGNvbmRpdGlvbnMpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIExpbWl0IHRoZSByZXR1cm5pbmcgcmVzdWx0XG4gICAqL1xuICBsaW1pdChsaW1pdDogbnVtYmVyKSB7XG4gICAgdGhpcy5fcXVlcnkgPSB0aGlzLl9xdWVyeS5saW1pdChsaW1pdCk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogU2tpcCByZWNvcmRzXG4gICAqL1xuICBza2lwKG9mZnNldDogbnVtYmVyKSB7XG4gICAgdGhpcy5fcXVlcnkgPSB0aGlzLl9xdWVyeS5za2lwKG9mZnNldCk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogU3lub255bSBvZiBTdWJRdWVyeSNza2lwKClcbiAgICovXG4gIG9mZnNldCA9IHRoaXMuc2tpcDtcblxuICAvKipcbiAgICogU2V0IHF1ZXJ5IHNvcnQgd2l0aCBkaXJlY3Rpb25cbiAgICovXG4gIHNvcnQoc29ydDogUXVlcnlTb3J0PFMsIENOPik6IHRoaXM7XG4gIHNvcnQoc29ydDogc3RyaW5nfCBTT2JqZWN0RmllbGROYW1lczxTLCBDTj4sIGRpcjogU29ydERpcik6IHRoaXM7XG4gIHNvcnQoXG4gICAgc29ydDogUXVlcnlTb3J0PFMsIENOPiB8IFNPYmplY3RGaWVsZE5hbWVzPFMsIENOPiB8IHN0cmluZyxcbiAgICBkaXI/OiBTb3J0RGlyLFxuICApIHtcbiAgICB0aGlzLl9xdWVyeSA9IHRoaXMuX3F1ZXJ5LnNvcnQoc29ydCBhcyBhbnksIGRpciBhcyBTb3J0RGlyKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIFN1YlF1ZXJ5I3NvcnQoKVxuICAgKi9cbiAgb3JkZXJieTogdHlwZW9mIFN1YlF1ZXJ5LnByb3RvdHlwZS5zb3J0ID0gdGhpcy5zb3J0O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgYXN5bmMgX2V4cGFuZEZpZWxkcygpIHtcbiAgICBjb25zdCBzb2JqZWN0ID0gYXdhaXQgdGhpcy5fcGFyZW50Ll9maW5kUmVsYXRpb25PYmplY3QodGhpcy5fcmVsTmFtZSk7XG4gICAgcmV0dXJuIHRoaXMuX3F1ZXJ5Ll9leHBhbmRGaWVsZHMoc29iamVjdCk7XG4gIH1cblxuICAvKipcbiAgICogQmFjayB0aGUgY29udGV4dCB0byBwYXJlbnQgcXVlcnkgb2JqZWN0XG4gICAqL1xuICBlbmQ8XG4gICAgQ1JQIGV4dGVuZHMgU09iamVjdENoaWxkUmVsYXRpb25zaGlwUHJvcDxcbiAgICAgIENSTixcbiAgICAgIENSXG4gICAgPiA9IFNPYmplY3RDaGlsZFJlbGF0aW9uc2hpcFByb3A8Q1JOLCBDUj4sXG4gICAgUFIxIGV4dGVuZHMgUmVjb3JkID0gUFIgJiBDUlBcbiAgPigpOiBRdWVyeTxTLCBQTiwgUFIxLCBQUVJUPiB7XG4gICAgcmV0dXJuICh0aGlzLl9wYXJlbnQgYXMgYW55KSBhcyBRdWVyeTxTLCBQTiwgUFIxLCBQUVJUPjtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBRdWVyeTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsWUFBWSxRQUFRLFFBQVE7QUFDckMsU0FBaUJDLFNBQVMsUUFBUSxlQUFlO0FBQ2pELE9BQU9DLFlBQVksSUFBSUMsWUFBWSxRQUFRLGlCQUFpQjtBQUU1RCxTQUFTQyxVQUFVLFFBQVEsZ0JBQWdCOztBQXdCM0M7QUFDQTtBQUNBOztBQU9BO0FBQ0E7QUFDQTs7QUFxREE7QUFDQTtBQUNBOztBQW1EQSxJQUFNQyxvQkFBb0IsR0FBRyxDQUMzQixhQUFhLEVBQ2IsU0FBUyxFQUNULGNBQWMsRUFDZCxPQUFPLENBQ0M7QUFJVixPQUFPLElBQU1DLGVBRVosR0FBR0MsdUJBQUEsQ0FBQUYsb0JBQW9CLEVBQUFHLElBQUEsQ0FBcEJILG9CQUFvQixFQUN0QixVQUFDSSxNQUFNLEVBQUVDLE1BQU07RUFBQSxPQUFBQyxhQUFBLENBQUFBLGFBQUEsS0FBV0YsTUFBTSxPQUFBRyxlQUFBLEtBQUdGLE1BQU0sRUFBR0EsTUFBTTtBQUFBLENBQUcsRUFDckQsQ0FBQyxDQUdILENBQUM7O0FBV1c7O0FBb0JaO0FBQ0E7QUFDQTtBQUNBLElBQU1HLHNCQUFzQixHQUFHLEdBQUc7QUFDbEMsSUFBTUMsd0JBQXdCLEdBQUcsQ0FBQzs7QUFFbEM7QUFDQTtBQUNBO0FBQ0EsV0FBYUMsS0FBSywwQkFBQUMsYUFBQTtFQXlCaEI7QUFDRjtBQUNBO0VBQ0UsU0FBQUQsTUFDRUUsSUFBbUIsRUFDbkJDLE1BQXdELEVBQ3hEQyxPQUErQixFQUMvQjtJQUFBLElBQUFDLEtBQUE7SUFBQUMsZUFBQSxPQUFBTixLQUFBO0lBQ0FLLEtBQUEsR0FBQUUsVUFBQSxPQUFBUCxLQUFBO0lBQVFILGVBQUEsQ0FBQVEsS0FBQSxhQXJCaUIsQ0FBQyxDQUFDO0lBQUFSLGVBQUEsQ0FBQVEsS0FBQSxlQUM2QixFQUFFO0lBQUFSLGVBQUEsQ0FBQVEsS0FBQSxlQUV2QyxLQUFLO0lBQUFSLGVBQUEsQ0FBQVEsS0FBQSxlQUNMLEtBQUs7SUFBQVIsZUFBQSxDQUFBUSxLQUFBLGVBQ0wsS0FBSztJQUFBUixlQUFBLENBQUFRLEtBQUEsZUFJZCxDQUFDO0lBQUFSLGVBQUEsQ0FBQVEsS0FBQSxrQkFDRSxDQUFDO0lBQUFSLGVBQUEsQ0FBQVEsS0FBQSxhQUNELEVBQUU7SUE2SWpCO0FBQ0Y7QUFDQTtJQUZFUixlQUFBLENBQUFRLEtBQUEsWUFHU0EsS0FBQSxDQUFLRyxJQUFJO0lBd0JsQjtBQUNGO0FBQ0E7SUFGRVgsZUFBQSxDQUFBUSxLQUFBLGFBQUFJLHFCQUFBLENBQUFKLEtBQUE7SUE4TEE7QUFDRjtBQUNBO0lBRkVSLGVBQUEsQ0FBQVEsS0FBQSxVQUdPQSxLQUFBLENBQUtLLE9BQU87SUFFbkI7QUFDRjtBQUNBO0lBRkViLGVBQUEsQ0FBQVEsS0FBQSxTQUdNQSxLQUFBLENBQUtLLE9BQU87SUEyYWxCO0FBQ0Y7QUFDQTtJQUZFYixlQUFBLENBQUFRLEtBQUEsWUFHU0EsS0FBQSxDQUFLTSxPQUFPO0lBRXJCO0FBQ0Y7QUFDQTtJQUZFZCxlQUFBLENBQUFRLEtBQUEsU0FHTUEsS0FBQSxDQUFLTSxPQUFPO0lBdHhCaEJOLEtBQUEsQ0FBS08sS0FBSyxHQUFHVixJQUFJO0lBQ2pCRyxLQUFBLENBQUtRLE9BQU8sR0FBR1gsSUFBSSxDQUFDWSxTQUFTLEdBQ3pCZCxLQUFLLENBQUNhLE9BQU8sQ0FBQ0UsY0FBYyxDQUFDYixJQUFJLENBQUNZLFNBQVMsQ0FBQyxHQUM1Q2QsS0FBSyxDQUFDYSxPQUFPO0lBQ2pCLElBQUksT0FBT1YsTUFBTSxLQUFLLFFBQVEsRUFBRTtNQUM5QkUsS0FBQSxDQUFLVyxLQUFLLEdBQUdiLE1BQU07TUFDbkJFLEtBQUEsQ0FBS1EsT0FBTyxDQUFDSSxLQUFLLG9CQUFBQyxNQUFBLENBQW9CZixNQUFNLENBQUUsQ0FBQztJQUNqRCxDQUFDLE1BQU0sSUFBSSxPQUFRQSxNQUFNLENBQVNnQixPQUFPLEtBQUssUUFBUSxFQUFFO01BQ3RELElBQU1BLE9BQWUsR0FBSWhCLE1BQU0sQ0FBU2dCLE9BQU87TUFDL0NkLEtBQUEsQ0FBS1EsT0FBTyxDQUFDSSxLQUFLLHVCQUFBQyxNQUFBLENBQXVCQyxPQUFPLENBQUUsQ0FBQztNQUNuRGQsS0FBQSxDQUFLZSxRQUFRLEdBQUdDLHlCQUFBLENBQUFGLE9BQU8sRUFBQTFCLElBQUEsQ0FBUDBCLE9BQU8sRUFBVSxHQUFHLENBQUMsR0FDakNkLEtBQUEsQ0FBS2lCLFlBQVksQ0FBQ0gsT0FBTyxDQUFDLEdBQzFCQSxPQUFPO0lBQ2IsQ0FBQyxNQUFNO01BQ0xkLEtBQUEsQ0FBS1EsT0FBTyxDQUFDSSxLQUFLLDJCQUFBQyxNQUFBLENBQTJCSyxlQUFBLENBQWVwQixNQUFNLENBQUMsQ0FBRSxDQUFDO01BQ3RFLElBQUFxQixJQUFBLEdBQStDckIsTUFBTTtRQUE3Q3NCLE9BQU0sR0FBQUQsSUFBQSxDQUFOQyxNQUFNO1FBQUVDLFFBQVEsR0FBQUwseUJBQUEsQ0FBQUcsSUFBQTtRQUFFRyxNQUFJLEdBQUFsQixxQkFBQSxDQUFBZSxJQUFBO1FBQUtJLE9BQU8sR0FBQUMsd0JBQUEsQ0FBQUwsSUFBQSxFQUFBTSxTQUFBO01BSTFDekIsS0FBQSxDQUFLdUIsT0FBTyxHQUFHQSxPQUFPO01BQ3RCdkIsS0FBQSxDQUFLMEIsTUFBTSxDQUFDTixPQUFNLENBQUM7TUFDbkIsSUFBSUMsUUFBUSxFQUFFO1FBQ1pyQixLQUFBLENBQUsyQixlQUFlLENBQUNOLFFBQVEsQ0FBQztNQUNoQztNQUNBLElBQUlDLE1BQUksRUFBRTtRQUNSbEIscUJBQUEsQ0FBQUosS0FBQSxFQUFBWixJQUFBLENBQUFZLEtBQUEsRUFBVXNCLE1BQUksQ0FBQztNQUNqQjtJQUNGO0lBQ0F0QixLQUFBLENBQUs0QixRQUFRLEdBQUFyQyxhQUFBO01BQ1hzQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO01BQ1hDLFFBQVEsRUFBRSxLQUFLO01BQ2ZDLFNBQVMsRUFBRSxLQUFLO01BQ2hCQyxPQUFPLEVBQUUsS0FBSztNQUNkQyxjQUFjLEVBQUU7SUFBYSxHQUN6QmxDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FDRjtJQUNqQjtJQUNBQyxLQUFBLENBQUtrQyxRQUFRLEdBQUcsSUFBQUMsUUFBQSxDQUFZLFVBQUNDLE9BQU8sRUFBRUMsTUFBTSxFQUFLO01BQy9DckMsS0FBQSxDQUFLc0MsRUFBRSxDQUFDLFVBQVUsRUFBRUYsT0FBTyxDQUFDO01BQzVCcEMsS0FBQSxDQUFLc0MsRUFBRSxDQUFDLE9BQU8sRUFBRUQsTUFBTSxDQUFDO0lBQzFCLENBQUMsQ0FBQztJQUNGckMsS0FBQSxDQUFLdUMsT0FBTyxHQUFHLElBQUl4RCxZQUFZLENBQUMsQ0FBQztJQUNqQ2lCLEtBQUEsQ0FBS3NDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsVUFBQ0UsTUFBTTtNQUFBLE9BQUt4QyxLQUFBLENBQUt1QyxPQUFPLENBQUNFLElBQUksQ0FBQ0QsTUFBTSxDQUFDO0lBQUEsRUFBQztJQUN4RHhDLEtBQUEsQ0FBS3NDLEVBQUUsQ0FBQyxLQUFLLEVBQUU7TUFBQSxPQUFNdEMsS0FBQSxDQUFLdUMsT0FBTyxDQUFDRSxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQUEsRUFBQztJQUM3Q3pDLEtBQUEsQ0FBS3NDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBQ0ksR0FBRyxFQUFLO01BQ3hCLElBQUk7UUFDRjFDLEtBQUEsQ0FBS3VDLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDLE9BQU8sRUFBRUQsR0FBRyxDQUFDO01BQ2pDLENBQUMsQ0FBQyxPQUFPRSxDQUFDLEVBQUU7UUFDVjtNQUFBO0lBRUosQ0FBQyxDQUFDO0lBQUMsT0FBQTVDLEtBQUE7RUFDTDs7RUFFQTtBQUNGO0FBQ0E7RUFGRTZDLFNBQUEsQ0FBQWxELEtBQUEsRUFBQUMsYUFBQTtFQUFBLE9BQUFrRCxZQUFBLENBQUFuRCxLQUFBO0lBQUFvRCxHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBdEIsTUFBTUEsQ0FBQSxFQUtzRDtNQUFBLElBQTFETixNQUE0QixHQUFBNkIsU0FBQSxDQUFBQyxNQUFBLFFBQUFELFNBQUEsUUFBQUUsU0FBQSxHQUFBRixTQUFBLE1BQUcsR0FBRztNQUNsQyxJQUFJLElBQUksQ0FBQ3RDLEtBQUssRUFBRTtRQUNkLE1BQU15QyxLQUFLLENBQ1Qsc0VBQ0YsQ0FBQztNQUNIO01BQ0EsU0FBU0MsWUFBWUEsQ0FBQ2pDLE1BQTRCLEVBQVk7UUFBQSxJQUFBa0MsUUFBQSxFQUFBQyxTQUFBLEVBQUFDLFNBQUEsRUFBQUMsU0FBQTtRQUM1RCxPQUFPLE9BQU9yQyxNQUFNLEtBQUssUUFBUSxHQUM3QkEsTUFBTSxDQUFDc0MsS0FBSyxDQUFDLFNBQVMsQ0FBQyxHQUN2QkMsY0FBQSxDQUFjdkMsTUFBTSxDQUFDLEdBQ3JCakMsdUJBQUEsQ0FBQW1FLFFBQUEsR0FBQU0sb0JBQUEsQ0FBQUwsU0FBQSxHQUFDbkMsTUFBTSxFQUFBaEMsSUFBQSxDQUFBbUUsU0FBQSxFQUNBRixZQUFZLENBQUMsRUFBQWpFLElBQUEsQ0FBQWtFLFFBQUEsRUFDQSxVQUFDTyxFQUFFLEVBQUVDLENBQUM7VUFBQSxJQUFBQyxTQUFBO1VBQUEsT0FBQUMsdUJBQUEsQ0FBQUQsU0FBQSxPQUFBM0UsSUFBQSxDQUFBMkUsU0FBQSxFQUFBRSxrQkFBQSxDQUFTSixFQUFFLEdBQUFJLGtCQUFBLENBQUtILENBQUM7UUFBQSxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQ2pEM0UsdUJBQUEsQ0FBQXFFLFNBQUEsR0FBQUksb0JBQUEsQ0FBQUgsU0FBQSxHQUFBUyxlQUFBLENBQWU5QyxNQUFrRCxDQUFDLEVBQUFoQyxJQUFBLENBQUFxRSxTQUFBLEVBQzNELFVBQUFVLEtBQUEsRUFBWTtVQUFBLElBQUFDLEtBQUEsR0FBQUMsY0FBQSxDQUFBRixLQUFBO1lBQVZMLENBQUMsR0FBQU0sS0FBQTtZQUFFRSxDQUFDLEdBQUFGLEtBQUE7VUFDVCxJQUFJLE9BQU9FLENBQUMsS0FBSyxRQUFRLElBQUksT0FBT0EsQ0FBQyxLQUFLLFNBQVMsRUFBRTtZQUNuRCxPQUFPQSxDQUFDLEdBQUcsQ0FBQ1IsQ0FBQyxDQUFDLEdBQUcsRUFBRTtVQUNyQixDQUFDLE1BQU07WUFBQSxJQUFBUyxTQUFBO1lBQ0wsT0FBT1gsb0JBQUEsQ0FBQVcsU0FBQSxHQUFBbEIsWUFBWSxDQUFDaUIsQ0FBQyxDQUFDLEVBQUFsRixJQUFBLENBQUFtRixTQUFBLEVBQUssVUFBQ0MsQ0FBQztjQUFBLElBQUFDLFNBQUE7Y0FBQSxPQUFBVCx1QkFBQSxDQUFBUyxTQUFBLE1BQUE1RCxNQUFBLENBQVFpRCxDQUFDLFFBQUExRSxJQUFBLENBQUFxRixTQUFBLEVBQUlELENBQUM7WUFBQSxDQUFFLENBQUM7VUFDaEQ7UUFDRixDQUFDLENBQUMsRUFBQXBGLElBQUEsQ0FBQW9FLFNBQUEsRUFDZ0IsVUFBQ0ssRUFBRSxFQUFFQyxDQUFDO1VBQUEsSUFBQVksU0FBQTtVQUFBLE9BQUFWLHVCQUFBLENBQUFVLFNBQUEsT0FBQXRGLElBQUEsQ0FBQXNGLFNBQUEsRUFBQVQsa0JBQUEsQ0FBU0osRUFBRSxHQUFBSSxrQkFBQSxDQUFLSCxDQUFDO1FBQUEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztNQUN2RDtNQUNBLElBQUkxQyxNQUFNLEVBQUU7UUFDVixJQUFJLENBQUNHLE9BQU8sQ0FBQ0gsTUFBTSxHQUFHaUMsWUFBWSxDQUFDakMsTUFBTSxDQUFDO01BQzVDO01BQ0E7TUFDQSxPQUFRLElBQUk7SUFDZDs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBMkIsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQTJCLEtBQUtBLENBQUNDLFVBQXlDLEVBQUU7TUFDL0MsSUFBSSxJQUFJLENBQUNqRSxLQUFLLEVBQUU7UUFDZCxNQUFNeUMsS0FBSyxDQUNULHlFQUNGLENBQUM7TUFDSDtNQUNBLElBQUksQ0FBQzdCLE9BQU8sQ0FBQ3FELFVBQVUsR0FBR0EsVUFBVTtNQUNwQyxPQUFPLElBQUk7SUFDYjs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBN0IsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQTZCLEtBQUtBLENBQUNBLE1BQWEsRUFBRTtNQUNuQixJQUFJLElBQUksQ0FBQ2xFLEtBQUssRUFBRTtRQUNkLE1BQU15QyxLQUFLLENBQ1QsOERBQ0YsQ0FBQztNQUNIO01BQ0EsSUFBSSxDQUFDN0IsT0FBTyxDQUFDc0QsS0FBSyxHQUFHQSxNQUFLO01BQzFCLE9BQU8sSUFBSTtJQUNiOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUE5QixHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBN0MsSUFBSUEsQ0FBQzJFLE1BQWMsRUFBRTtNQUNuQixJQUFJLElBQUksQ0FBQ25FLEtBQUssRUFBRTtRQUNkLE1BQU15QyxLQUFLLENBQ1Qsb0VBQ0YsQ0FBQztNQUNIO01BQ0EsSUFBSSxDQUFDN0IsT0FBTyxDQUFDdUQsTUFBTSxHQUFHQSxNQUFNO01BQzVCLE9BQU8sSUFBSTtJQUNiO0VBQUM7SUFBQS9CLEdBQUE7SUFBQUMsS0FBQSxZQUFBK0IsS0FBQTtNQUFBLFNBWUR6RCxJQUFJQSxDQUFBMEQsRUFBQSxFQUFBQyxHQUFBO1FBQUEsT0FBQUYsS0FBQSxDQUFBRyxLQUFBLE9BQUFqQyxTQUFBO01BQUE7TUFBSjNCLElBQUksQ0FBQTZELFFBQUE7UUFBQSxPQUFBSixLQUFBLENBQUFJLFFBQUE7TUFBQTtNQUFBLE9BQUo3RCxJQUFJO0lBQUEsRUFBSixVQUNFQSxJQUF3RCxFQUN4RDhELEdBQWEsRUFDYjtNQUNBLElBQUksSUFBSSxDQUFDekUsS0FBSyxFQUFFO1FBQ2QsTUFBTXlDLEtBQUssQ0FDVCw2REFDRixDQUFDO01BQ0g7TUFDQSxJQUFJLE9BQU85QixJQUFJLEtBQUssUUFBUSxJQUFJLE9BQU84RCxHQUFHLEtBQUssV0FBVyxFQUFFO1FBQzFELElBQUksQ0FBQzdELE9BQU8sQ0FBQ0QsSUFBSSxHQUFHLENBQUMsQ0FBQ0EsSUFBSSxFQUFFOEQsR0FBRyxDQUFDLENBQUM7TUFDbkMsQ0FBQyxNQUFNO1FBQ0wsSUFBSSxDQUFDN0QsT0FBTyxDQUFDRCxJQUFJLEdBQUdBLElBQTZDO01BQ25FO01BQ0EsT0FBTyxJQUFJO0lBQ2IsQ0FBQztFQUFBO0lBQUF5QixHQUFBO0lBQUFDLEtBQUEsRUFpQ0QsU0FBQXFDLE9BQU9BLENBT0xDLFlBQTBCLEVBQzFCVixVQUE0QyxFQUM1Q3hELE1BQXlDLEVBRUo7TUFBQSxJQURyQ3JCLE9BQXFFLEdBQUFrRCxTQUFBLENBQUFDLE1BQUEsUUFBQUQsU0FBQSxRQUFBRSxTQUFBLEdBQUFGLFNBQUEsTUFBRyxDQUFDLENBQUM7TUFFMUUsSUFBSSxJQUFJLENBQUN0QyxLQUFLLEVBQUU7UUFDZCxNQUFNeUMsS0FBSyxDQUNULGdGQUNGLENBQUM7TUFDSDtNQUNBLElBQU1tQyxXQUFvQyxHQUFHO1FBQzNDbkUsTUFBTSxFQUFFQSxNQUFNLEtBQUssSUFBSSxHQUFHK0IsU0FBUyxHQUFHL0IsTUFBTTtRQUM1Q29FLEtBQUssRUFBRUYsWUFBWTtRQUNuQlYsVUFBVSxFQUFFQSxVQUFVLEtBQUssSUFBSSxHQUFHekIsU0FBUyxHQUFHeUIsVUFBVTtRQUN4REMsS0FBSyxFQUFFOUUsT0FBTyxDQUFDOEUsS0FBSztRQUNwQkMsTUFBTSxFQUFFL0UsT0FBTyxDQUFDK0UsTUFBTTtRQUN0QnhELElBQUksRUFBQWxCLHFCQUFBLENBQUVMLE9BQU87TUFDZixDQUFDO01BQ0Q7TUFDQSxJQUFNMEYsVUFBVSxHQUFHLElBQUlDLFFBQVEsQ0FDN0IsSUFBSSxDQUFDbkYsS0FBSyxFQUNWK0UsWUFBWSxFQUNaQyxXQUFXLEVBQ1gsSUFDRixDQUFDO01BQ0QsSUFBSSxDQUFDSSxTQUFTLENBQUNsRCxJQUFJLENBQUNnRCxVQUFVLENBQUM7TUFDL0IsT0FBT0EsVUFBVTtJQUNuQjs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBMUMsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQXJCLGVBQWVBLENBQ2JOLFFBS0MsRUFDRDtNQUVBLElBQUksSUFBSSxDQUFDVixLQUFLLEVBQUU7UUFDZCxNQUFNeUMsS0FBSyxDQUNULGdGQUNGLENBQUM7TUFDSDtNQUNBLFNBQUF3QyxFQUFBLE1BQUFDLElBQUEsR0FBcUJDLFlBQUEsQ0FBWXpFLFFBQVEsQ0FBQyxFQUFBdUUsRUFBQSxHQUFBQyxJQUFBLENBQUEzQyxNQUFBLEVBQUEwQyxFQUFBLElBQVc7UUFBaEQsSUFBTUcsTUFBTSxHQUFBRixJQUFBLENBQUFELEVBQUE7UUFDZixJQUFBSSxLQUFBLEdBQTJDM0UsUUFBUSxDQUNqRDBFLE1BQU0sQ0FDUDtVQUZPbkIsV0FBVSxHQUFBb0IsS0FBQSxDQUFWcEIsVUFBVTtVQUFFeEQsUUFBTSxHQUFBNEUsS0FBQSxDQUFONUUsTUFBTTtVQUFLckIsUUFBTyxHQUFBeUIsd0JBQUEsQ0FBQXdFLEtBQUEsRUFBQUMsVUFBQTtRQUd0QyxJQUFJLENBQUNaLE9BQU8sQ0FBQ1UsTUFBTSxFQUFFbkIsV0FBVSxFQUFFeEQsUUFBTSxFQUFFckIsUUFBTyxDQUFDO01BQ25EO01BQ0EsT0FBTyxJQUFJO0lBQ2I7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQWdELEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUFsQixRQUFRQSxDQUFDQSxTQUFnQixFQUFFO01BQ3pCLElBQUksQ0FBQ0YsUUFBUSxDQUFDRSxRQUFRLEdBQUdBLFNBQVE7TUFDakMsT0FBTyxJQUFJO0lBQ2I7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQWlCLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUFqQixTQUFTQSxDQUFDQSxVQUFrQixFQUFFO01BQzVCLElBQUksQ0FBQ0gsUUFBUSxDQUFDRyxTQUFTLEdBQUdBLFVBQVM7TUFDbkMsT0FBTyxJQUFJO0lBQ2I7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQWdCLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUFoQixPQUFPQSxDQUFDQSxRQUFnQixFQUFFO01BQ3hCLElBQUksQ0FBQ0osUUFBUSxDQUFDSSxPQUFPLEdBQUdBLFFBQU87TUFDL0IsT0FBTyxJQUFJO0lBQ2I7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQWUsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQWtELGlCQUFpQkEsQ0FDZmpFLGNBQW9CLEVBQ0U7TUFDdEIsSUFBSUEsY0FBYyxJQUFJL0MsZUFBZSxFQUFFO1FBQ3JDLElBQUksQ0FBQzBDLFFBQVEsQ0FBQ0ssY0FBYyxHQUFHQSxjQUFjO01BQy9DO01BQ0E7TUFDQSxPQUFRLElBQUk7SUFDZDs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBYyxHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBM0MsT0FBT0EsQ0FBQSxFQUVpQjtNQUFBLElBQUE4RixNQUFBO01BQUEsSUFEdEJDLFFBQTJELEdBQUFuRCxTQUFBLENBQUFDLE1BQUEsUUFBQUQsU0FBQSxRQUFBRSxTQUFBLEdBQUFGLFNBQUEsTUFBRyxDQUFDLENBQUM7TUFFaEUsSUFBSSxJQUFJLENBQUNvRCxTQUFTLEVBQUU7UUFDbEIsTUFBTSxJQUFJakQsS0FBSyxDQUFDLHFDQUFxQyxDQUFDO01BQ3hEO01BRUEsSUFBSSxJQUFJLENBQUNrRCxTQUFTLEVBQUU7UUFDbEIsTUFBTSxJQUFJbEQsS0FBSyxDQUFDLGdDQUFnQyxDQUFDO01BQ25EO01BRUEsSUFBTXJELE9BQU8sR0FBRztRQUNkOEIsT0FBTyxFQUFFdUUsUUFBUSxDQUFDdkUsT0FBTyxJQUFJLElBQUksQ0FBQ0QsUUFBUSxDQUFDQyxPQUFPO1FBQ2xESSxjQUFjLEVBQUVtRSxRQUFRLENBQUNuRSxjQUFjLElBQUksSUFBSSxDQUFDTCxRQUFRLENBQUNLLGNBQWM7UUFDdkVGLFNBQVMsRUFBRXFFLFFBQVEsQ0FBQ3JFLFNBQVMsSUFBSSxJQUFJLENBQUNILFFBQVEsQ0FBQ0csU0FBUztRQUN4REQsUUFBUSxFQUFFc0UsUUFBUSxDQUFDdEUsUUFBUSxJQUFJLElBQUksQ0FBQ0YsUUFBUSxDQUFDRSxRQUFRO1FBQ3JERSxPQUFPLEVBQUVvRSxRQUFRLENBQUNwRSxPQUFPLElBQUksSUFBSSxDQUFDSixRQUFRLENBQUNJO01BQzdDLENBQUM7O01BRUQ7TUFDQTtNQUNBO01BQ0EsSUFBSSxDQUFDdUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxZQUFNO1FBQ3ZCLElBQ0V4RyxPQUFPLENBQUNrQyxjQUFjLEtBQUsvQyxlQUFlLENBQUNzSCxPQUFPLElBQ2xETCxNQUFJLENBQUNNLFNBQVMsRUFDZDtVQUNBTixNQUFJLENBQUMzRixPQUFPLENBQUNJLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQztVQUM1RCxJQUFNOEYsT0FBaUIsR0FBRyxFQUFFO1VBQzVCLElBQU1DLFFBQVEsR0FBRyxTQUFYQSxRQUFRQSxDQUFJbkUsTUFBYztZQUFBLE9BQUtrRSxPQUFPLENBQUNqRSxJQUFJLENBQUNELE1BQU0sQ0FBQztVQUFBO1VBQ3pEMkQsTUFBSSxDQUFDN0QsRUFBRSxDQUFDLFFBQVEsRUFBRXFFLFFBQVEsQ0FBQztVQUMzQlIsTUFBSSxDQUFDSSxJQUFJLENBQUMsS0FBSyxFQUFFLFlBQU07WUFDckJKLE1BQUksQ0FBQ1MsY0FBYyxDQUFDLFFBQVEsRUFBRUQsUUFBUSxDQUFDO1lBQ3ZDUixNQUFJLENBQUN4RCxJQUFJLENBQUMsVUFBVSxFQUFFK0QsT0FBTyxFQUFFUCxNQUFJLENBQUM7VUFDdEMsQ0FBQyxDQUFDO1FBQ0o7TUFDRixDQUFDLENBQUM7O01BRUY7TUFDQSxJQUFJLENBQUNFLFNBQVMsR0FBRyxJQUFJO01BRXJCUSxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQUMsU0FBQUMsUUFBQTtRQUFBLE9BQUFGLG1CQUFBLENBQUFHLElBQUEsVUFBQUMsU0FBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFDLElBQUEsR0FBQUQsU0FBQSxDQUFBRSxJQUFBO1lBQUE7Y0FDQztjQUNBbEIsTUFBSSxDQUFDM0YsT0FBTyxDQUFDSSxLQUFLLENBQUMscUJBQXFCLENBQUM7Y0FBQ3VHLFNBQUEsQ0FBQUMsSUFBQTtjQUFBRCxTQUFBLENBQUFFLElBQUE7Y0FBQSxPQUVsQ2xCLE1BQUksQ0FBQ21CLFFBQVEsQ0FBQ3ZILE9BQU8sQ0FBQztZQUFBO2NBQzVCb0csTUFBSSxDQUFDM0YsT0FBTyxDQUFDSSxLQUFLLENBQUMsd0JBQXdCLENBQUM7Y0FBQ3VHLFNBQUEsQ0FBQUUsSUFBQTtjQUFBO1lBQUE7Y0FBQUYsU0FBQSxDQUFBQyxJQUFBO2NBQUFELFNBQUEsQ0FBQUksRUFBQSxHQUFBSixTQUFBO2NBRTdDaEIsTUFBSSxDQUFDM0YsT0FBTyxDQUFDSSxLQUFLLENBQUMscUJBQXFCLEVBQUF1RyxTQUFBLENBQUFJLEVBQU8sQ0FBQztjQUNoRHBCLE1BQUksQ0FBQ3hELElBQUksQ0FBQyxPQUFPLEVBQUF3RSxTQUFBLENBQUFJLEVBQU8sQ0FBQztZQUFDO1lBQUE7Y0FBQSxPQUFBSixTQUFBLENBQUFLLElBQUE7VUFBQTtRQUFBLEdBQUFSLE9BQUE7TUFBQSxDQUU3QixHQUFFLENBQUM7O01BRUo7TUFDQSxPQUFRLElBQUk7SUFDZDtFQUFDO0lBQUFqRSxHQUFBO0lBQUFDLEtBQUEsRUFZRCxTQUFReUUsWUFBWUEsQ0FBQSxFQUFHO01BQ3JCLE9BQU8sSUFBSSxDQUFDMUcsUUFBUSxHQUNoQixDQUFDLElBQUksQ0FBQ1IsS0FBSyxDQUFDbUgsUUFBUSxDQUFDLENBQUMsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDM0csUUFBUSxDQUFDLENBQUM0RyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQzFELEVBQUU7SUFDUjtFQUFDO0lBQUE1RSxHQUFBO0lBQUFDLEtBQUEsRUFFRCxTQUFRL0IsWUFBWUEsQ0FBQzJHLEdBQVcsRUFBRTtNQUNoQyxPQUFPQSxHQUFHLENBQUNsRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNtRSxHQUFHLENBQUMsQ0FBQztJQUM3QjtFQUFDO0lBQUE5RSxHQUFBO0lBQUFDLEtBQUEsRUFrQkQsU0FBUThFLGlCQUFpQkEsQ0FDdkJDLE9BQWdCLEVBQ2hCOUYsY0FBbUMsRUFDQTtNQUFBLElBQUErRixjQUFBLEVBQUFDLGFBQUE7TUFDbkMsUUFBUWhHLGNBQWM7UUFDcEIsS0FBSyxPQUFPO1VBQ1YsT0FBTyxJQUFJLENBQUNpRyxTQUFTO1FBQ3ZCLEtBQUssY0FBYztVQUNqQixRQUFBRixjQUFBLElBQUFDLGFBQUEsR0FBTyxJQUFJLENBQUN2QixPQUFPLGNBQUF1QixhQUFBLHVCQUFaQSxhQUFBLENBQWUsQ0FBQyxDQUFDLGNBQUFELGNBQUEsY0FBQUEsY0FBQSxHQUFJLElBQUk7UUFDbEMsS0FBSyxTQUFTO1VBQ1osT0FBTyxJQUFJLENBQUN0QixPQUFPO1FBQ3JCO1FBQ0E7VUFDRSxPQUFBbkgsYUFBQSxDQUFBQSxhQUFBLEtBQ0s7WUFDRG1ILE9BQU8sRUFBRSxJQUFJLENBQUNBLE9BQU87WUFDckJ3QixTQUFTLEVBQUUsSUFBSSxDQUFDQSxTQUFTO1lBQ3pCQyxJQUFJLEVBQUVKLE9BQU8sYUFBUEEsT0FBTyxjQUFQQSxPQUFPLEdBQUksSUFBSSxDQUFFO1VBQ3pCLENBQUMsR0FDRyxJQUFJLENBQUNoSCxRQUFRLEdBQUc7WUFBRXFILGNBQWMsRUFBRSxJQUFJLENBQUNYLFlBQVksQ0FBQztVQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7TUFFdEU7SUFDRjtJQUNBO0FBQ0Y7QUFDQTtFQUZFO0lBQUExRSxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBcUYsU0FBQSxHQUFBeEIsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUF1QixTQUFldkksT0FBcUI7UUFBQSxJQUFBd0ksY0FBQSxFQUFBQyxVQUFBLEVBQUFDLG9CQUFBLEVBQUFDLGFBQUE7UUFBQSxJQUFBN0csT0FBQSxFQUFBSSxjQUFBLEVBQUFGLFNBQUEsRUFBQUQsUUFBQSxFQUFBRSxPQUFBLEVBQUE0RixHQUFBLEVBQUFlLElBQUEsRUFBQUMsSUFBQSxFQUFBQyxVQUFBLEVBQUFDLFNBQUEsRUFBQUMsS0FBQSxFQUFBdkcsTUFBQSxFQUFBd0csVUFBQSxFQUFBQyxNQUFBLEVBQUFsRyxHQUFBLEVBQUFtRyxNQUFBLEVBQUFDLFVBQUEsRUFBQUMsWUFBQSxFQUFBQyxDQUFBLEVBQUFDLE9BQUEsRUFBQUMsUUFBQTtRQUFBLE9BQUF6QyxtQkFBQSxDQUFBRyxJQUFBLFVBQUF1QyxVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXJDLElBQUEsR0FBQXFDLFVBQUEsQ0FBQXBDLElBQUE7WUFBQTtjQUMxQnhGLE9BQU8sR0FBbUQ5QixPQUFPLENBQWpFOEIsT0FBTyxFQUFFSSxjQUFjLEdBQW1DbEMsT0FBTyxDQUF4RGtDLGNBQWMsRUFBRUYsU0FBUyxHQUF3QmhDLE9BQU8sQ0FBeENnQyxTQUFTLEVBQUVELFFBQVEsR0FBYy9CLE9BQU8sQ0FBN0IrQixRQUFRLEVBQUVFLE9BQU8sR0FBS2pDLE9BQU8sQ0FBbkJpQyxPQUFPO2NBQzdELElBQUksQ0FBQ3hCLE9BQU8sQ0FBQ0ksS0FBSyxDQUFDLHNCQUFzQixFQUFFYixPQUFPLENBQUM7Y0FBQyxLQUVoRCxJQUFJLENBQUNnQixRQUFRO2dCQUFBMEksVUFBQSxDQUFBcEMsSUFBQTtnQkFBQTtjQUFBO2NBQ2ZPLEdBQUcsR0FBRyxJQUFJLENBQUNILFlBQVksQ0FBQyxDQUFDO2NBQUNnQyxVQUFBLENBQUFwQyxJQUFBO2NBQUE7WUFBQTtjQUFBb0MsVUFBQSxDQUFBcEMsSUFBQTtjQUFBLE9BRVAsSUFBSSxDQUFDcUMsTUFBTSxDQUFDLENBQUM7WUFBQTtjQUExQmYsSUFBSSxHQUFBYyxVQUFBLENBQUFFLElBQUE7Y0FDVixJQUFJLENBQUNuSixPQUFPLENBQUNJLEtBQUssV0FBQUMsTUFBQSxDQUFXOEgsSUFBSSxDQUFFLENBQUM7Y0FDcENmLEdBQUcsR0FBRyxDQUNKLElBQUksQ0FBQ3JILEtBQUssQ0FBQ21ILFFBQVEsQ0FBQyxDQUFDLEVBQ3JCLEdBQUcsRUFDSDFGLE9BQU8sR0FBRyxVQUFVLEdBQUcsT0FBTyxFQUM5QixLQUFLLEVBQ0w0SCxrQkFBa0IsQ0FBQ2pCLElBQUksQ0FBQyxDQUN6QixDQUFDaEIsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUFDO2NBQUE4QixVQUFBLENBQUFwQyxJQUFBO2NBQUEsT0FFTSxJQUFJLENBQUM5RyxLQUFLLENBQUNzSixPQUFPLENBQUk7Z0JBQUVDLE1BQU0sRUFBRSxLQUFLO2dCQUFFbEMsR0FBRyxFQUFIQSxHQUFHO2dCQUFFL0YsT0FBTyxFQUFQQTtjQUFRLENBQUMsQ0FBQztZQUFBO2NBQW5FK0csSUFBSSxHQUFBYSxVQUFBLENBQUFFLElBQUE7Y0FDVixJQUFJLENBQUNoSCxJQUFJLENBQUMsT0FBTyxDQUFDO2NBQ2xCLElBQUksQ0FBQ3VGLFNBQVMsR0FBR1UsSUFBSSxDQUFDVixTQUFTOztjQUUvQjtjQUFBLE1BQ0luRyxTQUFTLElBQUk2RyxJQUFJLENBQUNsQyxPQUFPLENBQUN4RCxNQUFNLEdBQUcsQ0FBQztnQkFBQXVHLFVBQUEsQ0FBQXBDLElBQUE7Z0JBQUE7Y0FBQTtjQUNoQ3dCLFVBQVUsR0FBRy9DLFlBQUEsQ0FBWThDLElBQUksQ0FBQ2xDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztjQUFBb0MsU0FBQSxHQUFBaUIsMEJBQUEsQ0FDMUJuQixJQUFJLENBQUNsQyxPQUFPO2NBQUErQyxVQUFBLENBQUFyQyxJQUFBO2NBQUEwQixTQUFBLENBQUFrQixDQUFBO1lBQUE7Y0FBQSxLQUFBakIsS0FBQSxHQUFBRCxTQUFBLENBQUFtQixDQUFBLElBQUE5QixJQUFBO2dCQUFBc0IsVUFBQSxDQUFBcEMsSUFBQTtnQkFBQTtjQUFBO2NBQXRCN0UsTUFBTSxHQUFBdUcsS0FBQSxDQUFBL0YsS0FBQTtjQUFBZ0csVUFBQSxHQUFBZSwwQkFBQSxDQUNHbEIsVUFBVTtjQUFBWSxVQUFBLENBQUFyQyxJQUFBO2NBQUE0QixVQUFBLENBQUFnQixDQUFBO1lBQUE7Y0FBQSxLQUFBZixNQUFBLEdBQUFELFVBQUEsQ0FBQWlCLENBQUEsSUFBQTlCLElBQUE7Z0JBQUFzQixVQUFBLENBQUFwQyxJQUFBO2dCQUFBO2NBQUE7Y0FBakJ0RSxHQUFHLEdBQUFrRyxNQUFBLENBQUFqRyxLQUFBO2NBQ05rSCxNQUFLLEdBQUcxSCxNQUFNLENBQUNPLEdBQUcsQ0FBQztjQUFBLE1BQ3JCbUgsTUFBSyxJQUFJQyxPQUFBLENBQU9ELE1BQUssTUFBSyxRQUFRLElBQUksU0FBUyxJQUFJQSxNQUFLLElBQUksZ0JBQWdCLElBQUlBLE1BQUs7Z0JBQUFULFVBQUEsQ0FBQXBDLElBQUE7Z0JBQUE7Y0FBQTtjQUFBb0MsVUFBQSxDQUFBbEMsRUFBQSxHQUFBaEksYUFBQTtjQUFBa0ssVUFBQSxDQUFBVyxFQUFBLEdBQUE3SyxhQUFBLEtBRWxGMkssTUFBSztjQUFBVCxVQUFBLENBQUFZLEVBQUE7Y0FBQVosVUFBQSxDQUFBcEMsSUFBQTtjQUFBLE9BQ08sSUFBSSxDQUFDaUQsd0JBQXdCLENBQUM5SCxNQUFNLEVBQUVPLEdBQUcsRUFBRWxCLE9BQU8sQ0FBQztZQUFBO2NBQUE0SCxVQUFBLENBQUFjLEVBQUEsR0FBQWQsVUFBQSxDQUFBRSxJQUFBO2NBQUFGLFVBQUEsQ0FBQWUsRUFBQSxHQUVsRHJILFNBQVM7Y0FBQXNHLFVBQUEsQ0FBQWdCLEVBQUE7Z0JBRnpCL0QsT0FBTyxFQUFBK0MsVUFBQSxDQUFBYyxFQUFBO2dCQUNQcEMsSUFBSSxFQUFFLElBQUk7Z0JBQ1ZDLGNBQWMsRUFBQXFCLFVBQUEsQ0FBQWU7Y0FBQTtjQUpoQmhJLE1BQU0sQ0FBQ08sR0FBRyxDQUFDLE9BQUEwRyxVQUFBLENBQUFsQyxFQUFBLEVBQUFrQyxVQUFBLENBQUFXLEVBQUEsRUFBQVgsVUFBQSxDQUFBWSxFQUFBLEVBQUFaLFVBQUEsQ0FBQWdCLEVBQUE7WUFBQTtjQUFBaEIsVUFBQSxDQUFBcEMsSUFBQTtjQUFBO1lBQUE7Y0FBQW9DLFVBQUEsQ0FBQXBDLElBQUE7Y0FBQTtZQUFBO2NBQUFvQyxVQUFBLENBQUFyQyxJQUFBO2NBQUFxQyxVQUFBLENBQUFpQixFQUFBLEdBQUFqQixVQUFBO2NBQUFULFVBQUEsQ0FBQXBHLENBQUEsQ0FBQTZHLFVBQUEsQ0FBQWlCLEVBQUE7WUFBQTtjQUFBakIsVUFBQSxDQUFBckMsSUFBQTtjQUFBNEIsVUFBQSxDQUFBbEYsQ0FBQTtjQUFBLE9BQUEyRixVQUFBLENBQUFrQixNQUFBO1lBQUE7Y0FBQWxCLFVBQUEsQ0FBQXBDLElBQUE7Y0FBQTtZQUFBO2NBQUFvQyxVQUFBLENBQUFwQyxJQUFBO2NBQUE7WUFBQTtjQUFBb0MsVUFBQSxDQUFBckMsSUFBQTtjQUFBcUMsVUFBQSxDQUFBbUIsRUFBQSxHQUFBbkIsVUFBQTtjQUFBWCxTQUFBLENBQUFsRyxDQUFBLENBQUE2RyxVQUFBLENBQUFtQixFQUFBO1lBQUE7Y0FBQW5CLFVBQUEsQ0FBQXJDLElBQUE7Y0FBQTBCLFNBQUEsQ0FBQWhGLENBQUE7Y0FBQSxPQUFBMkYsVUFBQSxDQUFBa0IsTUFBQTtZQUFBO2NBV25CLElBQUksQ0FBQ2pFLE9BQU8sSUFBQTZCLGNBQUEsR0FBRyxJQUFJLENBQUM3QixPQUFPLGNBQUE2QixjQUFBLHVCQUFadkUsdUJBQUEsQ0FBQXVFLGNBQUEsRUFBQW5KLElBQUEsQ0FBQW1KLGNBQUEsRUFDYnpHLFFBQVEsR0FBRyxJQUFJLENBQUM0RSxPQUFPLENBQUN4RCxNQUFNLEdBQUcwRixJQUFJLENBQUNsQyxPQUFPLENBQUN4RCxNQUFNLEdBQ2hEMEYsSUFBSSxDQUFDbEMsT0FBTyxHQUNabUUsc0JBQUEsQ0FBQXJDLFVBQUEsR0FBQUksSUFBSSxDQUFDbEMsT0FBTyxFQUFBdEgsSUFBQSxDQUFBb0osVUFBQSxFQUFPLENBQUMsRUFBRTFHLFFBQVEsR0FBRyxJQUFJLENBQUM0RSxPQUFPLENBQUN4RCxNQUFNLENBQzFELENBQUM7Y0FDRCxJQUFJLENBQUNuQyxRQUFRLEdBQUc2SCxJQUFJLENBQUNSLGNBQWMsR0FDL0IsSUFBSSxDQUFDbkgsWUFBWSxDQUFDMkgsSUFBSSxDQUFDUixjQUFjLENBQUMsR0FDdENqRixTQUFTO2NBQ2IsSUFBSSxDQUFDbUQsU0FBUyxHQUNaLElBQUksQ0FBQ0EsU0FBUyxJQUNkc0MsSUFBSSxDQUFDVCxJQUFJLElBQ1QsQ0FBQ3BHLFNBQVMsSUFDVixJQUFJLENBQUMyRSxPQUFPLENBQUN4RCxNQUFNLEtBQUtwQixRQUFRO2NBQ2hDO2NBQ0M4RyxJQUFJLENBQUNsQyxPQUFPLENBQUN4RCxNQUFNLEtBQUssQ0FBQyxJQUFJMEYsSUFBSSxDQUFDVCxJQUFJLEtBQUtoRixTQUFVOztjQUV4RDtjQUNNZ0csVUFBVSxJQUFBVixvQkFBQSxJQUFBQyxhQUFBLEdBQUdFLElBQUksQ0FBQ2xDLE9BQU8sY0FBQWdDLGFBQUEsdUJBQVpBLGFBQUEsQ0FBY3hGLE1BQU0sY0FBQXVGLG9CQUFBLGNBQUFBLG9CQUFBLEdBQUksQ0FBQztjQUN4Q1csWUFBWSxHQUFHLElBQUksQ0FBQ0EsWUFBWTtjQUMzQkMsQ0FBQyxHQUFHLENBQUM7WUFBQTtjQUFBLE1BQUVBLENBQUMsR0FBR0YsVUFBVTtnQkFBQU0sVUFBQSxDQUFBcEMsSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDeEIrQixZQUFZLElBQUl0SCxRQUFRO2dCQUFBMkgsVUFBQSxDQUFBcEMsSUFBQTtnQkFBQTtjQUFBO2NBQzFCLElBQUksQ0FBQ2YsU0FBUyxHQUFHLElBQUk7Y0FBQyxPQUFBbUQsVUFBQSxDQUFBcUIsTUFBQTtZQUFBO2NBR2xCdEksT0FBTSxHQUFHb0csSUFBSSxDQUFDbEMsT0FBTyxDQUFDMkMsQ0FBQyxDQUFDO2NBQzlCLElBQUksQ0FBQzFHLElBQUksQ0FBQyxRQUFRLEVBQUVILE9BQU0sRUFBRTRHLFlBQVksRUFBRSxJQUFJLENBQUM7Y0FDL0NBLFlBQVksSUFBSSxDQUFDO1lBQUM7Y0FQWUMsQ0FBQyxFQUFFO2NBQUFJLFVBQUEsQ0FBQXBDLElBQUE7Y0FBQTtZQUFBO2NBU25DLElBQUksQ0FBQytCLFlBQVksR0FBR0EsWUFBWTtjQUFDLEtBRTdCLElBQUksQ0FBQzlDLFNBQVM7Z0JBQUFtRCxVQUFBLENBQUFwQyxJQUFBO2dCQUFBO2NBQUE7Y0FDVmtDLFFBQVEsR0FBRyxJQUFJLENBQUN6QixpQkFBaUIsQ0FBQ2MsSUFBSSxDQUFDVCxJQUFJLEVBQUVsRyxjQUFjLENBQUMsRUFDbEU7Y0FDQSxJQUFJQSxjQUFjLEtBQUsvQyxlQUFlLENBQUNzSCxPQUFPLEVBQUU7Z0JBQzlDLElBQUksQ0FBQzdELElBQUksQ0FBQyxVQUFVLEVBQUU0RyxRQUFRLEVBQUUsSUFBSSxDQUFDO2NBQ3ZDO2NBQ0EsSUFBSSxDQUFDNUcsSUFBSSxDQUFDLEtBQUssQ0FBQztjQUFDLE9BQUE4RyxVQUFBLENBQUFxQixNQUFBLFdBQ1Z2QixRQUFRO1lBQUE7Y0FBQSxPQUFBRSxVQUFBLENBQUFxQixNQUFBLFdBRVIsSUFBSSxDQUFDeEQsUUFBUSxDQUFDdkgsT0FBTyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUEwSixVQUFBLENBQUFqQyxJQUFBO1VBQUE7UUFBQSxHQUFBYyxRQUFBO01BQUEsQ0FFaEM7TUFBQSxTQWhGS2hCLFFBQVFBLENBQUF5RCxHQUFBO1FBQUEsT0FBQTFDLFNBQUEsQ0FBQW5ELEtBQUEsT0FBQWpDLFNBQUE7TUFBQTtNQUFBLE9BQVJxRSxRQUFRO0lBQUE7SUFrRmQ7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBdkUsR0FBQTtJQUFBQyxLQUFBLEVBS0EsU0FBQWdJLE1BQU1BLENBQUEsRUFBaUM7TUFBQSxJQUFoQ0MsSUFBc0IsR0FBQWhJLFNBQUEsQ0FBQUMsTUFBQSxRQUFBRCxTQUFBLFFBQUFFLFNBQUEsR0FBQUYsU0FBQSxNQUFHLEtBQUs7TUFDbkMsSUFBSSxDQUFDLElBQUksQ0FBQ3FELFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQ0QsU0FBUyxFQUFFO1FBQ3RDLElBQUksQ0FBQ2hHLE9BQU8sQ0FBQztVQUFFMEIsU0FBUyxFQUFFO1FBQUssQ0FBQyxDQUFDO01BQ25DO01BQ0EsT0FBT2tKLElBQUksS0FBSyxRQUFRLEdBQUcsSUFBSSxDQUFDMUksT0FBTyxHQUFHLElBQUksQ0FBQ0EsT0FBTyxDQUFDeUksTUFBTSxDQUFDQyxJQUFJLENBQUM7SUFDckU7O0lBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUpFO0lBQUFsSSxHQUFBO0lBQUFDLEtBQUEsRUFLQSxTQUFBa0ksSUFBSUEsQ0FBQ0YsTUFBNkIsRUFBRTtNQUNsQyxPQUFPLElBQUksQ0FBQ0EsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDRSxJQUFJLENBQUNGLE1BQU0sQ0FBQztJQUMzQzs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBakksR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQW1JLGNBQUEsR0FBQXRFLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBcUUsU0FBb0JDLFFBQWlCO1FBQUEsSUFBQUMsVUFBQSxFQUFBQyxVQUFBLEVBQUFDLFVBQUEsRUFBQUMsVUFBQSxFQUFBQyxVQUFBO1FBQUEsSUFBQUMsYUFBQSxFQUFBQyxvQkFBQSxFQUFBeEssTUFBQSxFQUFBeUssbUJBQUEsRUFBQXJHLEtBQUEsRUFBQXNHLE9BQUEsRUFBQUMsa0JBQUEsRUFBQUMsbUJBQUEsRUFBQUMsT0FBQTtRQUFBLE9BQUFuRixtQkFBQSxDQUFBRyxJQUFBLFVBQUFpRixVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQS9FLElBQUEsR0FBQStFLFVBQUEsQ0FBQTlFLElBQUE7WUFBQTtjQUFBLEtBQy9CLElBQUksQ0FBQzFHLEtBQUs7Z0JBQUF3TCxVQUFBLENBQUE5RSxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUNOLElBQUlqRSxLQUFLLENBQ2Isa0VBQ0YsQ0FBQztZQUFBO2NBQUF1SSxhQUFBLEdBRWlDLElBQUksQ0FBQ3BLLE9BQU8sRUFBQXFLLG9CQUFBLEdBQUFELGFBQUEsQ0FBeEN2SyxNQUFNLEVBQU5BLE1BQU0sR0FBQXdLLG9CQUFBLGNBQUcsRUFBRSxHQUFBQSxvQkFBQSxFQUFBQyxtQkFBQSxHQUFBRixhQUFBLENBQUVuRyxLQUFLLEVBQUxBLEtBQUssR0FBQXFHLG1CQUFBLGNBQUcsRUFBRSxHQUFBQSxtQkFBQTtjQUN6QkMsT0FBTyxHQUFHVCxRQUFRLElBQUk3RixLQUFLO2NBQ2pDLElBQUksQ0FBQ2hGLE9BQU8sQ0FBQ0ksS0FBSyxDQUFBb0QsdUJBQUEsQ0FBQXNILFVBQUEsK0JBQUF6SyxNQUFBLENBQ1lpTCxPQUFPLGtCQUFBMU0sSUFBQSxDQUFBa00sVUFBQSxFQUFjbEssTUFBTSxDQUFDdUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUNwRSxDQUFDO2NBQUN3RSxVQUFBLENBQUE5RSxJQUFBO2NBQUEsT0FDc0JsRixRQUFBLENBQVFpSyxHQUFHLENBQUFwSSx1QkFBQSxDQUFBdUgsVUFBQSxJQUNqQyxJQUFJLENBQUNjLHFCQUFxQixDQUFDUCxPQUFPLEVBQUUxSyxNQUFNLENBQUMsR0FBQWhDLElBQUEsQ0FBQW1NLFVBQUEsRUFBQXRILGtCQUFBLENBQ3hDTCxvQkFBQSxDQUFBNEgsVUFBQSxPQUFJLENBQUM3RixTQUFTLEVBQUF2RyxJQUFBLENBQUFvTSxVQUFBO2dCQUFBLElBQUFjLEtBQUEsR0FBQXpGLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FBSyxTQUFBd0YsU0FBTzlHLFVBQVU7a0JBQUEsT0FBQXFCLG1CQUFBLENBQUFHLElBQUEsVUFBQXVGLFVBQUFDLFVBQUE7b0JBQUEsa0JBQUFBLFVBQUEsQ0FBQXJGLElBQUEsR0FBQXFGLFVBQUEsQ0FBQXBGLElBQUE7c0JBQUE7d0JBQUFvRixVQUFBLENBQUFwRixJQUFBO3dCQUFBLE9BQy9CNUIsVUFBVSxDQUFDaUgsYUFBYSxDQUFDLENBQUM7c0JBQUE7d0JBQUEsT0FBQUQsVUFBQSxDQUFBM0IsTUFBQSxXQUN6QixFQUFFO3NCQUFBO3NCQUFBO3dCQUFBLE9BQUEyQixVQUFBLENBQUFqRixJQUFBO29CQUFBO2tCQUFBLEdBQUErRSxRQUFBO2dCQUFBLENBQ1Y7Z0JBQUEsaUJBQUFJLEdBQUE7a0JBQUEsT0FBQUwsS0FBQSxDQUFBcEgsS0FBQSxPQUFBakMsU0FBQTtnQkFBQTtjQUFBLElBQUMsRUFDSCxDQUFDO1lBQUE7Y0FBQThJLGtCQUFBLEdBQUFJLFVBQUEsQ0FBQXhDLElBQUE7Y0FBQXFDLG1CQUFBLEdBQUEzSCxjQUFBLENBQUEwSCxrQkFBQTtjQU5LRSxPQUFPLEdBQUFELG1CQUFBO2NBT2QsSUFBSSxDQUFDekssT0FBTyxDQUFDSCxNQUFNLEdBQUc2SyxPQUFPO2NBQzdCLElBQUksQ0FBQzFLLE9BQU8sQ0FBQ0YsUUFBUSxHQUFHbEMsdUJBQUEsQ0FBQXNNLFVBQUEsR0FBQTdILG9CQUFBLENBQUE4SCxVQUFBLE9BQUksQ0FBQy9GLFNBQVMsRUFBQXZHLElBQUEsQ0FBQXNNLFVBQUEsRUFDL0IsVUFBQ2tCLE1BQU0sRUFBSztnQkFDZixJQUFNQyxPQUFPLEdBQUdELE1BQU0sQ0FBQ0UsTUFBTSxDQUFDdkwsT0FBTztnQkFDckMsT0FBTyxDQUFDc0wsT0FBTyxDQUFDckgsS0FBSyxFQUFFcUgsT0FBTyxDQUFDO2NBQ2pDLENBQUMsQ0FBQyxFQUFBek4sSUFBQSxDQUFBcU0sVUFBQSxFQUVBLFVBQUNwSyxRQUFRLEVBQUEwTCxLQUFBO2dCQUFBLElBQUFDLEtBQUEsR0FBQTNJLGNBQUEsQ0FBQTBJLEtBQUE7a0JBQUdFLE1BQU0sR0FBQUQsS0FBQTtrQkFBRUgsT0FBTyxHQUFBRyxLQUFBO2dCQUFBLE9BQUF6TixhQUFBLENBQUFBLGFBQUEsS0FDdEI4QixRQUFRLE9BQUE3QixlQUFBLEtBQ1Z5TixNQUFNLEVBQUdKLE9BQU87Y0FBQSxDQUNqQixFQUNGLENBQUMsQ0FDSCxDQUFDO1lBQUM7WUFBQTtjQUFBLE9BQUFWLFVBQUEsQ0FBQTNFLElBQUE7VUFBQTtRQUFBLEdBQUE0RCxRQUFBO01BQUEsQ0FDTDtNQUFBLFNBL0JLc0IsYUFBYUEsQ0FBQVEsR0FBQTtRQUFBLE9BQUEvQixjQUFBLENBQUFqRyxLQUFBLE9BQUFqQyxTQUFBO01BQUE7TUFBQSxPQUFieUosYUFBYTtJQUFBO0lBaUNuQjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUEzSixHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBbUssb0JBQUEsR0FBQXRHLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBcUcsU0FBMEJDLE9BQWU7UUFBQSxJQUFBQyxVQUFBO1FBQUEsSUFBQTlILEtBQUEsRUFBQXNHLE9BQUEsRUFBQXlCLFVBQUEsRUFBQUMsVUFBQSxFQUFBQyxNQUFBLEVBQUFDLEVBQUE7UUFBQSxPQUFBNUcsbUJBQUEsQ0FBQUcsSUFBQSxVQUFBMEcsVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUF4RyxJQUFBLEdBQUF3RyxVQUFBLENBQUF2RyxJQUFBO1lBQUE7Y0FDakM3QixLQUFLLEdBQUcsSUFBSSxDQUFDakUsT0FBTyxDQUFDaUUsS0FBSztjQUFBLElBQzNCQSxLQUFLO2dCQUFBb0ksVUFBQSxDQUFBdkcsSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDRixJQUFJakUsS0FBSyxDQUFDLDRDQUE0QyxDQUFDO1lBQUE7Y0FFL0QsSUFBSSxDQUFDNUMsT0FBTyxDQUFDSSxLQUFLLENBQUFvRCx1QkFBQSxDQUFBc0osVUFBQSxtQ0FBQXpNLE1BQUEsQ0FDZXdNLE9BQU8sZUFBQWpPLElBQUEsQ0FBQWtPLFVBQUEsRUFBUzlILEtBQUssVUFDdEQsQ0FBQztjQUFDb0ksVUFBQSxDQUFBdkcsSUFBQTtjQUFBLE9BQ29CLElBQUksQ0FBQzlHLEtBQUssQ0FBQ3NOLFNBQVMsQ0FBQ3JJLEtBQUssQ0FBQztZQUFBO2NBQTNDc0csT0FBTyxHQUFBOEIsVUFBQSxDQUFBakUsSUFBQTtjQUNQNEQsVUFBVSxHQUFHRixPQUFPLENBQUNTLFdBQVcsQ0FBQyxDQUFDO2NBQUFOLFVBQUEsR0FBQXpELDBCQUFBLENBQ3ZCK0IsT0FBTyxDQUFDaUMsa0JBQWtCO2NBQUFILFVBQUEsQ0FBQXhHLElBQUE7Y0FBQW9HLFVBQUEsQ0FBQXhELENBQUE7WUFBQTtjQUFBLEtBQUF5RCxNQUFBLEdBQUFELFVBQUEsQ0FBQXZELENBQUEsSUFBQTlCLElBQUE7Z0JBQUF5RixVQUFBLENBQUF2RyxJQUFBO2dCQUFBO2NBQUE7Y0FBaENxRyxFQUFFLEdBQUFELE1BQUEsQ0FBQXpLLEtBQUE7Y0FBQSxNQUVULENBQUMwSyxFQUFFLENBQUNNLGdCQUFnQixJQUFJLEVBQUUsRUFBRUYsV0FBVyxDQUFDLENBQUMsS0FBS1AsVUFBVSxJQUN4REcsRUFBRSxDQUFDTyxZQUFZO2dCQUFBTCxVQUFBLENBQUF2RyxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxPQUFBdUcsVUFBQSxDQUFBOUMsTUFBQSxXQUVSNEMsRUFBRSxDQUFDTyxZQUFZO1lBQUE7Y0FBQUwsVUFBQSxDQUFBdkcsSUFBQTtjQUFBO1lBQUE7Y0FBQXVHLFVBQUEsQ0FBQXZHLElBQUE7Y0FBQTtZQUFBO2NBQUF1RyxVQUFBLENBQUF4RyxJQUFBO2NBQUF3RyxVQUFBLENBQUFyRyxFQUFBLEdBQUFxRyxVQUFBO2NBQUFKLFVBQUEsQ0FBQTVLLENBQUEsQ0FBQWdMLFVBQUEsQ0FBQXJHLEVBQUE7WUFBQTtjQUFBcUcsVUFBQSxDQUFBeEcsSUFBQTtjQUFBb0csVUFBQSxDQUFBMUosQ0FBQTtjQUFBLE9BQUE4SixVQUFBLENBQUFqRCxNQUFBO1lBQUE7Y0FBQSxNQUdwQixJQUFJdkgsS0FBSyxpQ0FBQXZDLE1BQUEsQ0FBaUN3TSxPQUFPLENBQUUsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBTyxVQUFBLENBQUFwRyxJQUFBO1VBQUE7UUFBQSxHQUFBNEYsUUFBQTtNQUFBLENBQzNEO01BQUEsU0FuQktjLG1CQUFtQkEsQ0FBQUMsR0FBQTtRQUFBLE9BQUFoQixvQkFBQSxDQUFBakksS0FBQSxPQUFBakMsU0FBQTtNQUFBO01BQUEsT0FBbkJpTCxtQkFBbUI7SUFBQTtJQXFCekI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBbkwsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQW9MLHNCQUFBLEdBQUF2SCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQXNILFNBQ0V2QyxPQUFlLEVBQ2YxSyxNQUFnQjtRQUFBLElBQUFrTixNQUFBO1FBQUEsSUFBQUMsY0FBQTtRQUFBLE9BQUF6SCxtQkFBQSxDQUFBRyxJQUFBLFVBQUF1SCxVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXJILElBQUEsR0FBQXFILFVBQUEsQ0FBQXBILElBQUE7WUFBQTtjQUFBb0gsVUFBQSxDQUFBcEgsSUFBQTtjQUFBLE9BRWFsRixRQUFBLENBQVFpSyxHQUFHLENBQ3RDeEksb0JBQUEsQ0FBQXhDLE1BQU0sRUFBQWhDLElBQUEsQ0FBTmdDLE1BQU07Z0JBQUEsSUFBQXNOLEtBQUEsR0FBQTdILGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FBSyxTQUFBNEgsU0FBT3pFLEtBQUs7a0JBQUEsT0FBQXBELG1CQUFBLENBQUFHLElBQUEsVUFBQTJILFVBQUFDLFVBQUE7b0JBQUEsa0JBQUFBLFVBQUEsQ0FBQXpILElBQUEsR0FBQXlILFVBQUEsQ0FBQXhILElBQUE7c0JBQUE7d0JBQUEsT0FBQXdILFVBQUEsQ0FBQS9ELE1BQUEsV0FBS3dELE1BQUksQ0FBQ1Esb0JBQW9CLENBQUNoRCxPQUFPLEVBQUU1QixLQUFLLENBQUM7c0JBQUE7c0JBQUE7d0JBQUEsT0FBQTJFLFVBQUEsQ0FBQXJILElBQUE7b0JBQUE7a0JBQUEsR0FBQW1ILFFBQUE7Z0JBQUE7Z0JBQUEsaUJBQUFJLEdBQUE7a0JBQUEsT0FBQUwsS0FBQSxDQUFBeEosS0FBQSxPQUFBakMsU0FBQTtnQkFBQTtjQUFBLElBQ3ZFLENBQUM7WUFBQTtjQUZLc0wsY0FBYyxHQUFBRSxVQUFBLENBQUE5RSxJQUFBO2NBQUEsT0FBQThFLFVBQUEsQ0FBQTNELE1BQUEsV0FHYjNMLHVCQUFBLENBQUFvUCxjQUFjLEVBQUFuUCxJQUFBLENBQWRtUCxjQUFjLEVBQ25CLFVBQUNTLEtBQWUsRUFBRUMsSUFBYztnQkFBQSxJQUFBQyxVQUFBO2dCQUFBLE9BQUFsTCx1QkFBQSxDQUFBa0wsVUFBQSxPQUFBOVAsSUFBQSxDQUFBOFAsVUFBQSxFQUFBakwsa0JBQUEsQ0FBbUIrSyxLQUFLLEdBQUEvSyxrQkFBQSxDQUFLZ0wsSUFBSTtjQUFBLENBQUMsRUFDbEUsRUFDRixDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUFSLFVBQUEsQ0FBQWpILElBQUE7VUFBQTtRQUFBLEdBQUE2RyxRQUFBO01BQUEsQ0FDRjtNQUFBLFNBWEtoQyxxQkFBcUJBLENBQUE4QyxHQUFBLEVBQUFDLEdBQUE7UUFBQSxPQUFBaEIsc0JBQUEsQ0FBQWxKLEtBQUEsT0FBQWpDLFNBQUE7TUFBQTtNQUFBLE9BQXJCb0oscUJBQXFCO0lBQUE7SUFhM0I7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBdEosR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQXFNLHFCQUFBLEdBQUF4SSxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQXVJLFNBQ0V4RCxPQUFlLEVBQ2Y1QixLQUFhO1FBQUEsSUFBQXFGLFVBQUE7UUFBQSxJQUFBQyxLQUFBLEVBQUFDLFVBQUEsRUFBQUMsRUFBQSxFQUFBQyxLQUFBLEVBQUFDLFVBQUEsRUFBQUMsTUFBQSxFQUFBL0wsQ0FBQSxFQUFBZ00sTUFBQSxFQUFBQyxXQUFBLEVBQUFDLE1BQUEsRUFBQUMsTUFBQTtRQUFBLE9BQUFuSixtQkFBQSxDQUFBRyxJQUFBLFVBQUFpSixVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQS9JLElBQUEsR0FBQStJLFVBQUEsQ0FBQTlJLElBQUE7WUFBQTtjQUViLElBQUksQ0FBQzdHLE9BQU8sQ0FBQ0ksS0FBSyxDQUFBb0QsdUJBQUEsQ0FBQXVMLFVBQUEsd0JBQUExTyxNQUFBLENBQXFCcUosS0FBSyxlQUFBOUssSUFBQSxDQUFBbVEsVUFBQSxFQUFTekQsT0FBTyxVQUFNLENBQUM7Y0FDN0QwRCxLQUFLLEdBQUd0RixLQUFLLENBQUN4RyxLQUFLLENBQUMsR0FBRyxDQUFDO2NBQUEsTUFDMUI4TCxLQUFLLENBQUNBLEtBQUssQ0FBQ3RNLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHO2dCQUFBaU4sVUFBQSxDQUFBOUksSUFBQTtnQkFBQTtjQUFBO2NBQUE4SSxVQUFBLENBQUE5SSxJQUFBO2NBQUEsT0FDaEIsSUFBSSxDQUFDOUcsS0FBSyxDQUFDc04sU0FBUyxDQUFDL0IsT0FBTyxDQUFDO1lBQUE7Y0FBeEM0RCxFQUFFLEdBQUFTLFVBQUEsQ0FBQXhHLElBQUE7Y0FDUixJQUFJLENBQUNuSixPQUFPLENBQUNJLEtBQUssVUFBQUMsTUFBQSxDQUFVaUwsT0FBTyx3QkFBcUIsQ0FBQztjQUFDLE1BQ3REMEQsS0FBSyxDQUFDdE0sTUFBTSxHQUFHLENBQUM7Z0JBQUFpTixVQUFBLENBQUE5SSxJQUFBO2dCQUFBO2NBQUE7Y0FDWnNJLEtBQUssR0FBR0gsS0FBSyxDQUFDWSxLQUFLLENBQUMsQ0FBQztjQUFBUixVQUFBLEdBQUE3RiwwQkFBQSxDQUNYMkYsRUFBRSxDQUFDdE8sTUFBTTtjQUFBK08sVUFBQSxDQUFBL0ksSUFBQTtjQUFBd0ksVUFBQSxDQUFBNUYsQ0FBQTtZQUFBO2NBQUEsS0FBQTZGLE1BQUEsR0FBQUQsVUFBQSxDQUFBM0YsQ0FBQSxJQUFBOUIsSUFBQTtnQkFBQWdJLFVBQUEsQ0FBQTlJLElBQUE7Z0JBQUE7Y0FBQTtjQUFkdkQsQ0FBQyxHQUFBK0wsTUFBQSxDQUFBN00sS0FBQTtjQUFBLE1BRVJjLENBQUMsQ0FBQ2tLLGdCQUFnQixJQUNsQjJCLEtBQUssSUFDTDdMLENBQUMsQ0FBQ2tLLGdCQUFnQixDQUFDRixXQUFXLENBQUMsQ0FBQyxLQUFLNkIsS0FBSyxDQUFDN0IsV0FBVyxDQUFDLENBQUM7Z0JBQUFxQyxVQUFBLENBQUE5SSxJQUFBO2dCQUFBO2NBQUE7Y0FFbER5SSxNQUFNLEdBQUdoTSxDQUFDO2NBQ1ZpTSxXQUFXLEdBQUdELE1BQU0sQ0FBQ0MsV0FBVyxJQUFJLEVBQUU7Y0FDdENDLE1BQU0sR0FBR0QsV0FBVyxDQUFDN00sTUFBTSxLQUFLLENBQUMsR0FBRzZNLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNO2NBQUFJLFVBQUEsQ0FBQTlJLElBQUE7Y0FBQSxPQUM1QyxJQUFJLENBQUN5SCxvQkFBb0IsQ0FDNUNrQixNQUFNLEVBQ05SLEtBQUssQ0FBQzdILElBQUksQ0FBQyxHQUFHLENBQ2hCLENBQUM7WUFBQTtjQUhLc0ksTUFBTSxHQUFBRSxVQUFBLENBQUF4RyxJQUFBO2NBQUEsT0FBQXdHLFVBQUEsQ0FBQXJGLE1BQUEsV0FJTGxILG9CQUFBLENBQUFxTSxNQUFNLEVBQUE3USxJQUFBLENBQU42USxNQUFNLEVBQUssVUFBQ0ksRUFBRTtnQkFBQSxJQUFBQyxVQUFBO2dCQUFBLE9BQUF0TSx1QkFBQSxDQUFBc00sVUFBQSxNQUFBelAsTUFBQSxDQUFROE8sS0FBSyxRQUFBdlEsSUFBQSxDQUFBa1IsVUFBQSxFQUFJRCxFQUFFO2NBQUEsQ0FBRSxDQUFDO1lBQUE7Y0FBQUYsVUFBQSxDQUFBOUksSUFBQTtjQUFBO1lBQUE7Y0FBQThJLFVBQUEsQ0FBQTlJLElBQUE7Y0FBQTtZQUFBO2NBQUE4SSxVQUFBLENBQUEvSSxJQUFBO2NBQUErSSxVQUFBLENBQUE1SSxFQUFBLEdBQUE0SSxVQUFBO2NBQUFQLFVBQUEsQ0FBQWhOLENBQUEsQ0FBQXVOLFVBQUEsQ0FBQTVJLEVBQUE7WUFBQTtjQUFBNEksVUFBQSxDQUFBL0ksSUFBQTtjQUFBd0ksVUFBQSxDQUFBOUwsQ0FBQTtjQUFBLE9BQUFxTSxVQUFBLENBQUF4RixNQUFBO1lBQUE7Y0FBQSxPQUFBd0YsVUFBQSxDQUFBckYsTUFBQSxXQUd4QyxFQUFFO1lBQUE7Y0FBQSxPQUFBcUYsVUFBQSxDQUFBckYsTUFBQSxXQUVKbEgsb0JBQUEsQ0FBQTZMLFVBQUEsR0FBQUMsRUFBRSxDQUFDdE8sTUFBTSxFQUFBaEMsSUFBQSxDQUFBcVEsVUFBQSxFQUFLLFVBQUMzTCxDQUFDO2dCQUFBLE9BQUtBLENBQUMsQ0FBQ3lNLElBQUk7Y0FBQSxFQUFDO1lBQUE7Y0FBQSxPQUFBSixVQUFBLENBQUFyRixNQUFBLFdBRTlCLENBQUNaLEtBQUssQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBaUcsVUFBQSxDQUFBM0ksSUFBQTtVQUFBO1FBQUEsR0FBQThILFFBQUE7TUFBQSxDQUNmO01BQUEsU0FoQ0tSLG9CQUFvQkEsQ0FBQTBCLElBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFwQixxQkFBQSxDQUFBbkssS0FBQSxPQUFBakMsU0FBQTtNQUFBO01BQUEsT0FBcEI2TCxvQkFBb0I7SUFBQTtJQWtDMUI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBL0wsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQTBOLFFBQUEsR0FBQTdKLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBNEosU0FBQTtRQUFBLElBQUFoSSxJQUFBLEVBQUFmLEdBQUE7UUFBQSxPQUFBZCxtQkFBQSxDQUFBRyxJQUFBLFVBQUEySixVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXpKLElBQUEsR0FBQXlKLFVBQUEsQ0FBQXhKLElBQUE7WUFBQTtjQUFBd0osVUFBQSxDQUFBeEosSUFBQTtjQUFBLE9BQ3FCLElBQUksQ0FBQ3FDLE1BQU0sQ0FBQyxDQUFDO1lBQUE7Y0FBMUJmLElBQUksR0FBQWtJLFVBQUEsQ0FBQWxILElBQUE7Y0FDVixJQUFJLENBQUNuSixPQUFPLENBQUNJLEtBQUssV0FBQUMsTUFBQSxDQUFXOEgsSUFBSSxDQUFFLENBQUM7Y0FDOUJmLEdBQUcsc0JBQUEvRyxNQUFBLENBQXNCK0ksa0JBQWtCLENBQUNqQixJQUFJLENBQUM7Y0FBQSxPQUFBa0ksVUFBQSxDQUFBL0YsTUFBQSxXQUNoRCxJQUFJLENBQUN2SyxLQUFLLENBQUNzSixPQUFPLENBQXFCakMsR0FBRyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUFpSixVQUFBLENBQUFySixJQUFBO1VBQUE7UUFBQSxHQUFBbUosUUFBQTtNQUFBLENBQ25EO01BQUEsU0FMS0csT0FBT0EsQ0FBQTtRQUFBLE9BQUFKLFFBQUEsQ0FBQXhMLEtBQUEsT0FBQWpDLFNBQUE7TUFBQTtNQUFBLE9BQVA2TixPQUFPO0lBQUE7SUFPYjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUEvTixHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBK04sT0FBQSxHQUFBbEssaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUFpSyxVQUFBO1FBQUEsT0FBQWxLLG1CQUFBLENBQUFHLElBQUEsVUFBQWdLLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBOUosSUFBQSxHQUFBOEosVUFBQSxDQUFBN0osSUFBQTtZQUFBO2NBQUEsS0FDTSxJQUFJLENBQUMxRyxLQUFLO2dCQUFBdVEsVUFBQSxDQUFBN0osSUFBQTtnQkFBQTtjQUFBO2NBQUEsT0FBQTZKLFVBQUEsQ0FBQXBHLE1BQUEsV0FDTCxJQUFJLENBQUNuSyxLQUFLO1lBQUE7Y0FBQXVRLFVBQUEsQ0FBQTdKLElBQUE7Y0FBQSxPQUViLElBQUksQ0FBQ3FGLGFBQWEsQ0FBQyxDQUFDO1lBQUE7Y0FBQSxPQUFBd0UsVUFBQSxDQUFBcEcsTUFBQSxXQUNuQjlMLFVBQVUsQ0FBQyxJQUFJLENBQUN1QyxPQUFPLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQTJQLFVBQUEsQ0FBQTFKLElBQUE7VUFBQTtRQUFBLEdBQUF3SixTQUFBO01BQUEsQ0FDaEM7TUFBQSxTQU5LdEgsTUFBTUEsQ0FBQTtRQUFBLE9BQUFxSCxPQUFBLENBQUE3TCxLQUFBLE9BQUFqQyxTQUFBO01BQUE7TUFBQSxPQUFOeUcsTUFBTTtJQUFBO0lBUVo7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBTEU7RUFBQTtJQUFBM0csR0FBQTtJQUFBQyxLQUFBLEVBTUEsU0FBQW1PLElBQUlBLENBQ0ZDLFNBR2EsRUFDYkMsUUFBOEQsRUFDOUM7TUFDaEIsSUFBSSxDQUFDNUssU0FBUyxHQUFHLElBQUk7TUFDckIsSUFBSSxDQUFDLElBQUksQ0FBQ0gsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDRCxTQUFTLEVBQUU7UUFDdEMsSUFBSSxDQUFDaEcsT0FBTyxDQUFDLENBQUM7TUFDaEI7TUFDQSxJQUFJLENBQUMsSUFBSSxDQUFDNkIsUUFBUSxFQUFFO1FBQ2xCLE1BQU0sSUFBSWtCLEtBQUssQ0FDYix5REFDRixDQUFDO01BQ0g7TUFDQSxPQUFPLElBQUksQ0FBQ2xCLFFBQVEsQ0FBQ2lQLElBQUksQ0FBQ0MsU0FBUyxFQUFFQyxRQUFRLENBQUM7SUFDaEQ7RUFBQztJQUFBdE8sR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQXNPLE1BQUtBLENBQ0hELFFBRTJELEVBQzNCO01BQ2hDLE9BQU8sSUFBSSxDQUFDRixJQUFJLENBQUMsSUFBSSxFQUFFRSxRQUFRLENBQUM7SUFDbEM7RUFBQztJQUFBdE8sR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQXVPLE9BQU9BLENBQUEsRUFBbUM7TUFDeEM7TUFDQSxPQUFPcFAsUUFBQSxDQUFRQyxPQUFPLENBQUUsSUFBeUMsQ0FBQztJQUNwRTs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBVyxHQUFBO0lBQUFDLEtBQUEsRUFLQSxTQUFBMUMsT0FBT0EsQ0FBQzJLLElBQThCLEVBQUVsTCxPQUE2QixFQUFFO01BQUEsSUFBQXlSLHFCQUFBO1FBQUFDLE1BQUE7TUFDckUsSUFBSXRILE9BQUEsQ0FBT2MsSUFBSSxNQUFLLFFBQVEsSUFBSUEsSUFBSSxLQUFLLElBQUksRUFBRTtRQUM3Q2xMLE9BQU8sR0FBR2tMLElBQUk7UUFDZEEsSUFBSSxHQUFHOUgsU0FBUztNQUNsQjtNQUNBcEQsT0FBTyxHQUFHQSxPQUFPLElBQUksQ0FBQyxDQUFDO01BQ3ZCLElBQU0yUixLQUFrQixHQUFHekcsSUFBSSxJQUFLLElBQUksQ0FBQzFKLE9BQU8sQ0FBQ2lFLEtBQXFCO01BQ3RFLElBQUksQ0FBQ2tNLEtBQUssRUFBRTtRQUNWLE1BQU0sSUFBSXRPLEtBQUssQ0FDYixpRUFDRixDQUFDO01BQ0g7TUFDQTtNQUNBLElBQU11TyxZQUFZLEdBQ2hCNVIsT0FBTyxDQUFDNlIsU0FBUyxLQUFLLEtBQUssR0FDdkIsQ0FBQyxDQUFDLEdBQ0YsT0FBTzdSLE9BQU8sQ0FBQzhSLGFBQWEsS0FBSyxRQUFRLEdBQ3pDOVIsT0FBTyxDQUFDOFIsYUFBYTtNQUNyQjtNQUNGLElBQUksQ0FBQ3RSLEtBQUssQ0FBQ3VSLGNBQWMsQ0FBQyxFQUFFLENBQUMsR0FDM0JyUyxzQkFBc0IsR0FDdEIsSUFBSSxDQUFDYyxLQUFLLENBQUN3UixXQUFXLEdBQUcsQ0FBQztNQUVoQyxJQUFNQyxjQUFjLElBQUFSLHFCQUFBLEdBQUd6UixPQUFPLENBQUNpUyxjQUFjLGNBQUFSLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUk5Uix3QkFBd0I7TUFFekUsT0FBTyxJQUFBeUMsUUFBQSxDQUFZLFVBQUNDLE9BQU8sRUFBRUMsTUFBTSxFQUFLO1FBQ3RDLElBQU00UCxXQUFXLEdBQUcsU0FBZEEsV0FBV0EsQ0FBQTtVQUFBLE9BQ2ZSLE1BQUksQ0FBQ2xSLEtBQUssQ0FDUHVMLE9BQU8sQ0FBQzRGLEtBQUssQ0FBQyxDQUNkUSxVQUFVLENBQUMsQ0FBQyxDQUNaNVAsRUFBRSxDQUFDLFVBQVUsRUFBRUYsT0FBTyxDQUFDLENBQ3ZCRSxFQUFFLENBQUMsT0FBTyxFQUFFRCxNQUFNLENBQUM7UUFBQTtRQUN4QixJQUFJcUUsT0FBaUIsR0FBRyxFQUFFO1FBQzFCLElBQUl5TCxLQUE0QyxHQUFHLElBQUk7UUFDdkQsSUFBTUMsWUFBWSxHQUFHLFNBQWZBLFlBQVlBLENBQUlDLEdBQVcsRUFBSztVQUNwQyxJQUFJLENBQUNBLEdBQUcsQ0FBQ0MsRUFBRSxFQUFFO1lBQ1gsSUFBTTVQLEdBQUcsR0FBRyxJQUFJVSxLQUFLLENBQ25CLHVEQUNGLENBQUM7WUFDRHFPLE1BQUksQ0FBQzlPLElBQUksQ0FBQyxPQUFPLEVBQUVELEdBQUcsQ0FBQztZQUN2QjtVQUNGO1VBQ0EsSUFBTUYsTUFBYyxHQUFHO1lBQUU4UCxFQUFFLEVBQUVELEdBQUcsQ0FBQ0M7VUFBRyxDQUFDO1VBQ3JDLElBQUlILEtBQUssRUFBRTtZQUNUQSxLQUFLLENBQUNJLEtBQUssQ0FBQy9QLE1BQU0sQ0FBQztVQUNyQixDQUFDLE1BQU07WUFDTGtFLE9BQU8sQ0FBQ2pFLElBQUksQ0FBQ0QsTUFBTSxDQUFDO1lBQ3BCLElBQ0VtUCxZQUFZLElBQUksQ0FBQyxJQUNqQmpMLE9BQU8sQ0FBQ3hELE1BQU0sR0FBR3lPLFlBQVksSUFDN0JLLGNBQWMsS0FBSyxDQUFDLEVBQ3BCO2NBQ0E7Y0FDQUcsS0FBSyxHQUFHRixXQUFXLENBQUMsQ0FBQztjQUNyQixTQUFBTyxHQUFBLE1BQUFDLFFBQUEsR0FBcUIvTCxPQUFPLEVBQUE4TCxHQUFBLEdBQUFDLFFBQUEsQ0FBQXZQLE1BQUEsRUFBQXNQLEdBQUEsSUFBRTtnQkFBekIsSUFBTWhRLFFBQU0sR0FBQWlRLFFBQUEsQ0FBQUQsR0FBQTtnQkFDZkwsS0FBSyxDQUFDSSxLQUFLLENBQUMvUCxRQUFNLENBQUM7Y0FDckI7Y0FDQWtFLE9BQU8sR0FBRyxFQUFFO1lBQ2Q7VUFDRjtRQUNGLENBQUM7UUFDRCxJQUFNZ00sU0FBUyxHQUFHLFNBQVpBLFNBQVNBLENBQUEsRUFBUztVQUN0QixJQUFJUCxLQUFLLEVBQUU7WUFDVEEsS0FBSyxDQUFDUSxHQUFHLENBQUMsQ0FBQztVQUNiLENBQUMsTUFBTTtZQUNMLElBQU1DLEdBQUcsR0FBR2hQLG9CQUFBLENBQUE4QyxPQUFPLEVBQUF0SCxJQUFBLENBQVBzSCxPQUFPLEVBQUssVUFBQ2xFLE1BQU07Y0FBQSxPQUFLQSxNQUFNLENBQUM4UCxFQUFFO1lBQUEsQ0FBVSxDQUFDO1lBQ3hELElBQUk1TCxPQUFPLENBQUN4RCxNQUFNLEdBQUd5TyxZQUFZLElBQUlLLGNBQWMsS0FBSyxDQUFDLEVBQUU7Y0FDekRQLE1BQUksQ0FBQ2xSLEtBQUssQ0FBQ3NTLEtBQUssQ0FDYkMscUJBQXFCLENBQUM7Z0JBQ3JCQyxNQUFNLEVBQUVyQixLQUFLO2dCQUNic0IsU0FBUyxFQUFFLFFBQVE7Z0JBQ25CQyxLQUFLLEVBQUV2TTtjQUNULENBQUMsQ0FBQyxDQUNEeUssSUFBSSxDQUNILFVBQUMrQixVQUFVO2dCQUFBLE9BQ1Q5USxPQUFPLENBQUNxUCxNQUFJLENBQUMwQiw2QkFBNkIsQ0FBQ0QsVUFBVSxDQUFDLENBQUM7Y0FBQSxHQUN6RDdRLE1BQ0YsQ0FBQztZQUNMLENBQUMsTUFBTTtjQUNMb1AsTUFBSSxDQUFDbFIsS0FBSyxDQUNQdUwsT0FBTyxDQUFDNEYsS0FBSyxDQUFDLENBQ2RwUixPQUFPLENBQUNzUyxHQUFHLEVBQUU7Z0JBQUVRLGNBQWMsRUFBRTtjQUFLLENBQUMsQ0FBQyxDQUN0Q2pDLElBQUksQ0FBQy9PLE9BQU8sRUFBRUMsTUFBTSxDQUFDO1lBQzFCO1VBQ0Y7UUFDRixDQUFDO1FBQ0RvUCxNQUFJLENBQUN6RyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQ2xCMUksRUFBRSxDQUFDLE1BQU0sRUFBRThQLFlBQVksQ0FBQyxDQUN4QjlQLEVBQUUsQ0FBQyxLQUFLLEVBQUVvUSxTQUFTLENBQUMsQ0FDcEJwUSxFQUFFLENBQUMsT0FBTyxFQUFFRCxNQUFNLENBQUM7TUFDeEIsQ0FBQyxDQUFDO0lBQ0o7RUFBQztJQUFBVSxHQUFBO0lBQUFDLEtBQUEsRUF3QkQsU0FBQXFRLE1BQU1BLENBQ0pDLE9BQThCLEVBQzlCckksSUFBNkIsRUFDN0JsTCxPQUE0QixFQUM1QjtNQUFBLElBQUF3VCxzQkFBQTtRQUFBQyxNQUFBO01BQ0EsSUFBSXJKLE9BQUEsQ0FBT2MsSUFBSSxNQUFLLFFBQVEsSUFBSUEsSUFBSSxLQUFLLElBQUksRUFBRTtRQUM3Q2xMLE9BQU8sR0FBR2tMLElBQUk7UUFDZEEsSUFBSSxHQUFHOUgsU0FBUztNQUNsQjtNQUNBcEQsT0FBTyxHQUFHQSxPQUFPLElBQUksQ0FBQyxDQUFDO01BQ3ZCLElBQU0yUixLQUFrQixHQUN0QnpHLElBQUksSUFBSyxJQUFJLENBQUMxSixPQUFPLElBQUssSUFBSSxDQUFDQSxPQUFPLENBQUNpRSxLQUFzQjtNQUMvRCxJQUFJLENBQUNrTSxLQUFLLEVBQUU7UUFDVixNQUFNLElBQUl0TyxLQUFLLENBQ2IsaUVBQ0YsQ0FBQztNQUNIO01BQ0EsSUFBTXFRLFlBQVksR0FDaEIsT0FBT0gsT0FBTyxLQUFLLFVBQVUsR0FDekIxUCxvQkFBQSxDQUFBOUUsWUFBWSxFQUFBTSxJQUFBLENBQVpOLFlBQVksRUFBS3dVLE9BQU8sQ0FBQyxHQUN6QnhVLFlBQVksQ0FBQzRVLGVBQWUsQ0FBQ0osT0FBTyxFQUFFdlQsT0FBTyxDQUFDNFQsc0JBQXNCLENBQUM7TUFDM0U7TUFDQSxJQUFNaEMsWUFBWSxHQUNoQjVSLE9BQU8sQ0FBQzZSLFNBQVMsS0FBSyxLQUFLLEdBQ3ZCLENBQUMsQ0FBQyxHQUNGLE9BQU83UixPQUFPLENBQUM4UixhQUFhLEtBQUssUUFBUSxHQUN6QzlSLE9BQU8sQ0FBQzhSLGFBQWE7TUFDckI7TUFDRixJQUFJLENBQUN0UixLQUFLLENBQUN1UixjQUFjLENBQUMsRUFBRSxDQUFDLEdBQzNCclMsc0JBQXNCLEdBQ3RCLElBQUksQ0FBQ2MsS0FBSyxDQUFDd1IsV0FBVyxHQUFHLENBQUM7TUFDaEMsSUFBTUMsY0FBYyxJQUFBdUIsc0JBQUEsR0FBR3hULE9BQU8sQ0FBQ2lTLGNBQWMsY0FBQXVCLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUk3VCx3QkFBd0I7TUFDekUsT0FBTyxJQUFBeUMsUUFBQSxDQUFZLFVBQUNDLE9BQU8sRUFBRUMsTUFBTSxFQUFLO1FBQ3RDLElBQU00UCxXQUFXLEdBQUcsU0FBZEEsV0FBV0EsQ0FBQTtVQUFBLE9BQ2Z1QixNQUFJLENBQUNqVCxLQUFLLENBQ1B1TCxPQUFPLENBQUM0RixLQUFLLENBQUMsQ0FDZGtDLFVBQVUsQ0FBQyxDQUFDLENBQ1p0UixFQUFFLENBQUMsVUFBVSxFQUFFRixPQUFPLENBQUMsQ0FDdkJFLEVBQUUsQ0FBQyxPQUFPLEVBQUVELE1BQU0sQ0FBQztRQUFBO1FBQ3hCLElBQUlxRSxPQUF5QyxHQUFHLEVBQUU7UUFDbEQsSUFBSXlMLEtBQTRDLEdBQUcsSUFBSTtRQUN2RCxJQUFNQyxZQUFZLEdBQUcsU0FBZkEsWUFBWUEsQ0FBSTVQLE1BQWMsRUFBSztVQUN2QyxJQUFJMlAsS0FBSyxFQUFFO1lBQ1RBLEtBQUssQ0FBQ0ksS0FBSyxDQUFDL1AsTUFBTSxDQUFDO1VBQ3JCLENBQUMsTUFBTTtZQUNMa0UsT0FBTyxDQUFDakUsSUFBSSxDQUFDRCxNQUFtQyxDQUFDO1VBQ25EO1VBQ0EsSUFDRW1QLFlBQVksSUFBSSxDQUFDLElBQ2pCakwsT0FBTyxDQUFDeEQsTUFBTSxHQUFHeU8sWUFBWSxJQUM3QkssY0FBYyxLQUFLLENBQUMsRUFDcEI7WUFDQTtZQUNBRyxLQUFLLEdBQUdGLFdBQVcsQ0FBQyxDQUFDO1lBQ3JCLFNBQUE0QixHQUFBLE1BQUFDLFNBQUEsR0FBcUJwTixPQUFPLEVBQUFtTixHQUFBLEdBQUFDLFNBQUEsQ0FBQTVRLE1BQUEsRUFBQTJRLEdBQUEsSUFBRTtjQUF6QixJQUFNclIsUUFBTSxHQUFBc1IsU0FBQSxDQUFBRCxHQUFBO2NBQ2YxQixLQUFLLENBQUNJLEtBQUssQ0FBQy9QLFFBQU0sQ0FBQztZQUNyQjtZQUNBa0UsT0FBTyxHQUFHLEVBQUU7VUFDZDtRQUNGLENBQUM7UUFDRCxJQUFNZ00sU0FBUyxHQUFHLFNBQVpBLFNBQVNBLENBQUEsRUFBUztVQUN0QixJQUFJUCxLQUFLLEVBQUU7WUFDVEEsS0FBSyxDQUFDUSxHQUFHLENBQUMsQ0FBQztVQUNiLENBQUMsTUFBTTtZQUNMLElBQUlqTSxPQUFPLENBQUN4RCxNQUFNLEdBQUd5TyxZQUFZLElBQUlLLGNBQWMsS0FBSyxDQUFDLEVBQUU7Y0FDekR3QixNQUFJLENBQUNqVCxLQUFLLENBQUNzUyxLQUFLLENBQ2JDLHFCQUFxQixDQUFDO2dCQUNyQkMsTUFBTSxFQUFFckIsS0FBSztnQkFDYnNCLFNBQVMsRUFBRSxRQUFRO2dCQUNuQkMsS0FBSyxFQUFFdk07Y0FDVCxDQUFDLENBQUMsQ0FDRHlLLElBQUksQ0FDSCxVQUFDK0IsVUFBVTtnQkFBQSxPQUNUOVEsT0FBTyxDQUFDb1IsTUFBSSxDQUFDTCw2QkFBNkIsQ0FBQ0QsVUFBVSxDQUFDLENBQUM7Y0FBQSxHQUN6RDdRLE1BQ0YsQ0FBQztZQUNMLENBQUMsTUFBTTtjQUNMbVIsTUFBSSxDQUFDalQsS0FBSyxDQUNQdUwsT0FBTyxDQUFDNEYsS0FBSyxDQUFDLENBQ2QyQixNQUFNLENBQUMzTSxPQUFPLEVBQUU7Z0JBQUUwTSxjQUFjLEVBQUU7Y0FBSyxDQUFDLENBQUMsQ0FDekNqQyxJQUFJLENBQUMvTyxPQUFPLEVBQUVDLE1BQU0sQ0FBQztZQUMxQjtVQUNGO1FBQ0YsQ0FBQztRQUNEbVIsTUFBSSxDQUFDeEksTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUNsQjFJLEVBQUUsQ0FBQyxPQUFPLEVBQUVELE1BQU0sQ0FBQyxDQUNuQjZJLElBQUksQ0FBQ3VJLFlBQVksQ0FBQyxDQUNsQm5SLEVBQUUsQ0FBQyxNQUFNLEVBQUU4UCxZQUFZLENBQUMsQ0FDeEI5UCxFQUFFLENBQUMsS0FBSyxFQUFFb1EsU0FBUyxDQUFDLENBQ3BCcFEsRUFBRSxDQUFDLE9BQU8sRUFBRUQsTUFBTSxDQUFDO01BQ3hCLENBQUMsQ0FBQztJQUNKO0VBQUM7SUFBQVUsR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBUW1RLDZCQUE2QkEsQ0FDbkNZLGlCQUF3QyxFQUMxQjtNQUFBLElBQUFDLFVBQUEsRUFBQUMsVUFBQSxFQUFBQyxVQUFBO01BQ2QsSUFBTUMsa0JBQWdDLEdBQUd2USxvQkFBQSxDQUFBb1EsVUFBQSxHQUFBRCxpQkFBaUIsQ0FBQ0ssaUJBQWlCLEVBQUFoVixJQUFBLENBQUE0VSxVQUFBLEVBQzFFLFVBQUNLLENBQUMsRUFBSztRQUNMLElBQU1DLFVBQXNCLEdBQUc7VUFDN0JDLEVBQUUsRUFBRUYsQ0FBQyxDQUFDRyxNQUFNO1VBQ1pDLE9BQU8sRUFBRSxJQUFJO1VBQ2JDLE1BQU0sRUFBRTtRQUNWLENBQUM7UUFDRCxPQUFPSixVQUFVO01BQ25CLENBQ0YsQ0FBQztNQUVELElBQU1LLGlCQUFpQixHQUFHL1Esb0JBQUEsQ0FBQXFRLFVBQUEsR0FBQUYsaUJBQWlCLENBQUNhLGFBQWEsRUFBQXhWLElBQUEsQ0FBQTZVLFVBQUEsRUFBSyxVQUFDSSxDQUFDLEVBQUs7UUFDbkUsSUFBTUMsVUFBc0IsR0FBRztVQUM3QkcsT0FBTyxFQUFFLEtBQUs7VUFDZEMsTUFBTSxFQUFFLENBQ047WUFDRUcsU0FBUyxFQUFFUixDQUFDLENBQUNTLFNBQVM7WUFDdEJDLE9BQU8sRUFBRVYsQ0FBQyxDQUFDUztVQUNiLENBQUM7UUFFTCxDQUFDO1FBQ0QsT0FBT1IsVUFBVTtNQUNuQixDQUFDLENBQUM7TUFFRixPQUFBdFEsdUJBQUEsQ0FBQWtRLFVBQUEsT0FBQTlVLElBQUEsQ0FBQThVLFVBQUEsRUFBQWpRLGtCQUFBLENBQVdrUSxrQkFBa0IsR0FBQWxRLGtCQUFBLENBQUswUSxpQkFBaUI7SUFDckQ7O0lBRUE7QUFDRjtBQUNBO0FBQ0E7RUFIRTtJQUFBNVIsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQWdTLHlCQUFBLEdBQUFuTyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBSUEsU0FBQWtPLFVBQ0V6UyxNQUFjLEVBQ2QwUyxTQUFpQixFQUNqQnJULE9BQW1DO1FBQUEsSUFBQXNULGFBQUEsRUFBQUMsVUFBQSxFQUFBaE4sY0FBQSxFQUFBUSxJQUFBO1FBQUEsT0FBQTlCLG1CQUFBLENBQUFHLElBQUEsVUFBQW9PLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBbE8sSUFBQSxHQUFBa08sVUFBQSxDQUFBak8sSUFBQTtZQUFBO2NBRTdCOE4sYUFBYSxHQUFHM1MsTUFBTSxDQUFDMFMsU0FBUyxDQUFDO2NBQUEsTUFDbkMsQ0FBQ0MsYUFBYSxJQUFJLENBQUNBLGFBQWEsQ0FBQ3pPLE9BQU87Z0JBQUE0TyxVQUFBLENBQUFqTyxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxPQUFBaU8sVUFBQSxDQUFBeEssTUFBQSxXQUNuQyxFQUFFO1lBQUE7Y0FHUHNLLFVBQVUsR0FBQW5SLGtCQUFBLENBQU9rUixhQUFhLENBQUN6TyxPQUFPO2NBQ3RDMEIsY0FBYyxHQUFHK00sYUFBYSxDQUFDL00sY0FBYztZQUFBO2NBQUEsS0FFMUNBLGNBQWM7Z0JBQUFrTixVQUFBLENBQUFqTyxJQUFBO2dCQUFBO2NBQUE7Y0FBQWlPLFVBQUEsQ0FBQWpPLElBQUE7Y0FBQSxPQUdBLElBQUksQ0FBQzlHLEtBQUssQ0FBQ3NKLE9BQU8sQ0FBc0I7Z0JBQ3pEQyxNQUFNLEVBQUUsS0FBSztnQkFDYmxDLEdBQUcsRUFBRVEsY0FBYztnQkFBRTtnQkFDckJ2RyxPQUFPLEVBQVBBO2NBQ0YsQ0FBQyxDQUFDO1lBQUE7Y0FKSStHLElBQUksR0FBQTBNLFVBQUEsQ0FBQTNMLElBQUE7Y0FNVnlMLFVBQVUsR0FBR3BSLHVCQUFBLENBQUFvUixVQUFVLEVBQUFoVyxJQUFBLENBQVZnVyxVQUFVLEVBQVF4TSxJQUFJLENBQUNsQyxPQUFPLENBQUM7Y0FDNUMwQixjQUFjLEdBQUdRLElBQUksQ0FBQ1IsY0FBYztjQUFDa04sVUFBQSxDQUFBak8sSUFBQTtjQUFBO1lBQUE7Y0FBQSxPQUFBaU8sVUFBQSxDQUFBeEssTUFBQSxXQUdoQ3NLLFVBQVU7WUFBQTtZQUFBO2NBQUEsT0FBQUUsVUFBQSxDQUFBOU4sSUFBQTtVQUFBO1FBQUEsR0FBQXlOLFNBQUE7TUFBQSxDQUNsQjtNQUFBLFNBM0JhM0ssd0JBQXdCQSxDQUFBaUwsSUFBQSxFQUFBQyxJQUFBLEVBQUFDLElBQUE7UUFBQSxPQUFBVCx5QkFBQSxDQUFBOVAsS0FBQSxPQUFBakMsU0FBQTtNQUFBO01BQUEsT0FBeEJxSCx3QkFBd0I7SUFBQTtFQUFBO0FBQUEsRUFoOEI5QjFMLFlBQVk7O0FBODlCdEI7O0FBRUE7QUFDQTtBQUNBO0FBRkFZLGVBQUEsQ0FyK0JhRyxLQUFLLGFBTUNkLFNBQVMsQ0FBQyxPQUFPLENBQUM7QUFrK0JyQyxXQUFhNkcsUUFBUTtFQWFuQjtBQUNGO0FBQ0E7RUFDRSxTQUFBQSxTQUNFN0YsSUFBbUIsRUFDbkJ3TixPQUFZLEVBQ1p2TixNQUEwQixFQUMxQjRWLE1BQThCLEVBQzlCO0lBQUF6VixlQUFBLE9BQUF5RixRQUFBO0lBcURGO0FBQ0Y7QUFDQTtJQUZFbEcsZUFBQSxpQkFHUyxJQUFJLENBQUNXLElBQUk7SUFlbEI7QUFDRjtBQUNBO0lBRkVYLGVBQUEsa0JBQUFZLHFCQUFBLENBRzBDLElBQUk7SUF6RTVDLElBQUksQ0FBQ3VWLFFBQVEsR0FBR3RJLE9BQU87SUFDdkIsSUFBSSxDQUFDUCxNQUFNLEdBQUcsSUFBSW5OLEtBQUssQ0FBQ0UsSUFBSSxFQUFFQyxNQUFNLENBQUM7SUFDckMsSUFBSSxDQUFDOFYsT0FBTyxHQUFHRixNQUFNO0VBQ3ZCOztFQUVBO0FBQ0Y7QUFDQTtFQUZFLE9BQUE1UyxZQUFBLENBQUE0QyxRQUFBO0lBQUEzQyxHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBdEIsTUFBTUEsQ0FLSk4sTUFBNkIsRUFDcUM7TUFDbEU7TUFDQSxJQUFJLENBQUMwTCxNQUFNLEdBQUcsSUFBSSxDQUFDQSxNQUFNLENBQUNwTCxNQUFNLENBQUNOLE1BQU0sQ0FBUTtNQUMvQyxPQUFRLElBQUk7SUFTZDs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBMkIsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQTJCLEtBQUtBLENBQUNDLFVBQTBDLEVBQVE7TUFDdEQsSUFBSSxDQUFDa0ksTUFBTSxHQUFHLElBQUksQ0FBQ0EsTUFBTSxDQUFDbkksS0FBSyxDQUFDQyxVQUFVLENBQUM7TUFDM0MsT0FBTyxJQUFJO0lBQ2I7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQTdCLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUE2QixLQUFLQSxDQUFDQSxPQUFhLEVBQUU7TUFDbkIsSUFBSSxDQUFDaUksTUFBTSxHQUFHLElBQUksQ0FBQ0EsTUFBTSxDQUFDakksS0FBSyxDQUFDQSxPQUFLLENBQUM7TUFDdEMsT0FBTyxJQUFJO0lBQ2I7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQTlCLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUE3QyxJQUFJQSxDQUFDMkUsTUFBYyxFQUFFO01BQ25CLElBQUksQ0FBQ2dJLE1BQU0sR0FBRyxJQUFJLENBQUNBLE1BQU0sQ0FBQzNNLElBQUksQ0FBQzJFLE1BQU0sQ0FBQztNQUN0QyxPQUFPLElBQUk7SUFDYjtFQUFDO0lBQUEvQixHQUFBO0lBQUFDLEtBQUEsWUFBQTZTLE1BQUE7TUFBQSxTQVlEdlUsSUFBSUEsQ0FBQXdVLElBQUEsRUFBQUMsSUFBQTtRQUFBLE9BQUFGLE1BQUEsQ0FBQTNRLEtBQUEsT0FBQWpDLFNBQUE7TUFBQTtNQUFKM0IsSUFBSSxDQUFBNkQsUUFBQTtRQUFBLE9BQUEwUSxNQUFBLENBQUExUSxRQUFBO01BQUE7TUFBQSxPQUFKN0QsSUFBSTtJQUFBLEVBQUosVUFDRUEsSUFBMEQsRUFDMUQ4RCxHQUFhLEVBQ2I7TUFBQSxJQUFBNFEsVUFBQTtNQUNBLElBQUksQ0FBQ2xKLE1BQU0sR0FBRzFNLHFCQUFBLENBQUE0VixVQUFBLE9BQUksQ0FBQ2xKLE1BQU0sRUFBQTFOLElBQUEsQ0FBQTRXLFVBQUEsRUFBTTFVLElBQUksRUFBUzhELEdBQWMsQ0FBQztNQUMzRCxPQUFPLElBQUk7SUFDYixDQUFDO0VBQUE7SUFBQXJDLEdBQUE7SUFBQUMsS0FBQTtJQU9EO0FBQ0Y7QUFDQTtJQUZFO01BQUEsSUFBQWlULGNBQUEsR0FBQXBQLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBbVAsVUFBQTtRQUFBLElBQUFwSyxPQUFBO1FBQUEsT0FBQWhGLG1CQUFBLENBQUFHLElBQUEsVUFBQWtQLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBaFAsSUFBQSxHQUFBZ1AsVUFBQSxDQUFBL08sSUFBQTtZQUFBO2NBQUErTyxVQUFBLENBQUEvTyxJQUFBO2NBQUEsT0FDd0IsSUFBSSxDQUFDdU8sT0FBTyxDQUFDMUgsbUJBQW1CLENBQUMsSUFBSSxDQUFDeUgsUUFBUSxDQUFDO1lBQUE7Y0FBL0Q3SixPQUFPLEdBQUFzSyxVQUFBLENBQUF6TSxJQUFBO2NBQUEsT0FBQXlNLFVBQUEsQ0FBQXRMLE1BQUEsV0FDTixJQUFJLENBQUNnQyxNQUFNLENBQUNKLGFBQWEsQ0FBQ1osT0FBTyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUFzSyxVQUFBLENBQUE1TyxJQUFBO1VBQUE7UUFBQSxHQUFBME8sU0FBQTtNQUFBLENBQzFDO01BQUEsU0FIS3hKLGFBQWFBLENBQUE7UUFBQSxPQUFBdUosY0FBQSxDQUFBL1EsS0FBQSxPQUFBakMsU0FBQTtNQUFBO01BQUEsT0FBYnlKLGFBQWE7SUFBQTtJQUtuQjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUEzSixHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBMlAsR0FBR0EsQ0FBQSxFQU0wQjtNQUMzQixPQUFRLElBQUksQ0FBQ2lELE9BQU87SUFDdEI7RUFBQztBQUFBO0FBR0gsZUFBZWpXLEtBQUsiLCJpZ25vcmVMaXN0IjpbXX0=