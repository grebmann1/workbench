import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _readOnlyError from "@babel/runtime-corejs3/helpers/readOnlyError";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
var _excluded = ["$"];
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.to-string.js";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context17, _context18; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context17 = ownKeys(Object(t), !0)).call(_context17, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context18 = ownKeys(Object(t))).call(_context18, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
/**
 * @file Manages Salesforce Metadata API
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import { Readable } from 'stream';
import FormData from 'form-data';
import { registerModule } from '../jsforce';
import SOAP from '../soap';
import { isObject } from '../util/function';
import { ApiSchemas } from './metadata/schema';
export * from './metadata/schema';

/**
 *
 */

/**
 *
 */
function deallocateTypeWithMetadata(metadata) {
  var _ref = metadata,
    $ = _ref.$,
    md = _objectWithoutProperties(_ref, _excluded);
  return md;
}
function assignTypeWithMetadata(metadata, type) {
  var convert = function convert(md) {
    return _objectSpread(_defineProperty({}, '@xsi:type', type), md);
  };
  return _Array$isArray(metadata) ? _mapInstanceProperty(metadata).call(metadata, convert) : convert(metadata);
}

/**
 * Class for Salesforce Metadata API
 */
export var MetadataApi = /*#__PURE__*/function () {
  /**
   *
   */
  function MetadataApi(conn) {
    _classCallCheck(this, MetadataApi);
    /**
     * Polling interval in milliseconds
     */
    _defineProperty(this, "pollInterval", 1000);
    /**
     * Polling timeout in milliseconds
     */
    _defineProperty(this, "pollTimeout", 10000);
    this._conn = conn;
  }

  /**
   * Call Metadata API SOAP endpoint
   *
   * @private
   */
  return _createClass(MetadataApi, [{
    key: "_invoke",
    value: (function () {
      var _invoke2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(method, message, schema) {
        var _context;
        var soapEndpoint, res;
        return _regeneratorRuntime.wrap(function _callee$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              soapEndpoint = new SOAP(this._conn, {
                xmlns: 'http://soap.sforce.com/2006/04/metadata',
                endpointUrl: _concatInstanceProperty(_context = "".concat(this._conn.instanceUrl, "/services/Soap/m/")).call(_context, this._conn.version)
              });
              _context2.next = 3;
              return soapEndpoint.invoke(method, message, schema ? {
                result: schema
              } : undefined, ApiSchemas);
            case 3:
              res = _context2.sent;
              return _context2.abrupt("return", res.result);
            case 5:
            case "end":
              return _context2.stop();
          }
        }, _callee, this);
      }));
      function _invoke(_x, _x2, _x3) {
        return _invoke2.apply(this, arguments);
      }
      return _invoke;
    }()
    /**
     * Add one or more new metadata components to the organization.
     */
    )
  }, {
    key: "create",
    value: function create(type, metadata) {
      var isArray = _Array$isArray(metadata);
      metadata = assignTypeWithMetadata(metadata, type);
      var schema = isArray ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
      return this._invoke('createMetadata', {
        metadata: metadata
      }, schema);
    }

    /**
     * Read specified metadata components in the organization.
     */
  }, {
    key: "read",
    value: function () {
      var _read = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(type, fullNames) {
        var _context3;
        var ReadResultSchema, res;
        return _regeneratorRuntime.wrap(function _callee2$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              ReadResultSchema = type in ApiSchemas ? {
                type: ApiSchemas.ReadResult.type,
                props: {
                  records: [type]
                }
              } : ApiSchemas.ReadResult;
              _context4.next = 3;
              return this._invoke('readMetadata', {
                type: type,
                fullNames: fullNames
              }, ReadResultSchema);
            case 3:
              res = _context4.sent;
              return _context4.abrupt("return", _Array$isArray(fullNames) ? _mapInstanceProperty(_context3 = res.records).call(_context3, deallocateTypeWithMetadata) : deallocateTypeWithMetadata(res.records[0]));
            case 5:
            case "end":
              return _context4.stop();
          }
        }, _callee2, this);
      }));
      function read(_x4, _x5) {
        return _read.apply(this, arguments);
      }
      return read;
    }()
    /**
     * Update one or more metadata components in the organization.
     */
  }, {
    key: "update",
    value: function update(type, metadata) {
      var isArray = _Array$isArray(metadata);
      metadata = assignTypeWithMetadata(metadata, type);
      var schema = isArray ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
      return this._invoke('updateMetadata', {
        metadata: metadata
      }, schema);
    }

    /**
     * Upsert one or more components in your organization's data.
     */
  }, {
    key: "upsert",
    value: function upsert(type, metadata) {
      var isArray = _Array$isArray(metadata);
      metadata = assignTypeWithMetadata(metadata, type);
      var schema = isArray ? [ApiSchemas.UpsertResult] : ApiSchemas.UpsertResult;
      return this._invoke('upsertMetadata', {
        metadata: metadata
      }, schema);
    }

    /**
     * Deletes specified metadata components in the organization.
     */
  }, {
    key: "delete",
    value: function _delete(type, fullNames) {
      var schema = _Array$isArray(fullNames) ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
      return this._invoke('deleteMetadata', {
        type: type,
        fullNames: fullNames
      }, schema);
    }

    /**
     * Rename fullname of a metadata component in the organization
     */
  }, {
    key: "rename",
    value: function rename(type, oldFullName, newFullName) {
      return this._invoke('renameMetadata', {
        type: type,
        oldFullName: oldFullName,
        newFullName: newFullName
      }, ApiSchemas.SaveResult);
    }

    /**
     * Retrieves the metadata which describes your organization, including Apex classes and triggers,
     * custom objects, custom fields on standard objects, tab sets that define an app,
     * and many other components.
     */
  }, {
    key: "describe",
    value: function describe(asOfVersion) {
      if (!asOfVersion) {
        asOfVersion = this._conn.version;
      }
      return this._invoke('describeMetadata', {
        asOfVersion: asOfVersion
      }, ApiSchemas.DescribeMetadataResult);
    }

    /**
     * Retrieves property information about metadata components in your organization
     */
  }, {
    key: "list",
    value: function list(queries, asOfVersion) {
      if (!asOfVersion) {
        asOfVersion = this._conn.version;
      }
      return this._invoke('listMetadata', {
        queries: queries,
        asOfVersion: asOfVersion
      }, [ApiSchemas.FileProperties]);
    }

    /**
     * Checks the status of asynchronous metadata calls
     */
  }, {
    key: "checkStatus",
    value: function checkStatus(asyncProcessId) {
      var res = this._invoke('checkStatus', {
        asyncProcessId: asyncProcessId
      }, ApiSchemas.AsyncResult);
      return new AsyncResultLocator(this, res);
    }

    /**
     * Retrieves XML file representations of components in an organization
     */
  }, {
    key: "retrieve",
    value: function retrieve(request) {
      var res = this._invoke('retrieve', {
        request: request
      }, ApiSchemas.RetrieveResult);
      return new RetrieveResultLocator(this, res);
    }

    /**
     * Checks the status of declarative metadata call retrieve() and returns the zip file contents
     */
  }, {
    key: "checkRetrieveStatus",
    value: function checkRetrieveStatus(asyncProcessId) {
      return this._invoke('checkRetrieveStatus', {
        asyncProcessId: asyncProcessId
      }, ApiSchemas.RetrieveResult);
    }

    /**
     * Will deploy a recently validated deploy request
     *
     * @param options.id = the deploy ID that's been validated already from a previous checkOnly deploy request
     * @param options.rest = a boolean whether or not to use the REST API
     * @returns the deploy ID of the recent validation request
     */
  }, {
    key: "deployRecentValidation",
    value: (function () {
      var _deployRecentValidation = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3(options) {
        var id, rest, response, messageBody, requestInfo, requestOptions;
        return _regeneratorRuntime.wrap(function _callee3$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              id = options.id, rest = options.rest;
              if (!rest) {
                _context5.next = 10;
                break;
              }
              messageBody = _JSON$stringify({
                validatedDeployRequestId: id
              });
              requestInfo = {
                method: 'POST',
                url: "".concat(this._conn._baseUrl(), "/metadata/deployRequest"),
                body: messageBody,
                headers: {
                  'content-type': 'application/json'
                }
              };
              requestOptions = {
                headers: 'json'
              }; // This is the deploy ID of the deployRecentValidation response, not
              // the already validated deploy ID (i.e., validateddeployrequestid).
              // REST returns an object with an id property, SOAP returns the id as a string directly.
              _context5.next = 7;
              return this._conn.request(requestInfo, requestOptions);
            case 7:
              response = _context5.sent.id;
              _context5.next = 13;
              break;
            case 10:
              _context5.next = 12;
              return this._invoke('deployRecentValidation', {
                validationId: id
              });
            case 12:
              response = _context5.sent;
            case 13:
              return _context5.abrupt("return", response);
            case 14:
            case "end":
              return _context5.stop();
          }
        }, _callee3, this);
      }));
      function deployRecentValidation(_x6) {
        return _deployRecentValidation.apply(this, arguments);
      }
      return deployRecentValidation;
    }()
    /**
     * Deploy components into an organization using zipped file representations
     * using the REST Metadata API instead of SOAP
     */
    )
  }, {
    key: "deployRest",
    value: function deployRest(zipInput) {
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var form = new FormData();
      form.append('file', zipInput, {
        contentType: 'application/zip',
        filename: 'package.xml'
      });

      // Add the deploy options
      form.append('entity_content', _JSON$stringify({
        deployOptions: options
      }), {
        contentType: 'application/json'
      });
      var request = {
        url: '/metadata/deployRequest',
        method: 'POST',
        headers: _objectSpread({}, form.getHeaders()),
        body: form.getBuffer()
      };
      var res = this._conn.request(request);
      return new DeployResultLocator(this, res);
    }

    /**
     * Deploy components into an organization using zipped file representations
     */
  }, {
    key: "deploy",
    value: function deploy(zipInput) {
      var _this = this;
      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var res = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4() {
        var zipContentB64;
        return _regeneratorRuntime.wrap(function _callee4$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              _context6.next = 2;
              return new _Promise(function (resolve, reject) {
                if (isObject(zipInput) && 'pipe' in zipInput && typeof zipInput.pipe === 'function') {
                  var bufs = [];
                  zipInput.on('data', function (d) {
                    return bufs.push(d);
                  });
                  zipInput.on('error', reject);
                  zipInput.on('end', function () {
                    resolve(_concatInstanceProperty(Buffer).call(Buffer, bufs).toString('base64'));
                  });
                  // zipInput.resume();
                } else if (zipInput instanceof Buffer) {
                  resolve(zipInput.toString('base64'));
                } else if (zipInput instanceof String || typeof zipInput === 'string') {
                  resolve(zipInput);
                } else {
                  throw 'Unexpected zipInput type';
                }
              });
            case 2:
              zipContentB64 = _context6.sent;
              return _context6.abrupt("return", _this._invoke('deploy', {
                ZipFile: zipContentB64,
                DeployOptions: options
              }, ApiSchemas.DeployResult));
            case 4:
            case "end":
              return _context6.stop();
          }
        }, _callee4);
      }))();
      return new DeployResultLocator(this, res);
    }

    /**
     * Checks the status of declarative metadata call deploy(), using either
     * SOAP or REST APIs. SOAP is the default.
     */
  }, {
    key: "checkDeployStatus",
    value: (function () {
      var _checkDeployStatus = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee5(asyncProcessId) {
        var includeDetails,
          rest,
          _context7,
          url,
          _args5 = arguments;
        return _regeneratorRuntime.wrap(function _callee5$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              includeDetails = _args5.length > 1 && _args5[1] !== undefined ? _args5[1] : false;
              rest = _args5.length > 2 && _args5[2] !== undefined ? _args5[2] : false;
              if (!rest) {
                _context8.next = 9;
                break;
              }
              url = _concatInstanceProperty(_context7 = "/metadata/deployRequest/".concat(asyncProcessId)).call(_context7, includeDetails ? '?includeDetails=true' : '');
              _context8.next = 6;
              return this._conn.requestGet(url);
            case 6:
              return _context8.abrupt("return", _context8.sent.deployResult);
            case 9:
              return _context8.abrupt("return", this._invoke('checkDeployStatus', {
                asyncProcessId: asyncProcessId,
                includeDetails: includeDetails
              }, ApiSchemas.DeployResult));
            case 10:
            case "end":
              return _context8.stop();
          }
        }, _callee5, this);
      }));
      function checkDeployStatus(_x7) {
        return _checkDeployStatus.apply(this, arguments);
      }
      return checkDeployStatus;
    }())
  }, {
    key: "cancelDeploy",
    value: function () {
      var _cancelDeploy = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee6(id) {
        return _regeneratorRuntime.wrap(function _callee6$(_context9) {
          while (1) switch (_context9.prev = _context9.next) {
            case 0:
              return _context9.abrupt("return", this._invoke('cancelDeploy', {
                id: id
              }));
            case 1:
            case "end":
              return _context9.stop();
          }
        }, _callee6, this);
      }));
      function cancelDeploy(_x8) {
        return _cancelDeploy.apply(this, arguments);
      }
      return cancelDeploy;
    }()
  }]);
}();

/*--------------------------------------------*/

/**
 * The locator class for Metadata API asynchronous call result
 */
export var AsyncResultLocator = /*#__PURE__*/function (_EventEmitter) {
  /**
   *
   */
  function AsyncResultLocator(meta, promise) {
    var _this2;
    _classCallCheck(this, AsyncResultLocator);
    _this2 = _callSuper(this, AsyncResultLocator);
    _this2._meta = meta;
    _this2._promise = promise;
    return _this2;
  }

  /**
   * Promise/A+ interface
   * http://promises-aplus.github.io/promises-spec/
   *
   * @method Metadata~AsyncResultLocator#then
   */
  _inherits(AsyncResultLocator, _EventEmitter);
  return _createClass(AsyncResultLocator, [{
    key: "then",
    value: function then(onResolve, onReject) {
      return this._promise.then(onResolve, onReject);
    }

    /**
     * Check the status of async request
     */
  }, {
    key: "check",
    value: (function () {
      var _check = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee7() {
        var result;
        return _regeneratorRuntime.wrap(function _callee7$(_context10) {
          while (1) switch (_context10.prev = _context10.next) {
            case 0:
              _context10.next = 2;
              return this._promise;
            case 2:
              result = _context10.sent;
              this._id = result.id;
              return _context10.abrupt("return", this._meta.checkStatus(result.id));
            case 5:
            case "end":
              return _context10.stop();
          }
        }, _callee7, this);
      }));
      function check() {
        return _check.apply(this, arguments);
      }
      return check;
    }()
    /**
     * Polling until async call status becomes complete or error
     */
    )
  }, {
    key: "poll",
    value: function _poll(interval, timeout) {
      var _this3 = this;
      var startTime = new Date().getTime();
      var _poll = /*#__PURE__*/function () {
        var _ref3 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee8() {
          var now, errMsg, result;
          return _regeneratorRuntime.wrap(function _callee8$(_context11) {
            while (1) switch (_context11.prev = _context11.next) {
              case 0:
                _context11.prev = 0;
                now = new Date().getTime();
                if (!(startTime + timeout < now)) {
                  _context11.next = 7;
                  break;
                }
                errMsg = 'Polling time out.';
                if (_this3._id) {
                  errMsg += ' Process Id = ' + _this3._id;
                }
                _this3.emit('error', new Error(errMsg));
                return _context11.abrupt("return");
              case 7:
                _context11.next = 9;
                return _this3.check();
              case 9:
                result = _context11.sent;
                if (result.done) {
                  _this3.emit('complete', result);
                } else {
                  _this3.emit('progress', result);
                  _setTimeout(_poll, interval);
                }
                _context11.next = 16;
                break;
              case 13:
                _context11.prev = 13;
                _context11.t0 = _context11["catch"](0);
                _this3.emit('error', _context11.t0);
              case 16:
              case "end":
                return _context11.stop();
            }
          }, _callee8, null, [[0, 13]]);
        }));
        return function poll() {
          return _ref3.apply(this, arguments);
        };
      }();
      _setTimeout(_poll, interval);
    }

    /**
     * Check and wait until the async requests become in completed status
     */
  }, {
    key: "complete",
    value: function complete() {
      var _this4 = this;
      return new _Promise(function (resolve, reject) {
        _this4.on('complete', resolve);
        _this4.on('error', reject);
        _this4.poll(_this4._meta.pollInterval, _this4._meta.pollTimeout);
      });
    }
  }]);
}(EventEmitter);

/*--------------------------------------------*/
/**
 * The locator class to track retreive() Metadata API call result
 */
export var RetrieveResultLocator = /*#__PURE__*/function (_AsyncResultLocator) {
  function RetrieveResultLocator() {
    _classCallCheck(this, RetrieveResultLocator);
    return _callSuper(this, RetrieveResultLocator, arguments);
  }
  _inherits(RetrieveResultLocator, _AsyncResultLocator);
  return _createClass(RetrieveResultLocator, [{
    key: "complete",
    value: (
    /**
     * Poll checkRetrieveStatus() until the retrieve operation completes,
     * then return the RetrieveResult.
     */
    function () {
      var _complete = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee10() {
        var _this5 = this;
        var asyncResult, id;
        return _regeneratorRuntime.wrap(function _callee10$(_context13) {
          while (1) switch (_context13.prev = _context13.next) {
            case 0:
              if (this._id) {
                _context13.next = 5;
                break;
              }
              _context13.next = 3;
              return this._promise;
            case 3:
              asyncResult = _context13.sent;
              this._id = asyncResult.id;
            case 5:
              id = this._id;
              return _context13.abrupt("return", new _Promise(function (resolve, reject) {
                var startTime = new Date().getTime();
                var timeoutTime = startTime + _this5._meta.pollTimeout;
                var _poll2 = /*#__PURE__*/function () {
                  var _ref4 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee9() {
                    var now, err, result;
                    return _regeneratorRuntime.wrap(function _callee9$(_context12) {
                      while (1) switch (_context12.prev = _context12.next) {
                        case 0:
                          _context12.prev = 0;
                          now = new Date().getTime();
                          if (!(timeoutTime < now)) {
                            _context12.next = 7;
                            break;
                          }
                          err = new Error('Polling time out. Retrieve operation is not completed.');
                          _this5.emit('error', err);
                          reject(err);
                          return _context12.abrupt("return");
                        case 7:
                          _context12.next = 9;
                          return _this5._meta.checkRetrieveStatus(id);
                        case 9:
                          result = _context12.sent;
                          if (result.done) {
                            _this5.emit('complete', result);
                            resolve(result);
                          } else {
                            _this5.emit('progress', result);
                            _setTimeout(_poll2, _this5._meta.pollInterval);
                          }
                          _context12.next = 17;
                          break;
                        case 13:
                          _context12.prev = 13;
                          _context12.t0 = _context12["catch"](0);
                          _this5.emit('error', _context12.t0);
                          reject(_context12.t0);
                        case 17:
                        case "end":
                          return _context12.stop();
                      }
                    }, _callee9, null, [[0, 13]]);
                  }));
                  return function poll() {
                    return _ref4.apply(this, arguments);
                  };
                }();
                _setTimeout(_poll2, _this5._meta.pollInterval);
              }));
            case 7:
            case "end":
              return _context13.stop();
          }
        }, _callee10, this);
      }));
      function complete() {
        return _complete.apply(this, arguments);
      }
      return complete;
    }()
    /**
     * Change the retrieved result to Node.js readable stream
     */
    )
  }, {
    key: "stream",
    value: function stream() {
      var _this6 = this;
      var resultStream = new Readable();
      var reading = false;
      resultStream._read = /*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee11() {
        var result;
        return _regeneratorRuntime.wrap(function _callee11$(_context14) {
          while (1) switch (_context14.prev = _context14.next) {
            case 0:
              if (!reading) {
                _context14.next = 2;
                break;
              }
              return _context14.abrupt("return");
            case 2:
              reading = true;
              _context14.prev = 3;
              _context14.next = 6;
              return _this6.complete();
            case 6:
              result = _context14.sent;
              resultStream.push(Buffer.from(result.zipFile, 'base64'));
              resultStream.push(null);
              _context14.next = 14;
              break;
            case 11:
              _context14.prev = 11;
              _context14.t0 = _context14["catch"](3);
              resultStream.emit('error', _context14.t0);
            case 14:
            case "end":
              return _context14.stop();
          }
        }, _callee11, null, [[3, 11]]);
      }));
      return resultStream;
    }
  }]);
}(AsyncResultLocator);

/*--------------------------------------------*/
/**
 * The locator class to track deploy() Metadata API call result
 *
 * @protected
 * @class Metadata~DeployResultLocator
 * @extends Metadata~AsyncResultLocator
 * @param {Metadata} meta - Metadata API object
 * @param {Promise.<Metadata~AsyncResult>} result - Promise object for async result of deploy() call
 */
export var DeployResultLocator = /*#__PURE__*/function (_AsyncResultLocator2) {
  function DeployResultLocator() {
    _classCallCheck(this, DeployResultLocator);
    return _callSuper(this, DeployResultLocator, arguments);
  }
  _inherits(DeployResultLocator, _AsyncResultLocator2);
  return _createClass(DeployResultLocator, [{
    key: "complete",
    value: (
    /**
     * Poll checkDeployStatus() until the deploy operation completes,
     * then return the DeployResult.
     */
    function () {
      var _complete2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee13(includeDetails) {
        var _this7 = this;
        var asyncResult, id;
        return _regeneratorRuntime.wrap(function _callee13$(_context16) {
          while (1) switch (_context16.prev = _context16.next) {
            case 0:
              if (this._id) {
                _context16.next = 5;
                break;
              }
              _context16.next = 3;
              return this._promise;
            case 3:
              asyncResult = _context16.sent;
              this._id = asyncResult.id;
            case 5:
              id = this._id;
              return _context16.abrupt("return", new _Promise(function (resolve, reject) {
                var startTime = new Date().getTime();
                var timeoutTime = startTime + _this7._meta.pollTimeout;
                var _poll3 = /*#__PURE__*/function () {
                  var _ref6 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee12() {
                    var now, err, result;
                    return _regeneratorRuntime.wrap(function _callee12$(_context15) {
                      while (1) switch (_context15.prev = _context15.next) {
                        case 0:
                          _context15.prev = 0;
                          now = new Date().getTime();
                          if (!(timeoutTime < now)) {
                            _context15.next = 7;
                            break;
                          }
                          err = new Error('Polling time out. Deploy operation is not completed.');
                          _this7.emit('error', err);
                          reject(err);
                          return _context15.abrupt("return");
                        case 7:
                          _context15.next = 9;
                          return _this7._meta.checkDeployStatus(id, includeDetails);
                        case 9:
                          result = _context15.sent;
                          if (result.done) {
                            _this7.emit('complete', result);
                            resolve(result);
                          } else {
                            _this7.emit('progress', result);
                            _setTimeout(_poll3, _this7._meta.pollInterval);
                          }
                          _context15.next = 17;
                          break;
                        case 13:
                          _context15.prev = 13;
                          _context15.t0 = _context15["catch"](0);
                          _this7.emit('error', _context15.t0);
                          reject(_context15.t0);
                        case 17:
                        case "end":
                          return _context15.stop();
                      }
                    }, _callee12, null, [[0, 13]]);
                  }));
                  return function poll() {
                    return _ref6.apply(this, arguments);
                  };
                }();
                _setTimeout(_poll3, _this7._meta.pollInterval);
              }));
            case 7:
            case "end":
              return _context16.stop();
          }
        }, _callee13, this);
      }));
      function complete(_x9) {
        return _complete2.apply(this, arguments);
      }
      return complete;
    }())
  }]);
}(AsyncResultLocator);

/*--------------------------------------------*/
/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */
registerModule('metadata', function (conn) {
  return new MetadataApi(conn);
});
export default MetadataApi;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJSZWFkYWJsZSIsIkZvcm1EYXRhIiwicmVnaXN0ZXJNb2R1bGUiLCJTT0FQIiwiaXNPYmplY3QiLCJBcGlTY2hlbWFzIiwiZGVhbGxvY2F0ZVR5cGVXaXRoTWV0YWRhdGEiLCJtZXRhZGF0YSIsIl9yZWYiLCIkIiwibWQiLCJfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMiLCJfZXhjbHVkZWQiLCJhc3NpZ25UeXBlV2l0aE1ldGFkYXRhIiwidHlwZSIsImNvbnZlcnQiLCJfb2JqZWN0U3ByZWFkIiwiX2RlZmluZVByb3BlcnR5IiwiX0FycmF5JGlzQXJyYXkiLCJfbWFwSW5zdGFuY2VQcm9wZXJ0eSIsImNhbGwiLCJNZXRhZGF0YUFwaSIsImNvbm4iLCJfY2xhc3NDYWxsQ2hlY2siLCJfY29ubiIsIl9jcmVhdGVDbGFzcyIsImtleSIsInZhbHVlIiwiX2ludm9rZTIiLCJfYXN5bmNUb0dlbmVyYXRvciIsIl9yZWdlbmVyYXRvclJ1bnRpbWUiLCJtYXJrIiwiX2NhbGxlZSIsIm1ldGhvZCIsIm1lc3NhZ2UiLCJzY2hlbWEiLCJfY29udGV4dCIsInNvYXBFbmRwb2ludCIsInJlcyIsIndyYXAiLCJfY2FsbGVlJCIsIl9jb250ZXh0MiIsInByZXYiLCJuZXh0IiwieG1sbnMiLCJlbmRwb2ludFVybCIsIl9jb25jYXRJbnN0YW5jZVByb3BlcnR5IiwiY29uY2F0IiwiaW5zdGFuY2VVcmwiLCJ2ZXJzaW9uIiwiaW52b2tlIiwicmVzdWx0IiwidW5kZWZpbmVkIiwic2VudCIsImFicnVwdCIsInN0b3AiLCJfaW52b2tlIiwiX3giLCJfeDIiLCJfeDMiLCJhcHBseSIsImFyZ3VtZW50cyIsImNyZWF0ZSIsImlzQXJyYXkiLCJTYXZlUmVzdWx0IiwiX3JlYWQiLCJfY2FsbGVlMiIsImZ1bGxOYW1lcyIsIl9jb250ZXh0MyIsIlJlYWRSZXN1bHRTY2hlbWEiLCJfY2FsbGVlMiQiLCJfY29udGV4dDQiLCJSZWFkUmVzdWx0IiwicHJvcHMiLCJyZWNvcmRzIiwicmVhZCIsIl94NCIsIl94NSIsInVwZGF0ZSIsInVwc2VydCIsIlVwc2VydFJlc3VsdCIsImRlbGV0ZSIsInJlbmFtZSIsIm9sZEZ1bGxOYW1lIiwibmV3RnVsbE5hbWUiLCJkZXNjcmliZSIsImFzT2ZWZXJzaW9uIiwiRGVzY3JpYmVNZXRhZGF0YVJlc3VsdCIsImxpc3QiLCJxdWVyaWVzIiwiRmlsZVByb3BlcnRpZXMiLCJjaGVja1N0YXR1cyIsImFzeW5jUHJvY2Vzc0lkIiwiQXN5bmNSZXN1bHQiLCJBc3luY1Jlc3VsdExvY2F0b3IiLCJyZXRyaWV2ZSIsInJlcXVlc3QiLCJSZXRyaWV2ZVJlc3VsdCIsIlJldHJpZXZlUmVzdWx0TG9jYXRvciIsImNoZWNrUmV0cmlldmVTdGF0dXMiLCJfZGVwbG95UmVjZW50VmFsaWRhdGlvbiIsIl9jYWxsZWUzIiwib3B0aW9ucyIsImlkIiwicmVzdCIsInJlc3BvbnNlIiwibWVzc2FnZUJvZHkiLCJyZXF1ZXN0SW5mbyIsInJlcXVlc3RPcHRpb25zIiwiX2NhbGxlZTMkIiwiX2NvbnRleHQ1IiwiX0pTT04kc3RyaW5naWZ5IiwidmFsaWRhdGVkRGVwbG95UmVxdWVzdElkIiwidXJsIiwiX2Jhc2VVcmwiLCJib2R5IiwiaGVhZGVycyIsInZhbGlkYXRpb25JZCIsImRlcGxveVJlY2VudFZhbGlkYXRpb24iLCJfeDYiLCJkZXBsb3lSZXN0IiwiemlwSW5wdXQiLCJsZW5ndGgiLCJmb3JtIiwiYXBwZW5kIiwiY29udGVudFR5cGUiLCJmaWxlbmFtZSIsImRlcGxveU9wdGlvbnMiLCJnZXRIZWFkZXJzIiwiZ2V0QnVmZmVyIiwiRGVwbG95UmVzdWx0TG9jYXRvciIsImRlcGxveSIsIl90aGlzIiwiX2NhbGxlZTQiLCJ6aXBDb250ZW50QjY0IiwiX2NhbGxlZTQkIiwiX2NvbnRleHQ2IiwiX1Byb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwicGlwZSIsImJ1ZnMiLCJvbiIsImQiLCJwdXNoIiwiQnVmZmVyIiwidG9TdHJpbmciLCJTdHJpbmciLCJaaXBGaWxlIiwiRGVwbG95T3B0aW9ucyIsIkRlcGxveVJlc3VsdCIsIl9jaGVja0RlcGxveVN0YXR1cyIsIl9jYWxsZWU1IiwiaW5jbHVkZURldGFpbHMiLCJfY29udGV4dDciLCJfYXJnczUiLCJfY2FsbGVlNSQiLCJfY29udGV4dDgiLCJyZXF1ZXN0R2V0IiwiZGVwbG95UmVzdWx0IiwiY2hlY2tEZXBsb3lTdGF0dXMiLCJfeDciLCJfY2FuY2VsRGVwbG95IiwiX2NhbGxlZTYiLCJfY2FsbGVlNiQiLCJfY29udGV4dDkiLCJjYW5jZWxEZXBsb3kiLCJfeDgiLCJfRXZlbnRFbWl0dGVyIiwibWV0YSIsInByb21pc2UiLCJfdGhpczIiLCJfY2FsbFN1cGVyIiwiX21ldGEiLCJfcHJvbWlzZSIsIl9pbmhlcml0cyIsInRoZW4iLCJvblJlc29sdmUiLCJvblJlamVjdCIsIl9jaGVjayIsIl9jYWxsZWU3IiwiX2NhbGxlZTckIiwiX2NvbnRleHQxMCIsIl9pZCIsImNoZWNrIiwicG9sbCIsImludGVydmFsIiwidGltZW91dCIsIl90aGlzMyIsInN0YXJ0VGltZSIsIkRhdGUiLCJnZXRUaW1lIiwiX3JlZjMiLCJfY2FsbGVlOCIsIm5vdyIsImVyck1zZyIsIl9jYWxsZWU4JCIsIl9jb250ZXh0MTEiLCJlbWl0IiwiRXJyb3IiLCJkb25lIiwiX3NldFRpbWVvdXQiLCJ0MCIsImNvbXBsZXRlIiwiX3RoaXM0IiwicG9sbEludGVydmFsIiwicG9sbFRpbWVvdXQiLCJfQXN5bmNSZXN1bHRMb2NhdG9yIiwiX2NvbXBsZXRlIiwiX2NhbGxlZTEwIiwiX3RoaXM1IiwiYXN5bmNSZXN1bHQiLCJfY2FsbGVlMTAkIiwiX2NvbnRleHQxMyIsInRpbWVvdXRUaW1lIiwiX3JlZjQiLCJfY2FsbGVlOSIsImVyciIsIl9jYWxsZWU5JCIsIl9jb250ZXh0MTIiLCJzdHJlYW0iLCJfdGhpczYiLCJyZXN1bHRTdHJlYW0iLCJyZWFkaW5nIiwiX2NhbGxlZTExIiwiX2NhbGxlZTExJCIsIl9jb250ZXh0MTQiLCJmcm9tIiwiemlwRmlsZSIsIl9Bc3luY1Jlc3VsdExvY2F0b3IyIiwiX2NvbXBsZXRlMiIsIl9jYWxsZWUxMyIsIl90aGlzNyIsIl9jYWxsZWUxMyQiLCJfY29udGV4dDE2IiwiX3JlZjYiLCJfY2FsbGVlMTIiLCJfY2FsbGVlMTIkIiwiX2NvbnRleHQxNSIsIl94OSJdLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvbWV0YWRhdGEudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBNYW5hZ2VzIFNhbGVzZm9yY2UgTWV0YWRhdGEgQVBJXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJztcbmltcG9ydCB7IFJlYWRhYmxlIH0gZnJvbSAnc3RyZWFtJztcbmltcG9ydCBGb3JtRGF0YSBmcm9tICdmb3JtLWRhdGEnO1xuaW1wb3J0IHsgcmVnaXN0ZXJNb2R1bGUgfSBmcm9tICcuLi9qc2ZvcmNlJztcbmltcG9ydCBDb25uZWN0aW9uIGZyb20gJy4uL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IFNPQVAgZnJvbSAnLi4vc29hcCc7XG5pbXBvcnQgeyBpc09iamVjdCB9IGZyb20gJy4uL3V0aWwvZnVuY3Rpb24nO1xuaW1wb3J0IHsgU2NoZW1hLCBTb2FwU2NoZW1hRGVmLCBTb2FwU2NoZW1hLCBIdHRwUmVxdWVzdCB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7XG4gIEFwaVNjaGVtYXMsXG4gIE1ldGFkYXRhLFxuICBSZWFkUmVzdWx0LFxuICBTYXZlUmVzdWx0LFxuICBVcHNlcnRSZXN1bHQsXG4gIExpc3RNZXRhZGF0YVF1ZXJ5LFxuICBGaWxlUHJvcGVydGllcyxcbiAgRGVzY3JpYmVNZXRhZGF0YVJlc3VsdCxcbiAgUmV0cmlldmVSZXF1ZXN0LFxuICBEZXBsb3lPcHRpb25zLFxuICBSZXRyaWV2ZVJlc3VsdCxcbiAgRGVwbG95UmVzdWx0LFxuICBBc3luY1Jlc3VsdCxcbiAgQXBpU2NoZW1hVHlwZXMsIENhbmNlbERlcGxveVJlc3VsdCxcbn0gZnJvbSAnLi9tZXRhZGF0YS9zY2hlbWEnO1xuZXhwb3J0ICogZnJvbSAnLi9tZXRhZGF0YS9zY2hlbWEnO1xuXG4vKipcbiAqXG4gKi9cbnR5cGUgTWV0YWRhdGFUeXBlXzxcbiAgSyBleHRlbmRzIGtleW9mIEFwaVNjaGVtYVR5cGVzID0ga2V5b2YgQXBpU2NoZW1hVHlwZXNcbj4gPSBLIGV4dGVuZHMga2V5b2YgQXBpU2NoZW1hVHlwZXNcbiAgPyBBcGlTY2hlbWFUeXBlc1tLXSBleHRlbmRzIE1ldGFkYXRhXG4gICAgPyBLXG4gICAgOiBuZXZlclxuICA6IG5ldmVyO1xuXG5leHBvcnQgdHlwZSBNZXRhZGF0YVR5cGUgPSBNZXRhZGF0YVR5cGVfO1xuXG5leHBvcnQgdHlwZSBNZXRhZGF0YURlZmluaXRpb248XG4gIFQgZXh0ZW5kcyBzdHJpbmcsXG4gIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhXG4+ID0gTWV0YWRhdGEgZXh0ZW5kcyBNXG4gID8gVCBleHRlbmRzIGtleW9mIEFwaVNjaGVtYVR5cGVzICYgTWV0YWRhdGFUeXBlXG4gICAgPyBBcGlTY2hlbWFUeXBlc1tUXSBleHRlbmRzIE1ldGFkYXRhXG4gICAgICA/IEFwaVNjaGVtYVR5cGVzW1RdXG4gICAgICA6IE1ldGFkYXRhXG4gICAgOiBNZXRhZGF0YVxuICA6IE07XG5cbnR5cGUgRGVlcFBhcnRpYWw8VD4gPSBUIGV4dGVuZHMgYW55W11cbiAgPyBBcnJheTxEZWVwUGFydGlhbDxUW251bWJlcl0+PlxuICA6IFQgZXh0ZW5kcyBvYmplY3RcbiAgPyB7IFtLIGluIGtleW9mIFRdPzogRGVlcFBhcnRpYWw8VFtLXT4gfVxuICA6IFQ7XG5cbmV4cG9ydCB0eXBlIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFxuICBUIGV4dGVuZHMgc3RyaW5nLFxuICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YVxuPiA9IERlZXBQYXJ0aWFsPE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPj47XG5cbi8qKlxuICpcbiAqL1xuZnVuY3Rpb24gZGVhbGxvY2F0ZVR5cGVXaXRoTWV0YWRhdGE8TSBleHRlbmRzIE1ldGFkYXRhPihtZXRhZGF0YTogTSk6IE0ge1xuICBjb25zdCB7ICQsIC4uLm1kIH0gPSBtZXRhZGF0YSBhcyBhbnk7XG4gIHJldHVybiBtZDtcbn1cblxuZnVuY3Rpb24gYXNzaWduVHlwZVdpdGhNZXRhZGF0YShtZXRhZGF0YTogTWV0YWRhdGEgfCBNZXRhZGF0YVtdLCB0eXBlOiBzdHJpbmcpIHtcbiAgY29uc3QgY29udmVydCA9IChtZDogTWV0YWRhdGEpID0+ICh7IFsnQHhzaTp0eXBlJ106IHR5cGUsIC4uLm1kIH0pO1xuICByZXR1cm4gQXJyYXkuaXNBcnJheShtZXRhZGF0YSkgPyBtZXRhZGF0YS5tYXAoY29udmVydCkgOiBjb252ZXJ0KG1ldGFkYXRhKTtcbn1cblxuLyoqXG4gKiBDbGFzcyBmb3IgU2FsZXNmb3JjZSBNZXRhZGF0YSBBUElcbiAqL1xuZXhwb3J0IGNsYXNzIE1ldGFkYXRhQXBpPFMgZXh0ZW5kcyBTY2hlbWE+IHtcbiAgX2Nvbm46IENvbm5lY3Rpb248Uz47XG5cbiAgLyoqXG4gICAqIFBvbGxpbmcgaW50ZXJ2YWwgaW4gbWlsbGlzZWNvbmRzXG4gICAqL1xuICBwb2xsSW50ZXJ2YWw6IG51bWJlciA9IDEwMDA7XG5cbiAgLyoqXG4gICAqIFBvbGxpbmcgdGltZW91dCBpbiBtaWxsaXNlY29uZHNcbiAgICovXG4gIHBvbGxUaW1lb3V0OiBudW1iZXIgPSAxMDAwMDtcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKGNvbm46IENvbm5lY3Rpb248Uz4pIHtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsIE1ldGFkYXRhIEFQSSBTT0FQIGVuZHBvaW50XG4gICAqXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBhc3luYyBfaW52b2tlKFxuICAgIG1ldGhvZDogc3RyaW5nLFxuICAgIG1lc3NhZ2U6IG9iamVjdCxcbiAgICBzY2hlbWE/OiBTb2FwU2NoZW1hIHwgU29hcFNjaGVtYURlZixcbiAgKSB7XG4gICAgY29uc3Qgc29hcEVuZHBvaW50ID0gbmV3IFNPQVAodGhpcy5fY29ubiwge1xuICAgICAgeG1sbnM6ICdodHRwOi8vc29hcC5zZm9yY2UuY29tLzIwMDYvMDQvbWV0YWRhdGEnLFxuICAgICAgZW5kcG9pbnRVcmw6IGAke3RoaXMuX2Nvbm4uaW5zdGFuY2VVcmx9L3NlcnZpY2VzL1NvYXAvbS8ke3RoaXMuX2Nvbm4udmVyc2lvbn1gLFxuICAgIH0pO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHNvYXBFbmRwb2ludC5pbnZva2UoXG4gICAgICBtZXRob2QsXG4gICAgICBtZXNzYWdlLFxuICAgICAgc2NoZW1hID8gKHsgcmVzdWx0OiBzY2hlbWEgfSBhcyBTb2FwU2NoZW1hKSA6IHVuZGVmaW5lZCxcbiAgICAgIEFwaVNjaGVtYXMsXG4gICAgKTtcbiAgICByZXR1cm4gcmVzLnJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgb25lIG9yIG1vcmUgbmV3IG1ldGFkYXRhIGNvbXBvbmVudHMgdG8gdGhlIG9yZ2FuaXphdGlvbi5cbiAgICovXG4gIGNyZWF0ZTxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgTWV0YWRhdGFUeXBlID0gTWV0YWRhdGFUeXBlLFxuICAgIE1EIGV4dGVuZHMgSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIG1ldGFkYXRhOiBNRFtdKTogUHJvbWlzZTxTYXZlUmVzdWx0W10+O1xuICBjcmVhdGU8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIE1ldGFkYXRhVHlwZSA9IE1ldGFkYXRhVHlwZSxcbiAgICBNRCBleHRlbmRzIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPih0eXBlOiBULCBtZXRhZGF0YTogTUQpOiBQcm9taXNlPFNhdmVSZXN1bHQ+O1xuICBjcmVhdGU8XG4gICAgTSBleHRlbmRzIE1ldGFkYXRhID0gTWV0YWRhdGEsXG4gICAgVCBleHRlbmRzIE1ldGFkYXRhVHlwZSA9IE1ldGFkYXRhVHlwZSxcbiAgICBNRCBleHRlbmRzIElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPih0eXBlOiBULCBtZXRhZGF0YTogTUQgfCBNRFtdKTogUHJvbWlzZTxTYXZlUmVzdWx0IHwgU2F2ZVJlc3VsdFtdPjtcbiAgY3JlYXRlKHR5cGU6IHN0cmluZywgbWV0YWRhdGE6IE1ldGFkYXRhIHwgTWV0YWRhdGFbXSkge1xuICAgIGNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5KG1ldGFkYXRhKTtcbiAgICBtZXRhZGF0YSA9IGFzc2lnblR5cGVXaXRoTWV0YWRhdGEobWV0YWRhdGEsIHR5cGUpO1xuICAgIGNvbnN0IHNjaGVtYSA9IGlzQXJyYXkgPyBbQXBpU2NoZW1hcy5TYXZlUmVzdWx0XSA6IEFwaVNjaGVtYXMuU2F2ZVJlc3VsdDtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdjcmVhdGVNZXRhZGF0YScsIHsgbWV0YWRhdGEgfSwgc2NoZW1hKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWFkIHNwZWNpZmllZCBtZXRhZGF0YSBjb21wb25lbnRzIGluIHRoZSBvcmdhbml6YXRpb24uXG4gICAqL1xuICByZWFkPFxuICAgIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhLFxuICAgIFQgZXh0ZW5kcyBNZXRhZGF0YVR5cGUgPSBNZXRhZGF0YVR5cGUsXG4gICAgTUQgZXh0ZW5kcyBNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBNZXRhZGF0YURlZmluaXRpb248VCwgTT5cbiAgPih0eXBlOiBULCBmdWxsTmFtZXM6IHN0cmluZ1tdKTogUHJvbWlzZTxNRFtdPjtcbiAgcmVhZDxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgTWV0YWRhdGFUeXBlID0gTWV0YWRhdGFUeXBlLFxuICAgIE1EIGV4dGVuZHMgTWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gTWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgZnVsbE5hbWVzOiBzdHJpbmcpOiBQcm9taXNlPE1EPjtcbiAgcmVhZDxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgTWV0YWRhdGFUeXBlID0gTWV0YWRhdGFUeXBlLFxuICAgIE1EIGV4dGVuZHMgTWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+ID0gTWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgZnVsbE5hbWVzOiBzdHJpbmcgfCBzdHJpbmdbXSk6IFByb21pc2U8TUQgfCBNRFtdPjtcbiAgYXN5bmMgcmVhZCh0eXBlOiBzdHJpbmcsIGZ1bGxOYW1lczogc3RyaW5nIHwgc3RyaW5nW10pIHtcbiAgICBjb25zdCBSZWFkUmVzdWx0U2NoZW1hID1cbiAgICAgIHR5cGUgaW4gQXBpU2NoZW1hc1xuICAgICAgICA/ICh7XG4gICAgICAgICAgICB0eXBlOiBBcGlTY2hlbWFzLlJlYWRSZXN1bHQudHlwZSxcbiAgICAgICAgICAgIHByb3BzOiB7XG4gICAgICAgICAgICAgIHJlY29yZHM6IFt0eXBlXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSBhcyBjb25zdClcbiAgICAgICAgOiBBcGlTY2hlbWFzLlJlYWRSZXN1bHQ7XG4gICAgY29uc3QgcmVzOiBSZWFkUmVzdWx0ID0gYXdhaXQgdGhpcy5faW52b2tlKFxuICAgICAgJ3JlYWRNZXRhZGF0YScsXG4gICAgICB7IHR5cGUsIGZ1bGxOYW1lcyB9LFxuICAgICAgUmVhZFJlc3VsdFNjaGVtYSxcbiAgICApO1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KGZ1bGxOYW1lcylcbiAgICAgID8gcmVzLnJlY29yZHMubWFwKGRlYWxsb2NhdGVUeXBlV2l0aE1ldGFkYXRhKVxuICAgICAgOiBkZWFsbG9jYXRlVHlwZVdpdGhNZXRhZGF0YShyZXMucmVjb3Jkc1swXSk7XG4gIH1cblxuICAvKipcbiAgICogVXBkYXRlIG9uZSBvciBtb3JlIG1ldGFkYXRhIGNvbXBvbmVudHMgaW4gdGhlIG9yZ2FuaXphdGlvbi5cbiAgICovXG4gIHVwZGF0ZTxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgc3RyaW5nID0gc3RyaW5nLFxuICAgIE1EIGV4dGVuZHMgSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIG1ldGFkYXRhOiBBcnJheTxQYXJ0aWFsPE1EPj4pOiBQcm9taXNlPFNhdmVSZXN1bHRbXT47XG4gIHVwZGF0ZTxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgc3RyaW5nID0gc3RyaW5nLFxuICAgIE1EIGV4dGVuZHMgSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIG1ldGFkYXRhOiBQYXJ0aWFsPE1EPik6IFByb21pc2U8U2F2ZVJlc3VsdD47XG4gIHVwZGF0ZTxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgc3RyaW5nID0gc3RyaW5nLFxuICAgIE1EIGV4dGVuZHMgSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KFxuICAgIHR5cGU6IFQsXG4gICAgbWV0YWRhdGE6IFBhcnRpYWw8TUQ+IHwgQXJyYXk8UGFydGlhbDxNRD4+LFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+O1xuICB1cGRhdGUodHlwZTogc3RyaW5nLCBtZXRhZGF0YTogTWV0YWRhdGEgfCBNZXRhZGF0YVtdKSB7XG4gICAgY29uc3QgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkobWV0YWRhdGEpO1xuICAgIG1ldGFkYXRhID0gYXNzaWduVHlwZVdpdGhNZXRhZGF0YShtZXRhZGF0YSwgdHlwZSk7XG4gICAgY29uc3Qgc2NoZW1hID0gaXNBcnJheSA/IFtBcGlTY2hlbWFzLlNhdmVSZXN1bHRdIDogQXBpU2NoZW1hcy5TYXZlUmVzdWx0O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ3VwZGF0ZU1ldGFkYXRhJywgeyBtZXRhZGF0YSB9LCBzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwc2VydCBvbmUgb3IgbW9yZSBjb21wb25lbnRzIGluIHlvdXIgb3JnYW5pemF0aW9uJ3MgZGF0YS5cbiAgICovXG4gIHVwc2VydDxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgc3RyaW5nID0gc3RyaW5nLFxuICAgIE1EIGV4dGVuZHMgSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIG1ldGFkYXRhOiBNRFtdKTogUHJvbWlzZTxVcHNlcnRSZXN1bHRbXT47XG4gIHVwc2VydDxcbiAgICBNIGV4dGVuZHMgTWV0YWRhdGEgPSBNZXRhZGF0YSxcbiAgICBUIGV4dGVuZHMgc3RyaW5nID0gc3RyaW5nLFxuICAgIE1EIGV4dGVuZHMgSW5wdXRNZXRhZGF0YURlZmluaXRpb248VCwgTT4gPSBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPlxuICA+KHR5cGU6IFQsIG1ldGFkYXRhOiBNRCk6IFByb21pc2U8VXBzZXJ0UmVzdWx0PjtcbiAgdXBzZXJ0PFxuICAgIE0gZXh0ZW5kcyBNZXRhZGF0YSA9IE1ldGFkYXRhLFxuICAgIFQgZXh0ZW5kcyBzdHJpbmcgPSBzdHJpbmcsXG4gICAgTUQgZXh0ZW5kcyBJbnB1dE1ldGFkYXRhRGVmaW5pdGlvbjxULCBNPiA9IElucHV0TWV0YWRhdGFEZWZpbml0aW9uPFQsIE0+XG4gID4odHlwZTogVCwgbWV0YWRhdGE6IE1EIHwgTURbXSk6IFByb21pc2U8VXBzZXJ0UmVzdWx0IHwgVXBzZXJ0UmVzdWx0W10+O1xuICB1cHNlcnQodHlwZTogc3RyaW5nLCBtZXRhZGF0YTogTWV0YWRhdGEgfCBNZXRhZGF0YVtdKSB7XG4gICAgY29uc3QgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkobWV0YWRhdGEpO1xuICAgIG1ldGFkYXRhID0gYXNzaWduVHlwZVdpdGhNZXRhZGF0YShtZXRhZGF0YSwgdHlwZSk7XG4gICAgY29uc3Qgc2NoZW1hID0gaXNBcnJheVxuICAgICAgPyBbQXBpU2NoZW1hcy5VcHNlcnRSZXN1bHRdXG4gICAgICA6IEFwaVNjaGVtYXMuVXBzZXJ0UmVzdWx0O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ3Vwc2VydE1ldGFkYXRhJywgeyBtZXRhZGF0YSB9LCBzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZXMgc3BlY2lmaWVkIG1ldGFkYXRhIGNvbXBvbmVudHMgaW4gdGhlIG9yZ2FuaXphdGlvbi5cbiAgICovXG4gIGRlbGV0ZSh0eXBlOiBzdHJpbmcsIGZ1bGxOYW1lczogc3RyaW5nW10pOiBQcm9taXNlPFNhdmVSZXN1bHRbXT47XG4gIGRlbGV0ZSh0eXBlOiBzdHJpbmcsIGZ1bGxOYW1lczogc3RyaW5nKTogUHJvbWlzZTxTYXZlUmVzdWx0PjtcbiAgZGVsZXRlKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBmdWxsTmFtZXM6IHN0cmluZyB8IHN0cmluZ1tdLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+O1xuICBkZWxldGUodHlwZTogc3RyaW5nLCBmdWxsTmFtZXM6IHN0cmluZyB8IHN0cmluZ1tdKSB7XG4gICAgY29uc3Qgc2NoZW1hID0gQXJyYXkuaXNBcnJheShmdWxsTmFtZXMpXG4gICAgICA/IFtBcGlTY2hlbWFzLlNhdmVSZXN1bHRdXG4gICAgICA6IEFwaVNjaGVtYXMuU2F2ZVJlc3VsdDtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdkZWxldGVNZXRhZGF0YScsIHsgdHlwZSwgZnVsbE5hbWVzIH0sIHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuYW1lIGZ1bGxuYW1lIG9mIGEgbWV0YWRhdGEgY29tcG9uZW50IGluIHRoZSBvcmdhbml6YXRpb25cbiAgICovXG4gIHJlbmFtZShcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgb2xkRnVsbE5hbWU6IHN0cmluZyxcbiAgICBuZXdGdWxsTmFtZTogc3RyaW5nLFxuICApOiBQcm9taXNlPFNhdmVSZXN1bHQ+IHtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKFxuICAgICAgJ3JlbmFtZU1ldGFkYXRhJyxcbiAgICAgIHsgdHlwZSwgb2xkRnVsbE5hbWUsIG5ld0Z1bGxOYW1lIH0sXG4gICAgICBBcGlTY2hlbWFzLlNhdmVSZXN1bHQsXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgdGhlIG1ldGFkYXRhIHdoaWNoIGRlc2NyaWJlcyB5b3VyIG9yZ2FuaXphdGlvbiwgaW5jbHVkaW5nIEFwZXggY2xhc3NlcyBhbmQgdHJpZ2dlcnMsXG4gICAqIGN1c3RvbSBvYmplY3RzLCBjdXN0b20gZmllbGRzIG9uIHN0YW5kYXJkIG9iamVjdHMsIHRhYiBzZXRzIHRoYXQgZGVmaW5lIGFuIGFwcCxcbiAgICogYW5kIG1hbnkgb3RoZXIgY29tcG9uZW50cy5cbiAgICovXG4gIGRlc2NyaWJlKGFzT2ZWZXJzaW9uPzogc3RyaW5nKTogUHJvbWlzZTxEZXNjcmliZU1ldGFkYXRhUmVzdWx0PiB7XG4gICAgaWYgKCFhc09mVmVyc2lvbikge1xuICAgICAgYXNPZlZlcnNpb24gPSB0aGlzLl9jb25uLnZlcnNpb247XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9pbnZva2UoXG4gICAgICAnZGVzY3JpYmVNZXRhZGF0YScsXG4gICAgICB7IGFzT2ZWZXJzaW9uIH0sXG4gICAgICBBcGlTY2hlbWFzLkRlc2NyaWJlTWV0YWRhdGFSZXN1bHQsXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgcHJvcGVydHkgaW5mb3JtYXRpb24gYWJvdXQgbWV0YWRhdGEgY29tcG9uZW50cyBpbiB5b3VyIG9yZ2FuaXphdGlvblxuICAgKi9cbiAgbGlzdChcbiAgICBxdWVyaWVzOiBMaXN0TWV0YWRhdGFRdWVyeSB8IExpc3RNZXRhZGF0YVF1ZXJ5W10sXG4gICAgYXNPZlZlcnNpb24/OiBzdHJpbmcsXG4gICk6IFByb21pc2U8RmlsZVByb3BlcnRpZXNbXT4ge1xuICAgIGlmICghYXNPZlZlcnNpb24pIHtcbiAgICAgIGFzT2ZWZXJzaW9uID0gdGhpcy5fY29ubi52ZXJzaW9uO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdsaXN0TWV0YWRhdGEnLCB7IHF1ZXJpZXMsIGFzT2ZWZXJzaW9uIH0sIFtcbiAgICAgIEFwaVNjaGVtYXMuRmlsZVByb3BlcnRpZXMsXG4gICAgXSk7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIHRoZSBzdGF0dXMgb2YgYXN5bmNocm9ub3VzIG1ldGFkYXRhIGNhbGxzXG4gICAqL1xuICBjaGVja1N0YXR1cyhhc3luY1Byb2Nlc3NJZDogc3RyaW5nKSB7XG4gICAgY29uc3QgcmVzID0gdGhpcy5faW52b2tlKFxuICAgICAgJ2NoZWNrU3RhdHVzJyxcbiAgICAgIHsgYXN5bmNQcm9jZXNzSWQgfSxcbiAgICAgIEFwaVNjaGVtYXMuQXN5bmNSZXN1bHQsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IEFzeW5jUmVzdWx0TG9jYXRvcih0aGlzLCByZXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlcyBYTUwgZmlsZSByZXByZXNlbnRhdGlvbnMgb2YgY29tcG9uZW50cyBpbiBhbiBvcmdhbml6YXRpb25cbiAgICovXG4gIHJldHJpZXZlKHJlcXVlc3Q6IFBhcnRpYWw8UmV0cmlldmVSZXF1ZXN0Pikge1xuICAgIGNvbnN0IHJlcyA9IHRoaXMuX2ludm9rZShcbiAgICAgICdyZXRyaWV2ZScsXG4gICAgICB7IHJlcXVlc3QgfSxcbiAgICAgIEFwaVNjaGVtYXMuUmV0cmlldmVSZXN1bHQsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFJldHJpZXZlUmVzdWx0TG9jYXRvcih0aGlzLCByZXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrcyB0aGUgc3RhdHVzIG9mIGRlY2xhcmF0aXZlIG1ldGFkYXRhIGNhbGwgcmV0cmlldmUoKSBhbmQgcmV0dXJucyB0aGUgemlwIGZpbGUgY29udGVudHNcbiAgICovXG4gIGNoZWNrUmV0cmlldmVTdGF0dXMoYXN5bmNQcm9jZXNzSWQ6IHN0cmluZyk6IFByb21pc2U8UmV0cmlldmVSZXN1bHQ+IHtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKFxuICAgICAgJ2NoZWNrUmV0cmlldmVTdGF0dXMnLFxuICAgICAgeyBhc3luY1Byb2Nlc3NJZCB9LFxuICAgICAgQXBpU2NoZW1hcy5SZXRyaWV2ZVJlc3VsdCxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIFdpbGwgZGVwbG95IGEgcmVjZW50bHkgdmFsaWRhdGVkIGRlcGxveSByZXF1ZXN0XG4gICAqXG4gICAqIEBwYXJhbSBvcHRpb25zLmlkID0gdGhlIGRlcGxveSBJRCB0aGF0J3MgYmVlbiB2YWxpZGF0ZWQgYWxyZWFkeSBmcm9tIGEgcHJldmlvdXMgY2hlY2tPbmx5IGRlcGxveSByZXF1ZXN0XG4gICAqIEBwYXJhbSBvcHRpb25zLnJlc3QgPSBhIGJvb2xlYW4gd2hldGhlciBvciBub3QgdG8gdXNlIHRoZSBSRVNUIEFQSVxuICAgKiBAcmV0dXJucyB0aGUgZGVwbG95IElEIG9mIHRoZSByZWNlbnQgdmFsaWRhdGlvbiByZXF1ZXN0XG4gICAqL1xuICBwdWJsaWMgYXN5bmMgZGVwbG95UmVjZW50VmFsaWRhdGlvbihvcHRpb25zOiB7XG4gICAgaWQ6IHN0cmluZztcbiAgICByZXN0PzogYm9vbGVhbjtcbiAgfSk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgeyBpZCwgcmVzdCB9ID0gb3B0aW9ucztcbiAgICBsZXQgcmVzcG9uc2U6IHN0cmluZztcbiAgICBpZiAocmVzdCkge1xuICAgICAgY29uc3QgbWVzc2FnZUJvZHkgPSBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZhbGlkYXRlZERlcGxveVJlcXVlc3RJZDogaWQsXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgcmVxdWVzdEluZm86IEh0dHBSZXF1ZXN0ID0ge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgdXJsOiBgJHt0aGlzLl9jb25uLl9iYXNlVXJsKCl9L21ldGFkYXRhL2RlcGxveVJlcXVlc3RgLFxuICAgICAgICBib2R5OiBtZXNzYWdlQm9keSxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICdjb250ZW50LXR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0sXG4gICAgICB9O1xuICAgICAgY29uc3QgcmVxdWVzdE9wdGlvbnMgPSB7IGhlYWRlcnM6ICdqc29uJyB9O1xuICAgICAgLy8gVGhpcyBpcyB0aGUgZGVwbG95IElEIG9mIHRoZSBkZXBsb3lSZWNlbnRWYWxpZGF0aW9uIHJlc3BvbnNlLCBub3RcbiAgICAgIC8vIHRoZSBhbHJlYWR5IHZhbGlkYXRlZCBkZXBsb3kgSUQgKGkuZS4sIHZhbGlkYXRlZGRlcGxveXJlcXVlc3RpZCkuXG4gICAgICAvLyBSRVNUIHJldHVybnMgYW4gb2JqZWN0IHdpdGggYW4gaWQgcHJvcGVydHksIFNPQVAgcmV0dXJucyB0aGUgaWQgYXMgYSBzdHJpbmcgZGlyZWN0bHkuXG4gICAgICByZXNwb25zZSA9IChcbiAgICAgICAgYXdhaXQgdGhpcy5fY29ubi5yZXF1ZXN0PHsgaWQ6IHN0cmluZyB9PihyZXF1ZXN0SW5mbywgcmVxdWVzdE9wdGlvbnMpXG4gICAgICApLmlkO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXNwb25zZSA9IGF3YWl0IHRoaXMuX2ludm9rZSgnZGVwbG95UmVjZW50VmFsaWRhdGlvbicsIHtcbiAgICAgICAgdmFsaWRhdGlvbklkOiBpZCxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiByZXNwb25zZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXBsb3kgY29tcG9uZW50cyBpbnRvIGFuIG9yZ2FuaXphdGlvbiB1c2luZyB6aXBwZWQgZmlsZSByZXByZXNlbnRhdGlvbnNcbiAgICogdXNpbmcgdGhlIFJFU1QgTWV0YWRhdGEgQVBJIGluc3RlYWQgb2YgU09BUFxuICAgKi9cbiAgZGVwbG95UmVzdChcbiAgICB6aXBJbnB1dDogQnVmZmVyLFxuICAgIG9wdGlvbnM6IFBhcnRpYWw8RGVwbG95T3B0aW9ucz4gPSB7fSxcbiAgKTogRGVwbG95UmVzdWx0TG9jYXRvcjxTPiB7XG4gICAgY29uc3QgZm9ybSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgIGZvcm0uYXBwZW5kKCdmaWxlJywgemlwSW5wdXQsIHtcbiAgICAgIGNvbnRlbnRUeXBlOiAnYXBwbGljYXRpb24vemlwJyxcbiAgICAgIGZpbGVuYW1lOiAncGFja2FnZS54bWwnLFxuICAgIH0pO1xuXG4gICAgLy8gQWRkIHRoZSBkZXBsb3kgb3B0aW9uc1xuICAgIGZvcm0uYXBwZW5kKCdlbnRpdHlfY29udGVudCcsIEpTT04uc3RyaW5naWZ5KHsgZGVwbG95T3B0aW9uczogb3B0aW9ucyB9KSwge1xuICAgICAgY29udGVudFR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICB9KTtcblxuICAgIGNvbnN0IHJlcXVlc3Q6IEh0dHBSZXF1ZXN0ID0ge1xuICAgICAgdXJsOiAnL21ldGFkYXRhL2RlcGxveVJlcXVlc3QnLFxuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzOiB7IC4uLmZvcm0uZ2V0SGVhZGVycygpIH0sXG4gICAgICBib2R5OiBmb3JtLmdldEJ1ZmZlcigpLFxuICAgIH07XG4gICAgY29uc3QgcmVzID0gdGhpcy5fY29ubi5yZXF1ZXN0PEFzeW5jUmVzdWx0PihyZXF1ZXN0KTtcblxuICAgIHJldHVybiBuZXcgRGVwbG95UmVzdWx0TG9jYXRvcih0aGlzLCByZXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlcGxveSBjb21wb25lbnRzIGludG8gYW4gb3JnYW5pemF0aW9uIHVzaW5nIHppcHBlZCBmaWxlIHJlcHJlc2VudGF0aW9uc1xuICAgKi9cbiAgZGVwbG95KFxuICAgIHppcElucHV0OiBSZWFkYWJsZSB8IEJ1ZmZlciB8IHN0cmluZyxcbiAgICBvcHRpb25zOiBQYXJ0aWFsPERlcGxveU9wdGlvbnM+ID0ge30sXG4gICk6IERlcGxveVJlc3VsdExvY2F0b3I8Uz4ge1xuICAgIGNvbnN0IHJlcyA9IChhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCB6aXBDb250ZW50QjY0ID0gYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgaXNPYmplY3QoemlwSW5wdXQpICYmXG4gICAgICAgICAgJ3BpcGUnIGluIHppcElucHV0ICYmXG4gICAgICAgICAgdHlwZW9mIHppcElucHV0LnBpcGUgPT09ICdmdW5jdGlvbidcbiAgICAgICAgKSB7XG4gICAgICAgICAgY29uc3QgYnVmczogQnVmZmVyW10gPSBbXTtcbiAgICAgICAgICB6aXBJbnB1dC5vbignZGF0YScsIChkKSA9PiBidWZzLnB1c2goZCkpO1xuICAgICAgICAgIHppcElucHV0Lm9uKCdlcnJvcicsIHJlamVjdCk7XG4gICAgICAgICAgemlwSW5wdXQub24oJ2VuZCcsICgpID0+IHtcbiAgICAgICAgICAgIHJlc29sdmUoQnVmZmVyLmNvbmNhdChidWZzKS50b1N0cmluZygnYmFzZTY0JykpO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIC8vIHppcElucHV0LnJlc3VtZSgpO1xuICAgICAgICB9IGVsc2UgaWYgKHppcElucHV0IGluc3RhbmNlb2YgQnVmZmVyKSB7XG4gICAgICAgICAgcmVzb2x2ZSh6aXBJbnB1dC50b1N0cmluZygnYmFzZTY0JykpO1xuICAgICAgICB9IGVsc2UgaWYgKHppcElucHV0IGluc3RhbmNlb2YgU3RyaW5nIHx8IHR5cGVvZiB6aXBJbnB1dCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICByZXNvbHZlKHppcElucHV0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyAnVW5leHBlY3RlZCB6aXBJbnB1dCB0eXBlJztcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIHJldHVybiB0aGlzLl9pbnZva2UoXG4gICAgICAgICdkZXBsb3knLFxuICAgICAgICB7XG4gICAgICAgICAgWmlwRmlsZTogemlwQ29udGVudEI2NCxcbiAgICAgICAgICBEZXBsb3lPcHRpb25zOiBvcHRpb25zLFxuICAgICAgICB9LFxuICAgICAgICBBcGlTY2hlbWFzLkRlcGxveVJlc3VsdCxcbiAgICAgICk7XG4gICAgfSkoKTtcblxuICAgIHJldHVybiBuZXcgRGVwbG95UmVzdWx0TG9jYXRvcih0aGlzLCByZXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrcyB0aGUgc3RhdHVzIG9mIGRlY2xhcmF0aXZlIG1ldGFkYXRhIGNhbGwgZGVwbG95KCksIHVzaW5nIGVpdGhlclxuICAgKiBTT0FQIG9yIFJFU1QgQVBJcy4gU09BUCBpcyB0aGUgZGVmYXVsdC5cbiAgICovXG4gIGFzeW5jIGNoZWNrRGVwbG95U3RhdHVzKFxuICAgIGFzeW5jUHJvY2Vzc0lkOiBzdHJpbmcsXG4gICAgaW5jbHVkZURldGFpbHM6IGJvb2xlYW4gPSBmYWxzZSxcbiAgICByZXN0OiBib29sZWFuID0gZmFsc2UsXG4gICk6IFByb21pc2U8RGVwbG95UmVzdWx0PiB7XG4gICAgaWYgKHJlc3QpIHtcbiAgICAgIGNvbnN0IHVybCA9IGAvbWV0YWRhdGEvZGVwbG95UmVxdWVzdC8ke2FzeW5jUHJvY2Vzc0lkfSR7aW5jbHVkZURldGFpbHMgPyAnP2luY2x1ZGVEZXRhaWxzPXRydWUnIDogJyd9YDtcbiAgICAgIHR5cGUgQ2hlY2tEZXBsb3lTdGF0dXNSZXN0ID0ge1xuICAgICAgICBpZDogc3RyaW5nO1xuICAgICAgICB2YWxpZGF0ZWREZXBsb3lSZXF1ZXN0SWQ6IHN0cmluZyB8IG51bGw7XG4gICAgICAgIGRlcGxveVJlc3VsdDogRGVwbG95UmVzdWx0O1xuICAgICAgICBkZXBsb3lPcHRpb25zOiBEZXBsb3lPcHRpb25zIHwgbnVsbDtcbiAgICAgIH1cbiAgICAgIHJldHVybiAoYXdhaXQgdGhpcy5fY29ubi5yZXF1ZXN0R2V0PENoZWNrRGVwbG95U3RhdHVzUmVzdD4odXJsKSkuZGVwbG95UmVzdWx0O1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdGhpcy5faW52b2tlKFxuICAgICAgICAnY2hlY2tEZXBsb3lTdGF0dXMnLFxuICAgICAgICB7XG4gICAgICAgICAgYXN5bmNQcm9jZXNzSWQsXG4gICAgICAgICAgaW5jbHVkZURldGFpbHMsXG4gICAgICAgIH0sXG4gICAgICAgIEFwaVNjaGVtYXMuRGVwbG95UmVzdWx0LFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBjYW5jZWxEZXBsb3koaWQ6IHN0cmluZyk6IFByb21pc2U8Q2FuY2VsRGVwbG95UmVzdWx0PntcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdjYW5jZWxEZXBsb3knLCB7IGlkIH0pXG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG5cbi8qKlxuICogVGhlIGxvY2F0b3IgY2xhc3MgZm9yIE1ldGFkYXRhIEFQSSBhc3luY2hyb25vdXMgY2FsbCByZXN1bHRcbiAqL1xuZXhwb3J0IGNsYXNzIEFzeW5jUmVzdWx0TG9jYXRvcjxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgUiBleHRlbmRzIHt9ID0gQXN5bmNSZXN1bHRcbj4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBfbWV0YTogTWV0YWRhdGFBcGk8Uz47XG4gIF9wcm9taXNlOiBQcm9taXNlPEFzeW5jUmVzdWx0PjtcbiAgX2lkOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3RvcihtZXRhOiBNZXRhZGF0YUFwaTxTPiwgcHJvbWlzZTogUHJvbWlzZTxBc3luY1Jlc3VsdD4pIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX21ldGEgPSBtZXRhO1xuICAgIHRoaXMuX3Byb21pc2UgPSBwcm9taXNlO1xuICB9XG5cbiAgLyoqXG4gICAqIFByb21pc2UvQSsgaW50ZXJmYWNlXG4gICAqIGh0dHA6Ly9wcm9taXNlcy1hcGx1cy5naXRodWIuaW8vcHJvbWlzZXMtc3BlYy9cbiAgICpcbiAgICogQG1ldGhvZCBNZXRhZGF0YX5Bc3luY1Jlc3VsdExvY2F0b3IjdGhlblxuICAgKi9cbiAgdGhlbjxVLCBWPihcbiAgICBvblJlc29sdmU/OiAoKHJlc3VsdDogQXN5bmNSZXN1bHQpID0+IFUgfCBQcm9taXNlPFU+KSB8IG51bGwgfCB1bmRlZmluZWQsXG4gICAgb25SZWplY3Q/OiAoKGVycjogRXJyb3IpID0+IFYgfCBQcm9taXNlPFY+KSB8IG51bGwgfCB1bmRlZmluZWQsXG4gICk6IFByb21pc2U8VSB8IFY+IHtcbiAgICByZXR1cm4gdGhpcy5fcHJvbWlzZS50aGVuKG9uUmVzb2x2ZSwgb25SZWplY3QpO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrIHRoZSBzdGF0dXMgb2YgYXN5bmMgcmVxdWVzdFxuICAgKi9cbiAgYXN5bmMgY2hlY2soKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5fcHJvbWlzZTtcbiAgICB0aGlzLl9pZCA9IHJlc3VsdC5pZDtcbiAgICByZXR1cm4gdGhpcy5fbWV0YS5jaGVja1N0YXR1cyhyZXN1bHQuaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFBvbGxpbmcgdW50aWwgYXN5bmMgY2FsbCBzdGF0dXMgYmVjb21lcyBjb21wbGV0ZSBvciBlcnJvclxuICAgKi9cbiAgcG9sbChpbnRlcnZhbDogbnVtYmVyLCB0aW1lb3V0OiBudW1iZXIpIHtcbiAgICBjb25zdCBzdGFydFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgICBjb25zdCBwb2xsID0gYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICAgIGlmIChzdGFydFRpbWUgKyB0aW1lb3V0IDwgbm93KSB7XG4gICAgICAgICAgbGV0IGVyck1zZyA9ICdQb2xsaW5nIHRpbWUgb3V0Lic7XG4gICAgICAgICAgaWYgKHRoaXMuX2lkKSB7XG4gICAgICAgICAgICBlcnJNc2cgKz0gJyBQcm9jZXNzIElkID0gJyArIHRoaXMuX2lkO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgbmV3IEVycm9yKGVyck1zZykpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLmNoZWNrKCk7XG4gICAgICAgIGlmIChyZXN1bHQuZG9uZSkge1xuICAgICAgICAgIHRoaXMuZW1pdCgnY29tcGxldGUnLCByZXN1bHQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuZW1pdCgncHJvZ3Jlc3MnLCByZXN1bHQpO1xuICAgICAgICAgIHNldFRpbWVvdXQocG9sbCwgaW50ZXJ2YWwpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB9XG4gICAgfTtcbiAgICBzZXRUaW1lb3V0KHBvbGwsIGludGVydmFsKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVjayBhbmQgd2FpdCB1bnRpbCB0aGUgYXN5bmMgcmVxdWVzdHMgYmVjb21lIGluIGNvbXBsZXRlZCBzdGF0dXNcbiAgICovXG4gIGNvbXBsZXRlKCkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZTxSPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLm9uKCdjb21wbGV0ZScsIHJlc29sdmUpO1xuICAgICAgdGhpcy5vbignZXJyb3InLCByZWplY3QpO1xuICAgICAgdGhpcy5wb2xsKHRoaXMuX21ldGEucG9sbEludGVydmFsLCB0aGlzLl9tZXRhLnBvbGxUaW1lb3V0KTtcbiAgICB9KTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogVGhlIGxvY2F0b3IgY2xhc3MgdG8gdHJhY2sgcmV0cmVpdmUoKSBNZXRhZGF0YSBBUEkgY2FsbCByZXN1bHRcbiAqL1xuZXhwb3J0IGNsYXNzIFJldHJpZXZlUmVzdWx0TG9jYXRvcjxTIGV4dGVuZHMgU2NoZW1hPiBleHRlbmRzIEFzeW5jUmVzdWx0TG9jYXRvcjxcbiAgUyxcbiAgUmV0cmlldmVSZXN1bHRcbj4ge1xuICAvKipcbiAgICogUG9sbCBjaGVja1JldHJpZXZlU3RhdHVzKCkgdW50aWwgdGhlIHJldHJpZXZlIG9wZXJhdGlvbiBjb21wbGV0ZXMsXG4gICAqIHRoZW4gcmV0dXJuIHRoZSBSZXRyaWV2ZVJlc3VsdC5cbiAgICovXG4gIGFzeW5jIGNvbXBsZXRlKCkge1xuICAgIGlmICghdGhpcy5faWQpIHtcbiAgICAgIGNvbnN0IGFzeW5jUmVzdWx0ID0gYXdhaXQgdGhpcy5fcHJvbWlzZTtcbiAgICAgIHRoaXMuX2lkID0gYXN5bmNSZXN1bHQuaWQ7XG4gICAgfVxuICAgIGNvbnN0IGlkID0gdGhpcy5faWQ7XG5cbiAgICByZXR1cm4gbmV3IFByb21pc2U8UmV0cmlldmVSZXN1bHQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IHN0YXJ0VGltZSA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgY29uc3QgdGltZW91dFRpbWUgPSBzdGFydFRpbWUgKyB0aGlzLl9tZXRhLnBvbGxUaW1lb3V0O1xuXG4gICAgICBjb25zdCBwb2xsID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgICAgIGlmICh0aW1lb3V0VGltZSA8IG5vdykge1xuICAgICAgICAgICAgY29uc3QgZXJyID0gbmV3IEVycm9yKCdQb2xsaW5nIHRpbWUgb3V0LiBSZXRyaWV2ZSBvcGVyYXRpb24gaXMgbm90IGNvbXBsZXRlZC4nKTtcbiAgICAgICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuX21ldGEuY2hlY2tSZXRyaWV2ZVN0YXR1cyhpZCk7XG4gICAgICAgICAgaWYgKHJlc3VsdC5kb25lKSB7XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2NvbXBsZXRlJywgcmVzdWx0KTtcbiAgICAgICAgICAgIHJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5lbWl0KCdwcm9ncmVzcycsIHJlc3VsdCk7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KHBvbGwsIHRoaXMuX21ldGEucG9sbEludGVydmFsKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICBzZXRUaW1lb3V0KHBvbGwsIHRoaXMuX21ldGEucG9sbEludGVydmFsKTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGFuZ2UgdGhlIHJldHJpZXZlZCByZXN1bHQgdG8gTm9kZS5qcyByZWFkYWJsZSBzdHJlYW1cbiAgICovXG4gIHN0cmVhbSgpIHtcbiAgICBjb25zdCByZXN1bHRTdHJlYW0gPSBuZXcgUmVhZGFibGUoKTtcbiAgICBsZXQgcmVhZGluZyA9IGZhbHNlO1xuICAgIHJlc3VsdFN0cmVhbS5fcmVhZCA9IGFzeW5jICgpID0+IHtcbiAgICAgIGlmIChyZWFkaW5nKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHJlYWRpbmcgPSB0cnVlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5jb21wbGV0ZSgpO1xuICAgICAgICByZXN1bHRTdHJlYW0ucHVzaChCdWZmZXIuZnJvbShyZXN1bHQuemlwRmlsZSwgJ2Jhc2U2NCcpKTtcbiAgICAgICAgcmVzdWx0U3RyZWFtLnB1c2gobnVsbCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJlc3VsdFN0cmVhbS5lbWl0KCdlcnJvcicsIGUpO1xuICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIHJlc3VsdFN0cmVhbTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogVGhlIGxvY2F0b3IgY2xhc3MgdG8gdHJhY2sgZGVwbG95KCkgTWV0YWRhdGEgQVBJIGNhbGwgcmVzdWx0XG4gKlxuICogQHByb3RlY3RlZFxuICogQGNsYXNzIE1ldGFkYXRhfkRlcGxveVJlc3VsdExvY2F0b3JcbiAqIEBleHRlbmRzIE1ldGFkYXRhfkFzeW5jUmVzdWx0TG9jYXRvclxuICogQHBhcmFtIHtNZXRhZGF0YX0gbWV0YSAtIE1ldGFkYXRhIEFQSSBvYmplY3RcbiAqIEBwYXJhbSB7UHJvbWlzZS48TWV0YWRhdGF+QXN5bmNSZXN1bHQ+fSByZXN1bHQgLSBQcm9taXNlIG9iamVjdCBmb3IgYXN5bmMgcmVzdWx0IG9mIGRlcGxveSgpIGNhbGxcbiAqL1xuZXhwb3J0IGNsYXNzIERlcGxveVJlc3VsdExvY2F0b3I8UyBleHRlbmRzIFNjaGVtYT4gZXh0ZW5kcyBBc3luY1Jlc3VsdExvY2F0b3I8XG4gIFMsXG4gIERlcGxveVJlc3VsdFxuPiB7XG4gIC8qKlxuICAgKiBQb2xsIGNoZWNrRGVwbG95U3RhdHVzKCkgdW50aWwgdGhlIGRlcGxveSBvcGVyYXRpb24gY29tcGxldGVzLFxuICAgKiB0aGVuIHJldHVybiB0aGUgRGVwbG95UmVzdWx0LlxuICAgKi9cbiAgYXN5bmMgY29tcGxldGUoaW5jbHVkZURldGFpbHM/OiBib29sZWFuKSB7XG4gICAgaWYgKCF0aGlzLl9pZCkge1xuICAgICAgY29uc3QgYXN5bmNSZXN1bHQgPSBhd2FpdCB0aGlzLl9wcm9taXNlO1xuICAgICAgdGhpcy5faWQgPSBhc3luY1Jlc3VsdC5pZDtcbiAgICB9XG4gICAgY29uc3QgaWQgPSB0aGlzLl9pZDtcblxuICAgIHJldHVybiBuZXcgUHJvbWlzZTxEZXBsb3lSZXN1bHQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IHN0YXJ0VGltZSA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgY29uc3QgdGltZW91dFRpbWUgPSBzdGFydFRpbWUgKyB0aGlzLl9tZXRhLnBvbGxUaW1lb3V0O1xuXG4gICAgICBjb25zdCBwb2xsID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgICAgIGlmICh0aW1lb3V0VGltZSA8IG5vdykge1xuICAgICAgICAgICAgY29uc3QgZXJyID0gbmV3IEVycm9yKCdQb2xsaW5nIHRpbWUgb3V0LiBEZXBsb3kgb3BlcmF0aW9uIGlzIG5vdCBjb21wbGV0ZWQuJyk7XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLl9tZXRhLmNoZWNrRGVwbG95U3RhdHVzKGlkLCBpbmNsdWRlRGV0YWlscyk7XG4gICAgICAgICAgaWYgKHJlc3VsdC5kb25lKSB7XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2NvbXBsZXRlJywgcmVzdWx0KTtcbiAgICAgICAgICAgIHJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5lbWl0KCdwcm9ncmVzcycsIHJlc3VsdCk7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KHBvbGwsIHRoaXMuX21ldGEucG9sbEludGVydmFsKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICBzZXRUaW1lb3V0KHBvbGwsIHRoaXMuX21ldGEucG9sbEludGVydmFsKTtcbiAgICB9KTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qXG4gKiBSZWdpc3RlciBob29rIGluIGNvbm5lY3Rpb24gaW5zdGFudGlhdGlvbiBmb3IgZHluYW1pY2FsbHkgYWRkaW5nIHRoaXMgQVBJIG1vZHVsZSBmZWF0dXJlc1xuICovXG5yZWdpc3Rlck1vZHVsZSgnbWV0YWRhdGEnLCAoY29ubikgPT4gbmV3IE1ldGFkYXRhQXBpKGNvbm4pKTtcblxuZXhwb3J0IGRlZmF1bHQgTWV0YWRhdGFBcGk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLFlBQVksUUFBUSxRQUFRO0FBQ3JDLFNBQVNDLFFBQVEsUUFBUSxRQUFRO0FBQ2pDLE9BQU9DLFFBQVEsTUFBTSxXQUFXO0FBQ2hDLFNBQVNDLGNBQWMsUUFBUSxZQUFZO0FBRTNDLE9BQU9DLElBQUksTUFBTSxTQUFTO0FBQzFCLFNBQVNDLFFBQVEsUUFBUSxrQkFBa0I7QUFFM0MsU0FDRUMsVUFBVSxRQWNMLG1CQUFtQjtBQUMxQixjQUFjLG1CQUFtQjs7QUFFakM7QUFDQTtBQUNBOztBQWlDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQywwQkFBMEJBLENBQXFCQyxRQUFXLEVBQUs7RUFDdEUsSUFBQUMsSUFBQSxHQUFxQkQsUUFBUTtJQUFyQkUsQ0FBQyxHQUFBRCxJQUFBLENBQURDLENBQUM7SUFBS0MsRUFBRSxHQUFBQyx3QkFBQSxDQUFBSCxJQUFBLEVBQUFJLFNBQUE7RUFDaEIsT0FBT0YsRUFBRTtBQUNYO0FBRUEsU0FBU0csc0JBQXNCQSxDQUFDTixRQUErQixFQUFFTyxJQUFZLEVBQUU7RUFDN0UsSUFBTUMsT0FBTyxHQUFHLFNBQVZBLE9BQU9BLENBQUlMLEVBQVk7SUFBQSxPQUFBTSxhQUFBLENBQUFDLGVBQUEsS0FBUyxXQUFXLEVBQUdILElBQUksR0FBS0osRUFBRTtFQUFBLENBQUc7RUFDbEUsT0FBT1EsY0FBQSxDQUFjWCxRQUFRLENBQUMsR0FBR1ksb0JBQUEsQ0FBQVosUUFBUSxFQUFBYSxJQUFBLENBQVJiLFFBQVEsRUFBS1EsT0FBTyxDQUFDLEdBQUdBLE9BQU8sQ0FBQ1IsUUFBUSxDQUFDO0FBQzVFOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQWFjLFdBQVc7RUFhdEI7QUFDRjtBQUNBO0VBQ0UsU0FBQUEsWUFBWUMsSUFBbUIsRUFBRTtJQUFBQyxlQUFBLE9BQUFGLFdBQUE7SUFiakM7QUFDRjtBQUNBO0lBRkVKLGVBQUEsdUJBR3VCLElBQUk7SUFFM0I7QUFDRjtBQUNBO0lBRkVBLGVBQUEsc0JBR3NCLEtBQUs7SUFNekIsSUFBSSxDQUFDTyxLQUFLLEdBQUdGLElBQUk7RUFDbkI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUpFLE9BQUFHLFlBQUEsQ0FBQUosV0FBQTtJQUFBSyxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBQyxRQUFBLEdBQUFDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FLQSxTQUFBQyxRQUNFQyxNQUFjLEVBQ2RDLE9BQWUsRUFDZkMsTUFBbUM7UUFBQSxJQUFBQyxRQUFBO1FBQUEsSUFBQUMsWUFBQSxFQUFBQyxHQUFBO1FBQUEsT0FBQVIsbUJBQUEsQ0FBQVMsSUFBQSxVQUFBQyxTQUFBQyxTQUFBO1VBQUEsa0JBQUFBLFNBQUEsQ0FBQUMsSUFBQSxHQUFBRCxTQUFBLENBQUFFLElBQUE7WUFBQTtjQUU3Qk4sWUFBWSxHQUFHLElBQUlsQyxJQUFJLENBQUMsSUFBSSxDQUFDcUIsS0FBSyxFQUFFO2dCQUN4Q29CLEtBQUssRUFBRSx5Q0FBeUM7Z0JBQ2hEQyxXQUFXLEVBQUFDLHVCQUFBLENBQUFWLFFBQUEsTUFBQVcsTUFBQSxDQUFLLElBQUksQ0FBQ3ZCLEtBQUssQ0FBQ3dCLFdBQVcsd0JBQUE1QixJQUFBLENBQUFnQixRQUFBLEVBQW9CLElBQUksQ0FBQ1osS0FBSyxDQUFDeUIsT0FBTztjQUM5RSxDQUFDLENBQUM7Y0FBQVIsU0FBQSxDQUFBRSxJQUFBO2NBQUEsT0FDZ0JOLFlBQVksQ0FBQ2EsTUFBTSxDQUNuQ2pCLE1BQU0sRUFDTkMsT0FBTyxFQUNQQyxNQUFNLEdBQUk7Z0JBQUVnQixNQUFNLEVBQUVoQjtjQUFPLENBQUMsR0FBa0JpQixTQUFTLEVBQ3ZEL0MsVUFDRixDQUFDO1lBQUE7Y0FMS2lDLEdBQUcsR0FBQUcsU0FBQSxDQUFBWSxJQUFBO2NBQUEsT0FBQVosU0FBQSxDQUFBYSxNQUFBLFdBTUZoQixHQUFHLENBQUNhLE1BQU07WUFBQTtZQUFBO2NBQUEsT0FBQVYsU0FBQSxDQUFBYyxJQUFBO1VBQUE7UUFBQSxHQUFBdkIsT0FBQTtNQUFBLENBQ2xCO01BQUEsU0FoQkt3QixPQUFPQSxDQUFBQyxFQUFBLEVBQUFDLEdBQUEsRUFBQUMsR0FBQTtRQUFBLE9BQUEvQixRQUFBLENBQUFnQyxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVBMLE9BQU87SUFBQTtJQWtCYjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUE5QixHQUFBO0lBQUFDLEtBQUEsRUFrQkEsU0FBQW1DLE1BQU1BLENBQUNoRCxJQUFZLEVBQUVQLFFBQStCLEVBQUU7TUFDcEQsSUFBTXdELE9BQU8sR0FBRzdDLGNBQUEsQ0FBY1gsUUFBUSxDQUFDO01BQ3ZDQSxRQUFRLEdBQUdNLHNCQUFzQixDQUFDTixRQUFRLEVBQUVPLElBQUksQ0FBQztNQUNqRCxJQUFNcUIsTUFBTSxHQUFHNEIsT0FBTyxHQUFHLENBQUMxRCxVQUFVLENBQUMyRCxVQUFVLENBQUMsR0FBRzNELFVBQVUsQ0FBQzJELFVBQVU7TUFDeEUsT0FBTyxJQUFJLENBQUNSLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRTtRQUFFakQsUUFBUSxFQUFSQTtNQUFTLENBQUMsRUFBRTRCLE1BQU0sQ0FBQztJQUM3RDs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBVCxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBc0MsS0FBQSxHQUFBcEMsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQWtCQSxTQUFBbUMsU0FBV3BELElBQVksRUFBRXFELFNBQTRCO1FBQUEsSUFBQUMsU0FBQTtRQUFBLElBQUFDLGdCQUFBLEVBQUEvQixHQUFBO1FBQUEsT0FBQVIsbUJBQUEsQ0FBQVMsSUFBQSxVQUFBK0IsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUE3QixJQUFBLEdBQUE2QixTQUFBLENBQUE1QixJQUFBO1lBQUE7Y0FDN0MwQixnQkFBZ0IsR0FDcEJ2RCxJQUFJLElBQUlULFVBQVUsR0FDYjtnQkFDQ1MsSUFBSSxFQUFFVCxVQUFVLENBQUNtRSxVQUFVLENBQUMxRCxJQUFJO2dCQUNoQzJELEtBQUssRUFBRTtrQkFDTEMsT0FBTyxFQUFFLENBQUM1RCxJQUFJO2dCQUNoQjtjQUNGLENBQUMsR0FDRFQsVUFBVSxDQUFDbUUsVUFBVTtjQUFBRCxTQUFBLENBQUE1QixJQUFBO2NBQUEsT0FDRyxJQUFJLENBQUNhLE9BQU8sQ0FDeEMsY0FBYyxFQUNkO2dCQUFFMUMsSUFBSSxFQUFKQSxJQUFJO2dCQUFFcUQsU0FBUyxFQUFUQTtjQUFVLENBQUMsRUFDbkJFLGdCQUNGLENBQUM7WUFBQTtjQUpLL0IsR0FBZSxHQUFBaUMsU0FBQSxDQUFBbEIsSUFBQTtjQUFBLE9BQUFrQixTQUFBLENBQUFqQixNQUFBLFdBS2RwQyxjQUFBLENBQWNpRCxTQUFTLENBQUMsR0FDM0JoRCxvQkFBQSxDQUFBaUQsU0FBQSxHQUFBOUIsR0FBRyxDQUFDb0MsT0FBTyxFQUFBdEQsSUFBQSxDQUFBZ0QsU0FBQSxFQUFLOUQsMEJBQTBCLENBQUMsR0FDM0NBLDBCQUEwQixDQUFDZ0MsR0FBRyxDQUFDb0MsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUFILFNBQUEsQ0FBQWhCLElBQUE7VUFBQTtRQUFBLEdBQUFXLFFBQUE7TUFBQSxDQUMvQztNQUFBLFNBbEJLUyxJQUFJQSxDQUFBQyxHQUFBLEVBQUFDLEdBQUE7UUFBQSxPQUFBWixLQUFBLENBQUFMLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBSmMsSUFBSTtJQUFBO0lBb0JWO0FBQ0Y7QUFDQTtFQUZFO0lBQUFqRCxHQUFBO0lBQUFDLEtBQUEsRUFxQkEsU0FBQW1ELE1BQU1BLENBQUNoRSxJQUFZLEVBQUVQLFFBQStCLEVBQUU7TUFDcEQsSUFBTXdELE9BQU8sR0FBRzdDLGNBQUEsQ0FBY1gsUUFBUSxDQUFDO01BQ3ZDQSxRQUFRLEdBQUdNLHNCQUFzQixDQUFDTixRQUFRLEVBQUVPLElBQUksQ0FBQztNQUNqRCxJQUFNcUIsTUFBTSxHQUFHNEIsT0FBTyxHQUFHLENBQUMxRCxVQUFVLENBQUMyRCxVQUFVLENBQUMsR0FBRzNELFVBQVUsQ0FBQzJELFVBQVU7TUFDeEUsT0FBTyxJQUFJLENBQUNSLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRTtRQUFFakQsUUFBUSxFQUFSQTtNQUFTLENBQUMsRUFBRTRCLE1BQU0sQ0FBQztJQUM3RDs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBVCxHQUFBO0lBQUFDLEtBQUEsRUFrQkEsU0FBQW9ELE1BQU1BLENBQUNqRSxJQUFZLEVBQUVQLFFBQStCLEVBQUU7TUFDcEQsSUFBTXdELE9BQU8sR0FBRzdDLGNBQUEsQ0FBY1gsUUFBUSxDQUFDO01BQ3ZDQSxRQUFRLEdBQUdNLHNCQUFzQixDQUFDTixRQUFRLEVBQUVPLElBQUksQ0FBQztNQUNqRCxJQUFNcUIsTUFBTSxHQUFHNEIsT0FBTyxHQUNsQixDQUFDMUQsVUFBVSxDQUFDMkUsWUFBWSxDQUFDLEdBQ3pCM0UsVUFBVSxDQUFDMkUsWUFBWTtNQUMzQixPQUFPLElBQUksQ0FBQ3hCLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRTtRQUFFakQsUUFBUSxFQUFSQTtNQUFTLENBQUMsRUFBRTRCLE1BQU0sQ0FBQztJQUM3RDs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBVCxHQUFBO0lBQUFDLEtBQUEsRUFTQSxTQUFBc0QsT0FBTUEsQ0FBQ25FLElBQVksRUFBRXFELFNBQTRCLEVBQUU7TUFDakQsSUFBTWhDLE1BQU0sR0FBR2pCLGNBQUEsQ0FBY2lELFNBQVMsQ0FBQyxHQUNuQyxDQUFDOUQsVUFBVSxDQUFDMkQsVUFBVSxDQUFDLEdBQ3ZCM0QsVUFBVSxDQUFDMkQsVUFBVTtNQUN6QixPQUFPLElBQUksQ0FBQ1IsT0FBTyxDQUFDLGdCQUFnQixFQUFFO1FBQUUxQyxJQUFJLEVBQUpBLElBQUk7UUFBRXFELFNBQVMsRUFBVEE7TUFBVSxDQUFDLEVBQUVoQyxNQUFNLENBQUM7SUFDcEU7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQVQsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQXVELE1BQU1BLENBQ0pwRSxJQUFZLEVBQ1pxRSxXQUFtQixFQUNuQkMsV0FBbUIsRUFDRTtNQUNyQixPQUFPLElBQUksQ0FBQzVCLE9BQU8sQ0FDakIsZ0JBQWdCLEVBQ2hCO1FBQUUxQyxJQUFJLEVBQUpBLElBQUk7UUFBRXFFLFdBQVcsRUFBWEEsV0FBVztRQUFFQyxXQUFXLEVBQVhBO01BQVksQ0FBQyxFQUNsQy9FLFVBQVUsQ0FBQzJELFVBQ2IsQ0FBQztJQUNIOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFKRTtJQUFBdEMsR0FBQTtJQUFBQyxLQUFBLEVBS0EsU0FBQTBELFFBQVFBLENBQUNDLFdBQW9CLEVBQW1DO01BQzlELElBQUksQ0FBQ0EsV0FBVyxFQUFFO1FBQ2hCQSxXQUFXLEdBQUcsSUFBSSxDQUFDOUQsS0FBSyxDQUFDeUIsT0FBTztNQUNsQztNQUNBLE9BQU8sSUFBSSxDQUFDTyxPQUFPLENBQ2pCLGtCQUFrQixFQUNsQjtRQUFFOEIsV0FBVyxFQUFYQTtNQUFZLENBQUMsRUFDZmpGLFVBQVUsQ0FBQ2tGLHNCQUNiLENBQUM7SUFDSDs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBN0QsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQTZELElBQUlBLENBQ0ZDLE9BQWdELEVBQ2hESCxXQUFvQixFQUNPO01BQzNCLElBQUksQ0FBQ0EsV0FBVyxFQUFFO1FBQ2hCQSxXQUFXLEdBQUcsSUFBSSxDQUFDOUQsS0FBSyxDQUFDeUIsT0FBTztNQUNsQztNQUNBLE9BQU8sSUFBSSxDQUFDTyxPQUFPLENBQUMsY0FBYyxFQUFFO1FBQUVpQyxPQUFPLEVBQVBBLE9BQU87UUFBRUgsV0FBVyxFQUFYQTtNQUFZLENBQUMsRUFBRSxDQUM1RGpGLFVBQVUsQ0FBQ3FGLGNBQWMsQ0FDMUIsQ0FBQztJQUNKOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFoRSxHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBZ0UsV0FBV0EsQ0FBQ0MsY0FBc0IsRUFBRTtNQUNsQyxJQUFNdEQsR0FBRyxHQUFHLElBQUksQ0FBQ2tCLE9BQU8sQ0FDdEIsYUFBYSxFQUNiO1FBQUVvQyxjQUFjLEVBQWRBO01BQWUsQ0FBQyxFQUNsQnZGLFVBQVUsQ0FBQ3dGLFdBQ2IsQ0FBQztNQUNELE9BQU8sSUFBSUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFeEQsR0FBRyxDQUFDO0lBQzFDOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFaLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUFvRSxRQUFRQSxDQUFDQyxPQUFpQyxFQUFFO01BQzFDLElBQU0xRCxHQUFHLEdBQUcsSUFBSSxDQUFDa0IsT0FBTyxDQUN0QixVQUFVLEVBQ1Y7UUFBRXdDLE9BQU8sRUFBUEE7TUFBUSxDQUFDLEVBQ1gzRixVQUFVLENBQUM0RixjQUNiLENBQUM7TUFDRCxPQUFPLElBQUlDLHFCQUFxQixDQUFDLElBQUksRUFBRTVELEdBQUcsQ0FBQztJQUM3Qzs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBWixHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBd0UsbUJBQW1CQSxDQUFDUCxjQUFzQixFQUEyQjtNQUNuRSxPQUFPLElBQUksQ0FBQ3BDLE9BQU8sQ0FDakIscUJBQXFCLEVBQ3JCO1FBQUVvQyxjQUFjLEVBQWRBO01BQWUsQ0FBQyxFQUNsQnZGLFVBQVUsQ0FBQzRGLGNBQ2IsQ0FBQztJQUNIOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBTkU7SUFBQXZFLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUF5RSx1QkFBQSxHQUFBdkUsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQU9BLFNBQUFzRSxTQUFvQ0MsT0FHbkM7UUFBQSxJQUFBQyxFQUFBLEVBQUFDLElBQUEsRUFBQUMsUUFBQSxFQUFBQyxXQUFBLEVBQUFDLFdBQUEsRUFBQUMsY0FBQTtRQUFBLE9BQUE5RSxtQkFBQSxDQUFBUyxJQUFBLFVBQUFzRSxVQUFBQyxTQUFBO1VBQUEsa0JBQUFBLFNBQUEsQ0FBQXBFLElBQUEsR0FBQW9FLFNBQUEsQ0FBQW5FLElBQUE7WUFBQTtjQUNTNEQsRUFBRSxHQUFXRCxPQUFPLENBQXBCQyxFQUFFLEVBQUVDLElBQUksR0FBS0YsT0FBTyxDQUFoQkUsSUFBSTtjQUFBLEtBRVpBLElBQUk7Z0JBQUFNLFNBQUEsQ0FBQW5FLElBQUE7Z0JBQUE7Y0FBQTtjQUNBK0QsV0FBVyxHQUFHSyxlQUFBLENBQWU7Z0JBQ2pDQyx3QkFBd0IsRUFBRVQ7Y0FDNUIsQ0FBQyxDQUFDO2NBRUlJLFdBQXdCLEdBQUc7Z0JBQy9CMUUsTUFBTSxFQUFFLE1BQU07Z0JBQ2RnRixHQUFHLEtBQUFsRSxNQUFBLENBQUssSUFBSSxDQUFDdkIsS0FBSyxDQUFDMEYsUUFBUSxDQUFDLENBQUMsNEJBQXlCO2dCQUN0REMsSUFBSSxFQUFFVCxXQUFXO2dCQUNqQlUsT0FBTyxFQUFFO2tCQUNQLGNBQWMsRUFBRTtnQkFDbEI7Y0FDRixDQUFDO2NBQ0tSLGNBQWMsR0FBRztnQkFBRVEsT0FBTyxFQUFFO2NBQU8sQ0FBQyxFQUMxQztjQUNBO2NBQ0E7Y0FBQU4sU0FBQSxDQUFBbkUsSUFBQTtjQUFBLE9BRVEsSUFBSSxDQUFDbkIsS0FBSyxDQUFDd0UsT0FBTyxDQUFpQlcsV0FBVyxFQUFFQyxjQUFjLENBQUM7WUFBQTtjQUR2RUgsUUFBUSxHQUFBSyxTQUFBLENBQUF6RCxJQUFBLENBRU5rRCxFQUFFO2NBQUFPLFNBQUEsQ0FBQW5FLElBQUE7Y0FBQTtZQUFBO2NBQUFtRSxTQUFBLENBQUFuRSxJQUFBO2NBQUEsT0FFYSxJQUFJLENBQUNhLE9BQU8sQ0FBQyx3QkFBd0IsRUFBRTtnQkFDdEQ2RCxZQUFZLEVBQUVkO2NBQ2hCLENBQUMsQ0FBQztZQUFBO2NBRkZFLFFBQVEsR0FBQUssU0FBQSxDQUFBekQsSUFBQTtZQUFBO2NBQUEsT0FBQXlELFNBQUEsQ0FBQXhELE1BQUEsV0FLSG1ELFFBQVE7WUFBQTtZQUFBO2NBQUEsT0FBQUssU0FBQSxDQUFBdkQsSUFBQTtVQUFBO1FBQUEsR0FBQThDLFFBQUE7TUFBQSxDQUNoQjtNQUFBLFNBakNZaUIsc0JBQXNCQSxDQUFBQyxHQUFBO1FBQUEsT0FBQW5CLHVCQUFBLENBQUF4QyxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQXRCeUQsc0JBQXNCO0lBQUE7SUFtQ25DO0FBQ0Y7QUFDQTtBQUNBO0lBSEU7RUFBQTtJQUFBNUYsR0FBQTtJQUFBQyxLQUFBLEVBSUEsU0FBQTZGLFVBQVVBLENBQ1JDLFFBQWdCLEVBRVE7TUFBQSxJQUR4Qm5CLE9BQStCLEdBQUF6QyxTQUFBLENBQUE2RCxNQUFBLFFBQUE3RCxTQUFBLFFBQUFULFNBQUEsR0FBQVMsU0FBQSxNQUFHLENBQUMsQ0FBQztNQUVwQyxJQUFNOEQsSUFBSSxHQUFHLElBQUkxSCxRQUFRLENBQUMsQ0FBQztNQUMzQjBILElBQUksQ0FBQ0MsTUFBTSxDQUFDLE1BQU0sRUFBRUgsUUFBUSxFQUFFO1FBQzVCSSxXQUFXLEVBQUUsaUJBQWlCO1FBQzlCQyxRQUFRLEVBQUU7TUFDWixDQUFDLENBQUM7O01BRUY7TUFDQUgsSUFBSSxDQUFDQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUViLGVBQUEsQ0FBZTtRQUFFZ0IsYUFBYSxFQUFFekI7TUFBUSxDQUFDLENBQUMsRUFBRTtRQUN4RXVCLFdBQVcsRUFBRTtNQUNmLENBQUMsQ0FBQztNQUVGLElBQU03QixPQUFvQixHQUFHO1FBQzNCaUIsR0FBRyxFQUFFLHlCQUF5QjtRQUM5QmhGLE1BQU0sRUFBRSxNQUFNO1FBQ2RtRixPQUFPLEVBQUFwRyxhQUFBLEtBQU8yRyxJQUFJLENBQUNLLFVBQVUsQ0FBQyxDQUFDLENBQUU7UUFDakNiLElBQUksRUFBRVEsSUFBSSxDQUFDTSxTQUFTLENBQUM7TUFDdkIsQ0FBQztNQUNELElBQU0zRixHQUFHLEdBQUcsSUFBSSxDQUFDZCxLQUFLLENBQUN3RSxPQUFPLENBQWNBLE9BQU8sQ0FBQztNQUVwRCxPQUFPLElBQUlrQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUU1RixHQUFHLENBQUM7SUFDM0M7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQVosR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQXdHLE1BQU1BLENBQ0pWLFFBQW9DLEVBRVo7TUFBQSxJQUFBVyxLQUFBO01BQUEsSUFEeEI5QixPQUErQixHQUFBekMsU0FBQSxDQUFBNkQsTUFBQSxRQUFBN0QsU0FBQSxRQUFBVCxTQUFBLEdBQUFTLFNBQUEsTUFBRyxDQUFDLENBQUM7TUFFcEMsSUFBTXZCLEdBQUcsR0FBR1QsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUFDLFNBQUFzRyxTQUFBO1FBQUEsSUFBQUMsYUFBQTtRQUFBLE9BQUF4RyxtQkFBQSxDQUFBUyxJQUFBLFVBQUFnRyxVQUFBQyxTQUFBO1VBQUEsa0JBQUFBLFNBQUEsQ0FBQTlGLElBQUEsR0FBQThGLFNBQUEsQ0FBQTdGLElBQUE7WUFBQTtjQUFBNkYsU0FBQSxDQUFBN0YsSUFBQTtjQUFBLE9BQ2lCLElBQUE4RixRQUFBLENBQVksVUFBQ0MsT0FBTyxFQUFFQyxNQUFNLEVBQUs7Z0JBQzNELElBQ0V2SSxRQUFRLENBQUNxSCxRQUFRLENBQUMsSUFDbEIsTUFBTSxJQUFJQSxRQUFRLElBQ2xCLE9BQU9BLFFBQVEsQ0FBQ21CLElBQUksS0FBSyxVQUFVLEVBQ25DO2tCQUNBLElBQU1DLElBQWMsR0FBRyxFQUFFO2tCQUN6QnBCLFFBQVEsQ0FBQ3FCLEVBQUUsQ0FBQyxNQUFNLEVBQUUsVUFBQ0MsQ0FBQztvQkFBQSxPQUFLRixJQUFJLENBQUNHLElBQUksQ0FBQ0QsQ0FBQyxDQUFDO2tCQUFBLEVBQUM7a0JBQ3hDdEIsUUFBUSxDQUFDcUIsRUFBRSxDQUFDLE9BQU8sRUFBRUgsTUFBTSxDQUFDO2tCQUM1QmxCLFFBQVEsQ0FBQ3FCLEVBQUUsQ0FBQyxLQUFLLEVBQUUsWUFBTTtvQkFDdkJKLE9BQU8sQ0FBQzVGLHVCQUFBLENBQUFtRyxNQUFNLEVBQUE3SCxJQUFBLENBQU42SCxNQUFNLEVBQVFKLElBQUksQ0FBQyxDQUFDSyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7a0JBQ2pELENBQUMsQ0FBQztrQkFDRjtnQkFDRixDQUFDLE1BQU0sSUFBSXpCLFFBQVEsWUFBWXdCLE1BQU0sRUFBRTtrQkFDckNQLE9BQU8sQ0FBQ2pCLFFBQVEsQ0FBQ3lCLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDdEMsQ0FBQyxNQUFNLElBQUl6QixRQUFRLFlBQVkwQixNQUFNLElBQUksT0FBTzFCLFFBQVEsS0FBSyxRQUFRLEVBQUU7a0JBQ3JFaUIsT0FBTyxDQUFDakIsUUFBUSxDQUFDO2dCQUNuQixDQUFDLE1BQU07a0JBQ0wsTUFBTSwwQkFBMEI7Z0JBQ2xDO2NBQ0YsQ0FBQyxDQUFDO1lBQUE7Y0FwQklhLGFBQWEsR0FBQUUsU0FBQSxDQUFBbkYsSUFBQTtjQUFBLE9BQUFtRixTQUFBLENBQUFsRixNQUFBLFdBc0JaOEUsS0FBSSxDQUFDNUUsT0FBTyxDQUNqQixRQUFRLEVBQ1I7Z0JBQ0U0RixPQUFPLEVBQUVkLGFBQWE7Z0JBQ3RCZSxhQUFhLEVBQUUvQztjQUNqQixDQUFDLEVBQ0RqRyxVQUFVLENBQUNpSixZQUNiLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQWQsU0FBQSxDQUFBakYsSUFBQTtVQUFBO1FBQUEsR0FBQThFLFFBQUE7TUFBQSxDQUNGLEdBQUUsQ0FBQztNQUVKLE9BQU8sSUFBSUgsbUJBQW1CLENBQUMsSUFBSSxFQUFFNUYsR0FBRyxDQUFDO0lBQzNDOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBSEU7SUFBQVosR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQTRILGtCQUFBLEdBQUExSCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBSUEsU0FBQXlILFNBQ0U1RCxjQUFzQjtRQUFBLElBQUE2RCxjQUFBO1VBQUFqRCxJQUFBO1VBQUFrRCxTQUFBO1VBQUF6QyxHQUFBO1VBQUEwQyxNQUFBLEdBQUE5RixTQUFBO1FBQUEsT0FBQS9CLG1CQUFBLENBQUFTLElBQUEsVUFBQXFILFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBbkgsSUFBQSxHQUFBbUgsU0FBQSxDQUFBbEgsSUFBQTtZQUFBO2NBQ3RCOEcsY0FBdUIsR0FBQUUsTUFBQSxDQUFBakMsTUFBQSxRQUFBaUMsTUFBQSxRQUFBdkcsU0FBQSxHQUFBdUcsTUFBQSxNQUFHLEtBQUs7Y0FDL0JuRCxJQUFhLEdBQUFtRCxNQUFBLENBQUFqQyxNQUFBLFFBQUFpQyxNQUFBLFFBQUF2RyxTQUFBLEdBQUF1RyxNQUFBLE1BQUcsS0FBSztjQUFBLEtBRWpCbkQsSUFBSTtnQkFBQXFELFNBQUEsQ0FBQWxILElBQUE7Z0JBQUE7Y0FBQTtjQUNBc0UsR0FBRyxHQUFBbkUsdUJBQUEsQ0FBQTRHLFNBQUEsOEJBQUEzRyxNQUFBLENBQThCNkMsY0FBYyxHQUFBeEUsSUFBQSxDQUFBc0ksU0FBQSxFQUFHRCxjQUFjLEdBQUcsc0JBQXNCLEdBQUcsRUFBRTtjQUFBSSxTQUFBLENBQUFsSCxJQUFBO2NBQUEsT0FPdEYsSUFBSSxDQUFDbkIsS0FBSyxDQUFDc0ksVUFBVSxDQUF3QjdDLEdBQUcsQ0FBQztZQUFBO2NBQUEsT0FBQTRDLFNBQUEsQ0FBQXZHLE1BQUEsV0FBQXVHLFNBQUEsQ0FBQXhHLElBQUEsQ0FBRTBHLFlBQVk7WUFBQTtjQUFBLE9BQUFGLFNBQUEsQ0FBQXZHLE1BQUEsV0FFdEUsSUFBSSxDQUFDRSxPQUFPLENBQ2pCLG1CQUFtQixFQUNuQjtnQkFDRW9DLGNBQWMsRUFBZEEsY0FBYztnQkFDZDZELGNBQWMsRUFBZEE7Y0FDRixDQUFDLEVBQ0RwSixVQUFVLENBQUNpSixZQUNiLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQU8sU0FBQSxDQUFBdEcsSUFBQTtVQUFBO1FBQUEsR0FBQWlHLFFBQUE7TUFBQSxDQUVKO01BQUEsU0F4QktRLGlCQUFpQkEsQ0FBQUMsR0FBQTtRQUFBLE9BQUFWLGtCQUFBLENBQUEzRixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQWpCbUcsaUJBQWlCO0lBQUE7RUFBQTtJQUFBdEksR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQXVJLGFBQUEsR0FBQXJJLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0EwQnZCLFNBQUFvSSxTQUFtQjVELEVBQVU7UUFBQSxPQUFBekUsbUJBQUEsQ0FBQVMsSUFBQSxVQUFBNkgsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUEzSCxJQUFBLEdBQUEySCxTQUFBLENBQUExSCxJQUFBO1lBQUE7Y0FBQSxPQUFBMEgsU0FBQSxDQUFBL0csTUFBQSxXQUNwQixJQUFJLENBQUNFLE9BQU8sQ0FBQyxjQUFjLEVBQUU7Z0JBQUUrQyxFQUFFLEVBQUZBO2NBQUcsQ0FBQyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUE4RCxTQUFBLENBQUE5RyxJQUFBO1VBQUE7UUFBQSxHQUFBNEcsUUFBQTtNQUFBLENBQzVDO01BQUEsU0FGS0csWUFBWUEsQ0FBQUMsR0FBQTtRQUFBLE9BQUFMLGFBQUEsQ0FBQXRHLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBWnlHLFlBQVk7SUFBQTtFQUFBO0FBQUE7O0FBS3BCOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFdBQWF4RSxrQkFBa0IsMEJBQUEwRSxhQUFBO0VBUTdCO0FBQ0Y7QUFDQTtFQUNFLFNBQUExRSxtQkFBWTJFLElBQW9CLEVBQUVDLE9BQTZCLEVBQUU7SUFBQSxJQUFBQyxNQUFBO0lBQUFwSixlQUFBLE9BQUF1RSxrQkFBQTtJQUMvRDZFLE1BQUEsR0FBQUMsVUFBQSxPQUFBOUUsa0JBQUE7SUFDQTZFLE1BQUEsQ0FBS0UsS0FBSyxHQUFHSixJQUFJO0lBQ2pCRSxNQUFBLENBQUtHLFFBQVEsR0FBR0osT0FBTztJQUFDLE9BQUFDLE1BQUE7RUFDMUI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBTEVJLFNBQUEsQ0FBQWpGLGtCQUFBLEVBQUEwRSxhQUFBO0VBQUEsT0FBQS9JLFlBQUEsQ0FBQXFFLGtCQUFBO0lBQUFwRSxHQUFBO0lBQUFDLEtBQUEsRUFNQSxTQUFBcUosSUFBSUEsQ0FDRkMsU0FBd0UsRUFDeEVDLFFBQThELEVBQzlDO01BQ2hCLE9BQU8sSUFBSSxDQUFDSixRQUFRLENBQUNFLElBQUksQ0FBQ0MsU0FBUyxFQUFFQyxRQUFRLENBQUM7SUFDaEQ7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQXhKLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUF3SixNQUFBLEdBQUF0SixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQXFKLFNBQUE7UUFBQSxJQUFBakksTUFBQTtRQUFBLE9BQUFyQixtQkFBQSxDQUFBUyxJQUFBLFVBQUE4SSxVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTVJLElBQUEsR0FBQTRJLFVBQUEsQ0FBQTNJLElBQUE7WUFBQTtjQUFBMkksVUFBQSxDQUFBM0ksSUFBQTtjQUFBLE9BQ3VCLElBQUksQ0FBQ21JLFFBQVE7WUFBQTtjQUE1QjNILE1BQU0sR0FBQW1JLFVBQUEsQ0FBQWpJLElBQUE7Y0FDWixJQUFJLENBQUNrSSxHQUFHLEdBQUdwSSxNQUFNLENBQUNvRCxFQUFFO2NBQUMsT0FBQStFLFVBQUEsQ0FBQWhJLE1BQUEsV0FDZCxJQUFJLENBQUN1SCxLQUFLLENBQUNsRixXQUFXLENBQUN4QyxNQUFNLENBQUNvRCxFQUFFLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQStFLFVBQUEsQ0FBQS9ILElBQUE7VUFBQTtRQUFBLEdBQUE2SCxRQUFBO01BQUEsQ0FDekM7TUFBQSxTQUpLSSxLQUFLQSxDQUFBO1FBQUEsT0FBQUwsTUFBQSxDQUFBdkgsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFMMkgsS0FBSztJQUFBO0lBTVg7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBOUosR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQThKLEtBQUlBLENBQUNDLFFBQWdCLEVBQUVDLE9BQWUsRUFBRTtNQUFBLElBQUFDLE1BQUE7TUFDdEMsSUFBTUMsU0FBUyxHQUFHLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDO01BQ3RDLElBQU1OLEtBQUk7UUFBQSxJQUFBTyxLQUFBLEdBQUFuSyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQUcsU0FBQWtLLFNBQUE7VUFBQSxJQUFBQyxHQUFBLEVBQUFDLE1BQUEsRUFBQWhKLE1BQUE7VUFBQSxPQUFBckIsbUJBQUEsQ0FBQVMsSUFBQSxVQUFBNkosVUFBQUMsVUFBQTtZQUFBLGtCQUFBQSxVQUFBLENBQUEzSixJQUFBLEdBQUEySixVQUFBLENBQUExSixJQUFBO2NBQUE7Z0JBQUEwSixVQUFBLENBQUEzSixJQUFBO2dCQUVId0osR0FBRyxHQUFHLElBQUlKLElBQUksQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDO2dCQUFBLE1BQzVCRixTQUFTLEdBQUdGLE9BQU8sR0FBR08sR0FBRztrQkFBQUcsVUFBQSxDQUFBMUosSUFBQTtrQkFBQTtnQkFBQTtnQkFDdkJ3SixNQUFNLEdBQUcsbUJBQW1CO2dCQUNoQyxJQUFJUCxNQUFJLENBQUNMLEdBQUcsRUFBRTtrQkFDWlksTUFBTSxJQUFJLGdCQUFnQixHQUFHUCxNQUFJLENBQUNMLEdBQUc7Z0JBQ3ZDO2dCQUNBSyxNQUFJLENBQUNVLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSUMsS0FBSyxDQUFDSixNQUFNLENBQUMsQ0FBQztnQkFBQyxPQUFBRSxVQUFBLENBQUEvSSxNQUFBO2NBQUE7Z0JBQUErSSxVQUFBLENBQUExSixJQUFBO2dCQUFBLE9BR25CaUosTUFBSSxDQUFDSixLQUFLLENBQUMsQ0FBQztjQUFBO2dCQUEzQnJJLE1BQU0sR0FBQWtKLFVBQUEsQ0FBQWhKLElBQUE7Z0JBQ1osSUFBSUYsTUFBTSxDQUFDcUosSUFBSSxFQUFFO2tCQUNmWixNQUFJLENBQUNVLElBQUksQ0FBQyxVQUFVLEVBQUVuSixNQUFNLENBQUM7Z0JBQy9CLENBQUMsTUFBTTtrQkFDTHlJLE1BQUksQ0FBQ1UsSUFBSSxDQUFDLFVBQVUsRUFBRW5KLE1BQU0sQ0FBQztrQkFDN0JzSixXQUFBLENBQVdoQixLQUFJLEVBQUVDLFFBQVEsQ0FBQztnQkFDNUI7Z0JBQUNXLFVBQUEsQ0FBQTFKLElBQUE7Z0JBQUE7Y0FBQTtnQkFBQTBKLFVBQUEsQ0FBQTNKLElBQUE7Z0JBQUEySixVQUFBLENBQUFLLEVBQUEsR0FBQUwsVUFBQTtnQkFFRFQsTUFBSSxDQUFDVSxJQUFJLENBQUMsT0FBTyxFQUFBRCxVQUFBLENBQUFLLEVBQUssQ0FBQztjQUFDO2NBQUE7Z0JBQUEsT0FBQUwsVUFBQSxDQUFBOUksSUFBQTtZQUFBO1VBQUEsR0FBQTBJLFFBQUE7UUFBQSxDQUUzQjtRQUFBLGdCQXJCS1IsSUFBSUEsQ0FBQTtVQUFBLE9BQUFPLEtBQUEsQ0FBQXBJLEtBQUEsT0FBQUMsU0FBQTtRQUFBO01BQUEsR0FxQlQ7TUFDRDRJLFdBQUEsQ0FBV2hCLEtBQUksRUFBRUMsUUFBUSxDQUFDO0lBQzVCOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFoSyxHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBZ0wsUUFBUUEsQ0FBQSxFQUFHO01BQUEsSUFBQUMsTUFBQTtNQUNULE9BQU8sSUFBQW5FLFFBQUEsQ0FBZSxVQUFDQyxPQUFPLEVBQUVDLE1BQU0sRUFBSztRQUN6Q2lFLE1BQUksQ0FBQzlELEVBQUUsQ0FBQyxVQUFVLEVBQUVKLE9BQU8sQ0FBQztRQUM1QmtFLE1BQUksQ0FBQzlELEVBQUUsQ0FBQyxPQUFPLEVBQUVILE1BQU0sQ0FBQztRQUN4QmlFLE1BQUksQ0FBQ25CLElBQUksQ0FBQ21CLE1BQUksQ0FBQy9CLEtBQUssQ0FBQ2dDLFlBQVksRUFBRUQsTUFBSSxDQUFDL0IsS0FBSyxDQUFDaUMsV0FBVyxDQUFDO01BQzVELENBQUMsQ0FBQztJQUNKO0VBQUM7QUFBQSxFQTNFTy9NLFlBQVk7O0FBOEV0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQWFtRyxxQkFBcUIsMEJBQUE2RyxtQkFBQTtFQUFBLFNBQUE3RyxzQkFBQTtJQUFBM0UsZUFBQSxPQUFBMkUscUJBQUE7SUFBQSxPQUFBMEUsVUFBQSxPQUFBMUUscUJBQUEsRUFBQXJDLFNBQUE7RUFBQTtFQUFBa0gsU0FBQSxDQUFBN0UscUJBQUEsRUFBQTZHLG1CQUFBO0VBQUEsT0FBQXRMLFlBQUEsQ0FBQXlFLHFCQUFBO0lBQUF4RSxHQUFBO0lBQUFDLEtBQUE7SUFJaEM7QUFDRjtBQUNBO0FBQ0E7SUFIRTtNQUFBLElBQUFxTCxTQUFBLEdBQUFuTCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBSUEsU0FBQWtMLFVBQUE7UUFBQSxJQUFBQyxNQUFBO1FBQUEsSUFBQUMsV0FBQSxFQUFBNUcsRUFBQTtRQUFBLE9BQUF6RSxtQkFBQSxDQUFBUyxJQUFBLFVBQUE2SyxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTNLLElBQUEsR0FBQTJLLFVBQUEsQ0FBQTFLLElBQUE7WUFBQTtjQUFBLElBQ08sSUFBSSxDQUFDNEksR0FBRztnQkFBQThCLFVBQUEsQ0FBQTFLLElBQUE7Z0JBQUE7Y0FBQTtjQUFBMEssVUFBQSxDQUFBMUssSUFBQTtjQUFBLE9BQ2UsSUFBSSxDQUFDbUksUUFBUTtZQUFBO2NBQWpDcUMsV0FBVyxHQUFBRSxVQUFBLENBQUFoSyxJQUFBO2NBQ2pCLElBQUksQ0FBQ2tJLEdBQUcsR0FBRzRCLFdBQVcsQ0FBQzVHLEVBQUU7WUFBQztjQUV0QkEsRUFBRSxHQUFHLElBQUksQ0FBQ2dGLEdBQUc7Y0FBQSxPQUFBOEIsVUFBQSxDQUFBL0osTUFBQSxXQUVaLElBQUFtRixRQUFBLENBQTRCLFVBQUNDLE9BQU8sRUFBRUMsTUFBTSxFQUFLO2dCQUN0RCxJQUFNa0QsU0FBUyxHQUFHLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDO2dCQUN0QyxJQUFNdUIsV0FBVyxHQUFHekIsU0FBUyxHQUFHcUIsTUFBSSxDQUFDckMsS0FBSyxDQUFDaUMsV0FBVztnQkFFdEQsSUFBTXJCLE1BQUk7a0JBQUEsSUFBQThCLEtBQUEsR0FBQTFMLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FBRyxTQUFBeUwsU0FBQTtvQkFBQSxJQUFBdEIsR0FBQSxFQUFBdUIsR0FBQSxFQUFBdEssTUFBQTtvQkFBQSxPQUFBckIsbUJBQUEsQ0FBQVMsSUFBQSxVQUFBbUwsVUFBQUMsVUFBQTtzQkFBQSxrQkFBQUEsVUFBQSxDQUFBakwsSUFBQSxHQUFBaUwsVUFBQSxDQUFBaEwsSUFBQTt3QkFBQTswQkFBQWdMLFVBQUEsQ0FBQWpMLElBQUE7MEJBRUh3SixHQUFHLEdBQUcsSUFBSUosSUFBSSxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUM7MEJBQUEsTUFDNUJ1QixXQUFXLEdBQUdwQixHQUFHOzRCQUFBeUIsVUFBQSxDQUFBaEwsSUFBQTs0QkFBQTswQkFBQTswQkFDYjhLLEdBQUcsR0FBRyxJQUFJbEIsS0FBSyxDQUFDLHdEQUF3RCxDQUFDOzBCQUMvRVcsTUFBSSxDQUFDWixJQUFJLENBQUMsT0FBTyxFQUFFbUIsR0FBRyxDQUFDOzBCQUN2QjlFLE1BQU0sQ0FBQzhFLEdBQUcsQ0FBQzswQkFBQyxPQUFBRSxVQUFBLENBQUFySyxNQUFBO3dCQUFBOzBCQUFBcUssVUFBQSxDQUFBaEwsSUFBQTswQkFBQSxPQUdPdUssTUFBSSxDQUFDckMsS0FBSyxDQUFDMUUsbUJBQW1CLENBQUNJLEVBQUUsQ0FBQzt3QkFBQTswQkFBakRwRCxNQUFNLEdBQUF3SyxVQUFBLENBQUF0SyxJQUFBOzBCQUNaLElBQUlGLE1BQU0sQ0FBQ3FKLElBQUksRUFBRTs0QkFDZlUsTUFBSSxDQUFDWixJQUFJLENBQUMsVUFBVSxFQUFFbkosTUFBTSxDQUFDOzRCQUM3QnVGLE9BQU8sQ0FBQ3ZGLE1BQU0sQ0FBQzswQkFDakIsQ0FBQyxNQUFNOzRCQUNMK0osTUFBSSxDQUFDWixJQUFJLENBQUMsVUFBVSxFQUFFbkosTUFBTSxDQUFDOzRCQUM3QnNKLFdBQUEsQ0FBV2hCLE1BQUksRUFBRXlCLE1BQUksQ0FBQ3JDLEtBQUssQ0FBQ2dDLFlBQVksQ0FBQzswQkFDM0M7MEJBQUNjLFVBQUEsQ0FBQWhMLElBQUE7MEJBQUE7d0JBQUE7MEJBQUFnTCxVQUFBLENBQUFqTCxJQUFBOzBCQUFBaUwsVUFBQSxDQUFBakIsRUFBQSxHQUFBaUIsVUFBQTswQkFFRFQsTUFBSSxDQUFDWixJQUFJLENBQUMsT0FBTyxFQUFBcUIsVUFBQSxDQUFBakIsRUFBSyxDQUFDOzBCQUN2Qi9ELE1BQU0sQ0FBQWdGLFVBQUEsQ0FBQWpCLEVBQUksQ0FBQzt3QkFBQzt3QkFBQTswQkFBQSxPQUFBaUIsVUFBQSxDQUFBcEssSUFBQTtzQkFBQTtvQkFBQSxHQUFBaUssUUFBQTtrQkFBQSxDQUVmO2tCQUFBLGdCQXJCSy9CLElBQUlBLENBQUE7b0JBQUEsT0FBQThCLEtBQUEsQ0FBQTNKLEtBQUEsT0FBQUMsU0FBQTtrQkFBQTtnQkFBQSxHQXFCVDtnQkFFRDRJLFdBQUEsQ0FBV2hCLE1BQUksRUFBRXlCLE1BQUksQ0FBQ3JDLEtBQUssQ0FBQ2dDLFlBQVksQ0FBQztjQUMzQyxDQUFDLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQVEsVUFBQSxDQUFBOUosSUFBQTtVQUFBO1FBQUEsR0FBQTBKLFNBQUE7TUFBQSxDQUNIO01BQUEsU0FwQ0tOLFFBQVFBLENBQUE7UUFBQSxPQUFBSyxTQUFBLENBQUFwSixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVI4SSxRQUFRO0lBQUE7SUFzQ2Q7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBakwsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQWlNLE1BQU1BLENBQUEsRUFBRztNQUFBLElBQUFDLE1BQUE7TUFDUCxJQUFNQyxZQUFZLEdBQUcsSUFBSTlOLFFBQVEsQ0FBQyxDQUFDO01BQ25DLElBQUkrTixPQUFPLEdBQUcsS0FBSztNQUNuQkQsWUFBWSxDQUFDN0osS0FBSyxnQkFBQXBDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FBRyxTQUFBaU0sVUFBQTtRQUFBLElBQUE3SyxNQUFBO1FBQUEsT0FBQXJCLG1CQUFBLENBQUFTLElBQUEsVUFBQTBMLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBeEwsSUFBQSxHQUFBd0wsVUFBQSxDQUFBdkwsSUFBQTtZQUFBO2NBQUEsS0FDZm9MLE9BQU87Z0JBQUFHLFVBQUEsQ0FBQXZMLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE9BQUF1TCxVQUFBLENBQUE1SyxNQUFBO1lBQUE7Y0FHWHlLLE9BQU8sR0FBRyxJQUFJO2NBQUNHLFVBQUEsQ0FBQXhMLElBQUE7Y0FBQXdMLFVBQUEsQ0FBQXZMLElBQUE7Y0FBQSxPQUVRa0wsTUFBSSxDQUFDbEIsUUFBUSxDQUFDLENBQUM7WUFBQTtjQUE5QnhKLE1BQU0sR0FBQStLLFVBQUEsQ0FBQTdLLElBQUE7Y0FDWnlLLFlBQVksQ0FBQzlFLElBQUksQ0FBQ0MsTUFBTSxDQUFDa0YsSUFBSSxDQUFDaEwsTUFBTSxDQUFDaUwsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDO2NBQ3hETixZQUFZLENBQUM5RSxJQUFJLENBQUMsSUFBSSxDQUFDO2NBQUNrRixVQUFBLENBQUF2TCxJQUFBO2NBQUE7WUFBQTtjQUFBdUwsVUFBQSxDQUFBeEwsSUFBQTtjQUFBd0wsVUFBQSxDQUFBeEIsRUFBQSxHQUFBd0IsVUFBQTtjQUV4QkosWUFBWSxDQUFDeEIsSUFBSSxDQUFDLE9BQU8sRUFBQTRCLFVBQUEsQ0FBQXhCLEVBQUcsQ0FBQztZQUFDO1lBQUE7Y0FBQSxPQUFBd0IsVUFBQSxDQUFBM0ssSUFBQTtVQUFBO1FBQUEsR0FBQXlLLFNBQUE7TUFBQSxDQUVqQztNQUNELE9BQU9GLFlBQVk7SUFDckI7RUFBQztBQUFBLEVBbEUwRGhJLGtCQUFrQjs7QUFxRS9FO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBYW9DLG1CQUFtQiwwQkFBQW1HLG9CQUFBO0VBQUEsU0FBQW5HLG9CQUFBO0lBQUEzRyxlQUFBLE9BQUEyRyxtQkFBQTtJQUFBLE9BQUEwQyxVQUFBLE9BQUExQyxtQkFBQSxFQUFBckUsU0FBQTtFQUFBO0VBQUFrSCxTQUFBLENBQUE3QyxtQkFBQSxFQUFBbUcsb0JBQUE7RUFBQSxPQUFBNU0sWUFBQSxDQUFBeUcsbUJBQUE7SUFBQXhHLEdBQUE7SUFBQUMsS0FBQTtJQUk5QjtBQUNGO0FBQ0E7QUFDQTtJQUhFO01BQUEsSUFBQTJNLFVBQUEsR0FBQXpNLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FJQSxTQUFBd00sVUFBZTlFLGNBQXdCO1FBQUEsSUFBQStFLE1BQUE7UUFBQSxJQUFBckIsV0FBQSxFQUFBNUcsRUFBQTtRQUFBLE9BQUF6RSxtQkFBQSxDQUFBUyxJQUFBLFVBQUFrTSxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQWhNLElBQUEsR0FBQWdNLFVBQUEsQ0FBQS9MLElBQUE7WUFBQTtjQUFBLElBQ2hDLElBQUksQ0FBQzRJLEdBQUc7Z0JBQUFtRCxVQUFBLENBQUEvTCxJQUFBO2dCQUFBO2NBQUE7Y0FBQStMLFVBQUEsQ0FBQS9MLElBQUE7Y0FBQSxPQUNlLElBQUksQ0FBQ21JLFFBQVE7WUFBQTtjQUFqQ3FDLFdBQVcsR0FBQXVCLFVBQUEsQ0FBQXJMLElBQUE7Y0FDakIsSUFBSSxDQUFDa0ksR0FBRyxHQUFHNEIsV0FBVyxDQUFDNUcsRUFBRTtZQUFDO2NBRXRCQSxFQUFFLEdBQUcsSUFBSSxDQUFDZ0YsR0FBRztjQUFBLE9BQUFtRCxVQUFBLENBQUFwTCxNQUFBLFdBRVosSUFBQW1GLFFBQUEsQ0FBMEIsVUFBQ0MsT0FBTyxFQUFFQyxNQUFNLEVBQUs7Z0JBQ3BELElBQU1rRCxTQUFTLEdBQUcsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUM7Z0JBQ3RDLElBQU11QixXQUFXLEdBQUd6QixTQUFTLEdBQUcyQyxNQUFJLENBQUMzRCxLQUFLLENBQUNpQyxXQUFXO2dCQUV0RCxJQUFNckIsTUFBSTtrQkFBQSxJQUFBa0QsS0FBQSxHQUFBOU0saUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUFHLFNBQUE2TSxVQUFBO29CQUFBLElBQUExQyxHQUFBLEVBQUF1QixHQUFBLEVBQUF0SyxNQUFBO29CQUFBLE9BQUFyQixtQkFBQSxDQUFBUyxJQUFBLFVBQUFzTSxXQUFBQyxVQUFBO3NCQUFBLGtCQUFBQSxVQUFBLENBQUFwTSxJQUFBLEdBQUFvTSxVQUFBLENBQUFuTSxJQUFBO3dCQUFBOzBCQUFBbU0sVUFBQSxDQUFBcE0sSUFBQTswQkFFSHdKLEdBQUcsR0FBRyxJQUFJSixJQUFJLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQzswQkFBQSxNQUM1QnVCLFdBQVcsR0FBR3BCLEdBQUc7NEJBQUE0QyxVQUFBLENBQUFuTSxJQUFBOzRCQUFBOzBCQUFBOzBCQUNiOEssR0FBRyxHQUFHLElBQUlsQixLQUFLLENBQUMsc0RBQXNELENBQUM7MEJBQzdFaUMsTUFBSSxDQUFDbEMsSUFBSSxDQUFDLE9BQU8sRUFBRW1CLEdBQUcsQ0FBQzswQkFDdkI5RSxNQUFNLENBQUM4RSxHQUFHLENBQUM7MEJBQUMsT0FBQXFCLFVBQUEsQ0FBQXhMLE1BQUE7d0JBQUE7MEJBQUF3TCxVQUFBLENBQUFuTSxJQUFBOzBCQUFBLE9BR082TCxNQUFJLENBQUMzRCxLQUFLLENBQUNiLGlCQUFpQixDQUFDekQsRUFBRSxFQUFFa0QsY0FBYyxDQUFDO3dCQUFBOzBCQUEvRHRHLE1BQU0sR0FBQTJMLFVBQUEsQ0FBQXpMLElBQUE7MEJBQ1osSUFBSUYsTUFBTSxDQUFDcUosSUFBSSxFQUFFOzRCQUNmZ0MsTUFBSSxDQUFDbEMsSUFBSSxDQUFDLFVBQVUsRUFBRW5KLE1BQU0sQ0FBQzs0QkFDN0J1RixPQUFPLENBQUN2RixNQUFNLENBQUM7MEJBQ2pCLENBQUMsTUFBTTs0QkFDTHFMLE1BQUksQ0FBQ2xDLElBQUksQ0FBQyxVQUFVLEVBQUVuSixNQUFNLENBQUM7NEJBQzdCc0osV0FBQSxDQUFXaEIsTUFBSSxFQUFFK0MsTUFBSSxDQUFDM0QsS0FBSyxDQUFDZ0MsWUFBWSxDQUFDOzBCQUMzQzswQkFBQ2lDLFVBQUEsQ0FBQW5NLElBQUE7MEJBQUE7d0JBQUE7MEJBQUFtTSxVQUFBLENBQUFwTSxJQUFBOzBCQUFBb00sVUFBQSxDQUFBcEMsRUFBQSxHQUFBb0MsVUFBQTswQkFFRE4sTUFBSSxDQUFDbEMsSUFBSSxDQUFDLE9BQU8sRUFBQXdDLFVBQUEsQ0FBQXBDLEVBQUssQ0FBQzswQkFDdkIvRCxNQUFNLENBQUFtRyxVQUFBLENBQUFwQyxFQUFJLENBQUM7d0JBQUM7d0JBQUE7MEJBQUEsT0FBQW9DLFVBQUEsQ0FBQXZMLElBQUE7c0JBQUE7b0JBQUEsR0FBQXFMLFNBQUE7a0JBQUEsQ0FFZjtrQkFBQSxnQkFyQktuRCxJQUFJQSxDQUFBO29CQUFBLE9BQUFrRCxLQUFBLENBQUEvSyxLQUFBLE9BQUFDLFNBQUE7a0JBQUE7Z0JBQUEsR0FxQlQ7Z0JBRUQ0SSxXQUFBLENBQVdoQixNQUFJLEVBQUUrQyxNQUFJLENBQUMzRCxLQUFLLENBQUNnQyxZQUFZLENBQUM7Y0FDM0MsQ0FBQyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUE2QixVQUFBLENBQUFuTCxJQUFBO1VBQUE7UUFBQSxHQUFBZ0wsU0FBQTtNQUFBLENBQ0g7TUFBQSxTQXBDSzVCLFFBQVFBLENBQUFvQyxHQUFBO1FBQUEsT0FBQVQsVUFBQSxDQUFBMUssS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFSOEksUUFBUTtJQUFBO0VBQUE7QUFBQSxFQVIyQzdHLGtCQUFrQjs7QUErQzdFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E1RixjQUFjLENBQUMsVUFBVSxFQUFFLFVBQUNvQixJQUFJO0VBQUEsT0FBSyxJQUFJRCxXQUFXLENBQUNDLElBQUksQ0FBQztBQUFBLEVBQUM7QUFFM0QsZUFBZUQsV0FBVyIsImlnbm9yZUxpc3QiOltdfQ==