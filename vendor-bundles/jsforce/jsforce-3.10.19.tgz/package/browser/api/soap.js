import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
var _excluded = ["type", "attributes"];
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context12, _context13; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context12 = ownKeys(Object(t), !0)).call(_context12, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context13 = ownKeys(Object(t))).call(_context13, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof _Symbol && _getIteratorMethod(r) || r["@@iterator"]; if (!t) { if (_Array$isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { var _context11; if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = _sliceInstanceProperty(_context11 = {}.toString.call(r)).call(_context11, 8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? _Array$from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/es.regexp.to-string.js";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
/**
 * @file Salesforce SOAP API
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { registerModule } from '../jsforce';
import SOAP from '../soap';
import { ApiSchemas } from './soap/schema';

/**
 *
 */
function toSoapRecord(records) {
  var _context;
  return _mapInstanceProperty(_context = _Array$isArray(records) ? records : [records]).call(_context, function (record) {
    var _context2;
    var type = record.type,
      attributes = record.attributes,
      rec = _objectWithoutProperties(record, _excluded);
    var t = type || (attributes === null || attributes === void 0 ? void 0 : attributes.type);
    if (!t) {
      throw new Error('Given record is not including sObject type information');
    }
    var fieldsToNull = _filterInstanceProperty(_context2 = _Object$keys(rec)).call(_context2, function (field) {
      return record[field] === null;
    });
    var _iterator = _createForOfIteratorHelper(fieldsToNull),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var field = _step.value;
        delete rec[field];
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    return fieldsToNull.length > 0 ? _objectSpread({
      type: t,
      fieldsToNull: fieldsToNull
    }, rec) : _objectSpread({
      type: t
    }, rec);
  });
}

/**
 * API class for Partner SOAP call
 */
export var SoapApi = /*#__PURE__*/function () {
  function SoapApi(conn) {
    _classCallCheck(this, SoapApi);
    this._conn = conn;
  }

  /**
   * Call SOAP Api (Partner) endpoint
   * @private
   */
  return _createClass(SoapApi, [{
    key: "_invoke",
    value: (function () {
      var _invoke2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(method, message, schema, options) {
        var _context3;
        var soapEndpoint, res;
        return _regeneratorRuntime.wrap(function _callee$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              soapEndpoint = new SOAP(this._conn, {
                xmlns: (options === null || options === void 0 ? void 0 : options.xmlns) || 'urn:partner.soap.sforce.com',
                endpointUrl: (options === null || options === void 0 ? void 0 : options.endpointUrl) || _concatInstanceProperty(_context3 = "".concat(this._conn.instanceUrl, "/services/Soap/u/")).call(_context3, this._conn.version),
                headers: options === null || options === void 0 ? void 0 : options.headers
              });
              _context4.next = 3;
              return soapEndpoint.invoke(method, message, schema ? {
                result: schema
              } : undefined, ApiSchemas);
            case 3:
              res = _context4.sent;
              return _context4.abrupt("return", res.result);
            case 5:
            case "end":
              return _context4.stop();
          }
        }, _callee, this);
      }));
      function _invoke(_x, _x2, _x3, _x4) {
        return _invoke2.apply(this, arguments);
      }
      return _invoke;
    }()
    /**
     * Converts a Lead into an Account, Contact, or (optionally) an Opportunity.
     */
    )
  }, {
    key: "convertLead",
    value: function () {
      var _convertLead = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(leadConverts) {
        var schema;
        return _regeneratorRuntime.wrap(function _callee2$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              schema = _Array$isArray(leadConverts) ? [ApiSchemas.LeadConvertResult] : ApiSchemas.LeadConvertResult;
              return _context5.abrupt("return", this._invoke('convertLead', {
                leadConverts: leadConverts
              }, schema));
            case 2:
            case "end":
              return _context5.stop();
          }
        }, _callee2, this);
      }));
      function convertLead(_x5) {
        return _convertLead.apply(this, arguments);
      }
      return convertLead;
    }()
    /**
     * Merge up to three records into one
     */
  }, {
    key: "merge",
    value: function () {
      var _merge = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3(mergeRequests) {
        var schema;
        return _regeneratorRuntime.wrap(function _callee3$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              schema = _Array$isArray(mergeRequests) ? [ApiSchemas.MergeResult] : ApiSchemas.MergeResult;
              return _context6.abrupt("return", this._invoke('merge', {
                mergeRequests: mergeRequests
              }, schema));
            case 2:
            case "end":
              return _context6.stop();
          }
        }, _callee3, this);
      }));
      function merge(_x6) {
        return _merge.apply(this, arguments);
      }
      return merge;
    }()
    /**
     * Delete records from the recycle bin immediately
     */
  }, {
    key: "emptyRecycleBin",
    value: (function () {
      var _emptyRecycleBin = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4(ids) {
        return _regeneratorRuntime.wrap(function _callee4$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              return _context7.abrupt("return", this._invoke('emptyRecycleBin', {
                ids: ids
              }, [ApiSchemas.EmptyRecycleBinResult]));
            case 1:
            case "end":
              return _context7.stop();
          }
        }, _callee4, this);
      }));
      function emptyRecycleBin(_x7) {
        return _emptyRecycleBin.apply(this, arguments);
      }
      return emptyRecycleBin;
    }()
    /**
     * Returns information about the standard and custom apps available to the logged-in user
     */
    )
  }, {
    key: "describeTabs",
    value: (function () {
      var _describeTabs = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee5() {
        return _regeneratorRuntime.wrap(function _callee5$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              return _context8.abrupt("return", this._invoke('describeTabs', {}, [ApiSchemas.DescribeTabSetResult]));
            case 1:
            case "end":
              return _context8.stop();
          }
        }, _callee5, this);
      }));
      function describeTabs() {
        return _describeTabs.apply(this, arguments);
      }
      return describeTabs;
    }()
    /**
     * Retrieves the current system timestamp (Coordinated Universal Time (UTC) time zone) from the API
     */
    )
  }, {
    key: "getServerTimestamp",
    value: (function () {
      var _getServerTimestamp = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee6() {
        return _regeneratorRuntime.wrap(function _callee6$(_context9) {
          while (1) switch (_context9.prev = _context9.next) {
            case 0:
              return _context9.abrupt("return", this._invoke('getServerTimestamp', {}, ApiSchemas.GetServerTimestampResult));
            case 1:
            case "end":
              return _context9.stop();
          }
        }, _callee6, this);
      }));
      function getServerTimestamp() {
        return _getServerTimestamp.apply(this, arguments);
      }
      return getServerTimestamp;
    }()
    /**
     * Retrieves personal information for the user associated with the current session
     */
    )
  }, {
    key: "getUserInfo",
    value: (function () {
      var _getUserInfo = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee7() {
        return _regeneratorRuntime.wrap(function _callee7$(_context10) {
          while (1) switch (_context10.prev = _context10.next) {
            case 0:
              return _context10.abrupt("return", this._invoke('getUserInfo', {}, ApiSchemas.GetUserInfoResult));
            case 1:
            case "end":
              return _context10.stop();
          }
        }, _callee7, this);
      }));
      function getUserInfo() {
        return _getUserInfo.apply(this, arguments);
      }
      return getUserInfo;
    }()
    /**
     * Sets the specified user’s password to the specified value
     */
    )
  }, {
    key: "setPassword",
    value: function setPassword(userId, password) {
      return this._invoke('setPassword', {
        userId: userId,
        password: password
      }, 'string');
    }

    /**
     * Resets the specified user’s password
     */
  }, {
    key: "resetPassword",
    value: function resetPassword(userId) {
      return this._invoke('resetPassword', {
        userId: userId
      }, ApiSchemas.ResetPasswordResult);
    }

    /**
     * Adds one or more new records to your organization’s data
     */
  }, {
    key: "create",
    value: function create(sObjects) {
      var schema = _Array$isArray(sObjects) ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
      var args = {
        '@xmlns': 'urn:partner.soap.sforce.com',
        '@xmlns:ns1': 'sobject.partner.soap.sforce.com',
        'ns1:sObjects': toSoapRecord(sObjects)
      };
      return this._invoke('create', args, schema);
    }

    /**
     * Updates one or more existing records in your organization’s data.
     */
  }, {
    key: "update",
    value: function update(sObjects) {
      var schema = _Array$isArray(sObjects) ? [ApiSchemas.SaveResult] : ApiSchemas.SaveResult;
      var args = {
        '@xmlns': 'urn:partner.soap.sforce.com',
        '@xmlns:ns1': 'sobject.partner.soap.sforce.com',
        'ns1:sObjects': toSoapRecord(sObjects)
      };
      return this._invoke('update', args, schema);
    }

    /**
     * Creates new records and updates existing records in your organization’s data.
     */
  }, {
    key: "upsert",
    value: function upsert(externalIdFieldName, sObjects) {
      var schema = _Array$isArray(sObjects) ? [ApiSchemas.UpsertResult] : ApiSchemas.UpsertResult;
      var args = {
        '@xmlns': 'urn:partner.soap.sforce.com',
        '@xmlns:ns1': 'sobject.partner.soap.sforce.com',
        'ns1:externalIDFieldName': externalIdFieldName,
        'ns1:sObjects': toSoapRecord(sObjects)
      };
      return this._invoke('upsert', args, schema);
    }

    /**
     * Deletes one or more records from your organization’s data
     */
  }, {
    key: "delete",
    value: function _delete(ids) {
      var schema = _Array$isArray(ids) ? [ApiSchemas.DeleteResult] : ApiSchemas.DeleteResult;
      var args = {
        '@xmlns': 'urn:partner.soap.sforce.com',
        '@xmlns:ns1': 'sobject.partner.soap.sforce.com',
        'ns1:ids': ids
      };
      return this._invoke('delete', args, schema);
    }

    /**
     * Undelete records from the recycle bin immediately
     */
  }, {
    key: "undelete",
    value: function undelete(ids) {
      var schema = [ApiSchemas.UndeleteResult];
      var args = {
        '@xmlns': 'urn:partner.soap.sforce.com',
        '@xmlns:ns1': 'sobject.partner.soap.sforce.com',
        'ns1:ids': ids
      };
      return this._invoke('undelete', args, schema);
    }
  }]);
}();

/*--------------------------------------------*/
/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */
registerModule('soap', function (conn) {
  return new SoapApi(conn);
});
export default SoapApi;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZWdpc3Rlck1vZHVsZSIsIlNPQVAiLCJBcGlTY2hlbWFzIiwidG9Tb2FwUmVjb3JkIiwicmVjb3JkcyIsIl9jb250ZXh0IiwiX21hcEluc3RhbmNlUHJvcGVydHkiLCJfQXJyYXkkaXNBcnJheSIsImNhbGwiLCJyZWNvcmQiLCJfY29udGV4dDIiLCJ0eXBlIiwiYXR0cmlidXRlcyIsInJlYyIsIl9vYmplY3RXaXRob3V0UHJvcGVydGllcyIsIl9leGNsdWRlZCIsInQiLCJFcnJvciIsImZpZWxkc1RvTnVsbCIsIl9maWx0ZXJJbnN0YW5jZVByb3BlcnR5IiwiX09iamVjdCRrZXlzIiwiZmllbGQiLCJfaXRlcmF0b3IiLCJfY3JlYXRlRm9yT2ZJdGVyYXRvckhlbHBlciIsIl9zdGVwIiwicyIsIm4iLCJkb25lIiwidmFsdWUiLCJlcnIiLCJlIiwiZiIsImxlbmd0aCIsIl9vYmplY3RTcHJlYWQiLCJTb2FwQXBpIiwiY29ubiIsIl9jbGFzc0NhbGxDaGVjayIsIl9jb25uIiwiX2NyZWF0ZUNsYXNzIiwia2V5IiwiX2ludm9rZTIiLCJfYXN5bmNUb0dlbmVyYXRvciIsIl9yZWdlbmVyYXRvclJ1bnRpbWUiLCJtYXJrIiwiX2NhbGxlZSIsIm1ldGhvZCIsIm1lc3NhZ2UiLCJzY2hlbWEiLCJvcHRpb25zIiwiX2NvbnRleHQzIiwic29hcEVuZHBvaW50IiwicmVzIiwid3JhcCIsIl9jYWxsZWUkIiwiX2NvbnRleHQ0IiwicHJldiIsIm5leHQiLCJ4bWxucyIsImVuZHBvaW50VXJsIiwiX2NvbmNhdEluc3RhbmNlUHJvcGVydHkiLCJjb25jYXQiLCJpbnN0YW5jZVVybCIsInZlcnNpb24iLCJoZWFkZXJzIiwiaW52b2tlIiwicmVzdWx0IiwidW5kZWZpbmVkIiwic2VudCIsImFicnVwdCIsInN0b3AiLCJfaW52b2tlIiwiX3giLCJfeDIiLCJfeDMiLCJfeDQiLCJhcHBseSIsImFyZ3VtZW50cyIsIl9jb252ZXJ0TGVhZCIsIl9jYWxsZWUyIiwibGVhZENvbnZlcnRzIiwiX2NhbGxlZTIkIiwiX2NvbnRleHQ1IiwiTGVhZENvbnZlcnRSZXN1bHQiLCJjb252ZXJ0TGVhZCIsIl94NSIsIl9tZXJnZSIsIl9jYWxsZWUzIiwibWVyZ2VSZXF1ZXN0cyIsIl9jYWxsZWUzJCIsIl9jb250ZXh0NiIsIk1lcmdlUmVzdWx0IiwibWVyZ2UiLCJfeDYiLCJfZW1wdHlSZWN5Y2xlQmluIiwiX2NhbGxlZTQiLCJpZHMiLCJfY2FsbGVlNCQiLCJfY29udGV4dDciLCJFbXB0eVJlY3ljbGVCaW5SZXN1bHQiLCJlbXB0eVJlY3ljbGVCaW4iLCJfeDciLCJfZGVzY3JpYmVUYWJzIiwiX2NhbGxlZTUiLCJfY2FsbGVlNSQiLCJfY29udGV4dDgiLCJEZXNjcmliZVRhYlNldFJlc3VsdCIsImRlc2NyaWJlVGFicyIsIl9nZXRTZXJ2ZXJUaW1lc3RhbXAiLCJfY2FsbGVlNiIsIl9jYWxsZWU2JCIsIl9jb250ZXh0OSIsIkdldFNlcnZlclRpbWVzdGFtcFJlc3VsdCIsImdldFNlcnZlclRpbWVzdGFtcCIsIl9nZXRVc2VySW5mbyIsIl9jYWxsZWU3IiwiX2NhbGxlZTckIiwiX2NvbnRleHQxMCIsIkdldFVzZXJJbmZvUmVzdWx0IiwiZ2V0VXNlckluZm8iLCJzZXRQYXNzd29yZCIsInVzZXJJZCIsInBhc3N3b3JkIiwicmVzZXRQYXNzd29yZCIsIlJlc2V0UGFzc3dvcmRSZXN1bHQiLCJjcmVhdGUiLCJzT2JqZWN0cyIsIlNhdmVSZXN1bHQiLCJhcmdzIiwidXBkYXRlIiwidXBzZXJ0IiwiZXh0ZXJuYWxJZEZpZWxkTmFtZSIsIlVwc2VydFJlc3VsdCIsImRlbGV0ZSIsIkRlbGV0ZVJlc3VsdCIsInVuZGVsZXRlIiwiVW5kZWxldGVSZXN1bHQiXSwic291cmNlcyI6WyIuLi8uLi9zcmMvYXBpL3NvYXAudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBTYWxlc2ZvcmNlIFNPQVAgQVBJXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgcmVnaXN0ZXJNb2R1bGUgfSBmcm9tICcuLi9qc2ZvcmNlJztcbmltcG9ydCBDb25uZWN0aW9uIGZyb20gJy4uL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IFNPQVAgZnJvbSAnLi4vc29hcCc7XG5pbXBvcnQgeyBTY2hlbWEsIFJlY29yZCwgU29hcFNjaGVtYURlZiwgU29hcFNjaGVtYSB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7XG4gIEFwaVNjaGVtYXMsXG4gIExlYWRDb252ZXJ0LFxuICBMZWFkQ29udmVydFJlc3VsdCxcbiAgTWVyZ2VSZXF1ZXN0LFxuICBNZXJnZVJlc3VsdCxcbiAgRW1wdHlSZWN5Y2xlQmluUmVzdWx0LFxuICBVbmRlbGV0ZVJlc3VsdCxcbiAgRGVzY3JpYmVUYWJTZXRSZXN1bHQsXG4gIEdldFNlcnZlclRpbWVzdGFtcFJlc3VsdCxcbiAgR2V0VXNlckluZm9SZXN1bHQsXG4gIFJlc2V0UGFzc3dvcmRSZXN1bHQsXG4gIFNhdmVSZXN1bHQsXG4gIFVwc2VydFJlc3VsdCxcbiAgRGVsZXRlUmVzdWx0LFxufSBmcm9tICcuL3NvYXAvc2NoZW1hJztcblxuLyoqXG4gKlxuICovXG5mdW5jdGlvbiB0b1NvYXBSZWNvcmQocmVjb3JkczogUmVjb3JkIHwgUmVjb3JkW10pOiBSZWNvcmQgfCBSZWNvcmRbXSB7XG4gIHJldHVybiAoQXJyYXkuaXNBcnJheShyZWNvcmRzKSA/IHJlY29yZHMgOiBbcmVjb3Jkc10pLm1hcCgocmVjb3JkKSA9PiB7XG4gICAgY29uc3QgeyB0eXBlLCBhdHRyaWJ1dGVzLCAuLi5yZWMgfSA9IHJlY29yZDtcbiAgICBjb25zdCB0ID0gdHlwZSB8fCBhdHRyaWJ1dGVzPy50eXBlO1xuICAgIGlmICghdCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdHaXZlbiByZWNvcmQgaXMgbm90IGluY2x1ZGluZyBzT2JqZWN0IHR5cGUgaW5mb3JtYXRpb24nKTtcbiAgICB9XG4gICAgY29uc3QgZmllbGRzVG9OdWxsID0gT2JqZWN0LmtleXMocmVjKS5maWx0ZXIoXG4gICAgICAoZmllbGQpID0+IHJlY29yZFtmaWVsZF0gPT09IG51bGwsXG4gICAgKTtcbiAgICBmb3IgKGNvbnN0IGZpZWxkIG9mIGZpZWxkc1RvTnVsbCkge1xuICAgICAgZGVsZXRlIHJlY1tmaWVsZF07XG4gICAgfVxuICAgIHJldHVybiBmaWVsZHNUb051bGwubGVuZ3RoID4gMFxuICAgICAgPyB7IHR5cGU6IHQsIGZpZWxkc1RvTnVsbCwgLi4ucmVjIH1cbiAgICAgIDogeyB0eXBlOiB0LCAuLi5yZWMgfTtcbiAgfSk7XG59XG5cbi8qKlxuICogQVBJIGNsYXNzIGZvciBQYXJ0bmVyIFNPQVAgY2FsbFxuICovXG5leHBvcnQgY2xhc3MgU29hcEFwaTxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuXG4gIGNvbnN0cnVjdG9yKGNvbm46IENvbm5lY3Rpb248Uz4pIHtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsIFNPQVAgQXBpIChQYXJ0bmVyKSBlbmRwb2ludFxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgYXN5bmMgX2ludm9rZShcbiAgICBtZXRob2Q6IHN0cmluZyxcbiAgICBtZXNzYWdlOiBvYmplY3QsXG4gICAgc2NoZW1hOiBTb2FwU2NoZW1hIHwgU29hcFNjaGVtYURlZixcbiAgICBvcHRpb25zPzoge1xuICAgICAgaGVhZGVycz86IG9iamVjdDtcbiAgICAgIHhtbG5zPzogc3RyaW5nO1xuICAgICAgZW5kcG9pbnRVcmw/OiBzdHJpbmc7XG4gICAgfSxcbiAgKSB7XG4gICAgY29uc3Qgc29hcEVuZHBvaW50ID0gbmV3IFNPQVAodGhpcy5fY29ubiwge1xuICAgICAgeG1sbnM6IG9wdGlvbnM/LnhtbG5zIHx8ICd1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb20nLFxuICAgICAgZW5kcG9pbnRVcmw6IG9wdGlvbnM/LmVuZHBvaW50VXJsIHx8IGAke3RoaXMuX2Nvbm4uaW5zdGFuY2VVcmx9L3NlcnZpY2VzL1NvYXAvdS8ke3RoaXMuX2Nvbm4udmVyc2lvbn1gLFxuICAgICAgaGVhZGVyczogb3B0aW9ucz8uaGVhZGVyc1xuICAgIH0pO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHNvYXBFbmRwb2ludC5pbnZva2UoXG4gICAgICBtZXRob2QsXG4gICAgICBtZXNzYWdlLFxuICAgICAgc2NoZW1hID8gKHsgcmVzdWx0OiBzY2hlbWEgfSBhcyBTb2FwU2NoZW1hKSA6IHVuZGVmaW5lZCxcbiAgICAgIEFwaVNjaGVtYXMsXG4gICAgKTtcbiAgICByZXR1cm4gcmVzLnJlc3VsdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb252ZXJ0cyBhIExlYWQgaW50byBhbiBBY2NvdW50LCBDb250YWN0LCBvciAob3B0aW9uYWxseSkgYW4gT3Bwb3J0dW5pdHkuXG4gICAqL1xuICBjb252ZXJ0TGVhZChcbiAgICBsZWFkQ29udmVydHM6IEFycmF5PFBhcnRpYWw8TGVhZENvbnZlcnQ+PixcbiAgKTogUHJvbWlzZTxMZWFkQ29udmVydFJlc3VsdFtdPjtcbiAgY29udmVydExlYWQobGVhZENvbnZlcnQ6IFBhcnRpYWw8TGVhZENvbnZlcnQ+KTogUHJvbWlzZTxMZWFkQ29udmVydFJlc3VsdD47XG4gIGNvbnZlcnRMZWFkKFxuICAgIGxlYWRDb252ZXJ0OiBQYXJ0aWFsPExlYWRDb252ZXJ0PiB8IEFycmF5PFBhcnRpYWw8TGVhZENvbnZlcnQ+PixcbiAgKTogUHJvbWlzZTxMZWFkQ29udmVydFJlc3VsdCB8IExlYWRDb252ZXJ0UmVzdWx0W10+O1xuICBhc3luYyBjb252ZXJ0TGVhZChcbiAgICBsZWFkQ29udmVydHM6IFBhcnRpYWw8TGVhZENvbnZlcnQ+IHwgQXJyYXk8UGFydGlhbDxMZWFkQ29udmVydD4+LFxuICApIHtcbiAgICBjb25zdCBzY2hlbWEgPSBBcnJheS5pc0FycmF5KGxlYWRDb252ZXJ0cylcbiAgICAgID8gW0FwaVNjaGVtYXMuTGVhZENvbnZlcnRSZXN1bHRdXG4gICAgICA6IEFwaVNjaGVtYXMuTGVhZENvbnZlcnRSZXN1bHQ7XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZSgnY29udmVydExlYWQnLCB7IGxlYWRDb252ZXJ0cyB9LCBzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIE1lcmdlIHVwIHRvIHRocmVlIHJlY29yZHMgaW50byBvbmVcbiAgICovXG4gIG1lcmdlKG1lcmdlUmVxdWVzdHM6IEFycmF5PFBhcnRpYWw8TWVyZ2VSZXF1ZXN0Pj4pOiBQcm9taXNlPE1lcmdlUmVzdWx0W10+O1xuICBtZXJnZShtZXJnZVJlcXVlc3Q6IFBhcnRpYWw8TWVyZ2VSZXF1ZXN0Pik6IFByb21pc2U8TWVyZ2VSZXN1bHQ+O1xuICBtZXJnZShcbiAgICBtZXJnZVJlcXVlc3Q6IFBhcnRpYWw8TWVyZ2VSZXF1ZXN0PiB8IEFycmF5PFBhcnRpYWw8TWVyZ2VSZXF1ZXN0Pj4sXG4gICk6IFByb21pc2U8TWVyZ2VSZXN1bHQgfCBNZXJnZVJlc3VsdFtdPjtcbiAgYXN5bmMgbWVyZ2UoXG4gICAgbWVyZ2VSZXF1ZXN0czogUGFydGlhbDxNZXJnZVJlcXVlc3Q+IHwgQXJyYXk8UGFydGlhbDxNZXJnZVJlcXVlc3Q+PixcbiAgKSB7XG4gICAgY29uc3Qgc2NoZW1hID0gQXJyYXkuaXNBcnJheShtZXJnZVJlcXVlc3RzKVxuICAgICAgPyBbQXBpU2NoZW1hcy5NZXJnZVJlc3VsdF1cbiAgICAgIDogQXBpU2NoZW1hcy5NZXJnZVJlc3VsdDtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdtZXJnZScsIHsgbWVyZ2VSZXF1ZXN0cyB9LCBzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZSByZWNvcmRzIGZyb20gdGhlIHJlY3ljbGUgYmluIGltbWVkaWF0ZWx5XG4gICAqL1xuICBhc3luYyBlbXB0eVJlY3ljbGVCaW4oaWRzOiBzdHJpbmdbXSk6IFByb21pc2U8RW1wdHlSZWN5Y2xlQmluUmVzdWx0PiB7XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZSgnZW1wdHlSZWN5Y2xlQmluJywgeyBpZHMgfSwgW1xuICAgICAgQXBpU2NoZW1hcy5FbXB0eVJlY3ljbGVCaW5SZXN1bHQsXG4gICAgXSk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBpbmZvcm1hdGlvbiBhYm91dCB0aGUgc3RhbmRhcmQgYW5kIGN1c3RvbSBhcHBzIGF2YWlsYWJsZSB0byB0aGUgbG9nZ2VkLWluIHVzZXJcbiAgICovXG4gIGFzeW5jIGRlc2NyaWJlVGFicygpOiBQcm9taXNlPERlc2NyaWJlVGFiU2V0UmVzdWx0W10+IHtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdkZXNjcmliZVRhYnMnLCB7fSwgW0FwaVNjaGVtYXMuRGVzY3JpYmVUYWJTZXRSZXN1bHRdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgdGhlIGN1cnJlbnQgc3lzdGVtIHRpbWVzdGFtcCAoQ29vcmRpbmF0ZWQgVW5pdmVyc2FsIFRpbWUgKFVUQykgdGltZSB6b25lKSBmcm9tIHRoZSBBUElcbiAgICovXG4gIGFzeW5jIGdldFNlcnZlclRpbWVzdGFtcCgpOiBQcm9taXNlPEdldFNlcnZlclRpbWVzdGFtcFJlc3VsdD4ge1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoXG4gICAgICAnZ2V0U2VydmVyVGltZXN0YW1wJyxcbiAgICAgIHt9LFxuICAgICAgQXBpU2NoZW1hcy5HZXRTZXJ2ZXJUaW1lc3RhbXBSZXN1bHQsXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgcGVyc29uYWwgaW5mb3JtYXRpb24gZm9yIHRoZSB1c2VyIGFzc29jaWF0ZWQgd2l0aCB0aGUgY3VycmVudCBzZXNzaW9uXG4gICAqL1xuICBhc3luYyBnZXRVc2VySW5mbygpOiBQcm9taXNlPEdldFVzZXJJbmZvUmVzdWx0PiB7XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZSgnZ2V0VXNlckluZm8nLCB7fSwgQXBpU2NoZW1hcy5HZXRVc2VySW5mb1Jlc3VsdCk7XG4gIH1cblxuICAvKipcbiAgICogU2V0cyB0aGUgc3BlY2lmaWVkIHVzZXLigJlzIHBhc3N3b3JkIHRvIHRoZSBzcGVjaWZpZWQgdmFsdWVcbiAgICovXG4gIHNldFBhc3N3b3JkKHVzZXJJZDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCdzZXRQYXNzd29yZCcsIHsgdXNlcklkLCBwYXNzd29yZCB9LCAnc3RyaW5nJyk7XG4gIH1cblxuICAvKipcbiAgICogUmVzZXRzIHRoZSBzcGVjaWZpZWQgdXNlcuKAmXMgcGFzc3dvcmRcbiAgICovXG4gIHJlc2V0UGFzc3dvcmQodXNlcklkOiBzdHJpbmcpOiBQcm9taXNlPFJlc2V0UGFzc3dvcmRSZXN1bHQ+IHtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKFxuICAgICAgJ3Jlc2V0UGFzc3dvcmQnLFxuICAgICAgeyB1c2VySWQgfSxcbiAgICAgIEFwaVNjaGVtYXMuUmVzZXRQYXNzd29yZFJlc3VsdCxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgb25lIG9yIG1vcmUgbmV3IHJlY29yZHMgdG8geW91ciBvcmdhbml6YXRpb27igJlzIGRhdGFcbiAgICovXG4gIGNyZWF0ZShzT2JqZWN0OiBSZWNvcmRbXSk6IFByb21pc2U8U2F2ZVJlc3VsdFtdPjtcbiAgY3JlYXRlKHNPYmplY3Q6IFJlY29yZCk6IFByb21pc2U8U2F2ZVJlc3VsdD47XG4gIGNyZWF0ZShzT2JqZWN0czogUmVjb3JkIHwgUmVjb3JkW10pOiBQcm9taXNlPFNhdmVSZXN1bHQgfCBTYXZlUmVzdWx0W10+O1xuICBjcmVhdGUoc09iamVjdHM6IFJlY29yZCB8IFJlY29yZFtdKSB7XG4gICAgY29uc3Qgc2NoZW1hID0gQXJyYXkuaXNBcnJheShzT2JqZWN0cylcbiAgICAgID8gW0FwaVNjaGVtYXMuU2F2ZVJlc3VsdF1cbiAgICAgIDogQXBpU2NoZW1hcy5TYXZlUmVzdWx0O1xuICAgIGNvbnN0IGFyZ3MgPSB7XG4gICAgICAnQHhtbG5zJzogJ3VybjpwYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbScsXG4gICAgICAnQHhtbG5zOm5zMSc6ICdzb2JqZWN0LnBhcnRuZXIuc29hcC5zZm9yY2UuY29tJyxcbiAgICAgICduczE6c09iamVjdHMnOiB0b1NvYXBSZWNvcmQoc09iamVjdHMpLFxuICAgIH07XG4gICAgcmV0dXJuIHRoaXMuX2ludm9rZSgnY3JlYXRlJywgYXJncywgc2NoZW1hKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBVcGRhdGVzIG9uZSBvciBtb3JlIGV4aXN0aW5nIHJlY29yZHMgaW4geW91ciBvcmdhbml6YXRpb27igJlzIGRhdGEuXG4gICAqL1xuICB1cGRhdGUoc09iamVjdDogUmVjb3JkW10pOiBQcm9taXNlPFNhdmVSZXN1bHRbXT47XG4gIHVwZGF0ZShzT2JqZWN0OiBSZWNvcmQpOiBQcm9taXNlPFNhdmVSZXN1bHQ+O1xuICB1cGRhdGUoc09iamVjdHM6IFJlY29yZCB8IFJlY29yZFtdKTogUHJvbWlzZTxTYXZlUmVzdWx0IHwgU2F2ZVJlc3VsdFtdPjtcbiAgdXBkYXRlKHNPYmplY3RzOiBSZWNvcmQgfCBSZWNvcmRbXSkge1xuICAgIGNvbnN0IHNjaGVtYSA9IEFycmF5LmlzQXJyYXkoc09iamVjdHMpXG4gICAgICA/IFtBcGlTY2hlbWFzLlNhdmVSZXN1bHRdXG4gICAgICA6IEFwaVNjaGVtYXMuU2F2ZVJlc3VsdDtcbiAgICBjb25zdCBhcmdzID0ge1xuICAgICAgJ0B4bWxucyc6ICd1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb20nLFxuICAgICAgJ0B4bWxuczpuczEnOiAnc29iamVjdC5wYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbScsXG4gICAgICAnbnMxOnNPYmplY3RzJzogdG9Tb2FwUmVjb3JkKHNPYmplY3RzKSxcbiAgICB9O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ3VwZGF0ZScsIGFyZ3MsIHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlcyBuZXcgcmVjb3JkcyBhbmQgdXBkYXRlcyBleGlzdGluZyByZWNvcmRzIGluIHlvdXIgb3JnYW5pemF0aW9u4oCZcyBkYXRhLlxuICAgKi9cbiAgdXBzZXJ0KFxuICAgIGV4dGVybmFsSWRGaWVsZE5hbWU6IHN0cmluZyxcbiAgICBzT2JqZWN0czogUmVjb3JkW10sXG4gICk6IFByb21pc2U8VXBzZXJ0UmVzdWx0W10+O1xuICB1cHNlcnQoZXh0ZXJuYWxJZEZpZWxkTmFtZTogc3RyaW5nLCBzT2JqZWN0OiBSZWNvcmQpOiBQcm9taXNlPFVwc2VydFJlc3VsdD47XG4gIHVwc2VydChcbiAgICBleHRlcm5hbElkRmllbGROYW1lOiBzdHJpbmcsXG4gICAgc09iamVjdHM6IFJlY29yZCB8IFJlY29yZFtdLFxuICApOiBQcm9taXNlPFVwc2VydFJlc3VsdCB8IFVwc2VydFJlc3VsdFtdPjtcbiAgdXBzZXJ0KGV4dGVybmFsSWRGaWVsZE5hbWU6IHN0cmluZywgc09iamVjdHM6IFJlY29yZCB8IFJlY29yZFtdKSB7XG4gICAgY29uc3Qgc2NoZW1hID0gQXJyYXkuaXNBcnJheShzT2JqZWN0cylcbiAgICAgID8gW0FwaVNjaGVtYXMuVXBzZXJ0UmVzdWx0XVxuICAgICAgOiBBcGlTY2hlbWFzLlVwc2VydFJlc3VsdDtcbiAgICBjb25zdCBhcmdzID0ge1xuICAgICAgJ0B4bWxucyc6ICd1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb20nLFxuICAgICAgJ0B4bWxuczpuczEnOiAnc29iamVjdC5wYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbScsXG4gICAgICAnbnMxOmV4dGVybmFsSURGaWVsZE5hbWUnOiBleHRlcm5hbElkRmllbGROYW1lLFxuICAgICAgJ25zMTpzT2JqZWN0cyc6IHRvU29hcFJlY29yZChzT2JqZWN0cyksXG4gICAgfTtcbiAgICByZXR1cm4gdGhpcy5faW52b2tlKCd1cHNlcnQnLCBhcmdzLCBzY2hlbWEpO1xuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZXMgb25lIG9yIG1vcmUgcmVjb3JkcyBmcm9tIHlvdXIgb3JnYW5pemF0aW9u4oCZcyBkYXRhXG4gICAqL1xuICBkZWxldGUoaWRzOiBzdHJpbmcgfCBzdHJpbmdbXSk6IFByb21pc2U8RGVsZXRlUmVzdWx0W10+O1xuICBkZWxldGUoaWQ6IHN0cmluZyk6IFByb21pc2U8RGVsZXRlUmVzdWx0PjtcbiAgZGVsZXRlKGlkczogc3RyaW5nIHwgc3RyaW5nW10pOiBQcm9taXNlPERlbGV0ZVJlc3VsdCB8IERlbGV0ZVJlc3VsdFtdPjtcbiAgZGVsZXRlKGlkczogc3RyaW5nIHwgc3RyaW5nW10pIHtcbiAgICBjb25zdCBzY2hlbWEgPSBBcnJheS5pc0FycmF5KGlkcylcbiAgICAgID8gW0FwaVNjaGVtYXMuRGVsZXRlUmVzdWx0XVxuICAgICAgOiBBcGlTY2hlbWFzLkRlbGV0ZVJlc3VsdDtcbiAgICBjb25zdCBhcmdzID0ge1xuICAgICAgJ0B4bWxucyc6ICd1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb20nLFxuICAgICAgJ0B4bWxuczpuczEnOiAnc29iamVjdC5wYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbScsXG4gICAgICAnbnMxOmlkcyc6IGlkcyxcbiAgICB9O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ2RlbGV0ZScsIGFyZ3MsIHNjaGVtYSk7XG4gIH1cblxuICAvKipcbiAgICogVW5kZWxldGUgcmVjb3JkcyBmcm9tIHRoZSByZWN5Y2xlIGJpbiBpbW1lZGlhdGVseVxuICAgKi9cbiAgdW5kZWxldGUoaWRzOiBzdHJpbmdbXSk6IFByb21pc2U8VW5kZWxldGVSZXN1bHRbXT4ge1xuICAgIGNvbnN0IHNjaGVtYSA9IFtBcGlTY2hlbWFzLlVuZGVsZXRlUmVzdWx0XTtcbiAgICBjb25zdCBhcmdzID0ge1xuICAgICAgJ0B4bWxucyc6ICd1cm46cGFydG5lci5zb2FwLnNmb3JjZS5jb20nLFxuICAgICAgJ0B4bWxuczpuczEnOiAnc29iamVjdC5wYXJ0bmVyLnNvYXAuc2ZvcmNlLmNvbScsXG4gICAgICAnbnMxOmlkcyc6IGlkcyxcbiAgICB9O1xuICAgIHJldHVybiB0aGlzLl9pbnZva2UoJ3VuZGVsZXRlJywgYXJncywgc2NoZW1hKTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qXG4gKiBSZWdpc3RlciBob29rIGluIGNvbm5lY3Rpb24gaW5zdGFudGlhdGlvbiBmb3IgZHluYW1pY2FsbHkgYWRkaW5nIHRoaXMgQVBJIG1vZHVsZSBmZWF0dXJlc1xuICovXG5yZWdpc3Rlck1vZHVsZSgnc29hcCcsIChjb25uKSA9PiBuZXcgU29hcEFwaShjb25uKSk7XG5cbmV4cG9ydCBkZWZhdWx0IFNvYXBBcGk7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLGNBQWMsUUFBUSxZQUFZO0FBRTNDLE9BQU9DLElBQUksTUFBTSxTQUFTO0FBRTFCLFNBQ0VDLFVBQVUsUUFjTCxlQUFlOztBQUV0QjtBQUNBO0FBQ0E7QUFDQSxTQUFTQyxZQUFZQSxDQUFDQyxPQUEwQixFQUFxQjtFQUFBLElBQUFDLFFBQUE7RUFDbkUsT0FBT0Msb0JBQUEsQ0FBQUQsUUFBQSxHQUFDRSxjQUFBLENBQWNILE9BQU8sQ0FBQyxHQUFHQSxPQUFPLEdBQUcsQ0FBQ0EsT0FBTyxDQUFDLEVBQUFJLElBQUEsQ0FBQUgsUUFBQSxFQUFNLFVBQUNJLE1BQU0sRUFBSztJQUFBLElBQUFDLFNBQUE7SUFDcEUsSUFBUUMsSUFBSSxHQUF5QkYsTUFBTSxDQUFuQ0UsSUFBSTtNQUFFQyxVQUFVLEdBQWFILE1BQU0sQ0FBN0JHLFVBQVU7TUFBS0MsR0FBRyxHQUFBQyx3QkFBQSxDQUFLTCxNQUFNLEVBQUFNLFNBQUE7SUFDM0MsSUFBTUMsQ0FBQyxHQUFHTCxJQUFJLEtBQUlDLFVBQVUsYUFBVkEsVUFBVSx1QkFBVkEsVUFBVSxDQUFFRCxJQUFJO0lBQ2xDLElBQUksQ0FBQ0ssQ0FBQyxFQUFFO01BQ04sTUFBTSxJQUFJQyxLQUFLLENBQUMsd0RBQXdELENBQUM7SUFDM0U7SUFDQSxJQUFNQyxZQUFZLEdBQUdDLHVCQUFBLENBQUFULFNBQUEsR0FBQVUsWUFBQSxDQUFZUCxHQUFHLENBQUMsRUFBQUwsSUFBQSxDQUFBRSxTQUFBLEVBQ25DLFVBQUNXLEtBQUs7TUFBQSxPQUFLWixNQUFNLENBQUNZLEtBQUssQ0FBQyxLQUFLLElBQUk7SUFBQSxDQUNuQyxDQUFDO0lBQUMsSUFBQUMsU0FBQSxHQUFBQywwQkFBQSxDQUNrQkwsWUFBWTtNQUFBTSxLQUFBO0lBQUE7TUFBaEMsS0FBQUYsU0FBQSxDQUFBRyxDQUFBLE1BQUFELEtBQUEsR0FBQUYsU0FBQSxDQUFBSSxDQUFBLElBQUFDLElBQUEsR0FBa0M7UUFBQSxJQUF2Qk4sS0FBSyxHQUFBRyxLQUFBLENBQUFJLEtBQUE7UUFDZCxPQUFPZixHQUFHLENBQUNRLEtBQUssQ0FBQztNQUNuQjtJQUFDLFNBQUFRLEdBQUE7TUFBQVAsU0FBQSxDQUFBUSxDQUFBLENBQUFELEdBQUE7SUFBQTtNQUFBUCxTQUFBLENBQUFTLENBQUE7SUFBQTtJQUNELE9BQU9iLFlBQVksQ0FBQ2MsTUFBTSxHQUFHLENBQUMsR0FBQUMsYUFBQTtNQUN4QnRCLElBQUksRUFBRUssQ0FBQztNQUFFRSxZQUFZLEVBQVpBO0lBQVksR0FBS0wsR0FBRyxJQUFBb0IsYUFBQTtNQUM3QnRCLElBQUksRUFBRUs7SUFBQyxHQUFLSCxHQUFHLENBQUU7RUFDekIsQ0FBQyxDQUFDO0FBQ0o7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsV0FBYXFCLE9BQU87RUFHbEIsU0FBQUEsUUFBWUMsSUFBbUIsRUFBRTtJQUFBQyxlQUFBLE9BQUFGLE9BQUE7SUFDL0IsSUFBSSxDQUFDRyxLQUFLLEdBQUdGLElBQUk7RUFDbkI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7RUFIRSxPQUFBRyxZQUFBLENBQUFKLE9BQUE7SUFBQUssR0FBQTtJQUFBWCxLQUFBO01BQUEsSUFBQVksUUFBQSxHQUFBQyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBSUEsU0FBQUMsUUFDRUMsTUFBYyxFQUNkQyxPQUFlLEVBQ2ZDLE1BQWtDLEVBQ2xDQyxPQUlDO1FBQUEsSUFBQUMsU0FBQTtRQUFBLElBQUFDLFlBQUEsRUFBQUMsR0FBQTtRQUFBLE9BQUFULG1CQUFBLENBQUFVLElBQUEsVUFBQUMsU0FBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFDLElBQUEsR0FBQUQsU0FBQSxDQUFBRSxJQUFBO1lBQUE7Y0FFS04sWUFBWSxHQUFHLElBQUlqRCxJQUFJLENBQUMsSUFBSSxDQUFDb0MsS0FBSyxFQUFFO2dCQUN4Q29CLEtBQUssRUFBRSxDQUFBVCxPQUFPLGFBQVBBLE9BQU8sdUJBQVBBLE9BQU8sQ0FBRVMsS0FBSyxLQUFJLDZCQUE2QjtnQkFDdERDLFdBQVcsRUFBRSxDQUFBVixPQUFPLGFBQVBBLE9BQU8sdUJBQVBBLE9BQU8sQ0FBRVUsV0FBVyxLQUFBQyx1QkFBQSxDQUFBVixTQUFBLE1BQUFXLE1BQUEsQ0FBTyxJQUFJLENBQUN2QixLQUFLLENBQUN3QixXQUFXLHdCQUFBckQsSUFBQSxDQUFBeUMsU0FBQSxFQUFvQixJQUFJLENBQUNaLEtBQUssQ0FBQ3lCLE9BQU8sQ0FBRTtnQkFDdEdDLE9BQU8sRUFBRWYsT0FBTyxhQUFQQSxPQUFPLHVCQUFQQSxPQUFPLENBQUVlO2NBQ3BCLENBQUMsQ0FBQztjQUFBVCxTQUFBLENBQUFFLElBQUE7Y0FBQSxPQUNnQk4sWUFBWSxDQUFDYyxNQUFNLENBQ25DbkIsTUFBTSxFQUNOQyxPQUFPLEVBQ1BDLE1BQU0sR0FBSTtnQkFBRWtCLE1BQU0sRUFBRWxCO2NBQU8sQ0FBQyxHQUFrQm1CLFNBQVMsRUFDdkRoRSxVQUNGLENBQUM7WUFBQTtjQUxLaUQsR0FBRyxHQUFBRyxTQUFBLENBQUFhLElBQUE7Y0FBQSxPQUFBYixTQUFBLENBQUFjLE1BQUEsV0FNRmpCLEdBQUcsQ0FBQ2MsTUFBTTtZQUFBO1lBQUE7Y0FBQSxPQUFBWCxTQUFBLENBQUFlLElBQUE7VUFBQTtRQUFBLEdBQUF6QixPQUFBO01BQUEsQ0FDbEI7TUFBQSxTQXRCSzBCLE9BQU9BLENBQUFDLEVBQUEsRUFBQUMsR0FBQSxFQUFBQyxHQUFBLEVBQUFDLEdBQUE7UUFBQSxPQUFBbEMsUUFBQSxDQUFBbUMsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFQTixPQUFPO0lBQUE7SUF3QmI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBL0IsR0FBQTtJQUFBWCxLQUFBO01BQUEsSUFBQWlELFlBQUEsR0FBQXBDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FVQSxTQUFBbUMsU0FDRUMsWUFBZ0U7UUFBQSxJQUFBaEMsTUFBQTtRQUFBLE9BQUFMLG1CQUFBLENBQUFVLElBQUEsVUFBQTRCLFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBMUIsSUFBQSxHQUFBMEIsU0FBQSxDQUFBekIsSUFBQTtZQUFBO2NBRTFEVCxNQUFNLEdBQUd4QyxjQUFBLENBQWN3RSxZQUFZLENBQUMsR0FDdEMsQ0FBQzdFLFVBQVUsQ0FBQ2dGLGlCQUFpQixDQUFDLEdBQzlCaEYsVUFBVSxDQUFDZ0YsaUJBQWlCO2NBQUEsT0FBQUQsU0FBQSxDQUFBYixNQUFBLFdBQ3pCLElBQUksQ0FBQ0UsT0FBTyxDQUFDLGFBQWEsRUFBRTtnQkFBRVMsWUFBWSxFQUFaQTtjQUFhLENBQUMsRUFBRWhDLE1BQU0sQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBa0MsU0FBQSxDQUFBWixJQUFBO1VBQUE7UUFBQSxHQUFBUyxRQUFBO01BQUEsQ0FDN0Q7TUFBQSxTQVBLSyxXQUFXQSxDQUFBQyxHQUFBO1FBQUEsT0FBQVAsWUFBQSxDQUFBRixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVhPLFdBQVc7SUFBQTtJQVNqQjtBQUNGO0FBQ0E7RUFGRTtJQUFBNUMsR0FBQTtJQUFBWCxLQUFBO01BQUEsSUFBQXlELE1BQUEsR0FBQTVDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FRQSxTQUFBMkMsU0FDRUMsYUFBbUU7UUFBQSxJQUFBeEMsTUFBQTtRQUFBLE9BQUFMLG1CQUFBLENBQUFVLElBQUEsVUFBQW9DLFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBbEMsSUFBQSxHQUFBa0MsU0FBQSxDQUFBakMsSUFBQTtZQUFBO2NBRTdEVCxNQUFNLEdBQUd4QyxjQUFBLENBQWNnRixhQUFhLENBQUMsR0FDdkMsQ0FBQ3JGLFVBQVUsQ0FBQ3dGLFdBQVcsQ0FBQyxHQUN4QnhGLFVBQVUsQ0FBQ3dGLFdBQVc7Y0FBQSxPQUFBRCxTQUFBLENBQUFyQixNQUFBLFdBQ25CLElBQUksQ0FBQ0UsT0FBTyxDQUFDLE9BQU8sRUFBRTtnQkFBRWlCLGFBQWEsRUFBYkE7Y0FBYyxDQUFDLEVBQUV4QyxNQUFNLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQTBDLFNBQUEsQ0FBQXBCLElBQUE7VUFBQTtRQUFBLEdBQUFpQixRQUFBO01BQUEsQ0FDeEQ7TUFBQSxTQVBLSyxLQUFLQSxDQUFBQyxHQUFBO1FBQUEsT0FBQVAsTUFBQSxDQUFBVixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQUxlLEtBQUs7SUFBQTtJQVNYO0FBQ0Y7QUFDQTtFQUZFO0lBQUFwRCxHQUFBO0lBQUFYLEtBQUE7TUFBQSxJQUFBaUUsZ0JBQUEsR0FBQXBELGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBbUQsU0FBc0JDLEdBQWE7UUFBQSxPQUFBckQsbUJBQUEsQ0FBQVUsSUFBQSxVQUFBNEMsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUExQyxJQUFBLEdBQUEwQyxTQUFBLENBQUF6QyxJQUFBO1lBQUE7Y0FBQSxPQUFBeUMsU0FBQSxDQUFBN0IsTUFBQSxXQUMxQixJQUFJLENBQUNFLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRTtnQkFBRXlCLEdBQUcsRUFBSEE7Y0FBSSxDQUFDLEVBQUUsQ0FDOUM3RixVQUFVLENBQUNnRyxxQkFBcUIsQ0FDakMsQ0FBQztZQUFBO1lBQUE7Y0FBQSxPQUFBRCxTQUFBLENBQUE1QixJQUFBO1VBQUE7UUFBQSxHQUFBeUIsUUFBQTtNQUFBLENBQ0g7TUFBQSxTQUpLSyxlQUFlQSxDQUFBQyxHQUFBO1FBQUEsT0FBQVAsZ0JBQUEsQ0FBQWxCLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBZnVCLGVBQWU7SUFBQTtJQU1yQjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUE1RCxHQUFBO0lBQUFYLEtBQUE7TUFBQSxJQUFBeUUsYUFBQSxHQUFBNUQsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUEyRCxTQUFBO1FBQUEsT0FBQTVELG1CQUFBLENBQUFVLElBQUEsVUFBQW1ELFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBakQsSUFBQSxHQUFBaUQsU0FBQSxDQUFBaEQsSUFBQTtZQUFBO2NBQUEsT0FBQWdELFNBQUEsQ0FBQXBDLE1BQUEsV0FDUyxJQUFJLENBQUNFLE9BQU8sQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQ3BFLFVBQVUsQ0FBQ3VHLG9CQUFvQixDQUFDLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQUQsU0FBQSxDQUFBbkMsSUFBQTtVQUFBO1FBQUEsR0FBQWlDLFFBQUE7TUFBQSxDQUMzRTtNQUFBLFNBRktJLFlBQVlBLENBQUE7UUFBQSxPQUFBTCxhQUFBLENBQUExQixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVo4QixZQUFZO0lBQUE7SUFJbEI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBbkUsR0FBQTtJQUFBWCxLQUFBO01BQUEsSUFBQStFLG1CQUFBLEdBQUFsRSxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQWlFLFNBQUE7UUFBQSxPQUFBbEUsbUJBQUEsQ0FBQVUsSUFBQSxVQUFBeUQsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUF2RCxJQUFBLEdBQUF1RCxTQUFBLENBQUF0RCxJQUFBO1lBQUE7Y0FBQSxPQUFBc0QsU0FBQSxDQUFBMUMsTUFBQSxXQUNTLElBQUksQ0FBQ0UsT0FBTyxDQUNqQixvQkFBb0IsRUFDcEIsQ0FBQyxDQUFDLEVBQ0ZwRSxVQUFVLENBQUM2Ryx3QkFDYixDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUFELFNBQUEsQ0FBQXpDLElBQUE7VUFBQTtRQUFBLEdBQUF1QyxRQUFBO01BQUEsQ0FDRjtNQUFBLFNBTktJLGtCQUFrQkEsQ0FBQTtRQUFBLE9BQUFMLG1CQUFBLENBQUFoQyxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQWxCb0Msa0JBQWtCO0lBQUE7SUFReEI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBekUsR0FBQTtJQUFBWCxLQUFBO01BQUEsSUFBQXFGLFlBQUEsR0FBQXhFLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBdUUsU0FBQTtRQUFBLE9BQUF4RSxtQkFBQSxDQUFBVSxJQUFBLFVBQUErRCxVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQTdELElBQUEsR0FBQTZELFVBQUEsQ0FBQTVELElBQUE7WUFBQTtjQUFBLE9BQUE0RCxVQUFBLENBQUFoRCxNQUFBLFdBQ1MsSUFBSSxDQUFDRSxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQyxFQUFFcEUsVUFBVSxDQUFDbUgsaUJBQWlCLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQUQsVUFBQSxDQUFBL0MsSUFBQTtVQUFBO1FBQUEsR0FBQTZDLFFBQUE7TUFBQSxDQUNyRTtNQUFBLFNBRktJLFdBQVdBLENBQUE7UUFBQSxPQUFBTCxZQUFBLENBQUF0QyxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVgwQyxXQUFXO0lBQUE7SUFJakI7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBL0UsR0FBQTtJQUFBWCxLQUFBLEVBR0EsU0FBQTJGLFdBQVdBLENBQUNDLE1BQWMsRUFBRUMsUUFBZ0IsRUFBbUI7TUFDN0QsT0FBTyxJQUFJLENBQUNuRCxPQUFPLENBQUMsYUFBYSxFQUFFO1FBQUVrRCxNQUFNLEVBQU5BLE1BQU07UUFBRUMsUUFBUSxFQUFSQTtNQUFTLENBQUMsRUFBRSxRQUFRLENBQUM7SUFDcEU7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQWxGLEdBQUE7SUFBQVgsS0FBQSxFQUdBLFNBQUE4RixhQUFhQSxDQUFDRixNQUFjLEVBQWdDO01BQzFELE9BQU8sSUFBSSxDQUFDbEQsT0FBTyxDQUNqQixlQUFlLEVBQ2Y7UUFBRWtELE1BQU0sRUFBTkE7TUFBTyxDQUFDLEVBQ1Z0SCxVQUFVLENBQUN5SCxtQkFDYixDQUFDO0lBQ0g7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQXBGLEdBQUE7SUFBQVgsS0FBQSxFQU1BLFNBQUFnRyxNQUFNQSxDQUFDQyxRQUEyQixFQUFFO01BQ2xDLElBQU05RSxNQUFNLEdBQUd4QyxjQUFBLENBQWNzSCxRQUFRLENBQUMsR0FDbEMsQ0FBQzNILFVBQVUsQ0FBQzRILFVBQVUsQ0FBQyxHQUN2QjVILFVBQVUsQ0FBQzRILFVBQVU7TUFDekIsSUFBTUMsSUFBSSxHQUFHO1FBQ1gsUUFBUSxFQUFFLDZCQUE2QjtRQUN2QyxZQUFZLEVBQUUsaUNBQWlDO1FBQy9DLGNBQWMsRUFBRTVILFlBQVksQ0FBQzBILFFBQVE7TUFDdkMsQ0FBQztNQUNELE9BQU8sSUFBSSxDQUFDdkQsT0FBTyxDQUFDLFFBQVEsRUFBRXlELElBQUksRUFBRWhGLE1BQU0sQ0FBQztJQUM3Qzs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBUixHQUFBO0lBQUFYLEtBQUEsRUFNQSxTQUFBb0csTUFBTUEsQ0FBQ0gsUUFBMkIsRUFBRTtNQUNsQyxJQUFNOUUsTUFBTSxHQUFHeEMsY0FBQSxDQUFjc0gsUUFBUSxDQUFDLEdBQ2xDLENBQUMzSCxVQUFVLENBQUM0SCxVQUFVLENBQUMsR0FDdkI1SCxVQUFVLENBQUM0SCxVQUFVO01BQ3pCLElBQU1DLElBQUksR0FBRztRQUNYLFFBQVEsRUFBRSw2QkFBNkI7UUFDdkMsWUFBWSxFQUFFLGlDQUFpQztRQUMvQyxjQUFjLEVBQUU1SCxZQUFZLENBQUMwSCxRQUFRO01BQ3ZDLENBQUM7TUFDRCxPQUFPLElBQUksQ0FBQ3ZELE9BQU8sQ0FBQyxRQUFRLEVBQUV5RCxJQUFJLEVBQUVoRixNQUFNLENBQUM7SUFDN0M7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQVIsR0FBQTtJQUFBWCxLQUFBLEVBWUEsU0FBQXFHLE1BQU1BLENBQUNDLG1CQUEyQixFQUFFTCxRQUEyQixFQUFFO01BQy9ELElBQU05RSxNQUFNLEdBQUd4QyxjQUFBLENBQWNzSCxRQUFRLENBQUMsR0FDbEMsQ0FBQzNILFVBQVUsQ0FBQ2lJLFlBQVksQ0FBQyxHQUN6QmpJLFVBQVUsQ0FBQ2lJLFlBQVk7TUFDM0IsSUFBTUosSUFBSSxHQUFHO1FBQ1gsUUFBUSxFQUFFLDZCQUE2QjtRQUN2QyxZQUFZLEVBQUUsaUNBQWlDO1FBQy9DLHlCQUF5QixFQUFFRyxtQkFBbUI7UUFDOUMsY0FBYyxFQUFFL0gsWUFBWSxDQUFDMEgsUUFBUTtNQUN2QyxDQUFDO01BQ0QsT0FBTyxJQUFJLENBQUN2RCxPQUFPLENBQUMsUUFBUSxFQUFFeUQsSUFBSSxFQUFFaEYsTUFBTSxDQUFDO0lBQzdDOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFSLEdBQUE7SUFBQVgsS0FBQSxFQU1BLFNBQUF3RyxPQUFNQSxDQUFDckMsR0FBc0IsRUFBRTtNQUM3QixJQUFNaEQsTUFBTSxHQUFHeEMsY0FBQSxDQUFjd0YsR0FBRyxDQUFDLEdBQzdCLENBQUM3RixVQUFVLENBQUNtSSxZQUFZLENBQUMsR0FDekJuSSxVQUFVLENBQUNtSSxZQUFZO01BQzNCLElBQU1OLElBQUksR0FBRztRQUNYLFFBQVEsRUFBRSw2QkFBNkI7UUFDdkMsWUFBWSxFQUFFLGlDQUFpQztRQUMvQyxTQUFTLEVBQUVoQztNQUNiLENBQUM7TUFDRCxPQUFPLElBQUksQ0FBQ3pCLE9BQU8sQ0FBQyxRQUFRLEVBQUV5RCxJQUFJLEVBQUVoRixNQUFNLENBQUM7SUFDN0M7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQVIsR0FBQTtJQUFBWCxLQUFBLEVBR0EsU0FBQTBHLFFBQVFBLENBQUN2QyxHQUFhLEVBQTZCO01BQ2pELElBQU1oRCxNQUFNLEdBQUcsQ0FBQzdDLFVBQVUsQ0FBQ3FJLGNBQWMsQ0FBQztNQUMxQyxJQUFNUixJQUFJLEdBQUc7UUFDWCxRQUFRLEVBQUUsNkJBQTZCO1FBQ3ZDLFlBQVksRUFBRSxpQ0FBaUM7UUFDL0MsU0FBUyxFQUFFaEM7TUFDYixDQUFDO01BQ0QsT0FBTyxJQUFJLENBQUN6QixPQUFPLENBQUMsVUFBVSxFQUFFeUQsSUFBSSxFQUFFaEYsTUFBTSxDQUFDO0lBQy9DO0VBQUM7QUFBQTs7QUFHSDtBQUNBO0FBQ0E7QUFDQTtBQUNBL0MsY0FBYyxDQUFDLE1BQU0sRUFBRSxVQUFDbUMsSUFBSTtFQUFBLE9BQUssSUFBSUQsT0FBTyxDQUFDQyxJQUFJLENBQUM7QUFBQSxFQUFDO0FBRW5ELGVBQWVELE9BQU8iLCJpZ25vcmVMaXN0IjpbXX0=