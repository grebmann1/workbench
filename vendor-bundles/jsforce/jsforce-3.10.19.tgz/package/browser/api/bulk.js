import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _readOnlyError from "@babel/runtime-corejs3/helpers/readOnlyError";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _wrapNativeSuper from "@babel/runtime-corejs3/helpers/wrapNativeSuper";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
var _excluded = ["Id", "type", "attributes"],
  _excluded2 = ["path", "responseType"];
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof _Symbol && _getIteratorMethod(r) || r["@@iterator"]; if (!t) { if (_Array$isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { var _context25; if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = _sliceInstanceProperty(_context25 = {}.toString.call(r)).call(_context25, 8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? _Array$from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function ownKeys(e, r) { var t = _Object$keys2(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context23, _context24; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context23 = ownKeys(Object(t), !0)).call(_context23, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context24 = ownKeys(Object(t))).call(_context24, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _trimInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/trim";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _Object$keys2 from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _parseInt from "@babel/runtime-corejs3/core-js-stable/parse-int";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _mapInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/map";
import _includesInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/includes";
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.iterator.js";
import "core-js/modules/es.array.join.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.map.js";
import "core-js/modules/es.object.keys.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/es.regexp.to-string.js";
import "core-js/modules/es.set.js";
import "core-js/modules/es.string.match.js";
import "core-js/modules/es.string.replace.js";
import "core-js/modules/web.dom-exception.constructor.js";
import "core-js/modules/web.dom-exception.stack.js";
import "core-js/modules/web.dom-exception.to-string-tag.js";
import "core-js/modules/web.structured-clone.js";
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
/**
 * @file Manages Salesforce Bulk API related operations
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import { Writable } from 'stream';
import joinStreams from 'multistream';
import { Serializable, Parsable } from '../record-stream';
import HttpApi from '../http-api';
import { registerModule } from '../jsforce';
import { concatStreamsAsDuplex } from '../util/stream';
import is from '@sindresorhus/is';

/*--------------------------------------------*/

// In `HttpApi.parseResponseBody` we use xml2js to parse the XML response,
// all these props are of type `string` due to how we convert XML -> JSON:
// https://github.com/Leonidas-from-XIV/node-xml2js/issues/108
//
// TODO: xml2js allows to define value processing functions, maybe do it for the next major release?

/**
 * Class for Bulk API Job
 */
export var Job = /*#__PURE__*/function (_EventEmitter) {
  /**
   *
   */
  function Job(bulk, type, operation, options, jobId) {
    var _this;
    _classCallCheck(this, Job);
    _this = _callSuper(this, Job);
    _this._bulk = bulk;
    _this.type = type;
    _this.operation = operation;
    _this.options = options || {};
    _this.id = jobId !== null && jobId !== void 0 ? jobId : null;
    _this.state = _this.id ? 'Open' : 'Unknown';
    _this._batches = {};
    // default error handler to keep the latest error
    _this.on('error', function (error) {
      return _this._error = error;
    });
    return _this;
  }

  /**
   * Return latest jobInfo from cache
   */
  _inherits(Job, _EventEmitter);
  return _createClass(Job, [{
    key: "info",
    value: function info() {
      // if cache is not available, check the latest
      if (!this._jobInfo) {
        this._jobInfo = this.check();
      }
      return this._jobInfo;
    }

    /**
     * Open new job and get jobinfo
     */
  }, {
    key: "open",
    value: function open() {
      var _this2 = this;
      var bulk = this._bulk;
      var options = this.options;

      // if sobject type / operation is not provided
      if (!this.type || !this.operation) {
        throw new Error('type / operation is required to open a new job');
      }

      // if not requested opening job
      if (!this._jobInfo) {
        var _context, _context2, _context3, _context4, _context5;
        var _operation = this.operation.toLowerCase();
        if (_operation === 'harddelete') {
          _operation = 'hardDelete';
        }
        if (_operation === 'queryall') {
          _operation = 'queryAll';
        }
        var body = _trimInstanceProperty(_context = _concatInstanceProperty(_context2 = _concatInstanceProperty(_context3 = _concatInstanceProperty(_context4 = _concatInstanceProperty(_context5 = "\n<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<jobInfo  xmlns=\"http://www.force.com/2009/06/asyncapi/dataload\">\n  <operation>".concat(_operation, "</operation>\n  <object>")).call(_context5, this.type, "</object>\n  ")).call(_context4, options.extIdField ? "<externalIdFieldName>".concat(options.extIdField, "</externalIdFieldName>") : '', "\n  ")).call(_context3, options.concurrencyMode ? "<concurrencyMode>".concat(options.concurrencyMode, "</concurrencyMode>") : '', "\n  ")).call(_context2, options.assignmentRuleId ? "<assignmentRuleId>".concat(options.assignmentRuleId, "</assignmentRuleId>") : '', "\n  <contentType>CSV</contentType>\n</jobInfo>\n      ")).call(_context);
        this._jobInfo = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
          var res;
          return _regeneratorRuntime.wrap(function _callee$(_context6) {
            while (1) switch (_context6.prev = _context6.next) {
              case 0:
                _context6.prev = 0;
                _context6.next = 3;
                return bulk._request({
                  method: 'POST',
                  path: '/job',
                  body: body,
                  headers: {
                    'Content-Type': 'application/xml; charset=utf-8'
                  },
                  responseType: 'application/xml'
                });
              case 3:
                res = _context6.sent;
                _this2.emit('open', res.jobInfo);
                _this2.id = res.jobInfo.id;
                _this2.state = res.jobInfo.state;
                return _context6.abrupt("return", res.jobInfo);
              case 10:
                _context6.prev = 10;
                _context6.t0 = _context6["catch"](0);
                _this2.emit('error', _context6.t0);
                throw _context6.t0;
              case 14:
              case "end":
                return _context6.stop();
            }
          }, _callee, null, [[0, 10]]);
        }))();
      }
      return this._jobInfo;
    }

    /**
     * Create a new batch instance in the job
     */
  }, {
    key: "createBatch",
    value: function createBatch() {
      var _this3 = this;
      var batch = new Batch(this);
      batch.on('queue', function () {
        _this3._batches[batch.id] = batch;
      });
      return batch;
    }

    /**
     * Get a batch instance specified by given batch ID
     */
  }, {
    key: "batch",
    value: function batch(batchId) {
      var batch = this._batches[batchId];
      if (!batch) {
        batch = new Batch(this, batchId);
        this._batches[batchId] = batch;
      }
      return batch;
    }

    /**
     * Check the latest job status from server
     */
  }, {
    key: "check",
    value: function check() {
      var _this4 = this;
      var bulk = this._bulk;
      var logger = bulk._logger;
      this._jobInfo = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2() {
        var jobId, res;
        return _regeneratorRuntime.wrap(function _callee2$(_context7) {
          while (1) switch (_context7.prev = _context7.next) {
            case 0:
              _context7.next = 2;
              return _this4.ready();
            case 2:
              jobId = _context7.sent;
              _context7.next = 5;
              return bulk._request({
                method: 'GET',
                path: '/job/' + jobId,
                responseType: 'application/xml'
              });
            case 5:
              res = _context7.sent;
              logger.debug(res.jobInfo);
              _this4.id = res.jobInfo.id;
              _this4.type = res.jobInfo.object;
              _this4.operation = res.jobInfo.operation;
              _this4.state = res.jobInfo.state;
              return _context7.abrupt("return", res.jobInfo);
            case 12:
            case "end":
              return _context7.stop();
          }
        }, _callee2);
      }))();
      return this._jobInfo;
    }

    /**
     * Wait till the job is assigned to server
     */
  }, {
    key: "ready",
    value: function ready() {
      return this.id ? _Promise.resolve(this.id) : this.open().then(function (_ref3) {
        var id = _ref3.id;
        return id;
      });
    }

    /**
     * List all registered batch info in job
     */
  }, {
    key: "list",
    value: (function () {
      var _list = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3() {
        var bulk, logger, jobId, res, batchInfoList;
        return _regeneratorRuntime.wrap(function _callee3$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              bulk = this._bulk;
              logger = bulk._logger;
              _context8.next = 4;
              return this.ready();
            case 4:
              jobId = _context8.sent;
              _context8.next = 7;
              return bulk._request({
                method: 'GET',
                path: '/job/' + jobId + '/batch',
                responseType: 'application/xml'
              });
            case 7:
              res = _context8.sent;
              logger.debug(res.batchInfoList.batchInfo);
              batchInfoList = _Array$isArray(res.batchInfoList.batchInfo) ? res.batchInfoList.batchInfo : [res.batchInfoList.batchInfo];
              return _context8.abrupt("return", batchInfoList);
            case 11:
            case "end":
              return _context8.stop();
          }
        }, _callee3, this);
      }));
      function list() {
        return _list.apply(this, arguments);
      }
      return list;
    }()
    /**
     * Close opened job
     */
    )
  }, {
    key: "close",
    value: (function () {
      var _close = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4() {
        var jobInfo;
        return _regeneratorRuntime.wrap(function _callee4$(_context9) {
          while (1) switch (_context9.prev = _context9.next) {
            case 0:
              if (this.id) {
                _context9.next = 2;
                break;
              }
              return _context9.abrupt("return");
            case 2:
              _context9.prev = 2;
              _context9.next = 5;
              return this._changeState('Closed');
            case 5:
              jobInfo = _context9.sent;
              this.id = null;
              this.emit('close', jobInfo);
              return _context9.abrupt("return", jobInfo);
            case 11:
              _context9.prev = 11;
              _context9.t0 = _context9["catch"](2);
              this.emit('error', _context9.t0);
              throw _context9.t0;
            case 15:
            case "end":
              return _context9.stop();
          }
        }, _callee4, this, [[2, 11]]);
      }));
      function close() {
        return _close.apply(this, arguments);
      }
      return close;
    }()
    /**
     * Set the status to abort
     */
    )
  }, {
    key: "abort",
    value: (function () {
      var _abort = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee5() {
        var jobInfo;
        return _regeneratorRuntime.wrap(function _callee5$(_context10) {
          while (1) switch (_context10.prev = _context10.next) {
            case 0:
              if (this.id) {
                _context10.next = 2;
                break;
              }
              return _context10.abrupt("return");
            case 2:
              _context10.prev = 2;
              _context10.next = 5;
              return this._changeState('Aborted');
            case 5:
              jobInfo = _context10.sent;
              this.id = null;
              this.emit('abort', jobInfo);
              return _context10.abrupt("return", jobInfo);
            case 11:
              _context10.prev = 11;
              _context10.t0 = _context10["catch"](2);
              this.emit('error', _context10.t0);
              throw _context10.t0;
            case 15:
            case "end":
              return _context10.stop();
          }
        }, _callee5, this, [[2, 11]]);
      }));
      function abort() {
        return _abort.apply(this, arguments);
      }
      return abort;
    }()
    /**
     * @private
     */
    )
  }, {
    key: "_changeState",
    value: (function () {
      var _changeState2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee7(state) {
        var _this5 = this;
        var bulk, logger;
        return _regeneratorRuntime.wrap(function _callee7$(_context13) {
          while (1) switch (_context13.prev = _context13.next) {
            case 0:
              bulk = this._bulk;
              logger = bulk._logger;
              this._jobInfo = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee6() {
                var _context11;
                var jobId, body, res;
                return _regeneratorRuntime.wrap(function _callee6$(_context12) {
                  while (1) switch (_context12.prev = _context12.next) {
                    case 0:
                      _context12.next = 2;
                      return _this5.ready();
                    case 2:
                      jobId = _context12.sent;
                      body = _trimInstanceProperty(_context11 = " \n<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n  <jobInfo xmlns=\"http://www.force.com/2009/06/asyncapi/dataload\">\n  <state>".concat(state, "</state>\n</jobInfo>\n      ")).call(_context11);
                      _context12.next = 6;
                      return bulk._request({
                        method: 'POST',
                        path: '/job/' + jobId,
                        body: body,
                        headers: {
                          'Content-Type': 'application/xml; charset=utf-8'
                        },
                        responseType: 'application/xml'
                      });
                    case 6:
                      res = _context12.sent;
                      logger.debug(res.jobInfo);
                      _this5.state = res.jobInfo.state;
                      return _context12.abrupt("return", res.jobInfo);
                    case 10:
                    case "end":
                      return _context12.stop();
                  }
                }, _callee6);
              }))();
              return _context13.abrupt("return", this._jobInfo);
            case 4:
            case "end":
              return _context13.stop();
          }
        }, _callee7, this);
      }));
      function _changeState(_x) {
        return _changeState2.apply(this, arguments);
      }
      return _changeState;
    }())
  }]);
}(EventEmitter);

/*--------------------------------------------*/
var PollingTimeoutError = /*#__PURE__*/function (_Error) {
  /**
   *
   */
  function PollingTimeoutError(message, jobId, batchId) {
    var _this6;
    _classCallCheck(this, PollingTimeoutError);
    _this6 = _callSuper(this, PollingTimeoutError, [message]);
    _this6.name = 'PollingTimeout';
    _this6.jobId = jobId;
    _this6.batchId = batchId;
    return _this6;
  }
  _inherits(PollingTimeoutError, _Error);
  return _createClass(PollingTimeoutError);
}(/*#__PURE__*/_wrapNativeSuper(Error));
/*--------------------------------------------*/
/**
 * Batch (extends Writable)
 */
export var Batch = /*#__PURE__*/function (_Writable) {
  /**
   *
   */
  function Batch(job, id) {
    var _this7;
    _classCallCheck(this, Batch);
    _this7 = _callSuper(this, Batch, [{
      objectMode: true
    }]);
    _defineProperty(_this7, "run", _this7.execute);
    _defineProperty(_this7, "exec", _this7.execute);
    _this7.job = job;
    _this7.id = id;
    _this7._bulk = job._bulk;

    // default error handler to keep the latest error
    _this7.on('error', function (error) {
      return _this7._error = error;
    });

    //
    // setup data streams
    //
    var converterOptions = {
      nullValue: '#N/A'
    };
    var uploadStream = _this7._uploadStream = new Serializable();
    var uploadDataStream = uploadStream.stream('csv', converterOptions);
    var downloadStream = _this7._downloadStream = new Parsable();
    var downloadDataStream = downloadStream.stream('csv', converterOptions);
    _this7.on('finish', function () {
      return uploadStream.end();
    });
    uploadDataStream.once('readable', /*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee8() {
      return _regeneratorRuntime.wrap(function _callee8$(_context14) {
        while (1) switch (_context14.prev = _context14.next) {
          case 0:
            _context14.prev = 0;
            _context14.next = 3;
            return _this7.job.ready();
          case 3:
            // pipe upload data to batch API request stream
            uploadDataStream.pipe(_this7._createRequestStream());
            _context14.next = 9;
            break;
          case 6:
            _context14.prev = 6;
            _context14.t0 = _context14["catch"](0);
            _this7.emit('error', _context14.t0);
          case 9:
          case "end":
            return _context14.stop();
        }
      }, _callee8, null, [[0, 6]]);
    })));

    // duplex data stream, opened access to API programmers by Batch#stream()
    _this7._dataStream = concatStreamsAsDuplex(uploadDataStream, downloadDataStream);
    return _this7;
  }

  /**
   * Connect batch API and create stream instance of request/response
   *
   * @private
   */
  _inherits(Batch, _Writable);
  return _createClass(Batch, [{
    key: "_createRequestStream",
    value: function _createRequestStream() {
      var _this8 = this;
      var bulk = this._bulk;
      var logger = bulk._logger;
      var req = bulk._request({
        method: 'POST',
        path: '/job/' + this.job.id + '/batch',
        headers: {
          'Content-Type': 'text/csv'
        },
        responseType: 'application/xml'
      });
      _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee9() {
        var res;
        return _regeneratorRuntime.wrap(function _callee9$(_context15) {
          while (1) switch (_context15.prev = _context15.next) {
            case 0:
              _context15.prev = 0;
              _context15.next = 3;
              return req;
            case 3:
              res = _context15.sent;
              logger.debug(res.batchInfo);
              _this8.id = res.batchInfo.id;
              _this8.emit('queue', res.batchInfo);
              _context15.next = 12;
              break;
            case 9:
              _context15.prev = 9;
              _context15.t0 = _context15["catch"](0);
              _this8.emit('error', _context15.t0);
            case 12:
            case "end":
              return _context15.stop();
          }
        }, _callee9, null, [[0, 9]]);
      }))();
      return req.stream();
    }

    /**
     * Implementation of Writable
     */
  }, {
    key: "_write",
    value: function _write(record_, enc, cb) {
      var Id = record_.Id,
        type = record_.type,
        attributes = record_.attributes,
        rrec = _objectWithoutProperties(record_, _excluded);
      var record;
      switch (this.job.operation) {
        case 'insert':
          record = rrec;
          break;
        case 'delete':
        case 'hardDelete':
          record = {
            Id: Id
          };
          break;
        default:
          record = _objectSpread({
            Id: Id
          }, rrec);
      }
      this._uploadStream.write(record, enc, cb);
    }

    /**
     * Returns duplex stream which accepts CSV data input and batch result output
     */
  }, {
    key: "stream",
    value: function stream() {
      return this._dataStream;
    }

    /**
     * Execute batch operation
     */
  }, {
    key: "execute",
    value: function execute(input) {
      var _this9 = this;
      // if batch is already executed
      if (this._result) {
        throw new Error('Batch already executed.');
      }
      this._result = new _Promise(function (resolve, reject) {
        _this9.once('response', resolve);
        _this9.once('error', reject);
      });
      if (is.nodeStream(input)) {
        // if input has stream.Readable interface
        input.pipe(this._dataStream);
      } else {
        var recordData = structuredClone(input);
        if (_Array$isArray(recordData)) {
          var _iterator = _createForOfIteratorHelper(recordData),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var record = _step.value;
              for (var _i = 0, _Object$keys = _Object$keys2(record); _i < _Object$keys.length; _i++) {
                var key = _Object$keys[_i];
                if (typeof record[key] === 'boolean') {
                  record[key] = String(record[key]);
                }
              }
              this.write(record);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
          this.end();
        } else if (typeof recordData === 'string') {
          this._dataStream.write(recordData, 'utf8');
          this._dataStream.end();
        }
      }

      // return Batch instance for chaining
      return this;
    }
  }, {
    key: "then",
    value:
    /**
     * Promise/A+ interface
     * Delegate to promise, return promise instance for batch result
     */
    function then(onResolved, onReject) {
      if (!this._result) {
        this.execute();
      }
      return this._result.then(onResolved, onReject);
    }

    /**
     * Check the latest batch status in server
     */
  }, {
    key: "check",
    value: (function () {
      var _check = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee10() {
        var bulk, logger, jobId, batchId, res;
        return _regeneratorRuntime.wrap(function _callee10$(_context16) {
          while (1) switch (_context16.prev = _context16.next) {
            case 0:
              bulk = this._bulk;
              logger = bulk._logger;
              jobId = this.job.id;
              batchId = this.id;
              if (!(!jobId || !batchId)) {
                _context16.next = 6;
                break;
              }
              throw new Error('Batch not started.');
            case 6:
              _context16.next = 8;
              return bulk._request({
                method: 'GET',
                path: '/job/' + jobId + '/batch/' + batchId,
                responseType: 'application/xml'
              });
            case 8:
              res = _context16.sent;
              logger.debug(res.batchInfo);
              return _context16.abrupt("return", res.batchInfo);
            case 11:
            case "end":
              return _context16.stop();
          }
        }, _callee10, this);
      }));
      function check() {
        return _check.apply(this, arguments);
      }
      return check;
    }()
    /**
     * Polling the batch result and retrieve
     */
    )
  }, {
    key: "poll",
    value: function _poll(interval, timeout) {
      var _this10 = this;
      var jobId = this.job.id;
      var batchId = this.id;
      if (!jobId || !batchId) {
        throw new Error('Batch not started.');
      }
      var startTime = new Date().getTime();
      var endTime = startTime + timeout;
      if (timeout === 0) {
        var _context17;
        throw new PollingTimeoutError(_concatInstanceProperty(_context17 = "Skipping polling because of timeout = 0ms. Job Id = ".concat(jobId, " | Batch Id = ")).call(_context17, batchId), jobId, batchId);
      }
      var _poll = /*#__PURE__*/function () {
        var _ref7 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee11() {
          var now, err, res;
          return _regeneratorRuntime.wrap(function _callee11$(_context18) {
            while (1) switch (_context18.prev = _context18.next) {
              case 0:
                now = new Date().getTime();
                if (!(endTime < now)) {
                  _context18.next = 5;
                  break;
                }
                err = new PollingTimeoutError('Polling time out. Job Id = ' + jobId + ' , batch Id = ' + batchId, jobId, batchId);
                _this10.emit('error', err);
                return _context18.abrupt("return");
              case 5:
                _context18.prev = 5;
                _context18.next = 8;
                return _this10.check();
              case 8:
                res = _context18.sent;
                _context18.next = 15;
                break;
              case 11:
                _context18.prev = 11;
                _context18.t0 = _context18["catch"](5);
                _this10.emit('error', _context18.t0);
                return _context18.abrupt("return");
              case 15:
                if (res.state === 'Failed') {
                  if (_parseInt(res.numberRecordsProcessed, 10) > 0) {
                    _this10.retrieve();
                  } else {
                    _this10.emit('error', new Error(res.stateMessage));
                  }
                } else if (res.state === 'Completed') {
                  _this10.retrieve();
                } else if (res.state === 'NotProcessed') {
                  _this10.emit('error', new Error('Job has been aborted'));
                } else {
                  _this10.emit('inProgress', res);
                  _setTimeout(_poll, interval);
                }
              case 16:
              case "end":
                return _context18.stop();
            }
          }, _callee11, null, [[5, 11]]);
        }));
        return function poll() {
          return _ref7.apply(this, arguments);
        };
      }();
      _setTimeout(_poll, interval);
    }

    /**
     * Retrieve batch result
     */
  }, {
    key: "retrieve",
    value: (function () {
      var _retrieve = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee12() {
        var bulk, jobId, job, batchId, resp, results, _context19, res, resultId, _res;
        return _regeneratorRuntime.wrap(function _callee12$(_context20) {
          while (1) switch (_context20.prev = _context20.next) {
            case 0:
              bulk = this._bulk;
              jobId = this.job.id;
              job = this.job;
              batchId = this.id;
              if (!(!jobId || !batchId)) {
                _context20.next = 6;
                break;
              }
              throw new Error('Batch not started.');
            case 6:
              _context20.prev = 6;
              _context20.next = 9;
              return bulk._request({
                method: 'GET',
                path: '/job/' + jobId + '/batch/' + batchId + '/result'
              });
            case 9:
              resp = _context20.sent;
              if (job.operation === 'query' || job.operation === 'queryAll') {
                res = resp;
                resultId = res['result-list'].result;
                results = _mapInstanceProperty(_context19 = _Array$isArray(resultId) ? resultId : [resultId]).call(_context19, function (id) {
                  return {
                    id: id,
                    batchId: batchId,
                    jobId: jobId
                  };
                });
              } else {
                _res = resp;
                results = _mapInstanceProperty(_res).call(_res, function (ret) {
                  return {
                    id: ret.Id || null,
                    success: ret.Success === 'true',
                    created: ret.Created === 'true',
                    errors: ret.Error ? [ret.Error] : []
                  };
                });
              }
              this.emit('response', results);
              return _context20.abrupt("return", results);
            case 15:
              _context20.prev = 15;
              _context20.t0 = _context20["catch"](6);
              this.emit('error', _context20.t0);
              throw _context20.t0;
            case 19:
            case "end":
              return _context20.stop();
          }
        }, _callee12, this, [[6, 15]]);
      }));
      function retrieve() {
        return _retrieve.apply(this, arguments);
      }
      return retrieve;
    }()
    /**
     * Fetch query batch result as a record stream
     *
     * @param {String} resultId - Result id
     * @returns {RecordStream} - Record stream, convertible to CSV data stream
     */
    )
  }, {
    key: "result",
    value: function result(resultId) {
      var jobId = this.job.id;
      var batchId = this.id;
      if (!jobId || !batchId) {
        throw new Error('Batch not started.');
      }
      var resultStream = new Parsable();
      var resultDataStream = resultStream.stream('csv');
      this._bulk._request({
        method: 'GET',
        path: '/job/' + jobId + '/batch/' + batchId + '/result/' + resultId,
        responseType: 'application/octet-stream'
      }).stream().pipe(resultDataStream);
      return resultStream;
    }
  }]);
}(Writable);

/*--------------------------------------------*/
/**
 *
 */
var BulkApi = /*#__PURE__*/function (_HttpApi) {
  function BulkApi() {
    _classCallCheck(this, BulkApi);
    return _callSuper(this, BulkApi, arguments);
  }
  _inherits(BulkApi, _HttpApi);
  return _createClass(BulkApi, [{
    key: "beforeSend",
    value: function beforeSend(request) {
      var _this$_conn$accessTok;
      request.headers = _objectSpread(_objectSpread({}, request.headers), {}, {
        'X-SFDC-SESSION': (_this$_conn$accessTok = this._conn.accessToken) !== null && _this$_conn$accessTok !== void 0 ? _this$_conn$accessTok : ''
      });
    }
  }, {
    key: "isSessionExpired",
    value: function isSessionExpired(response) {
      var _context21;
      return response.statusCode === 400 && _includesInstanceProperty(_context21 = response.body).call(_context21, '<exceptionCode>InvalidSessionId</exceptionCode>');
    }
  }, {
    key: "hasErrorInResponseBody",
    value: function hasErrorInResponseBody(body) {
      return !!body.error;
    }
  }, {
    key: "parseError",
    value: function parseError(body) {
      return {
        errorCode: body.error.exceptionCode,
        message: body.error.exceptionMessage
      };
    }
  }]);
}(HttpApi);
/*--------------------------------------------*/
/**
 * Class for Bulk API
 *
 * @class
 */
export var Bulk = /*#__PURE__*/function () {
  /**
   *
   */
  function Bulk(conn) {
    _classCallCheck(this, Bulk);
    /**
     * Polling interval in milliseconds
     *
     * Default: 1000 (1 second)
     */
    _defineProperty(this, "pollInterval", 1000);
    /**
     * Polling timeout in milliseconds
     *
     * Default: 30000 (30 seconds)
     */
    _defineProperty(this, "pollTimeout", 30000);
    this._conn = conn;
    this._logger = conn._logger;
  }

  /**
   *
   */
  return _createClass(Bulk, [{
    key: "_request",
    value: function _request(request_) {
      var conn = this._conn;
      var path = request_.path,
        responseType = request_.responseType,
        rreq = _objectWithoutProperties(request_, _excluded2);
      var baseUrl = [conn.instanceUrl, 'services/async', conn.version].join('/');
      var request = _objectSpread(_objectSpread({}, rreq), {}, {
        url: baseUrl + path
      });
      return new BulkApi(this._conn, {
        responseType: responseType
      }).request(request);
    }

    /**
     * Create and start bulkload job and batch
     *
     * This method will return a Batch instance (writable stream)
     * which you can write records into as a CSV string.
     *
     * Batch also implements the a promise interface so you can `await` this method to get the job results.
     *
     * @example
     * // Insert an array of records and get the job results
     *
     * const res = await connection.bulk.load('Account', 'insert', accounts)
     *
     * @example
     * // Insert records from a csv file using the returned batch stream
     *
     * const csvFile = fs.createReadStream('accounts.csv')
     *
     * const batch = conn.bulk.load('Account', 'insert')
     * 
     * // The `response` event is emitted when the job results are retrieved
     * batch.on('response', res => {
     *   console.log(res)
     * })
      * csvFile.pipe(batch.stream())
     *
     *
     */
  }, {
    key: "load",
    value: function load(type, operation, optionsOrInput, input) {
      var _this11 = this;
      var options = {};
      if (typeof optionsOrInput === 'string' || _Array$isArray(optionsOrInput) || is.nodeStream(optionsOrInput)) {
        // when options is not plain hash object, it is omitted
        input = optionsOrInput;
      } else {
        options = optionsOrInput;
      }
      var job = this.createJob(type, operation, options);
      var batch = job.createBatch();
      var cleanup = function cleanup() {
        return job.close();
      };
      var cleanupOnError = function cleanupOnError(err) {
        if (err.name !== 'PollingTimeout') {
          cleanup();
        }
      };
      batch.on('response', cleanup);
      batch.on('error', cleanupOnError);
      batch.on('queue', function () {
        batch === null || batch === void 0 || batch.poll(_this11.pollInterval, _this11.pollTimeout);
      });
      return batch.execute(input);
    }

    /**
     * Execute bulk query and get record stream
     */
  }, {
    key: "query",
    value: (function () {
      var _query = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee13(soql) {
        var _this12 = this;
        var m, type, recordStream, dataStream, results, streams;
        return _regeneratorRuntime.wrap(function _callee13$(_context22) {
          while (1) switch (_context22.prev = _context22.next) {
            case 0:
              m = soql.replace(/\([\s\S]+\)/g, '').match(/FROM\s+(\w+)/i);
              if (m) {
                _context22.next = 3;
                break;
              }
              throw new Error('No sobject type found in query, maybe caused by invalid SOQL.');
            case 3:
              type = m[1];
              recordStream = new Parsable();
              dataStream = recordStream.stream('csv');
              _context22.next = 8;
              return this.load(type, 'query', soql);
            case 8:
              results = _context22.sent;
              streams = _mapInstanceProperty(results).call(results, function (result) {
                return _this12.job(result.jobId).batch(result.batchId).result(result.id).stream();
              });
              joinStreams(streams).pipe(dataStream);
              return _context22.abrupt("return", recordStream);
            case 12:
            case "end":
              return _context22.stop();
          }
        }, _callee13, this);
      }));
      function query(_x2) {
        return _query.apply(this, arguments);
      }
      return query;
    }()
    /**
     * Create a new job instance
     */
    )
  }, {
    key: "createJob",
    value: function createJob(type, operation) {
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return new Job(this, type, operation, options);
    }

    /**
     * Get a job instance specified by given job ID
     *
     * @param {String} jobId - Job ID
     * @returns {Bulk~Job}
     */
  }, {
    key: "job",
    value: function job(jobId) {
      return new Job(this, null, null, null, jobId);
    }
  }]);
}();

/*--------------------------------------------*/
/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */
registerModule('bulk', function (conn) {
  return new Bulk(conn);
});
export default Bulk;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJXcml0YWJsZSIsImpvaW5TdHJlYW1zIiwiU2VyaWFsaXphYmxlIiwiUGFyc2FibGUiLCJIdHRwQXBpIiwicmVnaXN0ZXJNb2R1bGUiLCJjb25jYXRTdHJlYW1zQXNEdXBsZXgiLCJpcyIsIkpvYiIsIl9FdmVudEVtaXR0ZXIiLCJidWxrIiwidHlwZSIsIm9wZXJhdGlvbiIsIm9wdGlvbnMiLCJqb2JJZCIsIl90aGlzIiwiX2NsYXNzQ2FsbENoZWNrIiwiX2NhbGxTdXBlciIsIl9idWxrIiwiaWQiLCJzdGF0ZSIsIl9iYXRjaGVzIiwib24iLCJlcnJvciIsIl9lcnJvciIsIl9pbmhlcml0cyIsIl9jcmVhdGVDbGFzcyIsImtleSIsInZhbHVlIiwiaW5mbyIsIl9qb2JJbmZvIiwiY2hlY2siLCJvcGVuIiwiX3RoaXMyIiwiRXJyb3IiLCJfY29udGV4dCIsIl9jb250ZXh0MiIsIl9jb250ZXh0MyIsIl9jb250ZXh0NCIsIl9jb250ZXh0NSIsInRvTG93ZXJDYXNlIiwiYm9keSIsIl90cmltSW5zdGFuY2VQcm9wZXJ0eSIsIl9jb25jYXRJbnN0YW5jZVByb3BlcnR5IiwiY29uY2F0IiwiY2FsbCIsImV4dElkRmllbGQiLCJjb25jdXJyZW5jeU1vZGUiLCJhc3NpZ25tZW50UnVsZUlkIiwiX2FzeW5jVG9HZW5lcmF0b3IiLCJfcmVnZW5lcmF0b3JSdW50aW1lIiwibWFyayIsIl9jYWxsZWUiLCJyZXMiLCJ3cmFwIiwiX2NhbGxlZSQiLCJfY29udGV4dDYiLCJwcmV2IiwibmV4dCIsIl9yZXF1ZXN0IiwibWV0aG9kIiwicGF0aCIsImhlYWRlcnMiLCJyZXNwb25zZVR5cGUiLCJzZW50IiwiZW1pdCIsImpvYkluZm8iLCJhYnJ1cHQiLCJ0MCIsInN0b3AiLCJjcmVhdGVCYXRjaCIsIl90aGlzMyIsImJhdGNoIiwiQmF0Y2giLCJiYXRjaElkIiwiX3RoaXM0IiwibG9nZ2VyIiwiX2xvZ2dlciIsIl9jYWxsZWUyIiwiX2NhbGxlZTIkIiwiX2NvbnRleHQ3IiwicmVhZHkiLCJkZWJ1ZyIsIm9iamVjdCIsIl9Qcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJfcmVmMyIsIl9saXN0IiwiX2NhbGxlZTMiLCJiYXRjaEluZm9MaXN0IiwiX2NhbGxlZTMkIiwiX2NvbnRleHQ4IiwiYmF0Y2hJbmZvIiwiX0FycmF5JGlzQXJyYXkiLCJsaXN0IiwiYXBwbHkiLCJhcmd1bWVudHMiLCJfY2xvc2UiLCJfY2FsbGVlNCIsIl9jYWxsZWU0JCIsIl9jb250ZXh0OSIsIl9jaGFuZ2VTdGF0ZSIsImNsb3NlIiwiX2Fib3J0IiwiX2NhbGxlZTUiLCJfY2FsbGVlNSQiLCJfY29udGV4dDEwIiwiYWJvcnQiLCJfY2hhbmdlU3RhdGUyIiwiX2NhbGxlZTciLCJfdGhpczUiLCJfY2FsbGVlNyQiLCJfY29udGV4dDEzIiwiX2NhbGxlZTYiLCJfY29udGV4dDExIiwiX2NhbGxlZTYkIiwiX2NvbnRleHQxMiIsIl94IiwiUG9sbGluZ1RpbWVvdXRFcnJvciIsIl9FcnJvciIsIm1lc3NhZ2UiLCJfdGhpczYiLCJuYW1lIiwiX3dyYXBOYXRpdmVTdXBlciIsIl9Xcml0YWJsZSIsImpvYiIsIl90aGlzNyIsIm9iamVjdE1vZGUiLCJfZGVmaW5lUHJvcGVydHkiLCJleGVjdXRlIiwiY29udmVydGVyT3B0aW9ucyIsIm51bGxWYWx1ZSIsInVwbG9hZFN0cmVhbSIsIl91cGxvYWRTdHJlYW0iLCJ1cGxvYWREYXRhU3RyZWFtIiwic3RyZWFtIiwiZG93bmxvYWRTdHJlYW0iLCJfZG93bmxvYWRTdHJlYW0iLCJkb3dubG9hZERhdGFTdHJlYW0iLCJlbmQiLCJvbmNlIiwiX2NhbGxlZTgiLCJfY2FsbGVlOCQiLCJfY29udGV4dDE0IiwicGlwZSIsIl9jcmVhdGVSZXF1ZXN0U3RyZWFtIiwiX2RhdGFTdHJlYW0iLCJfdGhpczgiLCJyZXEiLCJfY2FsbGVlOSIsIl9jYWxsZWU5JCIsIl9jb250ZXh0MTUiLCJfd3JpdGUiLCJyZWNvcmRfIiwiZW5jIiwiY2IiLCJJZCIsImF0dHJpYnV0ZXMiLCJycmVjIiwiX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzIiwiX2V4Y2x1ZGVkIiwicmVjb3JkIiwiX29iamVjdFNwcmVhZCIsIndyaXRlIiwiaW5wdXQiLCJfdGhpczkiLCJfcmVzdWx0IiwicmVqZWN0Iiwibm9kZVN0cmVhbSIsInJlY29yZERhdGEiLCJzdHJ1Y3R1cmVkQ2xvbmUiLCJfaXRlcmF0b3IiLCJfY3JlYXRlRm9yT2ZJdGVyYXRvckhlbHBlciIsIl9zdGVwIiwicyIsIm4iLCJkb25lIiwiX2kiLCJfT2JqZWN0JGtleXMiLCJfT2JqZWN0JGtleXMyIiwibGVuZ3RoIiwiU3RyaW5nIiwiZXJyIiwiZSIsImYiLCJvblJlc29sdmVkIiwib25SZWplY3QiLCJfY2hlY2siLCJfY2FsbGVlMTAiLCJfY2FsbGVlMTAkIiwiX2NvbnRleHQxNiIsInBvbGwiLCJpbnRlcnZhbCIsInRpbWVvdXQiLCJfdGhpczEwIiwic3RhcnRUaW1lIiwiRGF0ZSIsImdldFRpbWUiLCJlbmRUaW1lIiwiX2NvbnRleHQxNyIsIl9yZWY3IiwiX2NhbGxlZTExIiwibm93IiwiX2NhbGxlZTExJCIsIl9jb250ZXh0MTgiLCJfcGFyc2VJbnQiLCJudW1iZXJSZWNvcmRzUHJvY2Vzc2VkIiwicmV0cmlldmUiLCJzdGF0ZU1lc3NhZ2UiLCJfc2V0VGltZW91dCIsIl9yZXRyaWV2ZSIsIl9jYWxsZWUxMiIsInJlc3AiLCJyZXN1bHRzIiwiX2NvbnRleHQxOSIsInJlc3VsdElkIiwiX3JlcyIsIl9jYWxsZWUxMiQiLCJfY29udGV4dDIwIiwicmVzdWx0IiwiX21hcEluc3RhbmNlUHJvcGVydHkiLCJyZXQiLCJzdWNjZXNzIiwiU3VjY2VzcyIsImNyZWF0ZWQiLCJDcmVhdGVkIiwiZXJyb3JzIiwicmVzdWx0U3RyZWFtIiwicmVzdWx0RGF0YVN0cmVhbSIsIkJ1bGtBcGkiLCJfSHR0cEFwaSIsImJlZm9yZVNlbmQiLCJyZXF1ZXN0IiwiX3RoaXMkX2Nvbm4kYWNjZXNzVG9rIiwiX2Nvbm4iLCJhY2Nlc3NUb2tlbiIsImlzU2Vzc2lvbkV4cGlyZWQiLCJyZXNwb25zZSIsIl9jb250ZXh0MjEiLCJzdGF0dXNDb2RlIiwiX2luY2x1ZGVzSW5zdGFuY2VQcm9wZXJ0eSIsImhhc0Vycm9ySW5SZXNwb25zZUJvZHkiLCJwYXJzZUVycm9yIiwiZXJyb3JDb2RlIiwiZXhjZXB0aW9uQ29kZSIsImV4Y2VwdGlvbk1lc3NhZ2UiLCJCdWxrIiwiY29ubiIsInJlcXVlc3RfIiwicnJlcSIsIl9leGNsdWRlZDIiLCJiYXNlVXJsIiwiaW5zdGFuY2VVcmwiLCJ2ZXJzaW9uIiwiam9pbiIsInVybCIsImxvYWQiLCJvcHRpb25zT3JJbnB1dCIsIl90aGlzMTEiLCJjcmVhdGVKb2IiLCJjbGVhbnVwIiwiY2xlYW51cE9uRXJyb3IiLCJwb2xsSW50ZXJ2YWwiLCJwb2xsVGltZW91dCIsIl9xdWVyeSIsIl9jYWxsZWUxMyIsInNvcWwiLCJfdGhpczEyIiwibSIsInJlY29yZFN0cmVhbSIsImRhdGFTdHJlYW0iLCJzdHJlYW1zIiwiX2NhbGxlZTEzJCIsIl9jb250ZXh0MjIiLCJyZXBsYWNlIiwibWF0Y2giLCJxdWVyeSIsIl94MiIsInVuZGVmaW5lZCJdLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hcGkvYnVsay50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBmaWxlIE1hbmFnZXMgU2FsZXNmb3JjZSBCdWxrIEFQSSByZWxhdGVkIG9wZXJhdGlvbnNcbiAqIEBhdXRob3IgU2hpbmljaGkgVG9taXRhIDxzaGluaWNoaS50b21pdGFAZ21haWwuY29tPlxuICovXG5pbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IHsgRHVwbGV4LCBSZWFkYWJsZSwgV3JpdGFibGUgfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IGpvaW5TdHJlYW1zIGZyb20gJ211bHRpc3RyZWFtJztcbmltcG9ydCBDb25uZWN0aW9uIGZyb20gJy4uL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHsgU2VyaWFsaXphYmxlLCBQYXJzYWJsZSB9IGZyb20gJy4uL3JlY29yZC1zdHJlYW0nO1xuaW1wb3J0IEh0dHBBcGkgZnJvbSAnLi4vaHR0cC1hcGknO1xuaW1wb3J0IHsgcmVnaXN0ZXJNb2R1bGUgfSBmcm9tICcuLi9qc2ZvcmNlJztcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4uL3V0aWwvbG9nZ2VyJztcbmltcG9ydCB7IGNvbmNhdFN0cmVhbXNBc0R1cGxleCB9IGZyb20gJy4uL3V0aWwvc3RyZWFtJztcbmltcG9ydCB7XG4gIEh0dHBNZXRob2RzLFxuICBIdHRwUmVxdWVzdCxcbiAgSHR0cFJlc3BvbnNlLFxuICBSZWNvcmQsXG4gIFNjaGVtYSxcbn0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IGlzIGZyb20gJ0BzaW5kcmVzb3JodXMvaXMnO1xuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuZXhwb3J0IHR5cGUgQnVsa09wZXJhdGlvbiA9XG4gIHwgJ2luc2VydCdcbiAgfCAndXBkYXRlJ1xuICB8ICd1cHNlcnQnXG4gIHwgJ2RlbGV0ZSdcbiAgfCAnaGFyZERlbGV0ZSdcbiAgfCAncXVlcnknXG4gIHwgJ3F1ZXJ5QWxsJztcblxuZXhwb3J0IHR5cGUgQnVsa09wdGlvbnMgPSB7XG4gIGV4dElkRmllbGQ/OiBzdHJpbmc7XG4gIGNvbmN1cnJlbmN5TW9kZT86ICdTZXJpYWwnIHwgJ1BhcmFsbGVsJztcbiAgYXNzaWdubWVudFJ1bGVJZD86IHN0cmluZztcbn07XG5cbmV4cG9ydCB0eXBlIEpvYlN0YXRlID0gJ09wZW4nIHwgJ0Nsb3NlZCcgfCAnQWJvcnRlZCcgfCAnRmFpbGVkJyB8ICdVbmtub3duJyB8ICdOb3RQcm9jZXNzZWQnO1xuXG4vLyBJbiBgSHR0cEFwaS5wYXJzZVJlc3BvbnNlQm9keWAgd2UgdXNlIHhtbDJqcyB0byBwYXJzZSB0aGUgWE1MIHJlc3BvbnNlLFxuLy8gYWxsIHRoZXNlIHByb3BzIGFyZSBvZiB0eXBlIGBzdHJpbmdgIGR1ZSB0byBob3cgd2UgY29udmVydCBYTUwgLT4gSlNPTjpcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9MZW9uaWRhcy1mcm9tLVhJVi9ub2RlLXhtbDJqcy9pc3N1ZXMvMTA4XG4vL1xuLy8gVE9ETzogeG1sMmpzIGFsbG93cyB0byBkZWZpbmUgdmFsdWUgcHJvY2Vzc2luZyBmdW5jdGlvbnMsIG1heWJlIGRvIGl0IGZvciB0aGUgbmV4dCBtYWpvciByZWxlYXNlP1xuZXhwb3J0IHR5cGUgSm9iSW5mbyA9IHtcbiAgaWQ6IHN0cmluZztcbiAgb2JqZWN0OiBzdHJpbmc7XG4gIG9wZXJhdGlvbjogQnVsa09wZXJhdGlvbjtcbiAgc3RhdGU6IEpvYlN0YXRlO1xuICBjcmVhdGVkQnlJZDogc3RyaW5nO1xuICBjcmVhdGVkRGF0ZTogc3RyaW5nO1xuICBzeXN0ZW1Nb2RzdGFtcDogc3RyaW5nO1xuICBjb25jdXJyZW5jeU1vZGU6IHN0cmluZztcbiAgY29udGVudFR5cGU6IHN0cmluZztcbiAgbnVtYmVyQmF0Y2hlc1F1ZXVlZDogc3RyaW5nO1xuICBudW1iZXJCYXRjaGVzSW5Qcm9ncmVzczogc3RyaW5nO1xuICBudW1iZXJCYXRjaGVzQ29tcGxldGVkOiBzdHJpbmc7XG4gIG51bWJlckJhdGNoZXNGYWlsZWQ6IHN0cmluZztcbiAgbnVtYmVyQmF0Y2hlc1RvdGFsOiBzdHJpbmc7XG4gIG51bWJlclJlY29yZHNQcm9jZXNzZWQ6IHN0cmluZztcbiAgbnVtYmVyUmV0cmllczogc3RyaW5nO1xuICBhcGlWZXJzaW9uOiBzdHJpbmc7XG4gIG51bWJlclJlY29yZHNGYWlsZWQ6IHN0cmluZztcbiAgdG90YWxQcm9jZXNzaW5nVGltZTogc3RyaW5nO1xuICBhcGlBY3RpdmVQcm9jZXNzaW5nVGltZTogc3RyaW5nO1xuICBhcGV4UHJvY2Vzc2luZ1RpbWU6IHN0cmluZztcbn07XG5cbnR5cGUgSm9iSW5mb1Jlc3BvbnNlID0ge1xuICBqb2JJbmZvOiBKb2JJbmZvO1xufTtcblxuZXhwb3J0IHR5cGUgQmF0Y2hTdGF0ZSA9XG4gIHwgJ1F1ZXVlZCdcbiAgfCAnSW5Qcm9ncmVzcydcbiAgfCAnQ29tcGxldGVkJ1xuICB8ICdGYWlsZWQnXG4gIHwgJ05vdFByb2Nlc3NlZCc7XG5cbmV4cG9ydCB0eXBlIEJhdGNoSW5mbyA9IHtcbiAgaWQ6IHN0cmluZztcbiAgam9iSWQ6IHN0cmluZztcbiAgc3RhdGU6IEJhdGNoU3RhdGU7XG4gIHN0YXRlTWVzc2FnZTogc3RyaW5nO1xuICBudW1iZXJSZWNvcmRzUHJvY2Vzc2VkOiBzdHJpbmc7XG4gIG51bWJlclJlY29yZHNGYWlsZWQ6IHN0cmluZztcbiAgdG90YWxQcm9jZXNzaW5nVGltZTogc3RyaW5nO1xufTtcblxudHlwZSBCYXRjaEluZm9SZXNwb25zZSA9IHtcbiAgYmF0Y2hJbmZvOiBCYXRjaEluZm87XG59O1xuXG50eXBlIEJhdGNoSW5mb0xpc3RSZXNwb25zZSA9IHtcbiAgYmF0Y2hJbmZvTGlzdDoge1xuICAgIGJhdGNoSW5mbzogQmF0Y2hJbmZvIHwgQmF0Y2hJbmZvW107XG4gIH07XG59O1xuXG5leHBvcnQgdHlwZSBCdWxrUXVlcnlCYXRjaFJlc3VsdCA9IEFycmF5PHtcbiAgaWQ6IHN0cmluZztcbiAgYmF0Y2hJZDogc3RyaW5nO1xuICBqb2JJZDogc3RyaW5nO1xufT47XG5cbmV4cG9ydCB0eXBlIEJ1bGtJbmdlc3RCYXRjaFJlc3VsdCA9IEFycmF5PHtcbiAgaWQ6IHN0cmluZyB8IG51bGw7XG4gIHN1Y2Nlc3M6IGJvb2xlYW47XG4gIGNyZWF0ZWQ6IGJvb2xlYW47XG4gIGVycm9yczogc3RyaW5nW107XG59PjtcblxuZXhwb3J0IHR5cGUgQmF0Y2hSZXN1bHQ8T3ByIGV4dGVuZHMgQnVsa09wZXJhdGlvbj4gPSBPcHIgZXh0ZW5kc1xuICB8ICdxdWVyeSdcbiAgfCAncXVlcnlBbGwnXG4gID8gQnVsa1F1ZXJ5QmF0Y2hSZXN1bHRcbiAgOiBCdWxrSW5nZXN0QmF0Y2hSZXN1bHQ7XG5cbnR5cGUgQnVsa0luZ2VzdFJlc3VsdFJlc3BvbnNlID0gQXJyYXk8e1xuICBJZDogc3RyaW5nO1xuICBTdWNjZXNzOiBzdHJpbmc7XG4gIENyZWF0ZWQ6IHN0cmluZztcbiAgRXJyb3I6IHN0cmluZztcbn0+O1xuXG50eXBlIEJ1bGtRdWVyeVJlc3VsdFJlc3BvbnNlID0ge1xuICAncmVzdWx0LWxpc3QnOiB7XG4gICAgcmVzdWx0OiBzdHJpbmcgfCBzdHJpbmdbXTtcbiAgfTtcbn07XG5cbmV4cG9ydCB0eXBlIEJ1bGtSZXF1ZXN0ID0ge1xuICBtZXRob2Q6IEh0dHBNZXRob2RzO1xuICBwYXRoPzogc3RyaW5nO1xuICBib2R5Pzogc3RyaW5nO1xuICBoZWFkZXJzPzogeyBbbmFtZTogc3RyaW5nXTogc3RyaW5nIH07XG4gIHJlc3BvbnNlVHlwZT86IHN0cmluZztcbn07XG5cbi8qKlxuICogQ2xhc3MgZm9yIEJ1bGsgQVBJIEpvYlxuICovXG5leHBvcnQgY2xhc3MgSm9iPFxuICBTIGV4dGVuZHMgU2NoZW1hLFxuICBPcHIgZXh0ZW5kcyBCdWxrT3BlcmF0aW9uXG4+IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgdHlwZTogc3RyaW5nIHwgbnVsbDtcbiAgb3BlcmF0aW9uOiBPcHIgfCBudWxsO1xuICBvcHRpb25zOiBCdWxrT3B0aW9ucztcbiAgaWQ6IHN0cmluZyB8IG51bGw7XG4gIHN0YXRlOiBKb2JTdGF0ZTtcbiAgX2J1bGs6IEJ1bGs8Uz47XG4gIF9iYXRjaGVzOiB7IFtpZDogc3RyaW5nXTogQmF0Y2g8UywgT3ByPiB9O1xuICBfam9iSW5mbzogUHJvbWlzZTxKb2JJbmZvPiB8IHVuZGVmaW5lZDtcbiAgX2Vycm9yOiBFcnJvciB8IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKFxuICAgIGJ1bGs6IEJ1bGs8Uz4sXG4gICAgdHlwZTogc3RyaW5nIHwgbnVsbCxcbiAgICBvcGVyYXRpb246IE9wciB8IG51bGwsXG4gICAgb3B0aW9uczogQnVsa09wdGlvbnMgfCBudWxsLFxuICAgIGpvYklkPzogc3RyaW5nLFxuICApIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuX2J1bGsgPSBidWxrO1xuICAgIHRoaXMudHlwZSA9IHR5cGU7XG4gICAgdGhpcy5vcGVyYXRpb24gPSBvcGVyYXRpb247XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgICB0aGlzLmlkID0gam9iSWQgPz8gbnVsbDtcbiAgICB0aGlzLnN0YXRlID0gdGhpcy5pZCA/ICdPcGVuJyA6ICdVbmtub3duJztcbiAgICB0aGlzLl9iYXRjaGVzID0ge307XG4gICAgLy8gZGVmYXVsdCBlcnJvciBoYW5kbGVyIHRvIGtlZXAgdGhlIGxhdGVzdCBlcnJvclxuICAgIHRoaXMub24oJ2Vycm9yJywgKGVycm9yKSA9PiAodGhpcy5fZXJyb3IgPSBlcnJvcikpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybiBsYXRlc3Qgam9iSW5mbyBmcm9tIGNhY2hlXG4gICAqL1xuICBpbmZvKCkge1xuICAgIC8vIGlmIGNhY2hlIGlzIG5vdCBhdmFpbGFibGUsIGNoZWNrIHRoZSBsYXRlc3RcbiAgICBpZiAoIXRoaXMuX2pvYkluZm8pIHtcbiAgICAgIHRoaXMuX2pvYkluZm8gPSB0aGlzLmNoZWNrKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9qb2JJbmZvO1xuICB9XG5cbiAgLyoqXG4gICAqIE9wZW4gbmV3IGpvYiBhbmQgZ2V0IGpvYmluZm9cbiAgICovXG4gIG9wZW4oKTogUHJvbWlzZTxKb2JJbmZvPiB7XG4gICAgY29uc3QgYnVsayA9IHRoaXMuX2J1bGs7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblxuICAgIC8vIGlmIHNvYmplY3QgdHlwZSAvIG9wZXJhdGlvbiBpcyBub3QgcHJvdmlkZWRcbiAgICBpZiAoIXRoaXMudHlwZSB8fCAhdGhpcy5vcGVyYXRpb24pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcigndHlwZSAvIG9wZXJhdGlvbiBpcyByZXF1aXJlZCB0byBvcGVuIGEgbmV3IGpvYicpO1xuICAgIH1cblxuICAgIC8vIGlmIG5vdCByZXF1ZXN0ZWQgb3BlbmluZyBqb2JcbiAgICBpZiAoIXRoaXMuX2pvYkluZm8pIHtcbiAgICAgIGxldCBvcGVyYXRpb24gPSB0aGlzLm9wZXJhdGlvbi50b0xvd2VyQ2FzZSgpO1xuICAgICAgaWYgKG9wZXJhdGlvbiA9PT0gJ2hhcmRkZWxldGUnKSB7XG4gICAgICAgIG9wZXJhdGlvbiA9ICdoYXJkRGVsZXRlJztcbiAgICAgIH1cbiAgICAgIGlmIChvcGVyYXRpb24gPT09ICdxdWVyeWFsbCcpIHtcbiAgICAgICAgb3BlcmF0aW9uID0gJ3F1ZXJ5QWxsJztcbiAgICAgIH1cbiAgICAgIGNvbnN0IGJvZHkgPSBgXG48P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz5cbjxqb2JJbmZvICB4bWxucz1cImh0dHA6Ly93d3cuZm9yY2UuY29tLzIwMDkvMDYvYXN5bmNhcGkvZGF0YWxvYWRcIj5cbiAgPG9wZXJhdGlvbj4ke29wZXJhdGlvbn08L29wZXJhdGlvbj5cbiAgPG9iamVjdD4ke3RoaXMudHlwZX08L29iamVjdD5cbiAgJHtcbiAgICBvcHRpb25zLmV4dElkRmllbGRcbiAgICAgID8gYDxleHRlcm5hbElkRmllbGROYW1lPiR7b3B0aW9ucy5leHRJZEZpZWxkfTwvZXh0ZXJuYWxJZEZpZWxkTmFtZT5gXG4gICAgICA6ICcnXG4gIH1cbiAgJHtcbiAgICBvcHRpb25zLmNvbmN1cnJlbmN5TW9kZVxuICAgICAgPyBgPGNvbmN1cnJlbmN5TW9kZT4ke29wdGlvbnMuY29uY3VycmVuY3lNb2RlfTwvY29uY3VycmVuY3lNb2RlPmBcbiAgICAgIDogJydcbiAgfVxuICAke1xuICAgIG9wdGlvbnMuYXNzaWdubWVudFJ1bGVJZFxuICAgICAgPyBgPGFzc2lnbm1lbnRSdWxlSWQ+JHtvcHRpb25zLmFzc2lnbm1lbnRSdWxlSWR9PC9hc3NpZ25tZW50UnVsZUlkPmBcbiAgICAgIDogJydcbiAgfVxuICA8Y29udGVudFR5cGU+Q1NWPC9jb250ZW50VHlwZT5cbjwvam9iSW5mbz5cbiAgICAgIGAudHJpbSgpO1xuXG4gICAgICB0aGlzLl9qb2JJbmZvID0gKGFzeW5jICgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBidWxrLl9yZXF1ZXN0PEpvYkluZm9SZXNwb25zZT4oe1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICBwYXRoOiAnL2pvYicsXG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbDsgY2hhcnNldD11dGYtOCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24veG1sJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLmVtaXQoJ29wZW4nLCByZXMuam9iSW5mbyk7XG4gICAgICAgICAgdGhpcy5pZCA9IHJlcy5qb2JJbmZvLmlkO1xuICAgICAgICAgIHRoaXMuc3RhdGUgPSByZXMuam9iSW5mby5zdGF0ZTtcbiAgICAgICAgICByZXR1cm4gcmVzLmpvYkluZm87XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgfSkoKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2pvYkluZm87XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgbmV3IGJhdGNoIGluc3RhbmNlIGluIHRoZSBqb2JcbiAgICovXG4gIGNyZWF0ZUJhdGNoKCk6IEJhdGNoPFMsIE9wcj4ge1xuICAgIGNvbnN0IGJhdGNoID0gbmV3IEJhdGNoKHRoaXMpO1xuICAgIGJhdGNoLm9uKCdxdWV1ZScsICgpID0+IHtcbiAgICAgIHRoaXMuX2JhdGNoZXNbYmF0Y2guaWQhXSA9IGJhdGNoO1xuICAgIH0pO1xuICAgIHJldHVybiBiYXRjaDtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgYSBiYXRjaCBpbnN0YW5jZSBzcGVjaWZpZWQgYnkgZ2l2ZW4gYmF0Y2ggSURcbiAgICovXG4gIGJhdGNoKGJhdGNoSWQ6IHN0cmluZyk6IEJhdGNoPFMsIE9wcj4ge1xuICAgIGxldCBiYXRjaCA9IHRoaXMuX2JhdGNoZXNbYmF0Y2hJZF07XG4gICAgaWYgKCFiYXRjaCkge1xuICAgICAgYmF0Y2ggPSBuZXcgQmF0Y2godGhpcywgYmF0Y2hJZCk7XG4gICAgICB0aGlzLl9iYXRjaGVzW2JhdGNoSWRdID0gYmF0Y2g7XG4gICAgfVxuICAgIHJldHVybiBiYXRjaDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVjayB0aGUgbGF0ZXN0IGpvYiBzdGF0dXMgZnJvbSBzZXJ2ZXJcbiAgICovXG4gIGNoZWNrKCkge1xuICAgIGNvbnN0IGJ1bGsgPSB0aGlzLl9idWxrO1xuICAgIGNvbnN0IGxvZ2dlciA9IGJ1bGsuX2xvZ2dlcjtcblxuICAgIHRoaXMuX2pvYkluZm8gPSAoYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3Qgam9iSWQgPSBhd2FpdCB0aGlzLnJlYWR5KCk7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBidWxrLl9yZXF1ZXN0PEpvYkluZm9SZXNwb25zZT4oe1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICBwYXRoOiAnL2pvYi8nICsgam9iSWQsXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL3htbCcsXG4gICAgICB9KTtcbiAgICAgIGxvZ2dlci5kZWJ1ZyhyZXMuam9iSW5mbyk7XG4gICAgICB0aGlzLmlkID0gcmVzLmpvYkluZm8uaWQ7XG4gICAgICB0aGlzLnR5cGUgPSByZXMuam9iSW5mby5vYmplY3Q7XG4gICAgICB0aGlzLm9wZXJhdGlvbiA9IHJlcy5qb2JJbmZvLm9wZXJhdGlvbiBhcyBPcHI7XG4gICAgICB0aGlzLnN0YXRlID0gcmVzLmpvYkluZm8uc3RhdGU7XG4gICAgICByZXR1cm4gcmVzLmpvYkluZm87XG4gICAgfSkoKTtcblxuICAgIHJldHVybiB0aGlzLl9qb2JJbmZvO1xuICB9XG5cbiAgLyoqXG4gICAqIFdhaXQgdGlsbCB0aGUgam9iIGlzIGFzc2lnbmVkIHRvIHNlcnZlclxuICAgKi9cbiAgcmVhZHkoKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICByZXR1cm4gdGhpcy5pZFxuICAgICAgPyBQcm9taXNlLnJlc29sdmUodGhpcy5pZClcbiAgICAgIDogdGhpcy5vcGVuKCkudGhlbigoeyBpZCB9KSA9PiBpZCk7XG4gIH1cblxuICAvKipcbiAgICogTGlzdCBhbGwgcmVnaXN0ZXJlZCBiYXRjaCBpbmZvIGluIGpvYlxuICAgKi9cbiAgYXN5bmMgbGlzdCgpIHtcbiAgICBjb25zdCBidWxrID0gdGhpcy5fYnVsaztcbiAgICBjb25zdCBsb2dnZXIgPSBidWxrLl9sb2dnZXI7XG4gICAgY29uc3Qgam9iSWQgPSBhd2FpdCB0aGlzLnJlYWR5KCk7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYnVsay5fcmVxdWVzdDxCYXRjaEluZm9MaXN0UmVzcG9uc2U+KHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBwYXRoOiAnL2pvYi8nICsgam9iSWQgKyAnL2JhdGNoJyxcbiAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL3htbCcsXG4gICAgfSk7XG4gICAgbG9nZ2VyLmRlYnVnKHJlcy5iYXRjaEluZm9MaXN0LmJhdGNoSW5mbyk7XG4gICAgY29uc3QgYmF0Y2hJbmZvTGlzdCA9IEFycmF5LmlzQXJyYXkocmVzLmJhdGNoSW5mb0xpc3QuYmF0Y2hJbmZvKVxuICAgICAgPyByZXMuYmF0Y2hJbmZvTGlzdC5iYXRjaEluZm9cbiAgICAgIDogW3Jlcy5iYXRjaEluZm9MaXN0LmJhdGNoSW5mb107XG4gICAgcmV0dXJuIGJhdGNoSW5mb0xpc3Q7XG4gIH1cblxuICAvKipcbiAgICogQ2xvc2Ugb3BlbmVkIGpvYlxuICAgKi9cbiAgYXN5bmMgY2xvc2UoKSB7XG4gICAgaWYgKCF0aGlzLmlkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBqb2JJbmZvID0gYXdhaXQgdGhpcy5fY2hhbmdlU3RhdGUoJ0Nsb3NlZCcpO1xuICAgICAgdGhpcy5pZCA9IG51bGw7XG4gICAgICB0aGlzLmVtaXQoJ2Nsb3NlJywgam9iSW5mbyk7XG4gICAgICByZXR1cm4gam9iSW5mbztcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIHN0YXR1cyB0byBhYm9ydFxuICAgKi9cbiAgYXN5bmMgYWJvcnQoKSB7XG4gICAgaWYgKCF0aGlzLmlkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBqb2JJbmZvID0gYXdhaXQgdGhpcy5fY2hhbmdlU3RhdGUoJ0Fib3J0ZWQnKTtcbiAgICAgIHRoaXMuaWQgPSBudWxsO1xuICAgICAgdGhpcy5lbWl0KCdhYm9ydCcsIGpvYkluZm8pO1xuICAgICAgcmV0dXJuIGpvYkluZm87XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIGFzeW5jIF9jaGFuZ2VTdGF0ZShzdGF0ZTogSm9iU3RhdGUpIHtcbiAgICBjb25zdCBidWxrID0gdGhpcy5fYnVsaztcbiAgICBjb25zdCBsb2dnZXIgPSBidWxrLl9sb2dnZXI7XG5cbiAgICB0aGlzLl9qb2JJbmZvID0gKGFzeW5jICgpID0+IHtcbiAgICAgIGNvbnN0IGpvYklkID0gYXdhaXQgdGhpcy5yZWFkeSgpO1xuICAgICAgY29uc3QgYm9keSA9IGAgXG48P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz5cbiAgPGpvYkluZm8geG1sbnM9XCJodHRwOi8vd3d3LmZvcmNlLmNvbS8yMDA5LzA2L2FzeW5jYXBpL2RhdGFsb2FkXCI+XG4gIDxzdGF0ZT4ke3N0YXRlfTwvc3RhdGU+XG48L2pvYkluZm8+XG4gICAgICBgLnRyaW0oKTtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGJ1bGsuX3JlcXVlc3Q8Sm9iSW5mb1Jlc3BvbnNlPih7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBwYXRoOiAnL2pvYi8nICsgam9iSWQsXG4gICAgICAgIGJvZHk6IGJvZHksXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbDsgY2hhcnNldD11dGYtOCcsXG4gICAgICAgIH0sXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL3htbCcsXG4gICAgICB9KTtcbiAgICAgIGxvZ2dlci5kZWJ1ZyhyZXMuam9iSW5mbyk7XG4gICAgICB0aGlzLnN0YXRlID0gcmVzLmpvYkluZm8uc3RhdGU7XG4gICAgICByZXR1cm4gcmVzLmpvYkluZm87XG4gICAgfSkoKTtcbiAgICByZXR1cm4gdGhpcy5fam9iSW5mbztcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbmNsYXNzIFBvbGxpbmdUaW1lb3V0RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIGpvYklkOiBzdHJpbmc7XG4gIGJhdGNoSWQ6IHN0cmluZztcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKG1lc3NhZ2U6IHN0cmluZywgam9iSWQ6IHN0cmluZywgYmF0Y2hJZDogc3RyaW5nKSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ1BvbGxpbmdUaW1lb3V0JztcbiAgICB0aGlzLmpvYklkID0gam9iSWQ7XG4gICAgdGhpcy5iYXRjaElkID0gYmF0Y2hJZDtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qKlxuICogQmF0Y2ggKGV4dGVuZHMgV3JpdGFibGUpXG4gKi9cbmV4cG9ydCBjbGFzcyBCYXRjaDxcbiAgUyBleHRlbmRzIFNjaGVtYSxcbiAgT3ByIGV4dGVuZHMgQnVsa09wZXJhdGlvblxuPiBleHRlbmRzIFdyaXRhYmxlIHtcbiAgam9iOiBKb2I8UywgT3ByPjtcbiAgaWQ6IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgX2J1bGs6IEJ1bGs8Uz47XG4gIF91cGxvYWRTdHJlYW06IFNlcmlhbGl6YWJsZTtcbiAgX2Rvd25sb2FkU3RyZWFtOiBQYXJzYWJsZTtcbiAgX2RhdGFTdHJlYW06IER1cGxleDtcbiAgX3Jlc3VsdDogUHJvbWlzZTxCYXRjaFJlc3VsdDxPcHI+PiB8IHVuZGVmaW5lZDtcbiAgX2Vycm9yOiBFcnJvciB8IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKGpvYjogSm9iPFMsIE9wcj4sIGlkPzogc3RyaW5nKSB7XG4gICAgc3VwZXIoeyBvYmplY3RNb2RlOiB0cnVlIH0pO1xuICAgIHRoaXMuam9iID0gam9iO1xuICAgIHRoaXMuaWQgPSBpZDtcbiAgICB0aGlzLl9idWxrID0gam9iLl9idWxrO1xuXG4gICAgLy8gZGVmYXVsdCBlcnJvciBoYW5kbGVyIHRvIGtlZXAgdGhlIGxhdGVzdCBlcnJvclxuICAgIHRoaXMub24oJ2Vycm9yJywgKGVycm9yKSA9PiAodGhpcy5fZXJyb3IgPSBlcnJvcikpO1xuXG4gICAgLy9cbiAgICAvLyBzZXR1cCBkYXRhIHN0cmVhbXNcbiAgICAvL1xuICAgIGNvbnN0IGNvbnZlcnRlck9wdGlvbnMgPSB7IG51bGxWYWx1ZTogJyNOL0EnIH07XG4gICAgY29uc3QgdXBsb2FkU3RyZWFtID0gKHRoaXMuX3VwbG9hZFN0cmVhbSA9IG5ldyBTZXJpYWxpemFibGUoKSk7XG4gICAgY29uc3QgdXBsb2FkRGF0YVN0cmVhbSA9IHVwbG9hZFN0cmVhbS5zdHJlYW0oJ2NzdicsIGNvbnZlcnRlck9wdGlvbnMpO1xuICAgIGNvbnN0IGRvd25sb2FkU3RyZWFtID0gKHRoaXMuX2Rvd25sb2FkU3RyZWFtID0gbmV3IFBhcnNhYmxlKCkpO1xuICAgIGNvbnN0IGRvd25sb2FkRGF0YVN0cmVhbSA9IGRvd25sb2FkU3RyZWFtLnN0cmVhbSgnY3N2JywgY29udmVydGVyT3B0aW9ucyk7XG5cbiAgICB0aGlzLm9uKCdmaW5pc2gnLCAoKSA9PiB1cGxvYWRTdHJlYW0uZW5kKCkpO1xuICAgIHVwbG9hZERhdGFTdHJlYW0ub25jZSgncmVhZGFibGUnLCBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICAvLyBlbnN1cmUgdGhlIGpvYiBpcyBvcGVuZWQgaW4gc2VydmVyIG9yIGpvYiBpZCBpcyBhbHJlYWR5IGFzc2lnbmVkXG4gICAgICAgIGF3YWl0IHRoaXMuam9iLnJlYWR5KCk7XG4gICAgICAgIC8vIHBpcGUgdXBsb2FkIGRhdGEgdG8gYmF0Y2ggQVBJIHJlcXVlc3Qgc3RyZWFtXG4gICAgICAgIHVwbG9hZERhdGFTdHJlYW0ucGlwZSh0aGlzLl9jcmVhdGVSZXF1ZXN0U3RyZWFtKCkpO1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gZHVwbGV4IGRhdGEgc3RyZWFtLCBvcGVuZWQgYWNjZXNzIHRvIEFQSSBwcm9ncmFtbWVycyBieSBCYXRjaCNzdHJlYW0oKVxuICAgIHRoaXMuX2RhdGFTdHJlYW0gPSBjb25jYXRTdHJlYW1zQXNEdXBsZXgoXG4gICAgICB1cGxvYWREYXRhU3RyZWFtLFxuICAgICAgZG93bmxvYWREYXRhU3RyZWFtLFxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogQ29ubmVjdCBiYXRjaCBBUEkgYW5kIGNyZWF0ZSBzdHJlYW0gaW5zdGFuY2Ugb2YgcmVxdWVzdC9yZXNwb25zZVxuICAgKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2NyZWF0ZVJlcXVlc3RTdHJlYW0oKSB7XG4gICAgY29uc3QgYnVsayA9IHRoaXMuX2J1bGs7XG4gICAgY29uc3QgbG9nZ2VyID0gYnVsay5fbG9nZ2VyO1xuICAgIGNvbnN0IHJlcSA9IGJ1bGsuX3JlcXVlc3Q8QmF0Y2hJbmZvUmVzcG9uc2U+KHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgcGF0aDogJy9qb2IvJyArIHRoaXMuam9iLmlkICsgJy9iYXRjaCcsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAndGV4dC9jc3YnLFxuICAgICAgfSxcbiAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL3htbCcsXG4gICAgfSk7XG4gICAgKGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHJlcTtcbiAgICAgICAgbG9nZ2VyLmRlYnVnKHJlcy5iYXRjaEluZm8pO1xuICAgICAgICB0aGlzLmlkID0gcmVzLmJhdGNoSW5mby5pZDtcbiAgICAgICAgdGhpcy5lbWl0KCdxdWV1ZScsIHJlcy5iYXRjaEluZm8pO1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgfVxuICAgIH0pKCk7XG4gICAgcmV0dXJuIHJlcS5zdHJlYW0oKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbXBsZW1lbnRhdGlvbiBvZiBXcml0YWJsZVxuICAgKi9cbiAgX3dyaXRlKHJlY29yZF86IFJlY29yZCwgZW5jOiBCdWZmZXJFbmNvZGluZywgY2I6ICgpID0+IHZvaWQpIHtcbiAgICBjb25zdCB7IElkLCB0eXBlLCBhdHRyaWJ1dGVzLCAuLi5ycmVjIH0gPSByZWNvcmRfO1xuICAgIGxldCByZWNvcmQ7XG4gICAgc3dpdGNoICh0aGlzLmpvYi5vcGVyYXRpb24pIHtcbiAgICAgIGNhc2UgJ2luc2VydCc6XG4gICAgICAgIHJlY29yZCA9IHJyZWM7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnZGVsZXRlJzpcbiAgICAgIGNhc2UgJ2hhcmREZWxldGUnOlxuICAgICAgICByZWNvcmQgPSB7IElkIH07XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmVjb3JkID0geyBJZCwgLi4ucnJlYyB9O1xuICAgIH1cbiAgICB0aGlzLl91cGxvYWRTdHJlYW0ud3JpdGUocmVjb3JkLCBlbmMsIGNiKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGR1cGxleCBzdHJlYW0gd2hpY2ggYWNjZXB0cyBDU1YgZGF0YSBpbnB1dCBhbmQgYmF0Y2ggcmVzdWx0IG91dHB1dFxuICAgKi9cbiAgc3RyZWFtKCkge1xuICAgIHJldHVybiB0aGlzLl9kYXRhU3RyZWFtO1xuICB9XG5cbiAgLyoqXG4gICAqIEV4ZWN1dGUgYmF0Y2ggb3BlcmF0aW9uXG4gICAqL1xuICBleGVjdXRlKGlucHV0Pzogc3RyaW5nIHwgUmVjb3JkW10gfCBSZWFkYWJsZSkge1xuICAgIC8vIGlmIGJhdGNoIGlzIGFscmVhZHkgZXhlY3V0ZWRcbiAgICBpZiAodGhpcy5fcmVzdWx0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0JhdGNoIGFscmVhZHkgZXhlY3V0ZWQuJyk7XG4gICAgfVxuXG4gICAgdGhpcy5fcmVzdWx0ID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5vbmNlKCdyZXNwb25zZScsIHJlc29sdmUpO1xuICAgICAgdGhpcy5vbmNlKCdlcnJvcicsIHJlamVjdCk7XG4gICAgfSk7XG5cbiAgICBpZiAoaXMubm9kZVN0cmVhbShpbnB1dCkpIHtcbiAgICAgIC8vIGlmIGlucHV0IGhhcyBzdHJlYW0uUmVhZGFibGUgaW50ZXJmYWNlXG4gICAgICBpbnB1dC5waXBlKHRoaXMuX2RhdGFTdHJlYW0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCByZWNvcmREYXRhID0gc3RydWN0dXJlZENsb25lKGlucHV0KTtcblxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkocmVjb3JkRGF0YSkpIHtcbiAgICAgICAgZm9yIChjb25zdCByZWNvcmQgb2YgcmVjb3JkRGF0YSkge1xuICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKHJlY29yZCkpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgcmVjb3JkW2tleV0gPT09ICdib29sZWFuJykge1xuICAgICAgICAgICAgICByZWNvcmRba2V5XSA9IFN0cmluZyhyZWNvcmRba2V5XSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMud3JpdGUocmVjb3JkKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmVuZCgpO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgcmVjb3JkRGF0YSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgdGhpcy5fZGF0YVN0cmVhbS53cml0ZShyZWNvcmREYXRhLCAndXRmOCcpO1xuICAgICAgICB0aGlzLl9kYXRhU3RyZWFtLmVuZCgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIHJldHVybiBCYXRjaCBpbnN0YW5jZSBmb3IgY2hhaW5pbmdcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIHJ1biA9IHRoaXMuZXhlY3V0ZTtcblxuICBleGVjID0gdGhpcy5leGVjdXRlO1xuXG4gIC8qKlxuICAgKiBQcm9taXNlL0ErIGludGVyZmFjZVxuICAgKiBEZWxlZ2F0ZSB0byBwcm9taXNlLCByZXR1cm4gcHJvbWlzZSBpbnN0YW5jZSBmb3IgYmF0Y2ggcmVzdWx0XG4gICAqL1xuICB0aGVuKFxuICAgIG9uUmVzb2x2ZWQ6IChyZXM6IEJhdGNoUmVzdWx0PE9wcj4pID0+IHZvaWQsXG4gICAgb25SZWplY3Q6IChlcnI6IGFueSkgPT4gdm9pZCxcbiAgKSB7XG4gICAgaWYgKCF0aGlzLl9yZXN1bHQpIHtcbiAgICAgIHRoaXMuZXhlY3V0ZSgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fcmVzdWx0IS50aGVuKG9uUmVzb2x2ZWQsIG9uUmVqZWN0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVjayB0aGUgbGF0ZXN0IGJhdGNoIHN0YXR1cyBpbiBzZXJ2ZXJcbiAgICovXG4gIGFzeW5jIGNoZWNrKCkge1xuICAgIGNvbnN0IGJ1bGsgPSB0aGlzLl9idWxrO1xuICAgIGNvbnN0IGxvZ2dlciA9IGJ1bGsuX2xvZ2dlcjtcbiAgICBjb25zdCBqb2JJZCA9IHRoaXMuam9iLmlkO1xuICAgIGNvbnN0IGJhdGNoSWQgPSB0aGlzLmlkO1xuXG4gICAgaWYgKCFqb2JJZCB8fCAhYmF0Y2hJZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdCYXRjaCBub3Qgc3RhcnRlZC4nKTtcbiAgICB9XG4gICAgY29uc3QgcmVzID0gYXdhaXQgYnVsay5fcmVxdWVzdDxCYXRjaEluZm9SZXNwb25zZT4oe1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIHBhdGg6ICcvam9iLycgKyBqb2JJZCArICcvYmF0Y2gvJyArIGJhdGNoSWQsXG4gICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi94bWwnLFxuICAgIH0pO1xuICAgIGxvZ2dlci5kZWJ1ZyhyZXMuYmF0Y2hJbmZvKTtcbiAgICByZXR1cm4gcmVzLmJhdGNoSW5mbztcbiAgfVxuXG4gIC8qKlxuICAgKiBQb2xsaW5nIHRoZSBiYXRjaCByZXN1bHQgYW5kIHJldHJpZXZlXG4gICAqL1xuICBwb2xsKGludGVydmFsOiBudW1iZXIsIHRpbWVvdXQ6IG51bWJlcikge1xuICAgIGNvbnN0IGpvYklkID0gdGhpcy5qb2IuaWQ7XG4gICAgY29uc3QgYmF0Y2hJZCA9IHRoaXMuaWQ7XG5cbiAgICBpZiAoIWpvYklkIHx8ICFiYXRjaElkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0JhdGNoIG5vdCBzdGFydGVkLicpO1xuICAgIH1cbiAgICBjb25zdCBzdGFydFRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgICBjb25zdCBlbmRUaW1lID0gc3RhcnRUaW1lICsgdGltZW91dDtcblxuICAgIGlmICh0aW1lb3V0ID09PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgUG9sbGluZ1RpbWVvdXRFcnJvcihcbiAgICAgICAgYFNraXBwaW5nIHBvbGxpbmcgYmVjYXVzZSBvZiB0aW1lb3V0ID0gMG1zLiBKb2IgSWQgPSAke2pvYklkfSB8IEJhdGNoIElkID0gJHtiYXRjaElkfWAsXG4gICAgICAgIGpvYklkLFxuICAgICAgICBiYXRjaElkLFxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBwb2xsID0gYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG4gICAgICBpZiAoZW5kVGltZSA8IG5vdykge1xuICAgICAgICBjb25zdCBlcnIgPSBuZXcgUG9sbGluZ1RpbWVvdXRFcnJvcihcbiAgICAgICAgICAnUG9sbGluZyB0aW1lIG91dC4gSm9iIElkID0gJyArIGpvYklkICsgJyAsIGJhdGNoIElkID0gJyArIGJhdGNoSWQsXG4gICAgICAgICAgam9iSWQsXG4gICAgICAgICAgYmF0Y2hJZCxcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGxldCByZXM7XG4gICAgICB0cnkge1xuICAgICAgICByZXMgPSBhd2FpdCB0aGlzLmNoZWNrKCk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChyZXMuc3RhdGUgPT09ICdGYWlsZWQnKSB7XG4gICAgICAgIGlmIChwYXJzZUludChyZXMubnVtYmVyUmVjb3Jkc1Byb2Nlc3NlZCwgMTApID4gMCkge1xuICAgICAgICAgIHRoaXMucmV0cmlldmUoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgbmV3IEVycm9yKHJlcy5zdGF0ZU1lc3NhZ2UpKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChyZXMuc3RhdGUgPT09ICdDb21wbGV0ZWQnKSB7XG4gICAgICAgIHRoaXMucmV0cmlldmUoKTtcbiAgICAgIH0gZWxzZSBpZiAocmVzLnN0YXRlID09PSAnTm90UHJvY2Vzc2VkJykge1xuICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgbmV3IEVycm9yKCdKb2IgaGFzIGJlZW4gYWJvcnRlZCcpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZW1pdCgnaW5Qcm9ncmVzcycsIHJlcyk7XG4gICAgICAgIHNldFRpbWVvdXQocG9sbCwgaW50ZXJ2YWwpO1xuICAgICAgfVxuICAgIH07XG4gICAgc2V0VGltZW91dChwb2xsLCBpbnRlcnZhbCk7XG4gIH1cblxuICAvKipcbiAgICogUmV0cmlldmUgYmF0Y2ggcmVzdWx0XG4gICAqL1xuICBhc3luYyByZXRyaWV2ZSgpIHtcbiAgICBjb25zdCBidWxrID0gdGhpcy5fYnVsaztcbiAgICBjb25zdCBqb2JJZCA9IHRoaXMuam9iLmlkO1xuICAgIGNvbnN0IGpvYiA9IHRoaXMuam9iO1xuICAgIGNvbnN0IGJhdGNoSWQgPSB0aGlzLmlkO1xuXG4gICAgaWYgKCFqb2JJZCB8fCAhYmF0Y2hJZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdCYXRjaCBub3Qgc3RhcnRlZC4nKTtcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGJ1bGsuX3JlcXVlc3Q8XG4gICAgICAgIEJ1bGtJbmdlc3RSZXN1bHRSZXNwb25zZSB8IEJ1bGtRdWVyeVJlc3VsdFJlc3BvbnNlXG4gICAgICA+KHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgcGF0aDogJy9qb2IvJyArIGpvYklkICsgJy9iYXRjaC8nICsgYmF0Y2hJZCArICcvcmVzdWx0JyxcbiAgICAgIH0pO1xuICAgICAgbGV0IHJlc3VsdHM6IEJ1bGtJbmdlc3RCYXRjaFJlc3VsdCB8IEJ1bGtRdWVyeUJhdGNoUmVzdWx0O1xuICAgICAgaWYgKGpvYi5vcGVyYXRpb24gPT09ICdxdWVyeScgfHwgam9iLm9wZXJhdGlvbiA9PT0gJ3F1ZXJ5QWxsJykge1xuICAgICAgICBjb25zdCByZXMgPSByZXNwIGFzIEJ1bGtRdWVyeVJlc3VsdFJlc3BvbnNlO1xuICAgICAgICBjb25zdCByZXN1bHRJZCA9IHJlc1sncmVzdWx0LWxpc3QnXS5yZXN1bHQ7XG4gICAgICAgIHJlc3VsdHMgPSAoQXJyYXkuaXNBcnJheShyZXN1bHRJZClcbiAgICAgICAgICA/IHJlc3VsdElkXG4gICAgICAgICAgOiBbcmVzdWx0SWRdXG4gICAgICAgICkubWFwKChpZCkgPT4gKHsgaWQsIGJhdGNoSWQsIGpvYklkIH0pKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IHJlc3AgYXMgQnVsa0luZ2VzdFJlc3VsdFJlc3BvbnNlO1xuICAgICAgICByZXN1bHRzID0gcmVzLm1hcCgocmV0KSA9PiAoe1xuICAgICAgICAgIGlkOiByZXQuSWQgfHwgbnVsbCxcbiAgICAgICAgICBzdWNjZXNzOiByZXQuU3VjY2VzcyA9PT0gJ3RydWUnLFxuICAgICAgICAgIGNyZWF0ZWQ6IHJldC5DcmVhdGVkID09PSAndHJ1ZScsXG4gICAgICAgICAgZXJyb3JzOiByZXQuRXJyb3IgPyBbcmV0LkVycm9yXSA6IFtdLFxuICAgICAgICB9KSk7XG4gICAgICB9XG4gICAgICB0aGlzLmVtaXQoJ3Jlc3BvbnNlJywgcmVzdWx0cyk7XG4gICAgICByZXR1cm4gcmVzdWx0cztcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBGZXRjaCBxdWVyeSBiYXRjaCByZXN1bHQgYXMgYSByZWNvcmQgc3RyZWFtXG4gICAqXG4gICAqIEBwYXJhbSB7U3RyaW5nfSByZXN1bHRJZCAtIFJlc3VsdCBpZFxuICAgKiBAcmV0dXJucyB7UmVjb3JkU3RyZWFtfSAtIFJlY29yZCBzdHJlYW0sIGNvbnZlcnRpYmxlIHRvIENTViBkYXRhIHN0cmVhbVxuICAgKi9cbiAgcHVibGljIHJlc3VsdChyZXN1bHRJZDogc3RyaW5nKTogUGFyc2FibGU8UmVjb3JkPiB7XG4gICAgY29uc3Qgam9iSWQgPSB0aGlzLmpvYi5pZDtcbiAgICBjb25zdCBiYXRjaElkID0gdGhpcy5pZDtcbiAgICBpZiAoIWpvYklkIHx8ICFiYXRjaElkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0JhdGNoIG5vdCBzdGFydGVkLicpO1xuICAgIH1cbiAgICBjb25zdCByZXN1bHRTdHJlYW0gPSBuZXcgUGFyc2FibGUoKTtcbiAgICBjb25zdCByZXN1bHREYXRhU3RyZWFtID0gcmVzdWx0U3RyZWFtLnN0cmVhbSgnY3N2Jyk7XG4gICAgdGhpcy5fYnVsa1xuICAgICAgLl9yZXF1ZXN0KHtcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgcGF0aDogJy9qb2IvJyArIGpvYklkICsgJy9iYXRjaC8nICsgYmF0Y2hJZCArICcvcmVzdWx0LycgKyByZXN1bHRJZCxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJyxcbiAgICAgIH0pXG4gICAgICAuc3RyZWFtKClcbiAgICAgIC5waXBlKHJlc3VsdERhdGFTdHJlYW0pO1xuICAgIHJldHVybiByZXN1bHRTdHJlYW07XG4gIH1cbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKipcbiAqXG4gKi9cbmNsYXNzIEJ1bGtBcGk8UyBleHRlbmRzIFNjaGVtYT4gZXh0ZW5kcyBIdHRwQXBpPFM+IHtcbiAgYmVmb3JlU2VuZChyZXF1ZXN0OiBIdHRwUmVxdWVzdCkge1xuICAgIHJlcXVlc3QuaGVhZGVycyA9IHtcbiAgICAgIC4uLnJlcXVlc3QuaGVhZGVycyxcbiAgICAgICdYLVNGREMtU0VTU0lPTic6IHRoaXMuX2Nvbm4uYWNjZXNzVG9rZW4gPz8gJycsXG4gICAgfTtcbiAgfVxuXG4gIGlzU2Vzc2lvbkV4cGlyZWQocmVzcG9uc2U6IEh0dHBSZXNwb25zZSkge1xuICAgIHJldHVybiAoXG4gICAgICByZXNwb25zZS5zdGF0dXNDb2RlID09PSA0MDAgJiZcbiAgICAgIHJlc3BvbnNlLmJvZHkuaW5jbHVkZXMoJzxleGNlcHRpb25Db2RlPkludmFsaWRTZXNzaW9uSWQ8L2V4Y2VwdGlvbkNvZGU+JylcbiAgICApO1xuICB9XG5cbiAgaGFzRXJyb3JJblJlc3BvbnNlQm9keShib2R5OiBhbnkpIHtcbiAgICByZXR1cm4gISFib2R5LmVycm9yO1xuICB9XG5cbiAgcGFyc2VFcnJvcihib2R5OiBhbnkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZXJyb3JDb2RlOiBib2R5LmVycm9yLmV4Y2VwdGlvbkNvZGUsXG4gICAgICBtZXNzYWdlOiBib2R5LmVycm9yLmV4Y2VwdGlvbk1lc3NhZ2UsXG4gICAgfTtcbiAgfVxufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cblxuLyoqXG4gKiBDbGFzcyBmb3IgQnVsayBBUElcbiAqXG4gKiBAY2xhc3NcbiAqL1xuZXhwb3J0IGNsYXNzIEJ1bGs8UyBleHRlbmRzIFNjaGVtYT4ge1xuICBwcml2YXRlIHJlYWRvbmx5IF9jb25uOiBDb25uZWN0aW9uPFM+O1xuICBwdWJsaWMgcmVhZG9ubHkgX2xvZ2dlcjogTG9nZ2VyO1xuXG4gIC8qKlxuICAgKiBQb2xsaW5nIGludGVydmFsIGluIG1pbGxpc2Vjb25kc1xuICAgKlxuICAgKiBEZWZhdWx0OiAxMDAwICgxIHNlY29uZClcbiAgICovXG4gIHB1YmxpYyBwb2xsSW50ZXJ2YWwgPSAxMDAwO1xuXG4gIC8qKlxuICAgKiBQb2xsaW5nIHRpbWVvdXQgaW4gbWlsbGlzZWNvbmRzXG4gICAqXG4gICAqIERlZmF1bHQ6IDMwMDAwICgzMCBzZWNvbmRzKVxuICAgKi9cbiAgcHVibGljIHBvbGxUaW1lb3V0ID0gMzAwMDA7XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25uOiBDb25uZWN0aW9uPFM+KSB7XG4gICAgdGhpcy5fY29ubiA9IGNvbm47XG4gICAgdGhpcy5fbG9nZ2VyID0gY29ubi5fbG9nZ2VyO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqL1xuICBwdWJsaWMgX3JlcXVlc3Q8VD4ocmVxdWVzdF86IEJ1bGtSZXF1ZXN0KSB7XG4gICAgY29uc3QgY29ubiA9IHRoaXMuX2Nvbm47XG4gICAgY29uc3QgeyBwYXRoLCByZXNwb25zZVR5cGUsIC4uLnJyZXEgfSA9IHJlcXVlc3RfO1xuICAgIGNvbnN0IGJhc2VVcmwgPSBbY29ubi5pbnN0YW5jZVVybCwgJ3NlcnZpY2VzL2FzeW5jJywgY29ubi52ZXJzaW9uXS5qb2luKFxuICAgICAgJy8nLFxuICAgICk7XG4gICAgY29uc3QgcmVxdWVzdCA9IHtcbiAgICAgIC4uLnJyZXEsXG4gICAgICB1cmw6IGJhc2VVcmwgKyBwYXRoLFxuICAgIH07XG4gICAgcmV0dXJuIG5ldyBCdWxrQXBpKHRoaXMuX2Nvbm4sIHsgcmVzcG9uc2VUeXBlIH0pLnJlcXVlc3Q8VD4ocmVxdWVzdCk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGFuZCBzdGFydCBidWxrbG9hZCBqb2IgYW5kIGJhdGNoXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHdpbGwgcmV0dXJuIGEgQmF0Y2ggaW5zdGFuY2UgKHdyaXRhYmxlIHN0cmVhbSlcbiAgICogd2hpY2ggeW91IGNhbiB3cml0ZSByZWNvcmRzIGludG8gYXMgYSBDU1Ygc3RyaW5nLlxuICAgKlxuICAgKiBCYXRjaCBhbHNvIGltcGxlbWVudHMgdGhlIGEgcHJvbWlzZSBpbnRlcmZhY2Ugc28geW91IGNhbiBgYXdhaXRgIHRoaXMgbWV0aG9kIHRvIGdldCB0aGUgam9iIHJlc3VsdHMuXG4gICAqXG4gICAqIEBleGFtcGxlXG4gICAqIC8vIEluc2VydCBhbiBhcnJheSBvZiByZWNvcmRzIGFuZCBnZXQgdGhlIGpvYiByZXN1bHRzXG4gICAqXG4gICAqIGNvbnN0IHJlcyA9IGF3YWl0IGNvbm5lY3Rpb24uYnVsay5sb2FkKCdBY2NvdW50JywgJ2luc2VydCcsIGFjY291bnRzKVxuICAgKlxuICAgKiBAZXhhbXBsZVxuICAgKiAvLyBJbnNlcnQgcmVjb3JkcyBmcm9tIGEgY3N2IGZpbGUgdXNpbmcgdGhlIHJldHVybmVkIGJhdGNoIHN0cmVhbVxuICAgKlxuICAgKiBjb25zdCBjc3ZGaWxlID0gZnMuY3JlYXRlUmVhZFN0cmVhbSgnYWNjb3VudHMuY3N2JylcbiAgICpcbiAgICogY29uc3QgYmF0Y2ggPSBjb25uLmJ1bGsubG9hZCgnQWNjb3VudCcsICdpbnNlcnQnKVxuICAgKiBcbiAgICogLy8gVGhlIGByZXNwb25zZWAgZXZlbnQgaXMgZW1pdHRlZCB3aGVuIHRoZSBqb2IgcmVzdWx0cyBhcmUgcmV0cmlldmVkXG4gICAqIGJhdGNoLm9uKCdyZXNwb25zZScsIHJlcyA9PiB7XG4gICAqICAgY29uc29sZS5sb2cocmVzKVxuICAgKiB9KVxuXG4gICAqIGNzdkZpbGUucGlwZShiYXRjaC5zdHJlYW0oKSlcbiAgICpcbiAgICpcbiAgICovXG4gIGxvYWQ8T3ByIGV4dGVuZHMgQnVsa09wZXJhdGlvbj4oXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIG9wZXJhdGlvbjogT3ByLFxuICAgIGlucHV0PzogUmVjb3JkW10gfCBSZWFkYWJsZSB8IHN0cmluZyxcbiAgKTogQmF0Y2g8UywgT3ByPjtcbiAgbG9hZDxPcHIgZXh0ZW5kcyBCdWxrT3BlcmF0aW9uPihcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgb3BlcmF0aW9uOiBPcHIsXG4gICAgb3B0aW9uc09ySW5wdXQ/OiBCdWxrT3B0aW9ucyB8IFJlY29yZFtdIHwgUmVhZGFibGUgfCBzdHJpbmcsXG4gICAgaW5wdXQ/OiBSZWNvcmRbXSB8IFJlYWRhYmxlIHwgc3RyaW5nLFxuICApOiBCYXRjaDxTLCBPcHI+O1xuICBsb2FkPE9wciBleHRlbmRzIEJ1bGtPcGVyYXRpb24+KFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBvcGVyYXRpb246IE9wcixcbiAgICBvcHRpb25zT3JJbnB1dD86IEJ1bGtPcHRpb25zIHwgUmVjb3JkW10gfCBSZWFkYWJsZSB8IHN0cmluZyxcbiAgICBpbnB1dD86IFJlY29yZFtdIHwgUmVhZGFibGUgfCBzdHJpbmcsXG4gICkge1xuICAgIGxldCBvcHRpb25zOiBCdWxrT3B0aW9ucyA9IHt9O1xuICAgIGlmIChcbiAgICAgIHR5cGVvZiBvcHRpb25zT3JJbnB1dCA9PT0gJ3N0cmluZycgfHxcbiAgICAgIEFycmF5LmlzQXJyYXkob3B0aW9uc09ySW5wdXQpIHx8XG4gICAgICBpcy5ub2RlU3RyZWFtKG9wdGlvbnNPcklucHV0KVxuICAgICkge1xuICAgICAgLy8gd2hlbiBvcHRpb25zIGlzIG5vdCBwbGFpbiBoYXNoIG9iamVjdCwgaXQgaXMgb21pdHRlZFxuICAgICAgaW5wdXQgPSBvcHRpb25zT3JJbnB1dDtcbiAgICB9IGVsc2Uge1xuICAgICAgb3B0aW9ucyA9IG9wdGlvbnNPcklucHV0IGFzIEJ1bGtPcHRpb25zO1xuICAgIH1cbiAgICBjb25zdCBqb2IgPSB0aGlzLmNyZWF0ZUpvYih0eXBlLCBvcGVyYXRpb24sIG9wdGlvbnMpO1xuICAgIGNvbnN0IGJhdGNoID0gam9iLmNyZWF0ZUJhdGNoKCk7XG4gICAgY29uc3QgY2xlYW51cCA9ICgpID0+IGpvYi5jbG9zZSgpO1xuICAgIGNvbnN0IGNsZWFudXBPbkVycm9yID0gKGVycjogRXJyb3IpID0+IHtcbiAgICAgIGlmIChlcnIubmFtZSAhPT0gJ1BvbGxpbmdUaW1lb3V0Jykge1xuICAgICAgICBjbGVhbnVwKCk7XG4gICAgICB9XG4gICAgfTtcbiAgICBiYXRjaC5vbigncmVzcG9uc2UnLCBjbGVhbnVwKTtcbiAgICBiYXRjaC5vbignZXJyb3InLCBjbGVhbnVwT25FcnJvcik7XG4gICAgYmF0Y2gub24oJ3F1ZXVlJywgKCkgPT4ge1xuICAgICAgYmF0Y2g/LnBvbGwodGhpcy5wb2xsSW50ZXJ2YWwsIHRoaXMucG9sbFRpbWVvdXQpO1xuICAgIH0pO1xuICAgIHJldHVybiBiYXRjaC5leGVjdXRlKGlucHV0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBFeGVjdXRlIGJ1bGsgcXVlcnkgYW5kIGdldCByZWNvcmQgc3RyZWFtXG4gICAqL1xuICBwdWJsaWMgYXN5bmMgcXVlcnkoc29xbDogc3RyaW5nKTogUHJvbWlzZTxQYXJzYWJsZTxSZWNvcmQ+PiB7XG4gICAgY29uc3QgbSA9IHNvcWwucmVwbGFjZSgvXFwoW1xcc1xcU10rXFwpL2csICcnKS5tYXRjaCgvRlJPTVxccysoXFx3KykvaSk7XG4gICAgaWYgKCFtKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdObyBzb2JqZWN0IHR5cGUgZm91bmQgaW4gcXVlcnksIG1heWJlIGNhdXNlZCBieSBpbnZhbGlkIFNPUUwuJyxcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IHR5cGUgPSBtWzFdO1xuICAgIGNvbnN0IHJlY29yZFN0cmVhbSA9IG5ldyBQYXJzYWJsZSgpO1xuICAgIGNvbnN0IGRhdGFTdHJlYW0gPSByZWNvcmRTdHJlYW0uc3RyZWFtKCdjc3YnKTtcblxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCB0aGlzLmxvYWQodHlwZSwgJ3F1ZXJ5Jywgc29xbCk7XG4gICAgY29uc3Qgc3RyZWFtcyA9IHJlc3VsdHMubWFwKChyZXN1bHQpID0+XG4gICAgICB0aGlzLmpvYihyZXN1bHQuam9iSWQpLmJhdGNoKHJlc3VsdC5iYXRjaElkKS5yZXN1bHQocmVzdWx0LmlkKS5zdHJlYW0oKSxcbiAgICApO1xuICAgIGpvaW5TdHJlYW1zKHN0cmVhbXMpLnBpcGUoZGF0YVN0cmVhbSk7XG5cbiAgICByZXR1cm4gcmVjb3JkU3RyZWFtO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIG5ldyBqb2IgaW5zdGFuY2VcbiAgICovXG4gIHB1YmxpYyBjcmVhdGVKb2I8T3ByIGV4dGVuZHMgQnVsa09wZXJhdGlvbj4oXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIG9wZXJhdGlvbjogT3ByLFxuICAgIG9wdGlvbnM6IEJ1bGtPcHRpb25zID0ge30sXG4gICkge1xuICAgIHJldHVybiBuZXcgSm9iKHRoaXMsIHR5cGUsIG9wZXJhdGlvbiwgb3B0aW9ucyk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IGEgam9iIGluc3RhbmNlIHNwZWNpZmllZCBieSBnaXZlbiBqb2IgSURcbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd9IGpvYklkIC0gSm9iIElEXG4gICAqIEByZXR1cm5zIHtCdWxrfkpvYn1cbiAgICovXG4gIHB1YmxpYyBqb2I8T3ByIGV4dGVuZHMgQnVsa09wZXJhdGlvbj4oam9iSWQ6IHN0cmluZykge1xuICAgIHJldHVybiBuZXcgSm9iPFMsIE9wcj4odGhpcywgbnVsbCwgbnVsbCwgbnVsbCwgam9iSWQpO1xuICB9XG59XG5cbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0qL1xuLypcbiAqIFJlZ2lzdGVyIGhvb2sgaW4gY29ubmVjdGlvbiBpbnN0YW50aWF0aW9uIGZvciBkeW5hbWljYWxseSBhZGRpbmcgdGhpcyBBUEkgbW9kdWxlIGZlYXR1cmVzXG4gKi9cbnJlZ2lzdGVyTW9kdWxlKCdidWxrJywgKGNvbm4pID0+IG5ldyBCdWxrKGNvbm4pKTtcblxuZXhwb3J0IGRlZmF1bHQgQnVsaztcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLFlBQVksUUFBUSxRQUFRO0FBQ3JDLFNBQTJCQyxRQUFRLFFBQVEsUUFBUTtBQUNuRCxPQUFPQyxXQUFXLE1BQU0sYUFBYTtBQUVyQyxTQUFTQyxZQUFZLEVBQUVDLFFBQVEsUUFBUSxrQkFBa0I7QUFDekQsT0FBT0MsT0FBTyxNQUFNLGFBQWE7QUFDakMsU0FBU0MsY0FBYyxRQUFRLFlBQVk7QUFFM0MsU0FBU0MscUJBQXFCLFFBQVEsZ0JBQWdCO0FBUXRELE9BQU9DLEVBQUUsTUFBTSxrQkFBa0I7O0FBRWpDOztBQW1CQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQWdHQTtBQUNBO0FBQ0E7QUFDQSxXQUFhQyxHQUFHLDBCQUFBQyxhQUFBO0VBY2Q7QUFDRjtBQUNBO0VBQ0UsU0FBQUQsSUFDRUUsSUFBYSxFQUNiQyxJQUFtQixFQUNuQkMsU0FBcUIsRUFDckJDLE9BQTJCLEVBQzNCQyxLQUFjLEVBQ2Q7SUFBQSxJQUFBQyxLQUFBO0lBQUFDLGVBQUEsT0FBQVIsR0FBQTtJQUNBTyxLQUFBLEdBQUFFLFVBQUEsT0FBQVQsR0FBQTtJQUNBTyxLQUFBLENBQUtHLEtBQUssR0FBR1IsSUFBSTtJQUNqQkssS0FBQSxDQUFLSixJQUFJLEdBQUdBLElBQUk7SUFDaEJJLEtBQUEsQ0FBS0gsU0FBUyxHQUFHQSxTQUFTO0lBQzFCRyxLQUFBLENBQUtGLE9BQU8sR0FBR0EsT0FBTyxJQUFJLENBQUMsQ0FBQztJQUM1QkUsS0FBQSxDQUFLSSxFQUFFLEdBQUdMLEtBQUssYUFBTEEsS0FBSyxjQUFMQSxLQUFLLEdBQUksSUFBSTtJQUN2QkMsS0FBQSxDQUFLSyxLQUFLLEdBQUdMLEtBQUEsQ0FBS0ksRUFBRSxHQUFHLE1BQU0sR0FBRyxTQUFTO0lBQ3pDSixLQUFBLENBQUtNLFFBQVEsR0FBRyxDQUFDLENBQUM7SUFDbEI7SUFDQU4sS0FBQSxDQUFLTyxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQUNDLEtBQUs7TUFBQSxPQUFNUixLQUFBLENBQUtTLE1BQU0sR0FBR0QsS0FBSztJQUFBLENBQUMsQ0FBQztJQUFDLE9BQUFSLEtBQUE7RUFDckQ7O0VBRUE7QUFDRjtBQUNBO0VBRkVVLFNBQUEsQ0FBQWpCLEdBQUEsRUFBQUMsYUFBQTtFQUFBLE9BQUFpQixZQUFBLENBQUFsQixHQUFBO0lBQUFtQixHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBQyxJQUFJQSxDQUFBLEVBQUc7TUFDTDtNQUNBLElBQUksQ0FBQyxJQUFJLENBQUNDLFFBQVEsRUFBRTtRQUNsQixJQUFJLENBQUNBLFFBQVEsR0FBRyxJQUFJLENBQUNDLEtBQUssQ0FBQyxDQUFDO01BQzlCO01BQ0EsT0FBTyxJQUFJLENBQUNELFFBQVE7SUFDdEI7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQUgsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQUksSUFBSUEsQ0FBQSxFQUFxQjtNQUFBLElBQUFDLE1BQUE7TUFDdkIsSUFBTXZCLElBQUksR0FBRyxJQUFJLENBQUNRLEtBQUs7TUFDdkIsSUFBTUwsT0FBTyxHQUFHLElBQUksQ0FBQ0EsT0FBTzs7TUFFNUI7TUFDQSxJQUFJLENBQUMsSUFBSSxDQUFDRixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUNDLFNBQVMsRUFBRTtRQUNqQyxNQUFNLElBQUlzQixLQUFLLENBQUMsZ0RBQWdELENBQUM7TUFDbkU7O01BRUE7TUFDQSxJQUFJLENBQUMsSUFBSSxDQUFDSixRQUFRLEVBQUU7UUFBQSxJQUFBSyxRQUFBLEVBQUFDLFNBQUEsRUFBQUMsU0FBQSxFQUFBQyxTQUFBLEVBQUFDLFNBQUE7UUFDbEIsSUFBSTNCLFVBQVMsR0FBRyxJQUFJLENBQUNBLFNBQVMsQ0FBQzRCLFdBQVcsQ0FBQyxDQUFDO1FBQzVDLElBQUk1QixVQUFTLEtBQUssWUFBWSxFQUFFO1VBQzlCQSxVQUFTLEdBQUcsWUFBWTtRQUMxQjtRQUNBLElBQUlBLFVBQVMsS0FBSyxVQUFVLEVBQUU7VUFDNUJBLFVBQVMsR0FBRyxVQUFVO1FBQ3hCO1FBQ0EsSUFBTTZCLElBQUksR0FBR0MscUJBQUEsQ0FBQVAsUUFBQSxHQUFBUSx1QkFBQSxDQUFBUCxTQUFBLEdBQUFPLHVCQUFBLENBQUFOLFNBQUEsR0FBQU0sdUJBQUEsQ0FBQUwsU0FBQSxHQUFBSyx1QkFBQSxDQUFBSixTQUFBLHNJQUFBSyxNQUFBLENBR0poQyxVQUFTLCtCQUFBaUMsSUFBQSxDQUFBTixTQUFBLEVBQ1osSUFBSSxDQUFDNUIsSUFBSSxvQkFBQWtDLElBQUEsQ0FBQVAsU0FBQSxFQUVqQnpCLE9BQU8sQ0FBQ2lDLFVBQVUsMkJBQUFGLE1BQUEsQ0FDVS9CLE9BQU8sQ0FBQ2lDLFVBQVUsOEJBQzFDLEVBQUUsV0FBQUQsSUFBQSxDQUFBUixTQUFBLEVBR054QixPQUFPLENBQUNrQyxlQUFlLHVCQUFBSCxNQUFBLENBQ0MvQixPQUFPLENBQUNrQyxlQUFlLDBCQUMzQyxFQUFFLFdBQUFGLElBQUEsQ0FBQVQsU0FBQSxFQUdOdkIsT0FBTyxDQUFDbUMsZ0JBQWdCLHdCQUFBSixNQUFBLENBQ0MvQixPQUFPLENBQUNtQyxnQkFBZ0IsMkJBQzdDLEVBQUUsNkRBQUFILElBQUEsQ0FBQVYsUUFJRyxDQUFDO1FBRVIsSUFBSSxDQUFDTCxRQUFRLEdBQUdtQixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQUMsU0FBQUMsUUFBQTtVQUFBLElBQUFDLEdBQUE7VUFBQSxPQUFBSCxtQkFBQSxDQUFBSSxJQUFBLFVBQUFDLFNBQUFDLFNBQUE7WUFBQSxrQkFBQUEsU0FBQSxDQUFBQyxJQUFBLEdBQUFELFNBQUEsQ0FBQUUsSUFBQTtjQUFBO2dCQUFBRixTQUFBLENBQUFDLElBQUE7Z0JBQUFELFNBQUEsQ0FBQUUsSUFBQTtnQkFBQSxPQUVLaEQsSUFBSSxDQUFDaUQsUUFBUSxDQUFrQjtrQkFDL0NDLE1BQU0sRUFBRSxNQUFNO2tCQUNkQyxJQUFJLEVBQUUsTUFBTTtrQkFDWnBCLElBQUksRUFBSkEsSUFBSTtrQkFDSnFCLE9BQU8sRUFBRTtvQkFDUCxjQUFjLEVBQUU7a0JBQ2xCLENBQUM7a0JBQ0RDLFlBQVksRUFBRTtnQkFDaEIsQ0FBQyxDQUFDO2NBQUE7Z0JBUklWLEdBQUcsR0FBQUcsU0FBQSxDQUFBUSxJQUFBO2dCQVNUL0IsTUFBSSxDQUFDZ0MsSUFBSSxDQUFDLE1BQU0sRUFBRVosR0FBRyxDQUFDYSxPQUFPLENBQUM7Z0JBQzlCakMsTUFBSSxDQUFDZCxFQUFFLEdBQUdrQyxHQUFHLENBQUNhLE9BQU8sQ0FBQy9DLEVBQUU7Z0JBQ3hCYyxNQUFJLENBQUNiLEtBQUssR0FBR2lDLEdBQUcsQ0FBQ2EsT0FBTyxDQUFDOUMsS0FBSztnQkFBQyxPQUFBb0MsU0FBQSxDQUFBVyxNQUFBLFdBQ3hCZCxHQUFHLENBQUNhLE9BQU87Y0FBQTtnQkFBQVYsU0FBQSxDQUFBQyxJQUFBO2dCQUFBRCxTQUFBLENBQUFZLEVBQUEsR0FBQVosU0FBQTtnQkFFbEJ2QixNQUFJLENBQUNnQyxJQUFJLENBQUMsT0FBTyxFQUFBVCxTQUFBLENBQUFZLEVBQUssQ0FBQztnQkFBQyxNQUFBWixTQUFBLENBQUFZLEVBQUE7Y0FBQTtjQUFBO2dCQUFBLE9BQUFaLFNBQUEsQ0FBQWEsSUFBQTtZQUFBO1VBQUEsR0FBQWpCLE9BQUE7UUFBQSxDQUczQixHQUFFLENBQUM7TUFDTjtNQUNBLE9BQU8sSUFBSSxDQUFDdEIsUUFBUTtJQUN0Qjs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBSCxHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBMEMsV0FBV0EsQ0FBQSxFQUFrQjtNQUFBLElBQUFDLE1BQUE7TUFDM0IsSUFBTUMsS0FBSyxHQUFHLElBQUlDLEtBQUssQ0FBQyxJQUFJLENBQUM7TUFDN0JELEtBQUssQ0FBQ2xELEVBQUUsQ0FBQyxPQUFPLEVBQUUsWUFBTTtRQUN0QmlELE1BQUksQ0FBQ2xELFFBQVEsQ0FBQ21ELEtBQUssQ0FBQ3JELEVBQUUsQ0FBRSxHQUFHcUQsS0FBSztNQUNsQyxDQUFDLENBQUM7TUFDRixPQUFPQSxLQUFLO0lBQ2Q7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQTdDLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUE0QyxLQUFLQSxDQUFDRSxPQUFlLEVBQWlCO01BQ3BDLElBQUlGLEtBQUssR0FBRyxJQUFJLENBQUNuRCxRQUFRLENBQUNxRCxPQUFPLENBQUM7TUFDbEMsSUFBSSxDQUFDRixLQUFLLEVBQUU7UUFDVkEsS0FBSyxHQUFHLElBQUlDLEtBQUssQ0FBQyxJQUFJLEVBQUVDLE9BQU8sQ0FBQztRQUNoQyxJQUFJLENBQUNyRCxRQUFRLENBQUNxRCxPQUFPLENBQUMsR0FBR0YsS0FBSztNQUNoQztNQUNBLE9BQU9BLEtBQUs7SUFDZDs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBN0MsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQUcsS0FBS0EsQ0FBQSxFQUFHO01BQUEsSUFBQTRDLE1BQUE7TUFDTixJQUFNakUsSUFBSSxHQUFHLElBQUksQ0FBQ1EsS0FBSztNQUN2QixJQUFNMEQsTUFBTSxHQUFHbEUsSUFBSSxDQUFDbUUsT0FBTztNQUUzQixJQUFJLENBQUMvQyxRQUFRLEdBQUdtQixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQUMsU0FBQTJCLFNBQUE7UUFBQSxJQUFBaEUsS0FBQSxFQUFBdUMsR0FBQTtRQUFBLE9BQUFILG1CQUFBLENBQUFJLElBQUEsVUFBQXlCLFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBdkIsSUFBQSxHQUFBdUIsU0FBQSxDQUFBdEIsSUFBQTtZQUFBO2NBQUFzQixTQUFBLENBQUF0QixJQUFBO2NBQUEsT0FDS2lCLE1BQUksQ0FBQ00sS0FBSyxDQUFDLENBQUM7WUFBQTtjQUExQm5FLEtBQUssR0FBQWtFLFNBQUEsQ0FBQWhCLElBQUE7Y0FBQWdCLFNBQUEsQ0FBQXRCLElBQUE7Y0FBQSxPQUNPaEQsSUFBSSxDQUFDaUQsUUFBUSxDQUFrQjtnQkFDL0NDLE1BQU0sRUFBRSxLQUFLO2dCQUNiQyxJQUFJLEVBQUUsT0FBTyxHQUFHL0MsS0FBSztnQkFDckJpRCxZQUFZLEVBQUU7Y0FDaEIsQ0FBQyxDQUFDO1lBQUE7Y0FKSVYsR0FBRyxHQUFBMkIsU0FBQSxDQUFBaEIsSUFBQTtjQUtUWSxNQUFNLENBQUNNLEtBQUssQ0FBQzdCLEdBQUcsQ0FBQ2EsT0FBTyxDQUFDO2NBQ3pCUyxNQUFJLENBQUN4RCxFQUFFLEdBQUdrQyxHQUFHLENBQUNhLE9BQU8sQ0FBQy9DLEVBQUU7Y0FDeEJ3RCxNQUFJLENBQUNoRSxJQUFJLEdBQUcwQyxHQUFHLENBQUNhLE9BQU8sQ0FBQ2lCLE1BQU07Y0FDOUJSLE1BQUksQ0FBQy9ELFNBQVMsR0FBR3lDLEdBQUcsQ0FBQ2EsT0FBTyxDQUFDdEQsU0FBZ0I7Y0FDN0MrRCxNQUFJLENBQUN2RCxLQUFLLEdBQUdpQyxHQUFHLENBQUNhLE9BQU8sQ0FBQzlDLEtBQUs7Y0FBQyxPQUFBNEQsU0FBQSxDQUFBYixNQUFBLFdBQ3hCZCxHQUFHLENBQUNhLE9BQU87WUFBQTtZQUFBO2NBQUEsT0FBQWMsU0FBQSxDQUFBWCxJQUFBO1VBQUE7UUFBQSxHQUFBUyxRQUFBO01BQUEsQ0FDbkIsR0FBRSxDQUFDO01BRUosT0FBTyxJQUFJLENBQUNoRCxRQUFRO0lBQ3RCOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFILEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUFxRCxLQUFLQSxDQUFBLEVBQW9CO01BQ3ZCLE9BQU8sSUFBSSxDQUFDOUQsRUFBRSxHQUNWaUUsUUFBQSxDQUFRQyxPQUFPLENBQUMsSUFBSSxDQUFDbEUsRUFBRSxDQUFDLEdBQ3hCLElBQUksQ0FBQ2EsSUFBSSxDQUFDLENBQUMsQ0FBQ3NELElBQUksQ0FBQyxVQUFBQyxLQUFBO1FBQUEsSUFBR3BFLEVBQUUsR0FBQW9FLEtBQUEsQ0FBRnBFLEVBQUU7UUFBQSxPQUFPQSxFQUFFO01BQUEsRUFBQztJQUN0Qzs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBUSxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBNEQsS0FBQSxHQUFBdkMsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUFzQyxTQUFBO1FBQUEsSUFBQS9FLElBQUEsRUFBQWtFLE1BQUEsRUFBQTlELEtBQUEsRUFBQXVDLEdBQUEsRUFBQXFDLGFBQUE7UUFBQSxPQUFBeEMsbUJBQUEsQ0FBQUksSUFBQSxVQUFBcUMsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFuQyxJQUFBLEdBQUFtQyxTQUFBLENBQUFsQyxJQUFBO1lBQUE7Y0FDUWhELElBQUksR0FBRyxJQUFJLENBQUNRLEtBQUs7Y0FDakIwRCxNQUFNLEdBQUdsRSxJQUFJLENBQUNtRSxPQUFPO2NBQUFlLFNBQUEsQ0FBQWxDLElBQUE7Y0FBQSxPQUNQLElBQUksQ0FBQ3VCLEtBQUssQ0FBQyxDQUFDO1lBQUE7Y0FBMUJuRSxLQUFLLEdBQUE4RSxTQUFBLENBQUE1QixJQUFBO2NBQUE0QixTQUFBLENBQUFsQyxJQUFBO2NBQUEsT0FDT2hELElBQUksQ0FBQ2lELFFBQVEsQ0FBd0I7Z0JBQ3JEQyxNQUFNLEVBQUUsS0FBSztnQkFDYkMsSUFBSSxFQUFFLE9BQU8sR0FBRy9DLEtBQUssR0FBRyxRQUFRO2dCQUNoQ2lELFlBQVksRUFBRTtjQUNoQixDQUFDLENBQUM7WUFBQTtjQUpJVixHQUFHLEdBQUF1QyxTQUFBLENBQUE1QixJQUFBO2NBS1RZLE1BQU0sQ0FBQ00sS0FBSyxDQUFDN0IsR0FBRyxDQUFDcUMsYUFBYSxDQUFDRyxTQUFTLENBQUM7Y0FDbkNILGFBQWEsR0FBR0ksY0FBQSxDQUFjekMsR0FBRyxDQUFDcUMsYUFBYSxDQUFDRyxTQUFTLENBQUMsR0FDNUR4QyxHQUFHLENBQUNxQyxhQUFhLENBQUNHLFNBQVMsR0FDM0IsQ0FBQ3hDLEdBQUcsQ0FBQ3FDLGFBQWEsQ0FBQ0csU0FBUyxDQUFDO2NBQUEsT0FBQUQsU0FBQSxDQUFBekIsTUFBQSxXQUMxQnVCLGFBQWE7WUFBQTtZQUFBO2NBQUEsT0FBQUUsU0FBQSxDQUFBdkIsSUFBQTtVQUFBO1FBQUEsR0FBQW9CLFFBQUE7TUFBQSxDQUNyQjtNQUFBLFNBZEtNLElBQUlBLENBQUE7UUFBQSxPQUFBUCxLQUFBLENBQUFRLEtBQUEsT0FBQUMsU0FBQTtNQUFBO01BQUEsT0FBSkYsSUFBSTtJQUFBO0lBZ0JWO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQXBFLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFzRSxNQUFBLEdBQUFqRCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQWdELFNBQUE7UUFBQSxJQUFBakMsT0FBQTtRQUFBLE9BQUFoQixtQkFBQSxDQUFBSSxJQUFBLFVBQUE4QyxVQUFBQyxTQUFBO1VBQUEsa0JBQUFBLFNBQUEsQ0FBQTVDLElBQUEsR0FBQTRDLFNBQUEsQ0FBQTNDLElBQUE7WUFBQTtjQUFBLElBQ08sSUFBSSxDQUFDdkMsRUFBRTtnQkFBQWtGLFNBQUEsQ0FBQTNDLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE9BQUEyQyxTQUFBLENBQUFsQyxNQUFBO1lBQUE7Y0FBQWtDLFNBQUEsQ0FBQTVDLElBQUE7Y0FBQTRDLFNBQUEsQ0FBQTNDLElBQUE7Y0FBQSxPQUlZLElBQUksQ0FBQzRDLFlBQVksQ0FBQyxRQUFRLENBQUM7WUFBQTtjQUEzQ3BDLE9BQU8sR0FBQW1DLFNBQUEsQ0FBQXJDLElBQUE7Y0FDYixJQUFJLENBQUM3QyxFQUFFLEdBQUcsSUFBSTtjQUNkLElBQUksQ0FBQzhDLElBQUksQ0FBQyxPQUFPLEVBQUVDLE9BQU8sQ0FBQztjQUFDLE9BQUFtQyxTQUFBLENBQUFsQyxNQUFBLFdBQ3JCRCxPQUFPO1lBQUE7Y0FBQW1DLFNBQUEsQ0FBQTVDLElBQUE7Y0FBQTRDLFNBQUEsQ0FBQWpDLEVBQUEsR0FBQWlDLFNBQUE7Y0FFZCxJQUFJLENBQUNwQyxJQUFJLENBQUMsT0FBTyxFQUFBb0MsU0FBQSxDQUFBakMsRUFBSyxDQUFDO2NBQUMsTUFBQWlDLFNBQUEsQ0FBQWpDLEVBQUE7WUFBQTtZQUFBO2NBQUEsT0FBQWlDLFNBQUEsQ0FBQWhDLElBQUE7VUFBQTtRQUFBLEdBQUE4QixRQUFBO01BQUEsQ0FHM0I7TUFBQSxTQWJLSSxLQUFLQSxDQUFBO1FBQUEsT0FBQUwsTUFBQSxDQUFBRixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQUxNLEtBQUs7SUFBQTtJQWVYO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQTVFLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUE0RSxNQUFBLEdBQUF2RCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQXNELFNBQUE7UUFBQSxJQUFBdkMsT0FBQTtRQUFBLE9BQUFoQixtQkFBQSxDQUFBSSxJQUFBLFVBQUFvRCxVQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQWxELElBQUEsR0FBQWtELFVBQUEsQ0FBQWpELElBQUE7WUFBQTtjQUFBLElBQ08sSUFBSSxDQUFDdkMsRUFBRTtnQkFBQXdGLFVBQUEsQ0FBQWpELElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE9BQUFpRCxVQUFBLENBQUF4QyxNQUFBO1lBQUE7Y0FBQXdDLFVBQUEsQ0FBQWxELElBQUE7Y0FBQWtELFVBQUEsQ0FBQWpELElBQUE7Y0FBQSxPQUlZLElBQUksQ0FBQzRDLFlBQVksQ0FBQyxTQUFTLENBQUM7WUFBQTtjQUE1Q3BDLE9BQU8sR0FBQXlDLFVBQUEsQ0FBQTNDLElBQUE7Y0FDYixJQUFJLENBQUM3QyxFQUFFLEdBQUcsSUFBSTtjQUNkLElBQUksQ0FBQzhDLElBQUksQ0FBQyxPQUFPLEVBQUVDLE9BQU8sQ0FBQztjQUFDLE9BQUF5QyxVQUFBLENBQUF4QyxNQUFBLFdBQ3JCRCxPQUFPO1lBQUE7Y0FBQXlDLFVBQUEsQ0FBQWxELElBQUE7Y0FBQWtELFVBQUEsQ0FBQXZDLEVBQUEsR0FBQXVDLFVBQUE7Y0FFZCxJQUFJLENBQUMxQyxJQUFJLENBQUMsT0FBTyxFQUFBMEMsVUFBQSxDQUFBdkMsRUFBSyxDQUFDO2NBQUMsTUFBQXVDLFVBQUEsQ0FBQXZDLEVBQUE7WUFBQTtZQUFBO2NBQUEsT0FBQXVDLFVBQUEsQ0FBQXRDLElBQUE7VUFBQTtRQUFBLEdBQUFvQyxRQUFBO01BQUEsQ0FHM0I7TUFBQSxTQWJLRyxLQUFLQSxDQUFBO1FBQUEsT0FBQUosTUFBQSxDQUFBUixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQUxXLEtBQUs7SUFBQTtJQWVYO0FBQ0Y7QUFDQTtJQUZFO0VBQUE7SUFBQWpGLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFpRixhQUFBLEdBQUE1RCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQTJELFNBQW1CMUYsS0FBZTtRQUFBLElBQUEyRixNQUFBO1FBQUEsSUFBQXJHLElBQUEsRUFBQWtFLE1BQUE7UUFBQSxPQUFBMUIsbUJBQUEsQ0FBQUksSUFBQSxVQUFBMEQsVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUF4RCxJQUFBLEdBQUF3RCxVQUFBLENBQUF2RCxJQUFBO1lBQUE7Y0FDMUJoRCxJQUFJLEdBQUcsSUFBSSxDQUFDUSxLQUFLO2NBQ2pCMEQsTUFBTSxHQUFHbEUsSUFBSSxDQUFDbUUsT0FBTztjQUUzQixJQUFJLENBQUMvQyxRQUFRLEdBQUdtQixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQUMsU0FBQStELFNBQUE7Z0JBQUEsSUFBQUMsVUFBQTtnQkFBQSxJQUFBckcsS0FBQSxFQUFBMkIsSUFBQSxFQUFBWSxHQUFBO2dCQUFBLE9BQUFILG1CQUFBLENBQUFJLElBQUEsVUFBQThELFVBQUFDLFVBQUE7a0JBQUEsa0JBQUFBLFVBQUEsQ0FBQTVELElBQUEsR0FBQTRELFVBQUEsQ0FBQTNELElBQUE7b0JBQUE7c0JBQUEyRCxVQUFBLENBQUEzRCxJQUFBO3NCQUFBLE9BQ0txRCxNQUFJLENBQUM5QixLQUFLLENBQUMsQ0FBQztvQkFBQTtzQkFBMUJuRSxLQUFLLEdBQUF1RyxVQUFBLENBQUFyRCxJQUFBO3NCQUNMdkIsSUFBSSxHQUFHQyxxQkFBQSxDQUFBeUUsVUFBQSxvSUFBQXZFLE1BQUEsQ0FHUnhCLEtBQUssbUNBQUF5QixJQUFBLENBQUFzRSxVQUVILENBQUM7c0JBQUFFLFVBQUEsQ0FBQTNELElBQUE7c0JBQUEsT0FDVWhELElBQUksQ0FBQ2lELFFBQVEsQ0FBa0I7d0JBQy9DQyxNQUFNLEVBQUUsTUFBTTt3QkFDZEMsSUFBSSxFQUFFLE9BQU8sR0FBRy9DLEtBQUs7d0JBQ3JCMkIsSUFBSSxFQUFFQSxJQUFJO3dCQUNWcUIsT0FBTyxFQUFFOzBCQUNQLGNBQWMsRUFBRTt3QkFDbEIsQ0FBQzt3QkFDREMsWUFBWSxFQUFFO3NCQUNoQixDQUFDLENBQUM7b0JBQUE7c0JBUklWLEdBQUcsR0FBQWdFLFVBQUEsQ0FBQXJELElBQUE7c0JBU1RZLE1BQU0sQ0FBQ00sS0FBSyxDQUFDN0IsR0FBRyxDQUFDYSxPQUFPLENBQUM7c0JBQ3pCNkMsTUFBSSxDQUFDM0YsS0FBSyxHQUFHaUMsR0FBRyxDQUFDYSxPQUFPLENBQUM5QyxLQUFLO3NCQUFDLE9BQUFpRyxVQUFBLENBQUFsRCxNQUFBLFdBQ3hCZCxHQUFHLENBQUNhLE9BQU87b0JBQUE7b0JBQUE7c0JBQUEsT0FBQW1ELFVBQUEsQ0FBQWhELElBQUE7a0JBQUE7Z0JBQUEsR0FBQTZDLFFBQUE7Y0FBQSxDQUNuQixHQUFFLENBQUM7Y0FBQyxPQUFBRCxVQUFBLENBQUE5QyxNQUFBLFdBQ0UsSUFBSSxDQUFDckMsUUFBUTtZQUFBO1lBQUE7Y0FBQSxPQUFBbUYsVUFBQSxDQUFBNUMsSUFBQTtVQUFBO1FBQUEsR0FBQXlDLFFBQUE7TUFBQSxDQUNyQjtNQUFBLFNBMUJLUixZQUFZQSxDQUFBZ0IsRUFBQTtRQUFBLE9BQUFULGFBQUEsQ0FBQWIsS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFaSyxZQUFZO0lBQUE7RUFBQTtBQUFBLEVBcE9WdkcsWUFBWTs7QUFpUXRCO0FBQUEsSUFDTXdILG1CQUFtQiwwQkFBQUMsTUFBQTtFQUl2QjtBQUNGO0FBQ0E7RUFDRSxTQUFBRCxvQkFBWUUsT0FBZSxFQUFFM0csS0FBYSxFQUFFNEQsT0FBZSxFQUFFO0lBQUEsSUFBQWdELE1BQUE7SUFBQTFHLGVBQUEsT0FBQXVHLG1CQUFBO0lBQzNERyxNQUFBLEdBQUF6RyxVQUFBLE9BQUFzRyxtQkFBQSxHQUFNRSxPQUFPO0lBQ2JDLE1BQUEsQ0FBS0MsSUFBSSxHQUFHLGdCQUFnQjtJQUM1QkQsTUFBQSxDQUFLNUcsS0FBSyxHQUFHQSxLQUFLO0lBQ2xCNEcsTUFBQSxDQUFLaEQsT0FBTyxHQUFHQSxPQUFPO0lBQUMsT0FBQWdELE1BQUE7RUFDekI7RUFBQ2pHLFNBQUEsQ0FBQThGLG1CQUFBLEVBQUFDLE1BQUE7RUFBQSxPQUFBOUYsWUFBQSxDQUFBNkYsbUJBQUE7QUFBQSxlQUFBSyxnQkFBQSxDQVorQjFGLEtBQUs7QUFldkM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFhdUMsS0FBSywwQkFBQW9ELFNBQUE7RUFhaEI7QUFDRjtBQUNBO0VBQ0UsU0FBQXBELE1BQVlxRCxHQUFnQixFQUFFM0csRUFBVyxFQUFFO0lBQUEsSUFBQTRHLE1BQUE7SUFBQS9HLGVBQUEsT0FBQXlELEtBQUE7SUFDekNzRCxNQUFBLEdBQUE5RyxVQUFBLE9BQUF3RCxLQUFBLEdBQU07TUFBRXVELFVBQVUsRUFBRTtJQUFLLENBQUM7SUFBRUMsZUFBQSxDQUFBRixNQUFBLFNBb0l4QkEsTUFBQSxDQUFLRyxPQUFPO0lBQUFELGVBQUEsQ0FBQUYsTUFBQSxVQUVYQSxNQUFBLENBQUtHLE9BQU87SUFySWpCSCxNQUFBLENBQUtELEdBQUcsR0FBR0EsR0FBRztJQUNkQyxNQUFBLENBQUs1RyxFQUFFLEdBQUdBLEVBQUU7SUFDWjRHLE1BQUEsQ0FBSzdHLEtBQUssR0FBRzRHLEdBQUcsQ0FBQzVHLEtBQUs7O0lBRXRCO0lBQ0E2RyxNQUFBLENBQUt6RyxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQUNDLEtBQUs7TUFBQSxPQUFNd0csTUFBQSxDQUFLdkcsTUFBTSxHQUFHRCxLQUFLO0lBQUEsQ0FBQyxDQUFDOztJQUVsRDtJQUNBO0lBQ0E7SUFDQSxJQUFNNEcsZ0JBQWdCLEdBQUc7TUFBRUMsU0FBUyxFQUFFO0lBQU8sQ0FBQztJQUM5QyxJQUFNQyxZQUFZLEdBQUlOLE1BQUEsQ0FBS08sYUFBYSxHQUFHLElBQUlwSSxZQUFZLENBQUMsQ0FBRTtJQUM5RCxJQUFNcUksZ0JBQWdCLEdBQUdGLFlBQVksQ0FBQ0csTUFBTSxDQUFDLEtBQUssRUFBRUwsZ0JBQWdCLENBQUM7SUFDckUsSUFBTU0sY0FBYyxHQUFJVixNQUFBLENBQUtXLGVBQWUsR0FBRyxJQUFJdkksUUFBUSxDQUFDLENBQUU7SUFDOUQsSUFBTXdJLGtCQUFrQixHQUFHRixjQUFjLENBQUNELE1BQU0sQ0FBQyxLQUFLLEVBQUVMLGdCQUFnQixDQUFDO0lBRXpFSixNQUFBLENBQUt6RyxFQUFFLENBQUMsUUFBUSxFQUFFO01BQUEsT0FBTStHLFlBQVksQ0FBQ08sR0FBRyxDQUFDLENBQUM7SUFBQSxFQUFDO0lBQzNDTCxnQkFBZ0IsQ0FBQ00sSUFBSSxDQUFDLFVBQVUsZUFBQTVGLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FBRSxTQUFBMkYsU0FBQTtNQUFBLE9BQUE1RixtQkFBQSxDQUFBSSxJQUFBLFVBQUF5RixVQUFBQyxVQUFBO1FBQUEsa0JBQUFBLFVBQUEsQ0FBQXZGLElBQUEsR0FBQXVGLFVBQUEsQ0FBQXRGLElBQUE7VUFBQTtZQUFBc0YsVUFBQSxDQUFBdkYsSUFBQTtZQUFBdUYsVUFBQSxDQUFBdEYsSUFBQTtZQUFBLE9BR3hCcUUsTUFBQSxDQUFLRCxHQUFHLENBQUM3QyxLQUFLLENBQUMsQ0FBQztVQUFBO1lBQ3RCO1lBQ0FzRCxnQkFBZ0IsQ0FBQ1UsSUFBSSxDQUFDbEIsTUFBQSxDQUFLbUIsb0JBQW9CLENBQUMsQ0FBQyxDQUFDO1lBQUNGLFVBQUEsQ0FBQXRGLElBQUE7WUFBQTtVQUFBO1lBQUFzRixVQUFBLENBQUF2RixJQUFBO1lBQUF1RixVQUFBLENBQUE1RSxFQUFBLEdBQUE0RSxVQUFBO1lBRW5EakIsTUFBQSxDQUFLOUQsSUFBSSxDQUFDLE9BQU8sRUFBQStFLFVBQUEsQ0FBQTVFLEVBQUssQ0FBQztVQUFDO1VBQUE7WUFBQSxPQUFBNEUsVUFBQSxDQUFBM0UsSUFBQTtRQUFBO01BQUEsR0FBQXlFLFFBQUE7SUFBQSxDQUUzQixHQUFDOztJQUVGO0lBQ0FmLE1BQUEsQ0FBS29CLFdBQVcsR0FBRzdJLHFCQUFxQixDQUN0Q2lJLGdCQUFnQixFQUNoQkksa0JBQ0YsQ0FBQztJQUFDLE9BQUFaLE1BQUE7RUFDSjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0VBSkV0RyxTQUFBLENBQUFnRCxLQUFBLEVBQUFvRCxTQUFBO0VBQUEsT0FBQW5HLFlBQUEsQ0FBQStDLEtBQUE7SUFBQTlDLEdBQUE7SUFBQUMsS0FBQSxFQUtBLFNBQUFzSCxvQkFBb0JBLENBQUEsRUFBRztNQUFBLElBQUFFLE1BQUE7TUFDckIsSUFBTTFJLElBQUksR0FBRyxJQUFJLENBQUNRLEtBQUs7TUFDdkIsSUFBTTBELE1BQU0sR0FBR2xFLElBQUksQ0FBQ21FLE9BQU87TUFDM0IsSUFBTXdFLEdBQUcsR0FBRzNJLElBQUksQ0FBQ2lELFFBQVEsQ0FBb0I7UUFDM0NDLE1BQU0sRUFBRSxNQUFNO1FBQ2RDLElBQUksRUFBRSxPQUFPLEdBQUcsSUFBSSxDQUFDaUUsR0FBRyxDQUFDM0csRUFBRSxHQUFHLFFBQVE7UUFDdEMyQyxPQUFPLEVBQUU7VUFDUCxjQUFjLEVBQUU7UUFDbEIsQ0FBQztRQUNEQyxZQUFZLEVBQUU7TUFDaEIsQ0FBQyxDQUFDO01BQ0ZkLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FBQyxTQUFBbUcsU0FBQTtRQUFBLElBQUFqRyxHQUFBO1FBQUEsT0FBQUgsbUJBQUEsQ0FBQUksSUFBQSxVQUFBaUcsVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUEvRixJQUFBLEdBQUErRixVQUFBLENBQUE5RixJQUFBO1lBQUE7Y0FBQThGLFVBQUEsQ0FBQS9GLElBQUE7Y0FBQStGLFVBQUEsQ0FBQTlGLElBQUE7Y0FBQSxPQUVxQjJGLEdBQUc7WUFBQTtjQUFmaEcsR0FBRyxHQUFBbUcsVUFBQSxDQUFBeEYsSUFBQTtjQUNUWSxNQUFNLENBQUNNLEtBQUssQ0FBQzdCLEdBQUcsQ0FBQ3dDLFNBQVMsQ0FBQztjQUMzQnVELE1BQUksQ0FBQ2pJLEVBQUUsR0FBR2tDLEdBQUcsQ0FBQ3dDLFNBQVMsQ0FBQzFFLEVBQUU7Y0FDMUJpSSxNQUFJLENBQUNuRixJQUFJLENBQUMsT0FBTyxFQUFFWixHQUFHLENBQUN3QyxTQUFTLENBQUM7Y0FBQzJELFVBQUEsQ0FBQTlGLElBQUE7Y0FBQTtZQUFBO2NBQUE4RixVQUFBLENBQUEvRixJQUFBO2NBQUErRixVQUFBLENBQUFwRixFQUFBLEdBQUFvRixVQUFBO2NBRWxDSixNQUFJLENBQUNuRixJQUFJLENBQUMsT0FBTyxFQUFBdUYsVUFBQSxDQUFBcEYsRUFBSyxDQUFDO1lBQUM7WUFBQTtjQUFBLE9BQUFvRixVQUFBLENBQUFuRixJQUFBO1VBQUE7UUFBQSxHQUFBaUYsUUFBQTtNQUFBLENBRTNCLEdBQUUsQ0FBQztNQUNKLE9BQU9ELEdBQUcsQ0FBQ2IsTUFBTSxDQUFDLENBQUM7SUFDckI7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQTdHLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUE2SCxNQUFNQSxDQUFDQyxPQUFlLEVBQUVDLEdBQW1CLEVBQUVDLEVBQWMsRUFBRTtNQUMzRCxJQUFRQyxFQUFFLEdBQWdDSCxPQUFPLENBQXpDRyxFQUFFO1FBQUVsSixJQUFJLEdBQTBCK0ksT0FBTyxDQUFyQy9JLElBQUk7UUFBRW1KLFVBQVUsR0FBY0osT0FBTyxDQUEvQkksVUFBVTtRQUFLQyxJQUFJLEdBQUFDLHdCQUFBLENBQUtOLE9BQU8sRUFBQU8sU0FBQTtNQUNqRCxJQUFJQyxNQUFNO01BQ1YsUUFBUSxJQUFJLENBQUNwQyxHQUFHLENBQUNsSCxTQUFTO1FBQ3hCLEtBQUssUUFBUTtVQUNYc0osTUFBTSxHQUFHSCxJQUFJO1VBQ2I7UUFDRixLQUFLLFFBQVE7UUFDYixLQUFLLFlBQVk7VUFDZkcsTUFBTSxHQUFHO1lBQUVMLEVBQUUsRUFBRkE7VUFBRyxDQUFDO1VBQ2Y7UUFDRjtVQUNFSyxNQUFNLEdBQUFDLGFBQUE7WUFBS04sRUFBRSxFQUFGQTtVQUFFLEdBQUtFLElBQUksQ0FBRTtNQUM1QjtNQUNBLElBQUksQ0FBQ3pCLGFBQWEsQ0FBQzhCLEtBQUssQ0FBQ0YsTUFBTSxFQUFFUCxHQUFHLEVBQUVDLEVBQUUsQ0FBQztJQUMzQzs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBakksR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQTRHLE1BQU1BLENBQUEsRUFBRztNQUNQLE9BQU8sSUFBSSxDQUFDVyxXQUFXO0lBQ3pCOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUF4SCxHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBc0csT0FBT0EsQ0FBQ21DLEtBQW9DLEVBQUU7TUFBQSxJQUFBQyxNQUFBO01BQzVDO01BQ0EsSUFBSSxJQUFJLENBQUNDLE9BQU8sRUFBRTtRQUNoQixNQUFNLElBQUlySSxLQUFLLENBQUMseUJBQXlCLENBQUM7TUFDNUM7TUFFQSxJQUFJLENBQUNxSSxPQUFPLEdBQUcsSUFBQW5GLFFBQUEsQ0FBWSxVQUFDQyxPQUFPLEVBQUVtRixNQUFNLEVBQUs7UUFDOUNGLE1BQUksQ0FBQ3pCLElBQUksQ0FBQyxVQUFVLEVBQUV4RCxPQUFPLENBQUM7UUFDOUJpRixNQUFJLENBQUN6QixJQUFJLENBQUMsT0FBTyxFQUFFMkIsTUFBTSxDQUFDO01BQzVCLENBQUMsQ0FBQztNQUVGLElBQUlqSyxFQUFFLENBQUNrSyxVQUFVLENBQUNKLEtBQUssQ0FBQyxFQUFFO1FBQ3hCO1FBQ0FBLEtBQUssQ0FBQ3BCLElBQUksQ0FBQyxJQUFJLENBQUNFLFdBQVcsQ0FBQztNQUM5QixDQUFDLE1BQU07UUFDTCxJQUFNdUIsVUFBVSxHQUFHQyxlQUFlLENBQUNOLEtBQUssQ0FBQztRQUV6QyxJQUFJdkUsY0FBQSxDQUFjNEUsVUFBVSxDQUFDLEVBQUU7VUFBQSxJQUFBRSxTQUFBLEdBQUFDLDBCQUFBLENBQ1JILFVBQVU7WUFBQUksS0FBQTtVQUFBO1lBQS9CLEtBQUFGLFNBQUEsQ0FBQUcsQ0FBQSxNQUFBRCxLQUFBLEdBQUFGLFNBQUEsQ0FBQUksQ0FBQSxJQUFBQyxJQUFBLEdBQWlDO2NBQUEsSUFBdEJmLE1BQU0sR0FBQVksS0FBQSxDQUFBbEosS0FBQTtjQUNmLFNBQUFzSixFQUFBLE1BQUFDLFlBQUEsR0FBa0JDLGFBQUEsQ0FBWWxCLE1BQU0sQ0FBQyxFQUFBZ0IsRUFBQSxHQUFBQyxZQUFBLENBQUFFLE1BQUEsRUFBQUgsRUFBQSxJQUFFO2dCQUFsQyxJQUFNdkosR0FBRyxHQUFBd0osWUFBQSxDQUFBRCxFQUFBO2dCQUNaLElBQUksT0FBT2hCLE1BQU0sQ0FBQ3ZJLEdBQUcsQ0FBQyxLQUFLLFNBQVMsRUFBRTtrQkFDcEN1SSxNQUFNLENBQUN2SSxHQUFHLENBQUMsR0FBRzJKLE1BQU0sQ0FBQ3BCLE1BQU0sQ0FBQ3ZJLEdBQUcsQ0FBQyxDQUFDO2dCQUNuQztjQUNGO2NBQ0EsSUFBSSxDQUFDeUksS0FBSyxDQUFDRixNQUFNLENBQUM7WUFDcEI7VUFBQyxTQUFBcUIsR0FBQTtZQUFBWCxTQUFBLENBQUFZLENBQUEsQ0FBQUQsR0FBQTtVQUFBO1lBQUFYLFNBQUEsQ0FBQWEsQ0FBQTtVQUFBO1VBQ0QsSUFBSSxDQUFDN0MsR0FBRyxDQUFDLENBQUM7UUFDWixDQUFDLE1BQU0sSUFBSSxPQUFPOEIsVUFBVSxLQUFLLFFBQVEsRUFBRTtVQUN6QyxJQUFJLENBQUN2QixXQUFXLENBQUNpQixLQUFLLENBQUNNLFVBQVUsRUFBRSxNQUFNLENBQUM7VUFDMUMsSUFBSSxDQUFDdkIsV0FBVyxDQUFDUCxHQUFHLENBQUMsQ0FBQztRQUN4QjtNQUNGOztNQUVBO01BQ0EsT0FBTyxJQUFJO0lBQ2I7RUFBQztJQUFBakgsR0FBQTtJQUFBQyxLQUFBO0lBTUQ7QUFDRjtBQUNBO0FBQ0E7SUFDRSxTQUFBMEQsSUFBSUEsQ0FDRm9HLFVBQTJDLEVBQzNDQyxRQUE0QixFQUM1QjtNQUNBLElBQUksQ0FBQyxJQUFJLENBQUNwQixPQUFPLEVBQUU7UUFDakIsSUFBSSxDQUFDckMsT0FBTyxDQUFDLENBQUM7TUFDaEI7TUFDQSxPQUFPLElBQUksQ0FBQ3FDLE9BQU8sQ0FBRWpGLElBQUksQ0FBQ29HLFVBQVUsRUFBRUMsUUFBUSxDQUFDO0lBQ2pEOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFoSyxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBZ0ssTUFBQSxHQUFBM0ksaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUEwSSxVQUFBO1FBQUEsSUFBQW5MLElBQUEsRUFBQWtFLE1BQUEsRUFBQTlELEtBQUEsRUFBQTRELE9BQUEsRUFBQXJCLEdBQUE7UUFBQSxPQUFBSCxtQkFBQSxDQUFBSSxJQUFBLFVBQUF3SSxXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXRJLElBQUEsR0FBQXNJLFVBQUEsQ0FBQXJJLElBQUE7WUFBQTtjQUNRaEQsSUFBSSxHQUFHLElBQUksQ0FBQ1EsS0FBSztjQUNqQjBELE1BQU0sR0FBR2xFLElBQUksQ0FBQ21FLE9BQU87Y0FDckIvRCxLQUFLLEdBQUcsSUFBSSxDQUFDZ0gsR0FBRyxDQUFDM0csRUFBRTtjQUNuQnVELE9BQU8sR0FBRyxJQUFJLENBQUN2RCxFQUFFO2NBQUEsTUFFbkIsQ0FBQ0wsS0FBSyxJQUFJLENBQUM0RCxPQUFPO2dCQUFBcUgsVUFBQSxDQUFBckksSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDZCxJQUFJeEIsS0FBSyxDQUFDLG9CQUFvQixDQUFDO1lBQUE7Y0FBQTZKLFVBQUEsQ0FBQXJJLElBQUE7Y0FBQSxPQUVyQmhELElBQUksQ0FBQ2lELFFBQVEsQ0FBb0I7Z0JBQ2pEQyxNQUFNLEVBQUUsS0FBSztnQkFDYkMsSUFBSSxFQUFFLE9BQU8sR0FBRy9DLEtBQUssR0FBRyxTQUFTLEdBQUc0RCxPQUFPO2dCQUMzQ1gsWUFBWSxFQUFFO2NBQ2hCLENBQUMsQ0FBQztZQUFBO2NBSklWLEdBQUcsR0FBQTBJLFVBQUEsQ0FBQS9ILElBQUE7Y0FLVFksTUFBTSxDQUFDTSxLQUFLLENBQUM3QixHQUFHLENBQUN3QyxTQUFTLENBQUM7Y0FBQyxPQUFBa0csVUFBQSxDQUFBNUgsTUFBQSxXQUNyQmQsR0FBRyxDQUFDd0MsU0FBUztZQUFBO1lBQUE7Y0FBQSxPQUFBa0csVUFBQSxDQUFBMUgsSUFBQTtVQUFBO1FBQUEsR0FBQXdILFNBQUE7TUFBQSxDQUNyQjtNQUFBLFNBaEJLOUosS0FBS0EsQ0FBQTtRQUFBLE9BQUE2SixNQUFBLENBQUE1RixLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQUxsRSxLQUFLO0lBQUE7SUFrQlg7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBSixHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBb0ssS0FBSUEsQ0FBQ0MsUUFBZ0IsRUFBRUMsT0FBZSxFQUFFO01BQUEsSUFBQUMsT0FBQTtNQUN0QyxJQUFNckwsS0FBSyxHQUFHLElBQUksQ0FBQ2dILEdBQUcsQ0FBQzNHLEVBQUU7TUFDekIsSUFBTXVELE9BQU8sR0FBRyxJQUFJLENBQUN2RCxFQUFFO01BRXZCLElBQUksQ0FBQ0wsS0FBSyxJQUFJLENBQUM0RCxPQUFPLEVBQUU7UUFDdEIsTUFBTSxJQUFJeEMsS0FBSyxDQUFDLG9CQUFvQixDQUFDO01BQ3ZDO01BQ0EsSUFBTWtLLFNBQVMsR0FBRyxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQztNQUN0QyxJQUFNQyxPQUFPLEdBQUdILFNBQVMsR0FBR0YsT0FBTztNQUVuQyxJQUFJQSxPQUFPLEtBQUssQ0FBQyxFQUFFO1FBQUEsSUFBQU0sVUFBQTtRQUNqQixNQUFNLElBQUlqRixtQkFBbUIsQ0FBQTVFLHVCQUFBLENBQUE2SixVQUFBLDBEQUFBNUosTUFBQSxDQUM0QjlCLEtBQUsscUJBQUErQixJQUFBLENBQUEySixVQUFBLEVBQWlCOUgsT0FBTyxHQUNwRjVELEtBQUssRUFDTDRELE9BQ0YsQ0FBQztNQUNIO01BRUEsSUFBTXNILEtBQUk7UUFBQSxJQUFBUyxLQUFBLEdBQUF4SixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQUcsU0FBQXVKLFVBQUE7VUFBQSxJQUFBQyxHQUFBLEVBQUFwQixHQUFBLEVBQUFsSSxHQUFBO1VBQUEsT0FBQUgsbUJBQUEsQ0FBQUksSUFBQSxVQUFBc0osV0FBQUMsVUFBQTtZQUFBLGtCQUFBQSxVQUFBLENBQUFwSixJQUFBLEdBQUFvSixVQUFBLENBQUFuSixJQUFBO2NBQUE7Z0JBQ0xpSixHQUFHLEdBQUcsSUFBSU4sSUFBSSxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUM7Z0JBQUEsTUFDNUJDLE9BQU8sR0FBR0ksR0FBRztrQkFBQUUsVUFBQSxDQUFBbkosSUFBQTtrQkFBQTtnQkFBQTtnQkFDVDZILEdBQUcsR0FBRyxJQUFJaEUsbUJBQW1CLENBQ2pDLDZCQUE2QixHQUFHekcsS0FBSyxHQUFHLGdCQUFnQixHQUFHNEQsT0FBTyxFQUNsRTVELEtBQUssRUFDTDRELE9BQ0YsQ0FBQztnQkFDRHlILE9BQUksQ0FBQ2xJLElBQUksQ0FBQyxPQUFPLEVBQUVzSCxHQUFHLENBQUM7Z0JBQUMsT0FBQXNCLFVBQUEsQ0FBQTFJLE1BQUE7Y0FBQTtnQkFBQTBJLFVBQUEsQ0FBQXBKLElBQUE7Z0JBQUFvSixVQUFBLENBQUFuSixJQUFBO2dCQUFBLE9BS1p5SSxPQUFJLENBQUNwSyxLQUFLLENBQUMsQ0FBQztjQUFBO2dCQUF4QnNCLEdBQUcsR0FBQXdKLFVBQUEsQ0FBQTdJLElBQUE7Z0JBQUE2SSxVQUFBLENBQUFuSixJQUFBO2dCQUFBO2NBQUE7Z0JBQUFtSixVQUFBLENBQUFwSixJQUFBO2dCQUFBb0osVUFBQSxDQUFBekksRUFBQSxHQUFBeUksVUFBQTtnQkFFSFYsT0FBSSxDQUFDbEksSUFBSSxDQUFDLE9BQU8sRUFBQTRJLFVBQUEsQ0FBQXpJLEVBQUssQ0FBQztnQkFBQyxPQUFBeUksVUFBQSxDQUFBMUksTUFBQTtjQUFBO2dCQUcxQixJQUFJZCxHQUFHLENBQUNqQyxLQUFLLEtBQUssUUFBUSxFQUFFO2tCQUMxQixJQUFJMEwsU0FBQSxDQUFTekosR0FBRyxDQUFDMEosc0JBQXNCLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUNoRFosT0FBSSxDQUFDYSxRQUFRLENBQUMsQ0FBQztrQkFDakIsQ0FBQyxNQUFNO29CQUNMYixPQUFJLENBQUNsSSxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUkvQixLQUFLLENBQUNtQixHQUFHLENBQUM0SixZQUFZLENBQUMsQ0FBQztrQkFDakQ7Z0JBQ0YsQ0FBQyxNQUFNLElBQUk1SixHQUFHLENBQUNqQyxLQUFLLEtBQUssV0FBVyxFQUFFO2tCQUNwQytLLE9BQUksQ0FBQ2EsUUFBUSxDQUFDLENBQUM7Z0JBQ2pCLENBQUMsTUFBTSxJQUFJM0osR0FBRyxDQUFDakMsS0FBSyxLQUFLLGNBQWMsRUFBRTtrQkFDdkMrSyxPQUFJLENBQUNsSSxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUkvQixLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQztnQkFDdkQsQ0FBQyxNQUFNO2tCQUNMaUssT0FBSSxDQUFDbEksSUFBSSxDQUFDLFlBQVksRUFBRVosR0FBRyxDQUFDO2tCQUM1QjZKLFdBQUEsQ0FBV2xCLEtBQUksRUFBRUMsUUFBUSxDQUFDO2dCQUM1QjtjQUFDO2NBQUE7Z0JBQUEsT0FBQVksVUFBQSxDQUFBeEksSUFBQTtZQUFBO1VBQUEsR0FBQXFJLFNBQUE7UUFBQSxDQUNGO1FBQUEsZ0JBaENLVixJQUFJQSxDQUFBO1VBQUEsT0FBQVMsS0FBQSxDQUFBekcsS0FBQSxPQUFBQyxTQUFBO1FBQUE7TUFBQSxHQWdDVDtNQUNEaUgsV0FBQSxDQUFXbEIsS0FBSSxFQUFFQyxRQUFRLENBQUM7SUFDNUI7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQXRLLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUF1TCxTQUFBLEdBQUFsSyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQWlLLFVBQUE7UUFBQSxJQUFBMU0sSUFBQSxFQUFBSSxLQUFBLEVBQUFnSCxHQUFBLEVBQUFwRCxPQUFBLEVBQUEySSxJQUFBLEVBQUFDLE9BQUEsRUFBQUMsVUFBQSxFQUFBbEssR0FBQSxFQUFBbUssUUFBQSxFQUFBQyxJQUFBO1FBQUEsT0FBQXZLLG1CQUFBLENBQUFJLElBQUEsVUFBQW9LLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBbEssSUFBQSxHQUFBa0ssVUFBQSxDQUFBakssSUFBQTtZQUFBO2NBQ1FoRCxJQUFJLEdBQUcsSUFBSSxDQUFDUSxLQUFLO2NBQ2pCSixLQUFLLEdBQUcsSUFBSSxDQUFDZ0gsR0FBRyxDQUFDM0csRUFBRTtjQUNuQjJHLEdBQUcsR0FBRyxJQUFJLENBQUNBLEdBQUc7Y0FDZHBELE9BQU8sR0FBRyxJQUFJLENBQUN2RCxFQUFFO2NBQUEsTUFFbkIsQ0FBQ0wsS0FBSyxJQUFJLENBQUM0RCxPQUFPO2dCQUFBaUosVUFBQSxDQUFBakssSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDZCxJQUFJeEIsS0FBSyxDQUFDLG9CQUFvQixDQUFDO1lBQUE7Y0FBQXlMLFVBQUEsQ0FBQWxLLElBQUE7Y0FBQWtLLFVBQUEsQ0FBQWpLLElBQUE7Y0FBQSxPQUlsQmhELElBQUksQ0FBQ2lELFFBQVEsQ0FFOUI7Z0JBQ0FDLE1BQU0sRUFBRSxLQUFLO2dCQUNiQyxJQUFJLEVBQUUsT0FBTyxHQUFHL0MsS0FBSyxHQUFHLFNBQVMsR0FBRzRELE9BQU8sR0FBRztjQUNoRCxDQUFDLENBQUM7WUFBQTtjQUxJMkksSUFBSSxHQUFBTSxVQUFBLENBQUEzSixJQUFBO2NBT1YsSUFBSThELEdBQUcsQ0FBQ2xILFNBQVMsS0FBSyxPQUFPLElBQUlrSCxHQUFHLENBQUNsSCxTQUFTLEtBQUssVUFBVSxFQUFFO2dCQUN2RHlDLEdBQUcsR0FBR2dLLElBQUk7Z0JBQ1ZHLFFBQVEsR0FBR25LLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQ3VLLE1BQU07Z0JBQzFDTixPQUFPLEdBQUdPLG9CQUFBLENBQUFOLFVBQUEsR0FBQ3pILGNBQUEsQ0FBYzBILFFBQVEsQ0FBQyxHQUM5QkEsUUFBUSxHQUNSLENBQUNBLFFBQVEsQ0FBQyxFQUFBM0ssSUFBQSxDQUFBMEssVUFBQSxFQUNSLFVBQUNwTSxFQUFFO2tCQUFBLE9BQU07b0JBQUVBLEVBQUUsRUFBRkEsRUFBRTtvQkFBRXVELE9BQU8sRUFBUEEsT0FBTztvQkFBRTVELEtBQUssRUFBTEE7a0JBQU0sQ0FBQztnQkFBQSxDQUFDLENBQUM7Y0FDekMsQ0FBQyxNQUFNO2dCQUNDdUMsSUFBRyxHQUFHZ0ssSUFBSTtnQkFDaEJDLE9BQU8sR0FBR08sb0JBQUEsQ0FBQXhLLElBQUcsRUFBQVIsSUFBQSxDQUFIUSxJQUFHLEVBQUssVUFBQ3lLLEdBQUc7a0JBQUEsT0FBTTtvQkFDMUIzTSxFQUFFLEVBQUUyTSxHQUFHLENBQUNqRSxFQUFFLElBQUksSUFBSTtvQkFDbEJrRSxPQUFPLEVBQUVELEdBQUcsQ0FBQ0UsT0FBTyxLQUFLLE1BQU07b0JBQy9CQyxPQUFPLEVBQUVILEdBQUcsQ0FBQ0ksT0FBTyxLQUFLLE1BQU07b0JBQy9CQyxNQUFNLEVBQUVMLEdBQUcsQ0FBQzVMLEtBQUssR0FBRyxDQUFDNEwsR0FBRyxDQUFDNUwsS0FBSyxDQUFDLEdBQUc7a0JBQ3BDLENBQUM7Z0JBQUEsQ0FBQyxDQUFDO2NBQ0w7Y0FDQSxJQUFJLENBQUMrQixJQUFJLENBQUMsVUFBVSxFQUFFcUosT0FBTyxDQUFDO2NBQUMsT0FBQUssVUFBQSxDQUFBeEosTUFBQSxXQUN4Qm1KLE9BQU87WUFBQTtjQUFBSyxVQUFBLENBQUFsSyxJQUFBO2NBQUFrSyxVQUFBLENBQUF2SixFQUFBLEdBQUF1SixVQUFBO2NBRWQsSUFBSSxDQUFDMUosSUFBSSxDQUFDLE9BQU8sRUFBQTBKLFVBQUEsQ0FBQXZKLEVBQUssQ0FBQztjQUFDLE1BQUF1SixVQUFBLENBQUF2SixFQUFBO1lBQUE7WUFBQTtjQUFBLE9BQUF1SixVQUFBLENBQUF0SixJQUFBO1VBQUE7UUFBQSxHQUFBK0ksU0FBQTtNQUFBLENBRzNCO01BQUEsU0F4Q0tKLFFBQVFBLENBQUE7UUFBQSxPQUFBRyxTQUFBLENBQUFuSCxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVIrRyxRQUFRO0lBQUE7SUEwQ2Q7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBTEU7RUFBQTtJQUFBckwsR0FBQTtJQUFBQyxLQUFBLEVBTUEsU0FBT2dNLE1BQU1BLENBQUNKLFFBQWdCLEVBQW9CO01BQ2hELElBQU0xTSxLQUFLLEdBQUcsSUFBSSxDQUFDZ0gsR0FBRyxDQUFDM0csRUFBRTtNQUN6QixJQUFNdUQsT0FBTyxHQUFHLElBQUksQ0FBQ3ZELEVBQUU7TUFDdkIsSUFBSSxDQUFDTCxLQUFLLElBQUksQ0FBQzRELE9BQU8sRUFBRTtRQUN0QixNQUFNLElBQUl4QyxLQUFLLENBQUMsb0JBQW9CLENBQUM7TUFDdkM7TUFDQSxJQUFNa00sWUFBWSxHQUFHLElBQUlqTyxRQUFRLENBQUMsQ0FBQztNQUNuQyxJQUFNa08sZ0JBQWdCLEdBQUdELFlBQVksQ0FBQzVGLE1BQU0sQ0FBQyxLQUFLLENBQUM7TUFDbkQsSUFBSSxDQUFDdEgsS0FBSyxDQUNQeUMsUUFBUSxDQUFDO1FBQ1JDLE1BQU0sRUFBRSxLQUFLO1FBQ2JDLElBQUksRUFBRSxPQUFPLEdBQUcvQyxLQUFLLEdBQUcsU0FBUyxHQUFHNEQsT0FBTyxHQUFHLFVBQVUsR0FBRzhJLFFBQVE7UUFDbkV6SixZQUFZLEVBQUU7TUFDaEIsQ0FBQyxDQUFDLENBQ0R5RSxNQUFNLENBQUMsQ0FBQyxDQUNSUyxJQUFJLENBQUNvRixnQkFBZ0IsQ0FBQztNQUN6QixPQUFPRCxZQUFZO0lBQ3JCO0VBQUM7QUFBQSxFQXRUT3BPLFFBQVE7O0FBeVRsQjtBQUNBO0FBQ0E7QUFDQTtBQUZBLElBR01zTyxPQUFPLDBCQUFBQyxRQUFBO0VBQUEsU0FBQUQsUUFBQTtJQUFBdE4sZUFBQSxPQUFBc04sT0FBQTtJQUFBLE9BQUFyTixVQUFBLE9BQUFxTixPQUFBLEVBQUFySSxTQUFBO0VBQUE7RUFBQXhFLFNBQUEsQ0FBQTZNLE9BQUEsRUFBQUMsUUFBQTtFQUFBLE9BQUE3TSxZQUFBLENBQUE0TSxPQUFBO0lBQUEzTSxHQUFBO0lBQUFDLEtBQUEsRUFDWCxTQUFBNE0sVUFBVUEsQ0FBQ0MsT0FBb0IsRUFBRTtNQUFBLElBQUFDLHFCQUFBO01BQy9CRCxPQUFPLENBQUMzSyxPQUFPLEdBQUFxRyxhQUFBLENBQUFBLGFBQUEsS0FDVnNFLE9BQU8sQ0FBQzNLLE9BQU87UUFDbEIsZ0JBQWdCLEdBQUE0SyxxQkFBQSxHQUFFLElBQUksQ0FBQ0MsS0FBSyxDQUFDQyxXQUFXLGNBQUFGLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUk7TUFBRSxFQUMvQztJQUNIO0VBQUM7SUFBQS9NLEdBQUE7SUFBQUMsS0FBQSxFQUVELFNBQUFpTixnQkFBZ0JBLENBQUNDLFFBQXNCLEVBQUU7TUFBQSxJQUFBQyxVQUFBO01BQ3ZDLE9BQ0VELFFBQVEsQ0FBQ0UsVUFBVSxLQUFLLEdBQUcsSUFDM0JDLHlCQUFBLENBQUFGLFVBQUEsR0FBQUQsUUFBUSxDQUFDck0sSUFBSSxFQUFBSSxJQUFBLENBQUFrTSxVQUFBLEVBQVUsaURBQWlELENBQUM7SUFFN0U7RUFBQztJQUFBcE4sR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQXNOLHNCQUFzQkEsQ0FBQ3pNLElBQVMsRUFBRTtNQUNoQyxPQUFPLENBQUMsQ0FBQ0EsSUFBSSxDQUFDbEIsS0FBSztJQUNyQjtFQUFDO0lBQUFJLEdBQUE7SUFBQUMsS0FBQSxFQUVELFNBQUF1TixVQUFVQSxDQUFDMU0sSUFBUyxFQUFFO01BQ3BCLE9BQU87UUFDTDJNLFNBQVMsRUFBRTNNLElBQUksQ0FBQ2xCLEtBQUssQ0FBQzhOLGFBQWE7UUFDbkM1SCxPQUFPLEVBQUVoRixJQUFJLENBQUNsQixLQUFLLENBQUMrTjtNQUN0QixDQUFDO0lBQ0g7RUFBQztBQUFBLEVBeEJxQ2xQLE9BQU87QUEyQi9DO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQWFtUCxJQUFJO0VBa0JmO0FBQ0Y7QUFDQTtFQUNFLFNBQUFBLEtBQVlDLElBQW1CLEVBQUU7SUFBQXhPLGVBQUEsT0FBQXVPLElBQUE7SUFqQmpDO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7SUFKRXRILGVBQUEsdUJBS3NCLElBQUk7SUFFMUI7QUFDRjtBQUNBO0FBQ0E7QUFDQTtJQUpFQSxlQUFBLHNCQUtxQixLQUFLO0lBTXhCLElBQUksQ0FBQzBHLEtBQUssR0FBR2EsSUFBSTtJQUNqQixJQUFJLENBQUMzSyxPQUFPLEdBQUcySyxJQUFJLENBQUMzSyxPQUFPO0VBQzdCOztFQUVBO0FBQ0Y7QUFDQTtFQUZFLE9BQUFuRCxZQUFBLENBQUE2TixJQUFBO0lBQUE1TixHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFPK0IsUUFBUUEsQ0FBSThMLFFBQXFCLEVBQUU7TUFDeEMsSUFBTUQsSUFBSSxHQUFHLElBQUksQ0FBQ2IsS0FBSztNQUN2QixJQUFROUssSUFBSSxHQUE0QjRMLFFBQVEsQ0FBeEM1TCxJQUFJO1FBQUVFLFlBQVksR0FBYzBMLFFBQVEsQ0FBbEMxTCxZQUFZO1FBQUsyTCxJQUFJLEdBQUExRix3QkFBQSxDQUFLeUYsUUFBUSxFQUFBRSxVQUFBO01BQ2hELElBQU1DLE9BQU8sR0FBRyxDQUFDSixJQUFJLENBQUNLLFdBQVcsRUFBRSxnQkFBZ0IsRUFBRUwsSUFBSSxDQUFDTSxPQUFPLENBQUMsQ0FBQ0MsSUFBSSxDQUNyRSxHQUNGLENBQUM7TUFDRCxJQUFNdEIsT0FBTyxHQUFBdEUsYUFBQSxDQUFBQSxhQUFBLEtBQ1J1RixJQUFJO1FBQ1BNLEdBQUcsRUFBRUosT0FBTyxHQUFHL0w7TUFBSSxFQUNwQjtNQUNELE9BQU8sSUFBSXlLLE9BQU8sQ0FBQyxJQUFJLENBQUNLLEtBQUssRUFBRTtRQUFFNUssWUFBWSxFQUFaQTtNQUFhLENBQUMsQ0FBQyxDQUFDMEssT0FBTyxDQUFJQSxPQUFPLENBQUM7SUFDdEU7O0lBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUEzQkU7SUFBQTlNLEdBQUE7SUFBQUMsS0FBQSxFQXdDQSxTQUFBcU8sSUFBSUEsQ0FDRnRQLElBQVksRUFDWkMsU0FBYyxFQUNkc1AsY0FBMkQsRUFDM0Q3RixLQUFvQyxFQUNwQztNQUFBLElBQUE4RixPQUFBO01BQ0EsSUFBSXRQLE9BQW9CLEdBQUcsQ0FBQyxDQUFDO01BQzdCLElBQ0UsT0FBT3FQLGNBQWMsS0FBSyxRQUFRLElBQ2xDcEssY0FBQSxDQUFjb0ssY0FBYyxDQUFDLElBQzdCM1AsRUFBRSxDQUFDa0ssVUFBVSxDQUFDeUYsY0FBYyxDQUFDLEVBQzdCO1FBQ0E7UUFDQTdGLEtBQUssR0FBRzZGLGNBQWM7TUFDeEIsQ0FBQyxNQUFNO1FBQ0xyUCxPQUFPLEdBQUdxUCxjQUE2QjtNQUN6QztNQUNBLElBQU1wSSxHQUFHLEdBQUcsSUFBSSxDQUFDc0ksU0FBUyxDQUFDelAsSUFBSSxFQUFFQyxTQUFTLEVBQUVDLE9BQU8sQ0FBQztNQUNwRCxJQUFNMkQsS0FBSyxHQUFHc0QsR0FBRyxDQUFDeEQsV0FBVyxDQUFDLENBQUM7TUFDL0IsSUFBTStMLE9BQU8sR0FBRyxTQUFWQSxPQUFPQSxDQUFBO1FBQUEsT0FBU3ZJLEdBQUcsQ0FBQ3ZCLEtBQUssQ0FBQyxDQUFDO01BQUE7TUFDakMsSUFBTStKLGNBQWMsR0FBRyxTQUFqQkEsY0FBY0EsQ0FBSS9FLEdBQVUsRUFBSztRQUNyQyxJQUFJQSxHQUFHLENBQUM1RCxJQUFJLEtBQUssZ0JBQWdCLEVBQUU7VUFDakMwSSxPQUFPLENBQUMsQ0FBQztRQUNYO01BQ0YsQ0FBQztNQUNEN0wsS0FBSyxDQUFDbEQsRUFBRSxDQUFDLFVBQVUsRUFBRStPLE9BQU8sQ0FBQztNQUM3QjdMLEtBQUssQ0FBQ2xELEVBQUUsQ0FBQyxPQUFPLEVBQUVnUCxjQUFjLENBQUM7TUFDakM5TCxLQUFLLENBQUNsRCxFQUFFLENBQUMsT0FBTyxFQUFFLFlBQU07UUFDdEJrRCxLQUFLLGFBQUxBLEtBQUssZUFBTEEsS0FBSyxDQUFFd0gsSUFBSSxDQUFDbUUsT0FBSSxDQUFDSSxZQUFZLEVBQUVKLE9BQUksQ0FBQ0ssV0FBVyxDQUFDO01BQ2xELENBQUMsQ0FBQztNQUNGLE9BQU9oTSxLQUFLLENBQUMwRCxPQUFPLENBQUNtQyxLQUFLLENBQUM7SUFDN0I7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQTFJLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUE2TyxNQUFBLEdBQUF4TixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQXVOLFVBQW1CQyxJQUFZO1FBQUEsSUFBQUMsT0FBQTtRQUFBLElBQUFDLENBQUEsRUFBQWxRLElBQUEsRUFBQW1RLFlBQUEsRUFBQUMsVUFBQSxFQUFBekQsT0FBQSxFQUFBMEQsT0FBQTtRQUFBLE9BQUE5TixtQkFBQSxDQUFBSSxJQUFBLFVBQUEyTixXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQXpOLElBQUEsR0FBQXlOLFVBQUEsQ0FBQXhOLElBQUE7WUFBQTtjQUN2Qm1OLENBQUMsR0FBR0YsSUFBSSxDQUFDUSxPQUFPLENBQUMsY0FBYyxFQUFFLEVBQUUsQ0FBQyxDQUFDQyxLQUFLLENBQUMsZUFBZSxDQUFDO2NBQUEsSUFDNURQLENBQUM7Z0JBQUFLLFVBQUEsQ0FBQXhOLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE1BQ0UsSUFBSXhCLEtBQUssQ0FDYiwrREFDRixDQUFDO1lBQUE7Y0FFR3ZCLElBQUksR0FBR2tRLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FDWEMsWUFBWSxHQUFHLElBQUkzUSxRQUFRLENBQUMsQ0FBQztjQUM3QjRRLFVBQVUsR0FBR0QsWUFBWSxDQUFDdEksTUFBTSxDQUFDLEtBQUssQ0FBQztjQUFBMEksVUFBQSxDQUFBeE4sSUFBQTtjQUFBLE9BRXZCLElBQUksQ0FBQ3VNLElBQUksQ0FBQ3RQLElBQUksRUFBRSxPQUFPLEVBQUVnUSxJQUFJLENBQUM7WUFBQTtjQUE5Q3JELE9BQU8sR0FBQTRELFVBQUEsQ0FBQWxOLElBQUE7Y0FDUGdOLE9BQU8sR0FBR25ELG9CQUFBLENBQUFQLE9BQU8sRUFBQXpLLElBQUEsQ0FBUHlLLE9BQU8sRUFBSyxVQUFDTSxNQUFNO2dCQUFBLE9BQ2pDZ0QsT0FBSSxDQUFDOUksR0FBRyxDQUFDOEYsTUFBTSxDQUFDOU0sS0FBSyxDQUFDLENBQUMwRCxLQUFLLENBQUNvSixNQUFNLENBQUNsSixPQUFPLENBQUMsQ0FBQ2tKLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDek0sRUFBRSxDQUFDLENBQUNxSCxNQUFNLENBQUMsQ0FBQztjQUFBLENBQ3pFLENBQUM7Y0FDRHZJLFdBQVcsQ0FBQytRLE9BQU8sQ0FBQyxDQUFDL0gsSUFBSSxDQUFDOEgsVUFBVSxDQUFDO2NBQUMsT0FBQUcsVUFBQSxDQUFBL00sTUFBQSxXQUUvQjJNLFlBQVk7WUFBQTtZQUFBO2NBQUEsT0FBQUksVUFBQSxDQUFBN00sSUFBQTtVQUFBO1FBQUEsR0FBQXFNLFNBQUE7TUFBQSxDQUNwQjtNQUFBLFNBbEJZVyxLQUFLQSxDQUFBQyxHQUFBO1FBQUEsT0FBQWIsTUFBQSxDQUFBekssS0FBQSxPQUFBQyxTQUFBO01BQUE7TUFBQSxPQUFMb0wsS0FBSztJQUFBO0lBb0JsQjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUExUCxHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFPd08sU0FBU0EsQ0FDZHpQLElBQVksRUFDWkMsU0FBYyxFQUVkO01BQUEsSUFEQUMsT0FBb0IsR0FBQW9GLFNBQUEsQ0FBQW9GLE1BQUEsUUFBQXBGLFNBQUEsUUFBQXNMLFNBQUEsR0FBQXRMLFNBQUEsTUFBRyxDQUFDLENBQUM7TUFFekIsT0FBTyxJQUFJekYsR0FBRyxDQUFDLElBQUksRUFBRUcsSUFBSSxFQUFFQyxTQUFTLEVBQUVDLE9BQU8sQ0FBQztJQUNoRDs7SUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFMRTtJQUFBYyxHQUFBO0lBQUFDLEtBQUEsRUFNQSxTQUFPa0csR0FBR0EsQ0FBNEJoSCxLQUFhLEVBQUU7TUFDbkQsT0FBTyxJQUFJTixHQUFHLENBQVMsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFTSxLQUFLLENBQUM7SUFDdkQ7RUFBQztBQUFBOztBQUdIO0FBQ0E7QUFDQTtBQUNBO0FBQ0FULGNBQWMsQ0FBQyxNQUFNLEVBQUUsVUFBQ21QLElBQUk7RUFBQSxPQUFLLElBQUlELElBQUksQ0FBQ0MsSUFBSSxDQUFDO0FBQUEsRUFBQztBQUVoRCxlQUFlRCxJQUFJIiwiaWdub3JlTGlzdCI6W119