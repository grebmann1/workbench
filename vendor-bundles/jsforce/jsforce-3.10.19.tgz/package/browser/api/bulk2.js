import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _wrapNativeSuper from "@babel/runtime-corejs3/helpers/wrapNativeSuper";
var _excluded = ["pollInterval", "pollTimeout", "input"],
  _excluded2 = ["Id", "type", "attributes"];
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof _Symbol && _getIteratorMethod(r) || r["@@iterator"]; if (!t) { if (_Array$isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { var _context29; if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = _sliceInstanceProperty(_context29 = {}.toString.call(r)).call(_context29, 8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? _Array$from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function ownKeys(e, r) { var t = _Object$keys2(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context27, _context28; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context27 = ownKeys(Object(t), !0)).call(_context27, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context28 = ownKeys(Object(t))).call(_context28, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _includesInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/includes";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _URL from "@babel/runtime-corejs3/core-js-stable/url";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _Object$keys2 from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.iterator.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.map.js";
import "core-js/modules/es.object.keys.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/es.regexp.to-string.js";
import "core-js/modules/es.set.js";
import "core-js/modules/web.dom-exception.constructor.js";
import "core-js/modules/web.dom-exception.stack.js";
import "core-js/modules/web.dom-exception.to-string-tag.js";
import "core-js/modules/web.structured-clone.js";
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
import { EventEmitter } from 'events';
import { Writable } from 'stream';
import { Serializable, Parsable } from '../record-stream';
import HttpApi from '../http-api';
import { registerModule } from '../jsforce';
import { getLogger } from '../util/logger';
import { concatStreamsAsDuplex } from '../util/stream';
import is from '@sindresorhus/is';
var JobPollingTimeoutError = /*#__PURE__*/function (_Error) {
  /**
   *
   */
  function JobPollingTimeoutError(message, jobId) {
    var _this;
    _classCallCheck(this, JobPollingTimeoutError);
    _this = _callSuper(this, JobPollingTimeoutError, [message]);
    _this.name = 'JobPollingTimeout';
    _this.jobId = jobId;
    return _this;
  }
  _inherits(JobPollingTimeoutError, _Error);
  return _createClass(JobPollingTimeoutError);
}(/*#__PURE__*/_wrapNativeSuper(Error));
var BulkApiV2 = /*#__PURE__*/function (_HttpApi) {
  function BulkApiV2() {
    _classCallCheck(this, BulkApiV2);
    return _callSuper(this, BulkApiV2, arguments);
  }
  _inherits(BulkApiV2, _HttpApi);
  return _createClass(BulkApiV2, [{
    key: "hasErrorInResponseBody",
    value: function hasErrorInResponseBody(body) {
      return _Array$isArray(body) && _typeof(body[0]) === 'object' && 'errorCode' in body[0];
    }
  }, {
    key: "isSessionExpired",
    value: function isSessionExpired(response) {
      var _context;
      return response.statusCode === 401 && _includesInstanceProperty(_context = response.body).call(_context, 'INVALID_SESSION_ID');
    }
  }, {
    key: "parseError",
    value: function parseError(body) {
      return {
        errorCode: body[0].errorCode,
        message: body[0].message
      };
    }
  }]);
}(HttpApi);
export var BulkV2 = /*#__PURE__*/function () {
  function BulkV2(connection) {
    _classCallCheck(this, BulkV2);
    /**
     * Polling interval in milliseconds
     *
     * Default: 1000 (1 second)
     */
    _defineProperty(this, "pollInterval", 1000);
    /**
     * Polling timeout in milliseconds
     *
     * Default: 30000 (30 seconds)
     */
    _defineProperty(this, "pollTimeout", 30000);
    this.connection = connection;
    this.logger = this.connection._logLevel ? getLogger('bulk2').createInstance(this.connection._logLevel) : getLogger('bulk2');
  }

  /**
   * Create an instance of an ingest job object.
   *
   * @params {NewIngestJobOptions} options object
   * @returns {IngestJobV2} An ingest job instance
   * @example
   * // Upsert records to the Account object.
   *
   * const job = connection.bulk2.createJob({
   *   operation: 'insert'
   *   object: 'Account',
   * });
   *
   * // create the job in the org
   * await job.open()
   *
   * // upload data
   * await job.uploadData(csvFile)
   *
   * // finished uploading data, mark it as ready for processing
   * await job.close()
   */
  return _createClass(BulkV2, [{
    key: "createJob",
    value: function createJob(options) {
      return new IngestJobV2(this.connection, {
        bodyParams: options,
        pollingOptions: this
      });
    }

    /**
     * Get an ingest or query job instance specified by a given job ID
     *
     * @param options Options object with a job ID
     * @returns IngestJobV2 An ingest job
     */
  }, {
    key: "job",
    value: function job() {
      var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'ingest';
      var options = arguments.length > 1 ? arguments[1] : undefined;
      if (type === 'ingest') {
        return new IngestJobV2(this.connection, {
          id: options.id,
          pollingOptions: this
        });
      } else {
        return new QueryJobV2(this.connection, {
          id: options.id,
          pollingOptions: this
        });
      }
    }

    /**
     * Create, upload, and start bulkload job
     */
  }, {
    key: "loadAndWaitForResults",
    value: (function () {
      var _loadAndWaitForResults = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(options) {
        var pollInterval, pollTimeout, input, createJobOpts, job, err;
        return _regeneratorRuntime.wrap(function _callee$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              if (!options.pollTimeout) options.pollTimeout = this.pollTimeout;
              if (!options.pollInterval) options.pollInterval = this.pollInterval;
              pollInterval = options.pollInterval, pollTimeout = options.pollTimeout, input = options.input, createJobOpts = _objectWithoutProperties(options, _excluded);
              job = this.createJob(createJobOpts);
              _context2.prev = 4;
              _context2.next = 7;
              return job.open();
            case 7:
              _context2.next = 9;
              return job.uploadData(input);
            case 9:
              _context2.next = 11;
              return job.close();
            case 11:
              _context2.next = 13;
              return job.poll(pollInterval, pollTimeout);
            case 13:
              _context2.next = 15;
              return job.getAllResults();
            case 15:
              return _context2.abrupt("return", _context2.sent);
            case 18:
              _context2.prev = 18;
              _context2.t0 = _context2["catch"](4);
              err = _context2.t0;
              this.logger.error("bulk load failed due to: ".concat(err.message));
              if (err.name !== 'JobPollingTimeoutError') {
                // fires off one last attempt to clean up and ignores the result | error
                job.delete().catch(function (ignored) {
                  return ignored;
                });
              }
              throw err;
            case 24:
            case "end":
              return _context2.stop();
          }
        }, _callee, this, [[4, 18]]);
      }));
      function loadAndWaitForResults(_x) {
        return _loadAndWaitForResults.apply(this, arguments);
      }
      return loadAndWaitForResults;
    }()
    /**
     * Execute bulk query and get a record stream.
     *
     * Default timeout: 10000ms
     *
     * @param soql SOQL query
     * @param options
     *
     * @returns {RecordStream} - Record stream, convertible to a CSV data stream
     */
    )
  }, {
    key: "query",
    value: (function () {
      var _query = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(soql, options) {
        var queryJob, recordStream, dataStream, queryRecordsStream, err;
        return _regeneratorRuntime.wrap(function _callee2$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              queryJob = new QueryJobV2(this.connection, {
                bodyParams: {
                  query: soql,
                  operation: options !== null && options !== void 0 && options.scanAll ? 'queryAll' : 'query',
                  columnDelimiter: options === null || options === void 0 ? void 0 : options.columnDelimiter,
                  lineEnding: options === null || options === void 0 ? void 0 : options.lineEnding
                },
                pollingOptions: this
              });
              recordStream = new Parsable();
              dataStream = recordStream.stream('csv');
              _context3.prev = 3;
              _context3.next = 6;
              return queryJob.open();
            case 6:
              _context3.next = 8;
              return queryJob.poll(options === null || options === void 0 ? void 0 : options.pollInterval, options === null || options === void 0 ? void 0 : options.pollTimeout);
            case 8:
              _context3.next = 10;
              return queryJob.result().then(function (s) {
                return s.stream();
              });
            case 10:
              queryRecordsStream = _context3.sent;
              queryRecordsStream.pipe(dataStream);
              _context3.next = 20;
              break;
            case 14:
              _context3.prev = 14;
              _context3.t0 = _context3["catch"](3);
              err = _context3.t0;
              this.logger.error("bulk query failed due to: ".concat(err.message));
              if (err.name !== 'JobPollingTimeoutError') {
                // fires off one last attempt to clean up and ignores the result | error
                queryJob.delete().catch(function (ignored) {
                  return ignored;
                });
              }
              throw err;
            case 20:
              return _context3.abrupt("return", recordStream);
            case 21:
            case "end":
              return _context3.stop();
          }
        }, _callee2, this, [[3, 14]]);
      }));
      function query(_x2, _x3) {
        return _query.apply(this, arguments);
      }
      return query;
    }())
  }]);
}();
export var QueryJobV2 = /*#__PURE__*/function (_EventEmitter) {
  function QueryJobV2(conn, options) {
    var _this2;
    _classCallCheck(this, QueryJobV2);
    _this2 = _callSuper(this, QueryJobV2);
    _this2.connection = conn;
    _this2.logger = _this2.connection._logLevel ? getLogger('bulk2:QueryJobV2').createInstance(_this2.connection._logLevel) : getLogger('bulk2:QueryJobV2');
    if ('id' in options) {
      _this2._id = options.id;
    } else {
      _this2.bodyParams = options.bodyParams;
    }
    _this2.pollingOptions = options.pollingOptions;
    // default error handler to keep the latest error
    _this2.on('error', function (error) {
      return _this2.error = error;
    });
    return _this2;
  }

  /**
   * Get the query job ID.
   *
   * @returns {string} query job Id.
   */
  _inherits(QueryJobV2, _EventEmitter);
  return _createClass(QueryJobV2, [{
    key: "id",
    get: function get() {
      return this.jobInfo ? this.jobInfo.id : this._id;
    }

    /**
     * Get the query job info.
     *
     * @returns {Promise<QueryJobInfoV2>} query job information.
     */
  }, {
    key: "getInfo",
    value: function getInfo() {
      if (this.jobInfo) {
        return this.jobInfo;
      }
      throw new Error('No internal job info. Make sure to call `await job.check`.');
    }

    /**
     * Creates a query job
     *
     * @returns {Promise<QueryJobInfoV2>} job information.
     */
  }, {
    key: "open",
    value: (function () {
      var _open = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3() {
        return _regeneratorRuntime.wrap(function _callee3$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              if (this.bodyParams) {
                _context4.next = 2;
                break;
              }
              throw new Error('Missing required body params to open a new query job.');
            case 2:
              _context4.prev = 2;
              _context4.next = 5;
              return this.createQueryRequest({
                method: 'POST',
                body: _JSON$stringify(this.bodyParams),
                headers: {
                  'Content-Type': 'application/json; charset=utf-8'
                },
                responseType: 'application/json'
              });
            case 5:
              this.jobInfo = _context4.sent;
              this.logger.debug("Successfully created job ".concat(this.id));
              this.emit('open', this.jobInfo);
              _context4.next = 14;
              break;
            case 10:
              _context4.prev = 10;
              _context4.t0 = _context4["catch"](2);
              this.emit('error', _context4.t0);
              throw _context4.t0;
            case 14:
              return _context4.abrupt("return", this.jobInfo);
            case 15:
            case "end":
              return _context4.stop();
          }
        }, _callee3, this, [[2, 10]]);
      }));
      function open() {
        return _open.apply(this, arguments);
      }
      return open;
    }()
    /**
     * Abort the job
     *
     * The 'aborted' event is emitted when the job successfully aborts.
     * @returns {Promise<QueryJobInfoV2>} job information.
     */
    )
  }, {
    key: "abort",
    value: (function () {
      var _abort = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee4() {
        var state;
        return _regeneratorRuntime.wrap(function _callee4$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _context5.prev = 0;
              state = 'Aborted';
              _context5.next = 4;
              return this.createQueryRequest({
                method: 'PATCH',
                path: "/".concat(this.id),
                body: _JSON$stringify({
                  state: state
                }),
                headers: {
                  'Content-Type': 'application/json; charset=utf-8'
                },
                responseType: 'application/json'
              });
            case 4:
              this.jobInfo = _context5.sent;
              this.logger.debug("Successfully aborted job ".concat(this.id));
              return _context5.abrupt("return", this.jobInfo);
            case 9:
              _context5.prev = 9;
              _context5.t0 = _context5["catch"](0);
              this.emit('error', _context5.t0);
              throw _context5.t0;
            case 13:
            case "end":
              return _context5.stop();
          }
        }, _callee4, this, [[0, 9]]);
      }));
      function abort() {
        return _abort.apply(this, arguments);
      }
      return abort;
    }()
    /**
     * Poll for the state of the processing for the job.
     *
     * @param interval Polling interval in milliseconds
     * @param timeout Polling timeout in milliseconds
     * @returns {Promise<Record[]>} A promise that resolves when the job finished being processed.
     */
    )
  }, {
    key: "poll",
    value: (function () {
      var _poll = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee5() {
        var _context6, _context7;
        var interval,
          timeout,
          jobId,
          startTime,
          endTime,
          res,
          timeoutError,
          _args5 = arguments;
        return _regeneratorRuntime.wrap(function _callee5$(_context8) {
          while (1) switch (_context8.prev = _context8.next) {
            case 0:
              interval = _args5.length > 0 && _args5[0] !== undefined ? _args5[0] : this.pollingOptions.pollInterval;
              timeout = _args5.length > 1 && _args5[1] !== undefined ? _args5[1] : this.pollingOptions.pollTimeout;
              jobId = this.id;
              startTime = _Date$now();
              endTime = startTime + timeout;
              this.logger.debug('Start polling for job status');
              this.logger.debug(_concatInstanceProperty(_context6 = "Polling options: timeout:".concat(timeout, "ms | interval: ")).call(_context6, interval, "ms."));
              if (!(timeout === 0)) {
                _context8.next = 9;
                break;
              }
              throw new JobPollingTimeoutError("Skipping polling because of timeout = 0ms. Job Id = ".concat(jobId), jobId);
            case 9:
              if (!(endTime > _Date$now())) {
                _context8.next = 35;
                break;
              }
              _context8.prev = 10;
              _context8.next = 13;
              return this.check();
            case 13:
              res = _context8.sent;
              _context8.t0 = res.state;
              _context8.next = _context8.t0 === 'Aborted' ? 17 : _context8.t0 === 'UploadComplete' ? 18 : _context8.t0 === 'InProgress' ? 18 : _context8.t0 === 'Failed' ? 22 : _context8.t0 === 'JobComplete' ? 24 : 27;
              break;
            case 17:
              throw new Error('Job has been aborted');
            case 18:
              this.emit('inProgress', res);
              _context8.next = 21;
              return delay(interval);
            case 21:
              return _context8.abrupt("break", 27);
            case 22:
              // unlike ingest jobs, the API doesn't return an error msg:
              // https://developer.salesforce.com/docs/atlas.en-us.api_asynch.meta/api_asynch/query_get_one_job.htm
              this.logger.debug(res);
              throw new Error('Query job failed to complete');
            case 24:
              this.logger.debug("Job ".concat(this.id, " was successfully processed."));
              this.emit('jobComplete', res);
              return _context8.abrupt("return");
            case 27:
              _context8.next = 33;
              break;
            case 29:
              _context8.prev = 29;
              _context8.t1 = _context8["catch"](10);
              this.emit('error', _context8.t1);
              throw _context8.t1;
            case 33:
              _context8.next = 9;
              break;
            case 35:
              timeoutError = new JobPollingTimeoutError(_concatInstanceProperty(_context7 = "Polling timed out after ".concat(timeout, "ms. Job Id = ")).call(_context7, jobId), jobId);
              this.emit('error', timeoutError);
              throw timeoutError;
            case 38:
            case "end":
              return _context8.stop();
          }
        }, _callee5, this, [[10, 29]]);
      }));
      function poll() {
        return _poll.apply(this, arguments);
      }
      return poll;
    }()
    /**
     * Check the latest job status
     *
     * @returns {Promise<QueryJobInfoV2>} job information.
     */
    )
  }, {
    key: "check",
    value: (function () {
      var _check = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee6() {
        var jobInfo;
        return _regeneratorRuntime.wrap(function _callee6$(_context9) {
          while (1) switch (_context9.prev = _context9.next) {
            case 0:
              _context9.prev = 0;
              _context9.next = 3;
              return this.createQueryRequest({
                method: 'GET',
                path: "/".concat(this.id),
                responseType: 'application/json'
              });
            case 3:
              jobInfo = _context9.sent;
              this.jobInfo = jobInfo;
              return _context9.abrupt("return", jobInfo);
            case 8:
              _context9.prev = 8;
              _context9.t0 = _context9["catch"](0);
              this.emit('error', _context9.t0);
              throw _context9.t0;
            case 12:
            case "end":
              return _context9.stop();
          }
        }, _callee6, this, [[0, 8]]);
      }));
      function check() {
        return _check.apply(this, arguments);
      }
      return check;
    }()
    /**
     * Get the results for a query job as a record stream
     *
     * This method assumes the job finished being processed
     * @returns {RecordStream} - Record stream, convertible to a CSV data stream
     */
    )
  }, {
    key: "result",
    value: (function () {
      var _result = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee7() {
        var resultStream, resultDataStream, resultsPath, _context10, resPromise;
        return _regeneratorRuntime.wrap(function _callee7$(_context11) {
          while (1) switch (_context11.prev = _context11.next) {
            case 0:
              resultStream = new Parsable();
              resultDataStream = resultStream.stream('csv');
              resultsPath = "/".concat(this.id, "/results");
            case 3:
              if (!(this.locator !== 'null')) {
                _context11.next = 10;
                break;
              }
              resPromise = this.createQueryRequest({
                method: 'GET',
                path: this.locator
                // resultsPath starts with '/'
                ? _concatInstanceProperty(_context10 = "".concat(resultsPath, "?locator=")).call(_context10, this.locator) : resultsPath,
                headers: {
                  Accept: 'text/csv'
                }
              });
              resPromise.stream().pipe(resultDataStream);
              _context11.next = 8;
              return resPromise;
            case 8:
              _context11.next = 3;
              break;
            case 10:
              return _context11.abrupt("return", resultStream);
            case 11:
            case "end":
              return _context11.stop();
          }
        }, _callee7, this);
      }));
      function result() {
        return _result.apply(this, arguments);
      }
      return result;
    }()
    /**
     * Deletes a query job.
     */
    )
  }, {
    key: "delete",
    value: (function () {
      var _delete2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee8() {
        return _regeneratorRuntime.wrap(function _callee8$(_context12) {
          while (1) switch (_context12.prev = _context12.next) {
            case 0:
              return _context12.abrupt("return", this.createQueryRequest({
                method: 'DELETE',
                path: "/".concat(this.id)
              }));
            case 1:
            case "end":
              return _context12.stop();
          }
        }, _callee8, this);
      }));
      function _delete() {
        return _delete2.apply(this, arguments);
      }
      return _delete;
    }())
  }, {
    key: "createQueryRequest",
    value: function createQueryRequest(request) {
      var _this3 = this;
      var path = request.path,
        responseType = request.responseType;
      var basePath = "services/data/v".concat(this.connection.version, "/jobs/query");
      var url = new _URL(path ? basePath + path : basePath, this.connection.instanceUrl).toString();
      var httpApi = new BulkApiV2(this.connection, {
        responseType: responseType
      });
      httpApi.on('response', function (response) {
        _this3.locator = response.headers['sforce-locator'];
        _this3.logger.debug("sforce-locator: ".concat(_this3.locator));
      });
      return httpApi.request(_objectSpread(_objectSpread({}, request), {}, {
        url: url
      }));
    }
  }]);
}(EventEmitter);

/**
 * Class for Bulk API V2 Ingest Job
 */
export var IngestJobV2 = /*#__PURE__*/function (_EventEmitter2) {
  /**
   *
   */
  function IngestJobV2(conn, options) {
    var _this4;
    _classCallCheck(this, IngestJobV2);
    _this4 = _callSuper(this, IngestJobV2);
    _this4.connection = conn;
    _this4.logger = _this4.connection._logLevel ? getLogger('bulk2:IngestJobV2').createInstance(_this4.connection._logLevel) : getLogger('bulk2:IngestJobV2');
    _this4.pollingOptions = options.pollingOptions;
    if ('id' in options) {
      _this4._id = options.id;
    } else {
      _this4.bodyParams = options.bodyParams;
    }
    _this4.jobData = new JobDataV2({
      createRequest: function createRequest(request) {
        return _this4.createIngestRequest(request);
      },
      job: _this4
    });
    // default error handler to keep the latest error
    _this4.on('error', function (error) {
      return _this4.error = error;
    });
    return _this4;
  }

  /**
   * Get the query job ID.
   *
   * @returns {string} query job Id.
   */
  _inherits(IngestJobV2, _EventEmitter2);
  return _createClass(IngestJobV2, [{
    key: "id",
    get: function get() {
      return this.jobInfo ? this.jobInfo.id : this._id;
    }

    /**
     * Get the query job info.
     *
     * @returns {Promise<QueryJobInfoV2>} ingest job information.
     */
  }, {
    key: "getInfo",
    value: function getInfo() {
      if (this.jobInfo) {
        return this.jobInfo;
      }
      throw new Error('No internal job info. Make sure to call `await job.check`.');
    }

    /**
     * Create a job representing a bulk operation in the org
     *
     * @returns {Promise<QueryJobInfoV2>} job information.
     */
  }, {
    key: "open",
    value: (function () {
      var _open2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee9() {
        return _regeneratorRuntime.wrap(function _callee9$(_context13) {
          while (1) switch (_context13.prev = _context13.next) {
            case 0:
              if (this.bodyParams) {
                _context13.next = 2;
                break;
              }
              throw new Error('Missing required body params to open a new ingest job.');
            case 2:
              _context13.prev = 2;
              _context13.next = 5;
              return this.createIngestRequest({
                method: 'POST',
                body: _JSON$stringify(this.bodyParams),
                headers: {
                  'Content-Type': 'application/json; charset=utf-8'
                },
                responseType: 'application/json'
              });
            case 5:
              this.jobInfo = _context13.sent;
              this.logger.debug("Successfully created job ".concat(this.id));
              this.emit('open');
              _context13.next = 14;
              break;
            case 10:
              _context13.prev = 10;
              _context13.t0 = _context13["catch"](2);
              this.emit('error', _context13.t0);
              throw _context13.t0;
            case 14:
              return _context13.abrupt("return", this.jobInfo);
            case 15:
            case "end":
              return _context13.stop();
          }
        }, _callee9, this, [[2, 10]]);
      }));
      function open() {
        return _open2.apply(this, arguments);
      }
      return open;
    }()
    /** Upload data for a job in CSV format
     *
     *  @param input CSV as a string, or array of records or readable stream
     */
    )
  }, {
    key: "uploadData",
    value: (function () {
      var _uploadData = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee10(input) {
        return _regeneratorRuntime.wrap(function _callee10$(_context14) {
          while (1) switch (_context14.prev = _context14.next) {
            case 0:
              _context14.next = 2;
              return this.jobData.execute(input).result;
            case 2:
              this.logger.debug("Successfully uploaded data to job ".concat(this.id));
            case 3:
            case "end":
              return _context14.stop();
          }
        }, _callee10, this);
      }));
      function uploadData(_x4) {
        return _uploadData.apply(this, arguments);
      }
      return uploadData;
    }()
    /**
     * Close opened job
     *
     * This method will notify the org  that the upload of job data is complete and is ready for processing.
     */
    )
  }, {
    key: "close",
    value: (function () {
      var _close = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee11() {
        var state;
        return _regeneratorRuntime.wrap(function _callee11$(_context15) {
          while (1) switch (_context15.prev = _context15.next) {
            case 0:
              _context15.prev = 0;
              state = 'UploadComplete';
              _context15.next = 4;
              return this.createIngestRequest({
                method: 'PATCH',
                path: "/".concat(this.id),
                body: _JSON$stringify({
                  state: state
                }),
                headers: {
                  'Content-Type': 'application/json; charset=utf-8'
                },
                responseType: 'application/json'
              });
            case 4:
              this.jobInfo = _context15.sent;
              this.logger.debug("Successfully closed job ".concat(this.id));
              this.emit('close');
              _context15.next = 13;
              break;
            case 9:
              _context15.prev = 9;
              _context15.t0 = _context15["catch"](0);
              this.emit('error', _context15.t0);
              throw _context15.t0;
            case 13:
            case "end":
              return _context15.stop();
          }
        }, _callee11, this, [[0, 9]]);
      }));
      function close() {
        return _close.apply(this, arguments);
      }
      return close;
    }()
    /**
     * Set the status to abort
     */
    )
  }, {
    key: "abort",
    value: (function () {
      var _abort2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee12() {
        var state;
        return _regeneratorRuntime.wrap(function _callee12$(_context16) {
          while (1) switch (_context16.prev = _context16.next) {
            case 0:
              _context16.prev = 0;
              state = 'Aborted';
              _context16.next = 4;
              return this.createIngestRequest({
                method: 'PATCH',
                path: "/".concat(this.id),
                body: _JSON$stringify({
                  state: state
                }),
                headers: {
                  'Content-Type': 'application/json; charset=utf-8'
                },
                responseType: 'application/json'
              });
            case 4:
              this.jobInfo = _context16.sent;
              this.logger.debug("Successfully aborted job ".concat(this.id));
              this.emit('aborted');
              _context16.next = 13;
              break;
            case 9:
              _context16.prev = 9;
              _context16.t0 = _context16["catch"](0);
              this.emit('error', _context16.t0);
              throw _context16.t0;
            case 13:
            case "end":
              return _context16.stop();
          }
        }, _callee12, this, [[0, 9]]);
      }));
      function abort() {
        return _abort2.apply(this, arguments);
      }
      return abort;
    }()
    /**
     * Poll for the state of the processing for the job.
     *
     * This method will only throw after a timeout. To capture a
     * job failure while polling you must set a listener for the
     * `failed` event before calling it:
     *
     * job.on('failed', (err) => console.error(err))
     * await job.poll()
     *
     * @param interval Polling interval in milliseconds
     * @param timeout Polling timeout in milliseconds
     * @returns {Promise<void>} A promise that resolves when the job finishes successfully
     */
    )
  }, {
    key: "poll",
    value: (function () {
      var _poll2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee13() {
        var _context17, _context18;
        var interval,
          timeout,
          jobId,
          startTime,
          endTime,
          res,
          timeoutError,
          _args13 = arguments;
        return _regeneratorRuntime.wrap(function _callee13$(_context19) {
          while (1) switch (_context19.prev = _context19.next) {
            case 0:
              interval = _args13.length > 0 && _args13[0] !== undefined ? _args13[0] : this.pollingOptions.pollInterval;
              timeout = _args13.length > 1 && _args13[1] !== undefined ? _args13[1] : this.pollingOptions.pollTimeout;
              jobId = this.id;
              startTime = _Date$now();
              endTime = startTime + timeout;
              if (!(timeout === 0)) {
                _context19.next = 7;
                break;
              }
              throw new JobPollingTimeoutError("Skipping polling because of timeout = 0ms. Job Id = ".concat(jobId), jobId);
            case 7:
              this.logger.debug('Start polling for job status');
              this.logger.debug(_concatInstanceProperty(_context17 = "Polling options: timeout:".concat(timeout, "ms | interval: ")).call(_context17, interval, "ms."));
            case 9:
              if (!(endTime > _Date$now())) {
                _context19.next = 36;
                break;
              }
              _context19.prev = 10;
              _context19.next = 13;
              return this.check();
            case 13:
              res = _context19.sent;
              _context19.t0 = res.state;
              _context19.next = _context19.t0 === 'Open' ? 17 : _context19.t0 === 'Aborted' ? 18 : _context19.t0 === 'UploadComplete' ? 19 : _context19.t0 === 'InProgress' ? 19 : _context19.t0 === 'Failed' ? 23 : _context19.t0 === 'JobComplete' ? 25 : 28;
              break;
            case 17:
              throw new Error('Job is still open. Make sure close the job by `close` method on the job instance before polling.');
            case 18:
              throw new Error('Job has been aborted');
            case 19:
              this.emit('inProgress', res);
              _context19.next = 22;
              return delay(interval);
            case 22:
              return _context19.abrupt("break", 28);
            case 23:
              this.logger.debug(res);
              throw new Error("Ingest job failed to complete due to: ".concat(res.errorMessage));
            case 25:
              this.logger.debug("Job ".concat(this.id, " was successfully processed."));
              this.emit('jobComplete', res);
              return _context19.abrupt("return");
            case 28:
              _context19.next = 34;
              break;
            case 30:
              _context19.prev = 30;
              _context19.t1 = _context19["catch"](10);
              this.emit('error', _context19.t1);
              throw _context19.t1;
            case 34:
              _context19.next = 9;
              break;
            case 36:
              timeoutError = new JobPollingTimeoutError(_concatInstanceProperty(_context18 = "Polling timed out after ".concat(timeout, "ms. Job Id = ")).call(_context18, jobId), jobId);
              this.emit('error', timeoutError);
              throw timeoutError;
            case 39:
            case "end":
              return _context19.stop();
          }
        }, _callee13, this, [[10, 30]]);
      }));
      function poll() {
        return _poll2.apply(this, arguments);
      }
      return poll;
    }()
    /**
     * Check the latest batch status in server
     */
    )
  }, {
    key: "check",
    value: (function () {
      var _check2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee14() {
        var jobInfo;
        return _regeneratorRuntime.wrap(function _callee14$(_context20) {
          while (1) switch (_context20.prev = _context20.next) {
            case 0:
              _context20.prev = 0;
              _context20.next = 3;
              return this.createIngestRequest({
                method: 'GET',
                path: "/".concat(this.id),
                responseType: 'application/json'
              });
            case 3:
              jobInfo = _context20.sent;
              this.jobInfo = jobInfo;
              return _context20.abrupt("return", jobInfo);
            case 8:
              _context20.prev = 8;
              _context20.t0 = _context20["catch"](0);
              this.emit('error', _context20.t0);
              throw _context20.t0;
            case 12:
            case "end":
              return _context20.stop();
          }
        }, _callee14, this, [[0, 8]]);
      }));
      function check() {
        return _check2.apply(this, arguments);
      }
      return check;
    }()
    /** Return all record results
     *
     * This method will return successful, failed and unprocessed records
     *
     * @returns Promise<IngestJobV2Results>
     */
    )
  }, {
    key: "getAllResults",
    value: (function () {
      var _getAllResults = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee15() {
        var _yield$Promise$all, _yield$Promise$all2, successfulResults, failedResults, unprocessedRecords;
        return _regeneratorRuntime.wrap(function _callee15$(_context21) {
          while (1) switch (_context21.prev = _context21.next) {
            case 0:
              _context21.next = 2;
              return _Promise.all([this.getSuccessfulResults(), this.getFailedResults(), this.getUnprocessedRecords()]);
            case 2:
              _yield$Promise$all = _context21.sent;
              _yield$Promise$all2 = _slicedToArray(_yield$Promise$all, 3);
              successfulResults = _yield$Promise$all2[0];
              failedResults = _yield$Promise$all2[1];
              unprocessedRecords = _yield$Promise$all2[2];
              return _context21.abrupt("return", {
                successfulResults: successfulResults,
                failedResults: failedResults,
                unprocessedRecords: unprocessedRecords
              });
            case 8:
            case "end":
              return _context21.stop();
          }
        }, _callee15, this);
      }));
      function getAllResults() {
        return _getAllResults.apply(this, arguments);
      }
      return getAllResults;
    }()
    /** Return successful results
     *
     * The order of records returned is not guaranteed to match the ordering of the uploaded data.
     *
     * @param {boolean} raw Get results as a CSV string
     * @returns Promise<IngestJobV2SuccessfulResults>
     */
    )
  }, {
    key: "getSuccessfulResults",
    value: function () {
      var _getSuccessfulResults = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee16(raw) {
        var reqOpts, results;
        return _regeneratorRuntime.wrap(function _callee16$(_context22) {
          while (1) switch (_context22.prev = _context22.next) {
            case 0:
              reqOpts = {
                method: 'GET',
                path: "/".concat(this.id, "/successfulResults")
              };
              if (!raw) {
                _context22.next = 3;
                break;
              }
              return _context22.abrupt("return", this.createIngestRequest(_objectSpread(_objectSpread({}, reqOpts), {}, {
                responseType: 'text/plain'
              })));
            case 3:
              if (!this.bulkJobSuccessfulResults) {
                _context22.next = 5;
                break;
              }
              return _context22.abrupt("return", this.bulkJobSuccessfulResults);
            case 5:
              _context22.next = 7;
              return this.createIngestRequest({
                method: 'GET',
                path: "/".concat(this.id, "/successfulResults"),
                responseType: 'text/csv'
              });
            case 7:
              results = _context22.sent;
              this.bulkJobSuccessfulResults = results !== null && results !== void 0 ? results : [];
              return _context22.abrupt("return", this.bulkJobSuccessfulResults);
            case 10:
            case "end":
              return _context22.stop();
          }
        }, _callee16, this);
      }));
      function getSuccessfulResults(_x5) {
        return _getSuccessfulResults.apply(this, arguments);
      }
      return getSuccessfulResults;
    }()
    /** Return failed results
     *
     * The order of records in the response is not guaranteed to match the ordering of records in the original job data.
     *
     * @param {boolean} raw Get results as a CSV string
     * @returns Promise<IngestJobV2SuccessfulResults>
     */
  }, {
    key: "getFailedResults",
    value: function () {
      var _getFailedResults = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee17(raw) {
        var reqOpts, results;
        return _regeneratorRuntime.wrap(function _callee17$(_context23) {
          while (1) switch (_context23.prev = _context23.next) {
            case 0:
              reqOpts = {
                method: 'GET',
                path: "/".concat(this.id, "/failedResults")
              };
              if (!raw) {
                _context23.next = 3;
                break;
              }
              return _context23.abrupt("return", this.createIngestRequest(_objectSpread(_objectSpread({}, reqOpts), {}, {
                responseType: 'text/plain'
              })));
            case 3:
              if (!this.bulkJobFailedResults) {
                _context23.next = 5;
                break;
              }
              return _context23.abrupt("return", this.bulkJobFailedResults);
            case 5:
              _context23.next = 7;
              return this.createIngestRequest(_objectSpread(_objectSpread({}, reqOpts), {}, {
                responseType: 'text/csv'
              }));
            case 7:
              results = _context23.sent;
              this.bulkJobFailedResults = results !== null && results !== void 0 ? results : [];
              return _context23.abrupt("return", this.bulkJobFailedResults);
            case 10:
            case "end":
              return _context23.stop();
          }
        }, _callee17, this);
      }));
      function getFailedResults(_x6) {
        return _getFailedResults.apply(this, arguments);
      }
      return getFailedResults;
    }()
    /** Return unprocessed results
     *
     * The unprocessed records endpoint returns records as a CSV.
     * If the request helper is able to parse it, you get the records
     * as an array of objects.
     * If unable to parse it (bad CSV), you get the raw response as a string.
     *
     * The order of records in the response is not guaranteed to match the ordering of records in the original job data.
     *
     * @param {boolean} raw Get results as a CSV string
     * @returns Promise<IngestJobV2UnprocessedRecords>
     */
  }, {
    key: "getUnprocessedRecords",
    value: function () {
      var _getUnprocessedRecords = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee18(raw) {
        var reqOpts, results;
        return _regeneratorRuntime.wrap(function _callee18$(_context24) {
          while (1) switch (_context24.prev = _context24.next) {
            case 0:
              reqOpts = {
                method: 'GET',
                path: "/".concat(this.id, "/unprocessedrecords")
              };
              if (!raw) {
                _context24.next = 3;
                break;
              }
              return _context24.abrupt("return", this.createIngestRequest(_objectSpread(_objectSpread({}, reqOpts), {}, {
                responseType: 'text/plain'
              })));
            case 3:
              if (!this.bulkJobUnprocessedRecords) {
                _context24.next = 5;
                break;
              }
              return _context24.abrupt("return", this.bulkJobUnprocessedRecords);
            case 5:
              _context24.next = 7;
              return this.createIngestRequest(_objectSpread(_objectSpread({}, reqOpts), {}, {
                responseType: 'text/csv'
              }));
            case 7:
              results = _context24.sent;
              this.bulkJobUnprocessedRecords = results !== null && results !== void 0 ? results : [];
              return _context24.abrupt("return", this.bulkJobUnprocessedRecords);
            case 10:
            case "end":
              return _context24.stop();
          }
        }, _callee18, this);
      }));
      function getUnprocessedRecords(_x7) {
        return _getUnprocessedRecords.apply(this, arguments);
      }
      return getUnprocessedRecords;
    }()
    /**
     * Deletes an ingest job.
     */
  }, {
    key: "delete",
    value: (function () {
      var _delete3 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee19() {
        return _regeneratorRuntime.wrap(function _callee19$(_context25) {
          while (1) switch (_context25.prev = _context25.next) {
            case 0:
              return _context25.abrupt("return", this.createIngestRequest({
                method: 'DELETE',
                path: "/".concat(this.id)
              }));
            case 1:
            case "end":
              return _context25.stop();
          }
        }, _callee19, this);
      }));
      function _delete() {
        return _delete3.apply(this, arguments);
      }
      return _delete;
    }())
  }, {
    key: "createIngestRequest",
    value: function createIngestRequest(request) {
      var path = request.path,
        responseType = request.responseType;
      var basePath = "/services/data/v".concat(this.connection.version, "/jobs/ingest");
      var url = new _URL(path ? basePath + path : basePath, this.connection.instanceUrl).toString();
      return new BulkApiV2(this.connection, {
        responseType: responseType
      }).request(_objectSpread(_objectSpread({}, request), {}, {
        url: url
      }));
    }
  }]);
}(EventEmitter);
var JobDataV2 = /*#__PURE__*/function (_Writable) {
  /**
   *
   */
  function JobDataV2(options) {
    var _this5;
    _classCallCheck(this, JobDataV2);
    _this5 = _callSuper(this, JobDataV2, [{
      objectMode: true
    }]);
    var createRequest = options.createRequest;
    _this5.job = options.job;
    _this5.uploadStream = new Serializable();
    _this5.downloadStream = new Parsable();
    var converterOptions = {
      nullValue: '#N/A'
    };
    var uploadDataStream = _this5.uploadStream.stream('csv', converterOptions);
    var downloadDataStream = _this5.downloadStream.stream('csv', converterOptions);
    _this5.dataStream = concatStreamsAsDuplex(uploadDataStream, downloadDataStream);
    _this5.on('finish', function () {
      return _this5.uploadStream.end();
    });
    uploadDataStream.once('readable', function () {
      try {
        // pipe upload data to batch API request stream
        var req = createRequest({
          method: 'PUT',
          path: "/".concat(_this5.job.id, "/batches"),
          headers: {
            'Content-Type': 'text/csv'
          },
          responseType: 'application/json'
        });
        _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee20() {
          var res;
          return _regeneratorRuntime.wrap(function _callee20$(_context26) {
            while (1) switch (_context26.prev = _context26.next) {
              case 0:
                _context26.prev = 0;
                _context26.next = 3;
                return req;
              case 3:
                res = _context26.sent;
                _this5.emit('response', res);
                _context26.next = 10;
                break;
              case 7:
                _context26.prev = 7;
                _context26.t0 = _context26["catch"](0);
                _this5.emit('error', _context26.t0);
              case 10:
              case "end":
                return _context26.stop();
            }
          }, _callee20, null, [[0, 7]]);
        }))();
        uploadDataStream.pipe(req.stream());
      } catch (err) {
        _this5.emit('error', err);
      }
    });
    return _this5;
  }
  _inherits(JobDataV2, _Writable);
  return _createClass(JobDataV2, [{
    key: "_write",
    value: function _write(record_, enc, cb) {
      var Id = record_.Id,
        type = record_.type,
        attributes = record_.attributes,
        rrec = _objectWithoutProperties(record_, _excluded2);
      var record;
      switch (this.job.getInfo().operation) {
        case 'insert':
          record = rrec;
          break;
        case 'delete':
        case 'hardDelete':
          record = {
            Id: Id
          };
          break;
        default:
          record = _objectSpread({
            Id: Id
          }, rrec);
      }
      this.uploadStream.write(record, enc, cb);
    }

    /**
     * Returns duplex stream which accepts CSV data input and batch result output
     */
  }, {
    key: "stream",
    value: function stream() {
      return this.dataStream;
    }

    /**
     * Execute batch operation
     */
  }, {
    key: "execute",
    value: function execute(input) {
      var _this6 = this;
      if (this.result) {
        throw new Error('Data can only be uploaded to a job once.');
      }
      this.result = new _Promise(function (resolve, reject) {
        _this6.once('response', function () {
          return resolve();
        });
        _this6.once('error', reject);
      });
      if (is.nodeStream(input)) {
        // if input has stream.Readable interface
        input.pipe(this.dataStream);
      } else {
        var recordData = structuredClone(input);
        if (_Array$isArray(recordData)) {
          var _iterator = _createForOfIteratorHelper(recordData),
            _step;
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              var record = _step.value;
              for (var _i = 0, _Object$keys = _Object$keys2(record); _i < _Object$keys.length; _i++) {
                var key = _Object$keys[_i];
                if (typeof record[key] === 'boolean') {
                  record[key] = String(record[key]);
                }
              }
              this.write(record);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
          this.end();
        } else if (typeof recordData === 'string') {
          this.dataStream.write(recordData, 'utf8');
          this.dataStream.end();
        }
      }
      return this;
    }
  }]);
}(Writable);
function delay(ms) {
  return new _Promise(function (resolve) {
    return _setTimeout(resolve, ms);
  });
}

/*--------------------------------------------*/
/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */
registerModule('bulk2', function (conn) {
  return new BulkV2(conn);
});
export default BulkV2;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJXcml0YWJsZSIsIlNlcmlhbGl6YWJsZSIsIlBhcnNhYmxlIiwiSHR0cEFwaSIsInJlZ2lzdGVyTW9kdWxlIiwiZ2V0TG9nZ2VyIiwiY29uY2F0U3RyZWFtc0FzRHVwbGV4IiwiaXMiLCJKb2JQb2xsaW5nVGltZW91dEVycm9yIiwiX0Vycm9yIiwibWVzc2FnZSIsImpvYklkIiwiX3RoaXMiLCJfY2xhc3NDYWxsQ2hlY2siLCJfY2FsbFN1cGVyIiwibmFtZSIsIl9pbmhlcml0cyIsIl9jcmVhdGVDbGFzcyIsIl93cmFwTmF0aXZlU3VwZXIiLCJFcnJvciIsIkJ1bGtBcGlWMiIsIl9IdHRwQXBpIiwiYXJndW1lbnRzIiwia2V5IiwidmFsdWUiLCJoYXNFcnJvckluUmVzcG9uc2VCb2R5IiwiYm9keSIsIl9BcnJheSRpc0FycmF5IiwiX3R5cGVvZiIsImlzU2Vzc2lvbkV4cGlyZWQiLCJyZXNwb25zZSIsIl9jb250ZXh0Iiwic3RhdHVzQ29kZSIsIl9pbmNsdWRlc0luc3RhbmNlUHJvcGVydHkiLCJjYWxsIiwicGFyc2VFcnJvciIsImVycm9yQ29kZSIsIkJ1bGtWMiIsImNvbm5lY3Rpb24iLCJfZGVmaW5lUHJvcGVydHkiLCJsb2dnZXIiLCJfbG9nTGV2ZWwiLCJjcmVhdGVJbnN0YW5jZSIsImNyZWF0ZUpvYiIsIm9wdGlvbnMiLCJJbmdlc3RKb2JWMiIsImJvZHlQYXJhbXMiLCJwb2xsaW5nT3B0aW9ucyIsImpvYiIsInR5cGUiLCJsZW5ndGgiLCJ1bmRlZmluZWQiLCJpZCIsIlF1ZXJ5Sm9iVjIiLCJfbG9hZEFuZFdhaXRGb3JSZXN1bHRzIiwiX2FzeW5jVG9HZW5lcmF0b3IiLCJfcmVnZW5lcmF0b3JSdW50aW1lIiwibWFyayIsIl9jYWxsZWUiLCJwb2xsSW50ZXJ2YWwiLCJwb2xsVGltZW91dCIsImlucHV0IiwiY3JlYXRlSm9iT3B0cyIsImVyciIsIndyYXAiLCJfY2FsbGVlJCIsIl9jb250ZXh0MiIsInByZXYiLCJuZXh0IiwiX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzIiwiX2V4Y2x1ZGVkIiwib3BlbiIsInVwbG9hZERhdGEiLCJjbG9zZSIsInBvbGwiLCJnZXRBbGxSZXN1bHRzIiwiYWJydXB0Iiwic2VudCIsInQwIiwiZXJyb3IiLCJjb25jYXQiLCJkZWxldGUiLCJjYXRjaCIsImlnbm9yZWQiLCJzdG9wIiwibG9hZEFuZFdhaXRGb3JSZXN1bHRzIiwiX3giLCJhcHBseSIsIl9xdWVyeSIsIl9jYWxsZWUyIiwic29xbCIsInF1ZXJ5Sm9iIiwicmVjb3JkU3RyZWFtIiwiZGF0YVN0cmVhbSIsInF1ZXJ5UmVjb3Jkc1N0cmVhbSIsIl9jYWxsZWUyJCIsIl9jb250ZXh0MyIsInF1ZXJ5Iiwib3BlcmF0aW9uIiwic2NhbkFsbCIsImNvbHVtbkRlbGltaXRlciIsImxpbmVFbmRpbmciLCJzdHJlYW0iLCJyZXN1bHQiLCJ0aGVuIiwicyIsInBpcGUiLCJfeDIiLCJfeDMiLCJfRXZlbnRFbWl0dGVyIiwiY29ubiIsIl90aGlzMiIsIl9pZCIsIm9uIiwiZ2V0Iiwiam9iSW5mbyIsImdldEluZm8iLCJfb3BlbiIsIl9jYWxsZWUzIiwiX2NhbGxlZTMkIiwiX2NvbnRleHQ0IiwiY3JlYXRlUXVlcnlSZXF1ZXN0IiwibWV0aG9kIiwiX0pTT04kc3RyaW5naWZ5IiwiaGVhZGVycyIsInJlc3BvbnNlVHlwZSIsImRlYnVnIiwiZW1pdCIsIl9hYm9ydCIsIl9jYWxsZWU0Iiwic3RhdGUiLCJfY2FsbGVlNCQiLCJfY29udGV4dDUiLCJwYXRoIiwiYWJvcnQiLCJfcG9sbCIsIl9jYWxsZWU1IiwiX2NvbnRleHQ2IiwiX2NvbnRleHQ3IiwiaW50ZXJ2YWwiLCJ0aW1lb3V0Iiwic3RhcnRUaW1lIiwiZW5kVGltZSIsInJlcyIsInRpbWVvdXRFcnJvciIsIl9hcmdzNSIsIl9jYWxsZWU1JCIsIl9jb250ZXh0OCIsIl9EYXRlJG5vdyIsIl9jb25jYXRJbnN0YW5jZVByb3BlcnR5IiwiY2hlY2siLCJkZWxheSIsInQxIiwiX2NoZWNrIiwiX2NhbGxlZTYiLCJfY2FsbGVlNiQiLCJfY29udGV4dDkiLCJfcmVzdWx0IiwiX2NhbGxlZTciLCJyZXN1bHRTdHJlYW0iLCJyZXN1bHREYXRhU3RyZWFtIiwicmVzdWx0c1BhdGgiLCJfY29udGV4dDEwIiwicmVzUHJvbWlzZSIsIl9jYWxsZWU3JCIsIl9jb250ZXh0MTEiLCJsb2NhdG9yIiwiQWNjZXB0IiwiX2RlbGV0ZTIiLCJfY2FsbGVlOCIsIl9jYWxsZWU4JCIsIl9jb250ZXh0MTIiLCJyZXF1ZXN0IiwiX3RoaXMzIiwiYmFzZVBhdGgiLCJ2ZXJzaW9uIiwidXJsIiwiX1VSTCIsImluc3RhbmNlVXJsIiwidG9TdHJpbmciLCJodHRwQXBpIiwiX29iamVjdFNwcmVhZCIsIl9FdmVudEVtaXR0ZXIyIiwiX3RoaXM0Iiwiam9iRGF0YSIsIkpvYkRhdGFWMiIsImNyZWF0ZVJlcXVlc3QiLCJjcmVhdGVJbmdlc3RSZXF1ZXN0IiwiX29wZW4yIiwiX2NhbGxlZTkiLCJfY2FsbGVlOSQiLCJfY29udGV4dDEzIiwiX3VwbG9hZERhdGEiLCJfY2FsbGVlMTAiLCJfY2FsbGVlMTAkIiwiX2NvbnRleHQxNCIsImV4ZWN1dGUiLCJfeDQiLCJfY2xvc2UiLCJfY2FsbGVlMTEiLCJfY2FsbGVlMTEkIiwiX2NvbnRleHQxNSIsIl9hYm9ydDIiLCJfY2FsbGVlMTIiLCJfY2FsbGVlMTIkIiwiX2NvbnRleHQxNiIsIl9wb2xsMiIsIl9jYWxsZWUxMyIsIl9jb250ZXh0MTciLCJfY29udGV4dDE4IiwiX2FyZ3MxMyIsIl9jYWxsZWUxMyQiLCJfY29udGV4dDE5IiwiZXJyb3JNZXNzYWdlIiwiX2NoZWNrMiIsIl9jYWxsZWUxNCIsIl9jYWxsZWUxNCQiLCJfY29udGV4dDIwIiwiX2dldEFsbFJlc3VsdHMiLCJfY2FsbGVlMTUiLCJfeWllbGQkUHJvbWlzZSRhbGwiLCJfeWllbGQkUHJvbWlzZSRhbGwyIiwic3VjY2Vzc2Z1bFJlc3VsdHMiLCJmYWlsZWRSZXN1bHRzIiwidW5wcm9jZXNzZWRSZWNvcmRzIiwiX2NhbGxlZTE1JCIsIl9jb250ZXh0MjEiLCJfUHJvbWlzZSIsImFsbCIsImdldFN1Y2Nlc3NmdWxSZXN1bHRzIiwiZ2V0RmFpbGVkUmVzdWx0cyIsImdldFVucHJvY2Vzc2VkUmVjb3JkcyIsIl9zbGljZWRUb0FycmF5IiwiX2dldFN1Y2Nlc3NmdWxSZXN1bHRzIiwiX2NhbGxlZTE2IiwicmF3IiwicmVxT3B0cyIsInJlc3VsdHMiLCJfY2FsbGVlMTYkIiwiX2NvbnRleHQyMiIsImJ1bGtKb2JTdWNjZXNzZnVsUmVzdWx0cyIsIl94NSIsIl9nZXRGYWlsZWRSZXN1bHRzIiwiX2NhbGxlZTE3IiwiX2NhbGxlZTE3JCIsIl9jb250ZXh0MjMiLCJidWxrSm9iRmFpbGVkUmVzdWx0cyIsIl94NiIsIl9nZXRVbnByb2Nlc3NlZFJlY29yZHMiLCJfY2FsbGVlMTgiLCJfY2FsbGVlMTgkIiwiX2NvbnRleHQyNCIsImJ1bGtKb2JVbnByb2Nlc3NlZFJlY29yZHMiLCJfeDciLCJfZGVsZXRlMyIsIl9jYWxsZWUxOSIsIl9jYWxsZWUxOSQiLCJfY29udGV4dDI1IiwiX1dyaXRhYmxlIiwiX3RoaXM1Iiwib2JqZWN0TW9kZSIsInVwbG9hZFN0cmVhbSIsImRvd25sb2FkU3RyZWFtIiwiY29udmVydGVyT3B0aW9ucyIsIm51bGxWYWx1ZSIsInVwbG9hZERhdGFTdHJlYW0iLCJkb3dubG9hZERhdGFTdHJlYW0iLCJlbmQiLCJvbmNlIiwicmVxIiwiX2NhbGxlZTIwIiwiX2NhbGxlZTIwJCIsIl9jb250ZXh0MjYiLCJfd3JpdGUiLCJyZWNvcmRfIiwiZW5jIiwiY2IiLCJJZCIsImF0dHJpYnV0ZXMiLCJycmVjIiwiX2V4Y2x1ZGVkMiIsInJlY29yZCIsIndyaXRlIiwiX3RoaXM2IiwicmVzb2x2ZSIsInJlamVjdCIsIm5vZGVTdHJlYW0iLCJyZWNvcmREYXRhIiwic3RydWN0dXJlZENsb25lIiwiX2l0ZXJhdG9yIiwiX2NyZWF0ZUZvck9mSXRlcmF0b3JIZWxwZXIiLCJfc3RlcCIsIm4iLCJkb25lIiwiX2kiLCJfT2JqZWN0JGtleXMiLCJfT2JqZWN0JGtleXMyIiwiU3RyaW5nIiwiZSIsImYiLCJtcyIsIl9zZXRUaW1lb3V0Il0sInNvdXJjZXMiOlsiLi4vLi4vc3JjL2FwaS9idWxrMi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudHMnO1xuaW1wb3J0IHsgRHVwbGV4LCBSZWFkYWJsZSwgV3JpdGFibGUgfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi4vY29ubmVjdGlvbic7XG5pbXBvcnQgeyBTZXJpYWxpemFibGUsIFBhcnNhYmxlIH0gZnJvbSAnLi4vcmVjb3JkLXN0cmVhbSc7XG5pbXBvcnQgSHR0cEFwaSBmcm9tICcuLi9odHRwLWFwaSc7XG5pbXBvcnQgeyBTdHJlYW1Qcm9taXNlIH0gZnJvbSAnLi4vdXRpbC9wcm9taXNlJztcbmltcG9ydCB7IHJlZ2lzdGVyTW9kdWxlIH0gZnJvbSAnLi4vanNmb3JjZSc7XG5pbXBvcnQgeyBCdWxrUmVxdWVzdCB9IGZyb20gJy4vYnVsayc7XG5pbXBvcnQgeyBnZXRMb2dnZXIsIExvZ2dlciB9IGZyb20gJy4uL3V0aWwvbG9nZ2VyJztcbmltcG9ydCB7IGNvbmNhdFN0cmVhbXNBc0R1cGxleCB9IGZyb20gJy4uL3V0aWwvc3RyZWFtJztcbmltcG9ydCB7IEh0dHBSZXNwb25zZSwgUmVjb3JkLCBTY2hlbWEgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgaXMgZnJvbSAnQHNpbmRyZXNvcmh1cy9pcyc7XG5cbmV4cG9ydCB0eXBlIEluZ2VzdE9wZXJhdGlvbiA9XG4gIHwgJ2luc2VydCdcbiAgfCAndXBkYXRlJ1xuICB8ICd1cHNlcnQnXG4gIHwgJ2RlbGV0ZSdcbiAgfCAnaGFyZERlbGV0ZSc7XG5cbnR5cGUgQmFzZUpvYkluZm8gPSB7XG4gIGlkOiBzdHJpbmc7XG4gIG9iamVjdDogc3RyaW5nO1xuICBjcmVhdGVkQnlJZDogc3RyaW5nO1xuICBjcmVhdGVkRGF0ZTogc3RyaW5nO1xuICBzeXN0ZW1Nb2RzdGFtcDogc3RyaW5nO1xuICBhcGlWZXJzaW9uOiBudW1iZXI7XG4gIGxpbmVFbmRpbmc6ICdMRicgfCAnQ1JMRic7XG4gIGNvbHVtbkRlbGltaXRlcjpcbiAgICB8ICdCQUNLUVVPVEUnXG4gICAgfCAnQ0FSRVQnXG4gICAgfCAnQ09NTUEnXG4gICAgfCAnUElQRSdcbiAgICB8ICdTRU1JQ09MT04nXG4gICAgfCAnVEFCJztcbiAgY29uY3VycmVuY3lNb2RlOiAnUGFyYWxsZWwnO1xuICBjb250ZW50VHlwZTogJ0NTVic7XG4gIG51bWJlclJlY29yZHNQcm9jZXNzZWQ6IG51bWJlcjtcbiAgcmV0cmllczogbnVtYmVyO1xuICB0b3RhbFByb2Nlc3NpbmdUaW1lOiBudW1iZXI7XG59O1xuXG5leHBvcnQgdHlwZSBRdWVyeUpvYkluZm9WMiA9IEJhc2VKb2JJbmZvICYge1xuICBvcGVyYXRpb246ICdxdWVyeScgfCAncXVlcnlBbGwnO1xuICBzdGF0ZTogJ1VwbG9hZENvbXBsZXRlJyB8ICdJblByb2dyZXNzJyB8ICdBYm9ydGVkJyB8ICdKb2JDb21wbGV0ZScgfCAnRmFpbGVkJztcbiAgam9iVHlwZTogJ1YyUXVlcnknO1xuICBpc1BrQ2h1bmtpbmdTdXBwb3J0ZWQ6IGJvb2xlYW47XG59O1xuXG5leHBvcnQgdHlwZSBKb2JJbmZvVjIgPSBCYXNlSm9iSW5mbyAmIHtcbiAgYXBleFByb2Nlc3NpbmdUaW1lOiBudW1iZXI7XG4gIGFwaUFjdGl2ZVByb2Nlc3NpbmdUaW1lOiBudW1iZXI7XG4gIGFzc2lnbm1lbnRSdWxlSWQ/OiBzdHJpbmc7XG4gIGNvbnRlbnRVcmw6IHN0cmluZztcbiAgZXJyb3JNZXNzYWdlPzogc3RyaW5nO1xuICBleHRlcm5hbElkRmllbGROYW1lPzogc3RyaW5nO1xuICBqb2JUeXBlOiAnQmlnT2JqZWN0SW5nZXN0JyB8ICdDbGFzc2ljJyB8ICdWMkluZ2VzdCc7XG4gIG9wZXJhdGlvbjogSW5nZXN0T3BlcmF0aW9uO1xuICBzdGF0ZTpcbiAgICB8ICdPcGVuJ1xuICAgIHwgJ1VwbG9hZENvbXBsZXRlJ1xuICAgIHwgJ0luUHJvZ3Jlc3MnXG4gICAgfCAnSm9iQ29tcGxldGUnXG4gICAgfCAnQWJvcnRlZCdcbiAgICB8ICdGYWlsZWQnO1xuICBudW1iZXJSZWNvcmRzRmFpbGVkOiBudW1iZXI7XG59O1xuXG5leHBvcnQgdHlwZSBJbmdlc3RKb2JWMlN1Y2Nlc3NmdWxSZXN1bHRzPFMgZXh0ZW5kcyBTY2hlbWE+ID0gQXJyYXk8XG4gIHtcbiAgICBzZl9fQ3JlYXRlZDogJ3RydWUnIHwgJ2ZhbHNlJztcbiAgICBzZl9fSWQ6IHN0cmluZztcbiAgfSAmIFNcbj47XG5cbmV4cG9ydCB0eXBlIEluZ2VzdEpvYlYyRmFpbGVkUmVzdWx0czxTIGV4dGVuZHMgU2NoZW1hPiA9IEFycmF5PFxuICB7XG4gICAgc2ZfX0Vycm9yOiBzdHJpbmc7XG4gICAgc2ZfX0lkOiBzdHJpbmc7XG4gIH0gJiBTXG4+O1xuXG5leHBvcnQgdHlwZSBJbmdlc3RKb2JWMlVucHJvY2Vzc2VkUmVjb3JkczxTIGV4dGVuZHMgU2NoZW1hPiA9IFNbXSB8IHN0cmluZztcblxuZXhwb3J0IHR5cGUgSW5nZXN0Sm9iVjJSZXN1bHRzPFMgZXh0ZW5kcyBTY2hlbWE+ID0ge1xuICBzdWNjZXNzZnVsUmVzdWx0czogSW5nZXN0Sm9iVjJTdWNjZXNzZnVsUmVzdWx0czxTPjtcbiAgZmFpbGVkUmVzdWx0czogSW5nZXN0Sm9iVjJGYWlsZWRSZXN1bHRzPFM+O1xuICB1bnByb2Nlc3NlZFJlY29yZHM6IEluZ2VzdEpvYlYyVW5wcm9jZXNzZWRSZWNvcmRzPFM+O1xufTtcblxudHlwZSBOZXdJbmdlc3RKb2JPcHRpb25zID0gUmVxdWlyZWQ8UGljazxKb2JJbmZvVjIsICdvYmplY3QnIHwgJ29wZXJhdGlvbic+PiAmXG4gIFBhcnRpYWw8XG4gICAgUGljazxcbiAgICAgIEpvYkluZm9WMixcbiAgICAgIHwgJ2Fzc2lnbm1lbnRSdWxlSWQnXG4gICAgICB8ICdjb2x1bW5EZWxpbWl0ZXInXG4gICAgICB8ICdleHRlcm5hbElkRmllbGROYW1lJ1xuICAgICAgfCAnbGluZUVuZGluZydcbiAgICAgIHwgJ2NvbnRlbnRUeXBlJ1xuICAgID5cbiAgPjtcblxudHlwZSBOZXdRdWVyeUpvYk9wdGlvbnMgPSB7XG4gIHF1ZXJ5OiBzdHJpbmc7XG4gIG9wZXJhdGlvbjogUXVlcnlKb2JJbmZvVjJbJ29wZXJhdGlvbiddO1xufSAmIFBhcnRpYWw8UGljazxRdWVyeUpvYkluZm9WMiwgJ2NvbHVtbkRlbGltaXRlcicgfCAnbGluZUVuZGluZyc+PjtcblxudHlwZSBDcmVhdGVJbmdlc3RKb2JWMk9wdGlvbnMgPSB7XG4gIGJvZHlQYXJhbXM6IE5ld0luZ2VzdEpvYk9wdGlvbnM7XG4gIHBvbGxpbmdPcHRpb25zOiBCdWxrVjJQb2xsaW5nT3B0aW9ucztcbn07XG5cbnR5cGUgRXhpc3RpbmdJbmdlc3RKb2JPcHRpb25zID0ge1xuICBpZDogc3RyaW5nO1xuICBwb2xsaW5nT3B0aW9uczogQnVsa1YyUG9sbGluZ09wdGlvbnM7XG59O1xuXG50eXBlIENyZWF0ZUluZ2VzdEpvYlYyUmVxdWVzdCA9IDxUPihyZXF1ZXN0OiBCdWxrUmVxdWVzdCkgPT4gU3RyZWFtUHJvbWlzZTxUPjtcblxudHlwZSBDcmVhdGVKb2JEYXRhVjJPcHRpb25zPFMgZXh0ZW5kcyBTY2hlbWE+ID0ge1xuICBqb2I6IEluZ2VzdEpvYlYyPFM+O1xuICBjcmVhdGVSZXF1ZXN0OiBDcmVhdGVJbmdlc3RKb2JWMlJlcXVlc3Q7XG59O1xuXG50eXBlIENyZWF0ZVF1ZXJ5Sm9iVjJPcHRpb25zID0ge1xuICBib2R5UGFyYW1zOiBOZXdRdWVyeUpvYk9wdGlvbnM7XG4gIHBvbGxpbmdPcHRpb25zOiBCdWxrVjJQb2xsaW5nT3B0aW9ucztcbn07XG5cbnR5cGUgRXhpc3RpbmdRdWVyeUpvYlYyT3B0aW9ucyA9IHtcbiAgaWQ6IHN0cmluZztcbiAgcG9sbGluZ09wdGlvbnM6IEJ1bGtWMlBvbGxpbmdPcHRpb25zO1xufTtcblxudHlwZSBCdWxrVjJQb2xsaW5nT3B0aW9ucyA9IHtcbiAgcG9sbEludGVydmFsOiBudW1iZXI7XG4gIHBvbGxUaW1lb3V0OiBudW1iZXI7XG59O1xuXG5jbGFzcyBKb2JQb2xsaW5nVGltZW91dEVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBqb2JJZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IobWVzc2FnZTogc3RyaW5nLCBqb2JJZDogc3RyaW5nKSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0pvYlBvbGxpbmdUaW1lb3V0JztcbiAgICB0aGlzLmpvYklkID0gam9iSWQ7XG4gIH1cbn1cblxuY2xhc3MgQnVsa0FwaVYyPFMgZXh0ZW5kcyBTY2hlbWE+IGV4dGVuZHMgSHR0cEFwaTxTPiB7XG4gIGhhc0Vycm9ySW5SZXNwb25zZUJvZHkoYm9keTogYW55KSB7XG4gICAgcmV0dXJuIChcbiAgICAgIEFycmF5LmlzQXJyYXkoYm9keSkgJiZcbiAgICAgIHR5cGVvZiBib2R5WzBdID09PSAnb2JqZWN0JyAmJlxuICAgICAgJ2Vycm9yQ29kZScgaW4gYm9keVswXVxuICAgICk7XG4gIH1cblxuICBpc1Nlc3Npb25FeHBpcmVkKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpOiBib29sZWFuIHtcbiAgICByZXR1cm4gKFxuICAgICAgcmVzcG9uc2Uuc3RhdHVzQ29kZSA9PT0gNDAxICYmXG4gICAgICByZXNwb25zZS5ib2R5LmluY2x1ZGVzKCdJTlZBTElEX1NFU1NJT05fSUQnKVxuICAgICk7XG4gIH1cblxuICBwYXJzZUVycm9yKGJvZHk6IGFueSkge1xuICAgIHJldHVybiB7XG4gICAgICBlcnJvckNvZGU6IGJvZHlbMF0uZXJyb3JDb2RlLFxuICAgICAgbWVzc2FnZTogYm9keVswXS5tZXNzYWdlLFxuICAgIH07XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIEJ1bGtWMjxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIHByaXZhdGUgY29ubmVjdGlvbjogQ29ubmVjdGlvbjxTPjtcbiAgcHJpdmF0ZSBsb2dnZXI6IExvZ2dlcjtcblxuICAvKipcbiAgICogUG9sbGluZyBpbnRlcnZhbCBpbiBtaWxsaXNlY29uZHNcbiAgICpcbiAgICogRGVmYXVsdDogMTAwMCAoMSBzZWNvbmQpXG4gICAqL1xuICBwdWJsaWMgcG9sbEludGVydmFsID0gMTAwMDtcblxuICAvKipcbiAgICogUG9sbGluZyB0aW1lb3V0IGluIG1pbGxpc2Vjb25kc1xuICAgKlxuICAgKiBEZWZhdWx0OiAzMDAwMCAoMzAgc2Vjb25kcylcbiAgICovXG4gIHB1YmxpYyBwb2xsVGltZW91dCA9IDMwMDAwO1xuXG4gIGNvbnN0cnVjdG9yKGNvbm5lY3Rpb246IENvbm5lY3Rpb248Uz4pIHtcbiAgICB0aGlzLmNvbm5lY3Rpb24gPSBjb25uZWN0aW9uO1xuICAgIHRoaXMubG9nZ2VyID0gdGhpcy5jb25uZWN0aW9uLl9sb2dMZXZlbFxuICAgICAgPyBnZXRMb2dnZXIoJ2J1bGsyJykuY3JlYXRlSW5zdGFuY2UodGhpcy5jb25uZWN0aW9uLl9sb2dMZXZlbClcbiAgICAgIDogZ2V0TG9nZ2VyKCdidWxrMicpO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhbiBpbnN0YW5jZSBvZiBhbiBpbmdlc3Qgam9iIG9iamVjdC5cbiAgICpcbiAgICogQHBhcmFtcyB7TmV3SW5nZXN0Sm9iT3B0aW9uc30gb3B0aW9ucyBvYmplY3RcbiAgICogQHJldHVybnMge0luZ2VzdEpvYlYyfSBBbiBpbmdlc3Qgam9iIGluc3RhbmNlXG4gICAqIEBleGFtcGxlXG4gICAqIC8vIFVwc2VydCByZWNvcmRzIHRvIHRoZSBBY2NvdW50IG9iamVjdC5cbiAgICpcbiAgICogY29uc3Qgam9iID0gY29ubmVjdGlvbi5idWxrMi5jcmVhdGVKb2Ioe1xuICAgKiAgIG9wZXJhdGlvbjogJ2luc2VydCdcbiAgICogICBvYmplY3Q6ICdBY2NvdW50JyxcbiAgICogfSk7XG4gICAqXG4gICAqIC8vIGNyZWF0ZSB0aGUgam9iIGluIHRoZSBvcmdcbiAgICogYXdhaXQgam9iLm9wZW4oKVxuICAgKlxuICAgKiAvLyB1cGxvYWQgZGF0YVxuICAgKiBhd2FpdCBqb2IudXBsb2FkRGF0YShjc3ZGaWxlKVxuICAgKlxuICAgKiAvLyBmaW5pc2hlZCB1cGxvYWRpbmcgZGF0YSwgbWFyayBpdCBhcyByZWFkeSBmb3IgcHJvY2Vzc2luZ1xuICAgKiBhd2FpdCBqb2IuY2xvc2UoKVxuICAgKi9cbiAgcHVibGljIGNyZWF0ZUpvYihvcHRpb25zOiBOZXdJbmdlc3RKb2JPcHRpb25zKTogSW5nZXN0Sm9iVjI8Uz4ge1xuICAgIHJldHVybiBuZXcgSW5nZXN0Sm9iVjIodGhpcy5jb25uZWN0aW9uLCB7XG4gICAgICBib2R5UGFyYW1zOiBvcHRpb25zLFxuICAgICAgcG9sbGluZ09wdGlvbnM6IHRoaXMsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IGFuIGluZ2VzdCBvciBxdWVyeSBqb2IgaW5zdGFuY2Ugc3BlY2lmaWVkIGJ5IGEgZ2l2ZW4gam9iIElEXG4gICAqXG4gICAqIEBwYXJhbSBvcHRpb25zIE9wdGlvbnMgb2JqZWN0IHdpdGggYSBqb2IgSURcbiAgICogQHJldHVybnMgSW5nZXN0Sm9iVjIgQW4gaW5nZXN0IGpvYlxuICAgKi9cbiAgcHVibGljIGpvYihcbiAgICB0eXBlOiAncXVlcnknLFxuICAgIG9wdGlvbnM6IFBpY2s8RXhpc3RpbmdRdWVyeUpvYlYyT3B0aW9ucywgJ2lkJz4sXG4gICk6IFF1ZXJ5Sm9iVjI8Uz47XG4gIHB1YmxpYyBqb2IoXG4gICAgdHlwZTogJ2luZ2VzdCcsXG4gICAgb3B0aW9uczogUGljazxFeGlzdGluZ0luZ2VzdEpvYk9wdGlvbnMsICdpZCc+LFxuICApOiBJbmdlc3RKb2JWMjxTPjtcbiAgcHVibGljIGpvYihcbiAgICB0eXBlOiAnaW5nZXN0JyB8ICdxdWVyeScgPSAnaW5nZXN0JyxcbiAgICBvcHRpb25zOiBFeGlzdGluZ0luZ2VzdEpvYk9wdGlvbnMgfCBFeGlzdGluZ1F1ZXJ5Sm9iVjJPcHRpb25zLFxuICApOiBJbmdlc3RKb2JWMjxTPiB8IFF1ZXJ5Sm9iVjI8Uz4ge1xuICAgIGlmICh0eXBlID09PSAnaW5nZXN0Jykge1xuICAgICAgcmV0dXJuIG5ldyBJbmdlc3RKb2JWMih0aGlzLmNvbm5lY3Rpb24sIHtcbiAgICAgICAgaWQ6IG9wdGlvbnMuaWQsXG4gICAgICAgIHBvbGxpbmdPcHRpb25zOiB0aGlzLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBuZXcgUXVlcnlKb2JWMih0aGlzLmNvbm5lY3Rpb24sIHtcbiAgICAgICAgaWQ6IG9wdGlvbnMuaWQsXG4gICAgICAgIHBvbGxpbmdPcHRpb25zOiB0aGlzLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSwgdXBsb2FkLCBhbmQgc3RhcnQgYnVsa2xvYWQgam9iXG4gICAqL1xuICBhc3luYyBsb2FkQW5kV2FpdEZvclJlc3VsdHMoXG4gICAgb3B0aW9uczogTmV3SW5nZXN0Sm9iT3B0aW9ucyAmXG4gICAgICBQYXJ0aWFsPEJ1bGtWMlBvbGxpbmdPcHRpb25zPiAmIHtcbiAgICAgICAgaW5wdXQ6IFJlY29yZFtdIHwgUmVhZGFibGUgfCBzdHJpbmc7XG4gICAgICB9LFxuICApOiBQcm9taXNlPEluZ2VzdEpvYlYyUmVzdWx0czxTPj4ge1xuICAgIGlmICghb3B0aW9ucy5wb2xsVGltZW91dCkgb3B0aW9ucy5wb2xsVGltZW91dCA9IHRoaXMucG9sbFRpbWVvdXQ7XG4gICAgaWYgKCFvcHRpb25zLnBvbGxJbnRlcnZhbCkgb3B0aW9ucy5wb2xsSW50ZXJ2YWwgPSB0aGlzLnBvbGxJbnRlcnZhbDtcblxuICAgIGNvbnN0IHsgcG9sbEludGVydmFsLCBwb2xsVGltZW91dCwgaW5wdXQsIC4uLmNyZWF0ZUpvYk9wdHMgfSA9IG9wdGlvbnM7XG5cbiAgICBjb25zdCBqb2IgPSB0aGlzLmNyZWF0ZUpvYihjcmVhdGVKb2JPcHRzKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgam9iLm9wZW4oKTtcbiAgICAgIGF3YWl0IGpvYi51cGxvYWREYXRhKGlucHV0KTtcbiAgICAgIGF3YWl0IGpvYi5jbG9zZSgpO1xuICAgICAgYXdhaXQgam9iLnBvbGwocG9sbEludGVydmFsLCBwb2xsVGltZW91dCk7XG4gICAgICByZXR1cm4gYXdhaXQgam9iLmdldEFsbFJlc3VsdHMoKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc3QgZXJyID0gZXJyb3IgYXMgRXJyb3I7XG4gICAgICB0aGlzLmxvZ2dlci5lcnJvcihgYnVsayBsb2FkIGZhaWxlZCBkdWUgdG86ICR7ZXJyLm1lc3NhZ2V9YCk7XG5cbiAgICAgIGlmIChlcnIubmFtZSAhPT0gJ0pvYlBvbGxpbmdUaW1lb3V0RXJyb3InKSB7XG4gICAgICAgIC8vIGZpcmVzIG9mZiBvbmUgbGFzdCBhdHRlbXB0IHRvIGNsZWFuIHVwIGFuZCBpZ25vcmVzIHRoZSByZXN1bHQgfCBlcnJvclxuICAgICAgICBqb2IuZGVsZXRlKCkuY2F0Y2goKGlnbm9yZWQpID0+IGlnbm9yZWQpO1xuICAgICAgfVxuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBFeGVjdXRlIGJ1bGsgcXVlcnkgYW5kIGdldCBhIHJlY29yZCBzdHJlYW0uXG4gICAqXG4gICAqIERlZmF1bHQgdGltZW91dDogMTAwMDBtc1xuICAgKlxuICAgKiBAcGFyYW0gc29xbCBTT1FMIHF1ZXJ5XG4gICAqIEBwYXJhbSBvcHRpb25zXG4gICAqXG4gICAqIEByZXR1cm5zIHtSZWNvcmRTdHJlYW19IC0gUmVjb3JkIHN0cmVhbSwgY29udmVydGlibGUgdG8gYSBDU1YgZGF0YSBzdHJlYW1cbiAgICovXG4gIGFzeW5jIHF1ZXJ5KFxuICAgIHNvcWw6IHN0cmluZyxcbiAgICBvcHRpb25zPzogUGFydGlhbDxCdWxrVjJQb2xsaW5nT3B0aW9ucz4gJiB7XG4gICAgICBzY2FuQWxsPzogYm9vbGVhbjtcbiAgICAgIGNvbHVtbkRlbGltaXRlcj86IFF1ZXJ5Sm9iSW5mb1YyWydjb2x1bW5EZWxpbWl0ZXInXTtcbiAgICAgIGxpbmVFbmRpbmc/OiBRdWVyeUpvYkluZm9WMlsnbGluZUVuZGluZyddO1xuICAgIH0sXG4gICk6IFByb21pc2U8UGFyc2FibGU8UmVjb3JkPj4ge1xuICAgIGNvbnN0IHF1ZXJ5Sm9iID0gbmV3IFF1ZXJ5Sm9iVjIodGhpcy5jb25uZWN0aW9uLCB7XG4gICAgICBib2R5UGFyYW1zOiB7XG4gICAgICAgIHF1ZXJ5OiBzb3FsLFxuICAgICAgICBvcGVyYXRpb246IG9wdGlvbnM/LnNjYW5BbGwgPyAncXVlcnlBbGwnIDogJ3F1ZXJ5JyxcbiAgICAgICAgY29sdW1uRGVsaW1pdGVyOiBvcHRpb25zPy5jb2x1bW5EZWxpbWl0ZXIsXG4gICAgICAgIGxpbmVFbmRpbmc6IG9wdGlvbnM/LmxpbmVFbmRpbmcsXG4gICAgICB9LFxuICAgICAgcG9sbGluZ09wdGlvbnM6IHRoaXMsXG4gICAgfSk7XG5cbiAgICBjb25zdCByZWNvcmRTdHJlYW0gPSBuZXcgUGFyc2FibGUoKTtcbiAgICBjb25zdCBkYXRhU3RyZWFtID0gcmVjb3JkU3RyZWFtLnN0cmVhbSgnY3N2Jyk7XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgcXVlcnlKb2Iub3BlbigpO1xuICAgICAgYXdhaXQgcXVlcnlKb2IucG9sbChvcHRpb25zPy5wb2xsSW50ZXJ2YWwsIG9wdGlvbnM/LnBvbGxUaW1lb3V0KTtcblxuICAgICAgY29uc3QgcXVlcnlSZWNvcmRzU3RyZWFtID0gYXdhaXQgcXVlcnlKb2JcbiAgICAgICAgLnJlc3VsdCgpXG4gICAgICAgIC50aGVuKChzKSA9PiBzLnN0cmVhbSgpKTtcbiAgICAgIHF1ZXJ5UmVjb3Jkc1N0cmVhbS5waXBlKGRhdGFTdHJlYW0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zdCBlcnIgPSBlcnJvciBhcyBFcnJvcjtcbiAgICAgIHRoaXMubG9nZ2VyLmVycm9yKGBidWxrIHF1ZXJ5IGZhaWxlZCBkdWUgdG86ICR7ZXJyLm1lc3NhZ2V9YCk7XG5cbiAgICAgIGlmIChlcnIubmFtZSAhPT0gJ0pvYlBvbGxpbmdUaW1lb3V0RXJyb3InKSB7XG4gICAgICAgIC8vIGZpcmVzIG9mZiBvbmUgbGFzdCBhdHRlbXB0IHRvIGNsZWFuIHVwIGFuZCBpZ25vcmVzIHRoZSByZXN1bHQgfCBlcnJvclxuICAgICAgICBxdWVyeUpvYi5kZWxldGUoKS5jYXRjaCgoaWdub3JlZCkgPT4gaWdub3JlZCk7XG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gICAgcmV0dXJuIHJlY29yZFN0cmVhbTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgUXVlcnlKb2JWMjxTIGV4dGVuZHMgU2NoZW1hPiBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIHByaXZhdGUgcmVhZG9ubHkgY29ubmVjdGlvbjogQ29ubmVjdGlvbjxTPjtcbiAgcHJpdmF0ZSByZWFkb25seSBsb2dnZXI6IExvZ2dlcjtcbiAgcHJpdmF0ZSByZWFkb25seSBfaWQ/OiBzdHJpbmc7XG4gIHByaXZhdGUgcmVhZG9ubHkgYm9keVBhcmFtcz86IE5ld1F1ZXJ5Sm9iT3B0aW9ucztcbiAgcHJpdmF0ZSByZWFkb25seSBwb2xsaW5nT3B0aW9uczogQnVsa1YyUG9sbGluZ09wdGlvbnM7XG4gIHByaXZhdGUgZXJyb3I6IEVycm9yIHwgdW5kZWZpbmVkO1xuICBwcml2YXRlIGpvYkluZm8/OiBRdWVyeUpvYkluZm9WMjtcbiAgcHJpdmF0ZSBsb2NhdG9yPzogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIGNvbm46IENvbm5lY3Rpb248Uz4sXG4gICAgb3B0aW9uczogRXhpc3RpbmdRdWVyeUpvYlYyT3B0aW9ucyB8IENyZWF0ZVF1ZXJ5Sm9iVjJPcHRpb25zLFxuICApIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuY29ubmVjdGlvbiA9IGNvbm47XG4gICAgdGhpcy5sb2dnZXIgPSB0aGlzLmNvbm5lY3Rpb24uX2xvZ0xldmVsXG4gICAgICA/IGdldExvZ2dlcignYnVsazI6UXVlcnlKb2JWMicpLmNyZWF0ZUluc3RhbmNlKHRoaXMuY29ubmVjdGlvbi5fbG9nTGV2ZWwpXG4gICAgICA6IGdldExvZ2dlcignYnVsazI6UXVlcnlKb2JWMicpO1xuICAgIGlmICgnaWQnIGluIG9wdGlvbnMpIHtcbiAgICAgIHRoaXMuX2lkID0gb3B0aW9ucy5pZDtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5ib2R5UGFyYW1zID0gb3B0aW9ucy5ib2R5UGFyYW1zO1xuICAgIH1cbiAgICB0aGlzLnBvbGxpbmdPcHRpb25zID0gb3B0aW9ucy5wb2xsaW5nT3B0aW9ucztcbiAgICAvLyBkZWZhdWx0IGVycm9yIGhhbmRsZXIgdG8ga2VlcCB0aGUgbGF0ZXN0IGVycm9yXG4gICAgdGhpcy5vbignZXJyb3InLCAoZXJyb3IpID0+ICh0aGlzLmVycm9yID0gZXJyb3IpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgdGhlIHF1ZXJ5IGpvYiBJRC5cbiAgICpcbiAgICogQHJldHVybnMge3N0cmluZ30gcXVlcnkgam9iIElkLlxuICAgKi9cbiAgcHVibGljIGdldCBpZCgpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLmpvYkluZm8gPyB0aGlzLmpvYkluZm8uaWQgOiAodGhpcy5faWQgYXMgc3RyaW5nKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgdGhlIHF1ZXJ5IGpvYiBpbmZvLlxuICAgKlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxRdWVyeUpvYkluZm9WMj59IHF1ZXJ5IGpvYiBpbmZvcm1hdGlvbi5cbiAgICovXG4gIHB1YmxpYyBnZXRJbmZvKCk6IFF1ZXJ5Sm9iSW5mb1YyIHtcbiAgICBpZiAodGhpcy5qb2JJbmZvKSB7XG4gICAgICByZXR1cm4gdGhpcy5qb2JJbmZvO1xuICAgIH1cblxuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdObyBpbnRlcm5hbCBqb2IgaW5mby4gTWFrZSBzdXJlIHRvIGNhbGwgYGF3YWl0IGpvYi5jaGVja2AuJyxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBxdWVyeSBqb2JcbiAgICpcbiAgICogQHJldHVybnMge1Byb21pc2U8UXVlcnlKb2JJbmZvVjI+fSBqb2IgaW5mb3JtYXRpb24uXG4gICAqL1xuICBhc3luYyBvcGVuKCk6IFByb21pc2U8UXVlcnlKb2JJbmZvVjI+IHtcbiAgICBpZiAoIXRoaXMuYm9keVBhcmFtcykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdNaXNzaW5nIHJlcXVpcmVkIGJvZHkgcGFyYW1zIHRvIG9wZW4gYSBuZXcgcXVlcnkgam9iLicpO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgdGhpcy5qb2JJbmZvID0gYXdhaXQgdGhpcy5jcmVhdGVRdWVyeVJlcXVlc3Q8UXVlcnlKb2JJbmZvVjI+KHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHRoaXMuYm9keVBhcmFtcyksXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLTgnLFxuICAgICAgICB9LFxuICAgICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIH0pO1xuICAgICAgdGhpcy5sb2dnZXIuZGVidWcoYFN1Y2Nlc3NmdWxseSBjcmVhdGVkIGpvYiAke3RoaXMuaWR9YCk7XG4gICAgICB0aGlzLmVtaXQoJ29wZW4nLCB0aGlzLmpvYkluZm8pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuam9iSW5mbztcbiAgfVxuXG4gIC8qKlxuICAgKiBBYm9ydCB0aGUgam9iXG4gICAqXG4gICAqIFRoZSAnYWJvcnRlZCcgZXZlbnQgaXMgZW1pdHRlZCB3aGVuIHRoZSBqb2Igc3VjY2Vzc2Z1bGx5IGFib3J0cy5cbiAgICogQHJldHVybnMge1Byb21pc2U8UXVlcnlKb2JJbmZvVjI+fSBqb2IgaW5mb3JtYXRpb24uXG4gICAqL1xuICBhc3luYyBhYm9ydCgpOiBQcm9taXNlPFF1ZXJ5Sm9iSW5mb1YyPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0YXRlOiBRdWVyeUpvYkluZm9WMlsnc3RhdGUnXSA9ICdBYm9ydGVkJztcbiAgICAgIHRoaXMuam9iSW5mbyA9IGF3YWl0IHRoaXMuY3JlYXRlUXVlcnlSZXF1ZXN0PFF1ZXJ5Sm9iSW5mb1YyPih7XG4gICAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgICAgcGF0aDogYC8ke3RoaXMuaWR9YCxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBzdGF0ZSB9KSxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLTgnIH0sXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmxvZ2dlci5kZWJ1ZyhgU3VjY2Vzc2Z1bGx5IGFib3J0ZWQgam9iICR7dGhpcy5pZH1gKTtcbiAgICAgIHJldHVybiB0aGlzLmpvYkluZm87XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUG9sbCBmb3IgdGhlIHN0YXRlIG9mIHRoZSBwcm9jZXNzaW5nIGZvciB0aGUgam9iLlxuICAgKlxuICAgKiBAcGFyYW0gaW50ZXJ2YWwgUG9sbGluZyBpbnRlcnZhbCBpbiBtaWxsaXNlY29uZHNcbiAgICogQHBhcmFtIHRpbWVvdXQgUG9sbGluZyB0aW1lb3V0IGluIG1pbGxpc2Vjb25kc1xuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxSZWNvcmRbXT59IEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdoZW4gdGhlIGpvYiBmaW5pc2hlZCBiZWluZyBwcm9jZXNzZWQuXG4gICAqL1xuICBhc3luYyBwb2xsKFxuICAgIGludGVydmFsOiBudW1iZXIgPSB0aGlzLnBvbGxpbmdPcHRpb25zLnBvbGxJbnRlcnZhbCxcbiAgICB0aW1lb3V0OiBudW1iZXIgPSB0aGlzLnBvbGxpbmdPcHRpb25zLnBvbGxUaW1lb3V0LFxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBqb2JJZCA9IHRoaXMuaWQ7XG4gICAgY29uc3Qgc3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICBjb25zdCBlbmRUaW1lID0gc3RhcnRUaW1lICsgdGltZW91dDtcblxuICAgIHRoaXMubG9nZ2VyLmRlYnVnKCdTdGFydCBwb2xsaW5nIGZvciBqb2Igc3RhdHVzJyk7XG4gICAgdGhpcy5sb2dnZXIuZGVidWcoXG4gICAgICBgUG9sbGluZyBvcHRpb25zOiB0aW1lb3V0OiR7dGltZW91dH1tcyB8IGludGVydmFsOiAke2ludGVydmFsfW1zLmAsXG4gICAgKTtcblxuICAgIGlmICh0aW1lb3V0ID09PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgSm9iUG9sbGluZ1RpbWVvdXRFcnJvcihcbiAgICAgICAgYFNraXBwaW5nIHBvbGxpbmcgYmVjYXVzZSBvZiB0aW1lb3V0ID0gMG1zLiBKb2IgSWQgPSAke2pvYklkfWAsXG4gICAgICAgIGpvYklkLFxuICAgICAgKTtcbiAgICB9XG5cbiAgICB3aGlsZSAoZW5kVGltZSA+IERhdGUubm93KCkpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuY2hlY2soKTtcbiAgICAgICAgc3dpdGNoIChyZXMuc3RhdGUpIHtcbiAgICAgICAgICBjYXNlICdBYm9ydGVkJzpcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignSm9iIGhhcyBiZWVuIGFib3J0ZWQnKTtcbiAgICAgICAgICBjYXNlICdVcGxvYWRDb21wbGV0ZSc6XG4gICAgICAgICAgY2FzZSAnSW5Qcm9ncmVzcyc6XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2luUHJvZ3Jlc3MnLCByZXMpO1xuICAgICAgICAgICAgYXdhaXQgZGVsYXkoaW50ZXJ2YWwpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSAnRmFpbGVkJzpcbiAgICAgICAgICAgIC8vIHVubGlrZSBpbmdlc3Qgam9icywgdGhlIEFQSSBkb2Vzbid0IHJldHVybiBhbiBlcnJvciBtc2c6XG4gICAgICAgICAgICAvLyBodHRwczovL2RldmVsb3Blci5zYWxlc2ZvcmNlLmNvbS9kb2NzL2F0bGFzLmVuLXVzLmFwaV9hc3luY2gubWV0YS9hcGlfYXN5bmNoL3F1ZXJ5X2dldF9vbmVfam9iLmh0bVxuICAgICAgICAgICAgdGhpcy5sb2dnZXIuZGVidWcocmVzKTtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignUXVlcnkgam9iIGZhaWxlZCB0byBjb21wbGV0ZScpO1xuICAgICAgICAgIGNhc2UgJ0pvYkNvbXBsZXRlJzpcbiAgICAgICAgICAgIHRoaXMubG9nZ2VyLmRlYnVnKGBKb2IgJHt0aGlzLmlkfSB3YXMgc3VjY2Vzc2Z1bGx5IHByb2Nlc3NlZC5gKTtcbiAgICAgICAgICAgIHRoaXMuZW1pdCgnam9iQ29tcGxldGUnLCByZXMpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICAgIHRocm93IGVycjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCB0aW1lb3V0RXJyb3IgPSBuZXcgSm9iUG9sbGluZ1RpbWVvdXRFcnJvcihcbiAgICAgIGBQb2xsaW5nIHRpbWVkIG91dCBhZnRlciAke3RpbWVvdXR9bXMuIEpvYiBJZCA9ICR7am9iSWR9YCxcbiAgICAgIGpvYklkLFxuICAgICk7XG4gICAgdGhpcy5lbWl0KCdlcnJvcicsIHRpbWVvdXRFcnJvcik7XG4gICAgdGhyb3cgdGltZW91dEVycm9yO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrIHRoZSBsYXRlc3Qgam9iIHN0YXR1c1xuICAgKlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxRdWVyeUpvYkluZm9WMj59IGpvYiBpbmZvcm1hdGlvbi5cbiAgICovXG4gIGFzeW5jIGNoZWNrKCk6IFByb21pc2U8UXVlcnlKb2JJbmZvVjI+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgam9iSW5mbyA9IGF3YWl0IHRoaXMuY3JlYXRlUXVlcnlSZXF1ZXN0PFF1ZXJ5Sm9iSW5mb1YyPih7XG4gICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgIHBhdGg6IGAvJHt0aGlzLmlkfWAsXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmpvYkluZm8gPSBqb2JJbmZvO1xuICAgICAgcmV0dXJuIGpvYkluZm87XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogR2V0IHRoZSByZXN1bHRzIGZvciBhIHF1ZXJ5IGpvYiBhcyBhIHJlY29yZCBzdHJlYW1cbiAgICpcbiAgICogVGhpcyBtZXRob2QgYXNzdW1lcyB0aGUgam9iIGZpbmlzaGVkIGJlaW5nIHByb2Nlc3NlZFxuICAgKiBAcmV0dXJucyB7UmVjb3JkU3RyZWFtfSAtIFJlY29yZCBzdHJlYW0sIGNvbnZlcnRpYmxlIHRvIGEgQ1NWIGRhdGEgc3RyZWFtXG4gICAqL1xuICBwdWJsaWMgYXN5bmMgcmVzdWx0KCk6IFByb21pc2U8UGFyc2FibGU8UmVjb3JkPj4ge1xuICAgIGNvbnN0IHJlc3VsdFN0cmVhbSA9IG5ldyBQYXJzYWJsZSgpO1xuICAgIGNvbnN0IHJlc3VsdERhdGFTdHJlYW0gPSByZXN1bHRTdHJlYW0uc3RyZWFtKCdjc3YnKTtcblxuICAgIGNvbnN0IHJlc3VsdHNQYXRoID0gYC8ke3RoaXMuaWR9L3Jlc3VsdHNgO1xuXG4gICAgd2hpbGUgKHRoaXMubG9jYXRvciAhPT0gJ251bGwnKSB7XG4gICAgICBjb25zdCByZXNQcm9taXNlID0gdGhpcy5jcmVhdGVRdWVyeVJlcXVlc3Qoe1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICBwYXRoOiB0aGlzLmxvY2F0b3JcbiAgICAgICAgICAvLyByZXN1bHRzUGF0aCBzdGFydHMgd2l0aCAnLydcbiAgICAgICAgICA/IGAke3Jlc3VsdHNQYXRofT9sb2NhdG9yPSR7dGhpcy5sb2NhdG9yfWBcbiAgICAgICAgICA6IHJlc3VsdHNQYXRoLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgQWNjZXB0OiAndGV4dC9jc3YnLFxuICAgICAgICB9LFxuICAgICAgfSk7XG5cbiAgICAgIHJlc1Byb21pc2Uuc3RyZWFtKCkucGlwZShyZXN1bHREYXRhU3RyZWFtKTtcbiAgICAgIGF3YWl0IHJlc1Byb21pc2U7XG4gICAgfVxuXG4gICAgcmV0dXJuIHJlc3VsdFN0cmVhbTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGVzIGEgcXVlcnkgam9iLlxuICAgKi9cbiAgYXN5bmMgZGVsZXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHJldHVybiB0aGlzLmNyZWF0ZVF1ZXJ5UmVxdWVzdDx2b2lkPih7XG4gICAgICBtZXRob2Q6ICdERUxFVEUnLFxuICAgICAgcGF0aDogYC8ke3RoaXMuaWR9YCxcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgY3JlYXRlUXVlcnlSZXF1ZXN0PFQ+KHJlcXVlc3Q6IEJ1bGtSZXF1ZXN0KSB7XG4gICAgY29uc3QgeyBwYXRoLCByZXNwb25zZVR5cGUgfSA9IHJlcXVlc3Q7XG5cbiAgICBjb25zdCBiYXNlUGF0aCA9IGBzZXJ2aWNlcy9kYXRhL3Yke3RoaXMuY29ubmVjdGlvbi52ZXJzaW9ufS9qb2JzL3F1ZXJ5YDtcblxuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwoXG4gICAgICBwYXRoID8gYmFzZVBhdGggKyBwYXRoIDogYmFzZVBhdGgsXG4gICAgICB0aGlzLmNvbm5lY3Rpb24uaW5zdGFuY2VVcmwsXG4gICAgKS50b1N0cmluZygpO1xuXG4gICAgY29uc3QgaHR0cEFwaSA9IG5ldyBCdWxrQXBpVjIodGhpcy5jb25uZWN0aW9uLCB7IHJlc3BvbnNlVHlwZSB9KTtcblxuICAgIGh0dHBBcGkub24oJ3Jlc3BvbnNlJywgKHJlc3BvbnNlOiBIdHRwUmVzcG9uc2UpID0+IHtcbiAgICAgIHRoaXMubG9jYXRvciA9IHJlc3BvbnNlLmhlYWRlcnNbJ3Nmb3JjZS1sb2NhdG9yJ107XG4gICAgICB0aGlzLmxvZ2dlci5kZWJ1Zyhgc2ZvcmNlLWxvY2F0b3I6ICR7dGhpcy5sb2NhdG9yfWApO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIGh0dHBBcGkucmVxdWVzdDxUPih7XG4gICAgICAuLi5yZXF1ZXN0LFxuICAgICAgdXJsLFxuICAgIH0pO1xuICB9XG59XG5cbi8qKlxuICogQ2xhc3MgZm9yIEJ1bGsgQVBJIFYyIEluZ2VzdCBKb2JcbiAqL1xuZXhwb3J0IGNsYXNzIEluZ2VzdEpvYlYyPFMgZXh0ZW5kcyBTY2hlbWE+IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgcHJpdmF0ZSByZWFkb25seSBjb25uZWN0aW9uOiBDb25uZWN0aW9uPFM+O1xuICBwcml2YXRlIHJlYWRvbmx5IGxvZ2dlcjogTG9nZ2VyO1xuICBwcml2YXRlIHJlYWRvbmx5IF9pZD86IHN0cmluZztcbiAgcHJpdmF0ZSByZWFkb25seSBib2R5UGFyYW1zPzogTmV3SW5nZXN0Sm9iT3B0aW9ucztcbiAgcHJpdmF0ZSByZWFkb25seSBqb2JEYXRhOiBKb2JEYXRhVjI8Uz47XG4gIHByaXZhdGUgcG9sbGluZ09wdGlvbnM6IEJ1bGtWMlBvbGxpbmdPcHRpb25zO1xuICBwcml2YXRlIGJ1bGtKb2JTdWNjZXNzZnVsUmVzdWx0cz86IEluZ2VzdEpvYlYyU3VjY2Vzc2Z1bFJlc3VsdHM8Uz47XG4gIHByaXZhdGUgYnVsa0pvYkZhaWxlZFJlc3VsdHM/OiBJbmdlc3RKb2JWMkZhaWxlZFJlc3VsdHM8Uz47XG4gIHByaXZhdGUgYnVsa0pvYlVucHJvY2Vzc2VkUmVjb3Jkcz86IEluZ2VzdEpvYlYyVW5wcm9jZXNzZWRSZWNvcmRzPFM+O1xuICBwcml2YXRlIGVycm9yOiBFcnJvciB8IHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBqb2JJbmZvPzogSm9iSW5mb1YyO1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoXG4gICAgY29ubjogQ29ubmVjdGlvbjxTPixcbiAgICBvcHRpb25zOiBDcmVhdGVJbmdlc3RKb2JWMk9wdGlvbnMgfCBFeGlzdGluZ0luZ2VzdEpvYk9wdGlvbnMsXG4gICkge1xuICAgIHN1cGVyKCk7XG5cbiAgICB0aGlzLmNvbm5lY3Rpb24gPSBjb25uO1xuICAgIHRoaXMubG9nZ2VyID0gdGhpcy5jb25uZWN0aW9uLl9sb2dMZXZlbFxuICAgICAgPyBnZXRMb2dnZXIoJ2J1bGsyOkluZ2VzdEpvYlYyJykuY3JlYXRlSW5zdGFuY2UodGhpcy5jb25uZWN0aW9uLl9sb2dMZXZlbClcbiAgICAgIDogZ2V0TG9nZ2VyKCdidWxrMjpJbmdlc3RKb2JWMicpO1xuICAgIHRoaXMucG9sbGluZ09wdGlvbnMgPSBvcHRpb25zLnBvbGxpbmdPcHRpb25zO1xuICAgIGlmICgnaWQnIGluIG9wdGlvbnMpIHtcbiAgICAgIHRoaXMuX2lkID0gb3B0aW9ucy5pZDtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5ib2R5UGFyYW1zID0gb3B0aW9ucy5ib2R5UGFyYW1zO1xuICAgIH1cbiAgICB0aGlzLmpvYkRhdGEgPSBuZXcgSm9iRGF0YVYyPFM+KHtcbiAgICAgIGNyZWF0ZVJlcXVlc3Q6IChyZXF1ZXN0KSA9PiB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3QocmVxdWVzdCksXG4gICAgICBqb2I6IHRoaXMsXG4gICAgfSk7XG4gICAgLy8gZGVmYXVsdCBlcnJvciBoYW5kbGVyIHRvIGtlZXAgdGhlIGxhdGVzdCBlcnJvclxuICAgIHRoaXMub24oJ2Vycm9yJywgKGVycm9yKSA9PiAodGhpcy5lcnJvciA9IGVycm9yKSk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHRoZSBxdWVyeSBqb2IgSUQuXG4gICAqXG4gICAqIEByZXR1cm5zIHtzdHJpbmd9IHF1ZXJ5IGpvYiBJZC5cbiAgICovXG4gIHB1YmxpYyBnZXQgaWQoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5qb2JJbmZvID8gdGhpcy5qb2JJbmZvLmlkIDogKHRoaXMuX2lkIGFzIHN0cmluZyk7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHRoZSBxdWVyeSBqb2IgaW5mby5cbiAgICpcbiAgICogQHJldHVybnMge1Byb21pc2U8UXVlcnlKb2JJbmZvVjI+fSBpbmdlc3Qgam9iIGluZm9ybWF0aW9uLlxuICAgKi9cbiAgcHVibGljIGdldEluZm8oKTogSm9iSW5mb1YyIHtcbiAgICBpZiAodGhpcy5qb2JJbmZvKSB7XG4gICAgICByZXR1cm4gdGhpcy5qb2JJbmZvO1xuICAgIH1cblxuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdObyBpbnRlcm5hbCBqb2IgaW5mby4gTWFrZSBzdXJlIHRvIGNhbGwgYGF3YWl0IGpvYi5jaGVja2AuJyxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIGpvYiByZXByZXNlbnRpbmcgYSBidWxrIG9wZXJhdGlvbiBpbiB0aGUgb3JnXG4gICAqXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPFF1ZXJ5Sm9iSW5mb1YyPn0gam9iIGluZm9ybWF0aW9uLlxuICAgKi9cbiAgYXN5bmMgb3BlbigpOiBQcm9taXNlPFBhcnRpYWw8Sm9iSW5mb1YyPj4ge1xuICAgIGlmICghdGhpcy5ib2R5UGFyYW1zKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ01pc3NpbmcgcmVxdWlyZWQgYm9keSBwYXJhbXMgdG8gb3BlbiBhIG5ldyBpbmdlc3Qgam9iLicpO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICB0aGlzLmpvYkluZm8gPSBhd2FpdCB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8Sm9iSW5mb1YyPih7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh0aGlzLmJvZHlQYXJhbXMpLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uOyBjaGFyc2V0PXV0Zi04JyxcbiAgICAgICAgfSxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICB9KTtcbiAgICAgIHRoaXMubG9nZ2VyLmRlYnVnKGBTdWNjZXNzZnVsbHkgY3JlYXRlZCBqb2IgJHt0aGlzLmlkfWApO1xuICAgICAgdGhpcy5lbWl0KCdvcGVuJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5qb2JJbmZvO1xuICB9XG5cbiAgLyoqIFVwbG9hZCBkYXRhIGZvciBhIGpvYiBpbiBDU1YgZm9ybWF0XG4gICAqXG4gICAqICBAcGFyYW0gaW5wdXQgQ1NWIGFzIGEgc3RyaW5nLCBvciBhcnJheSBvZiByZWNvcmRzIG9yIHJlYWRhYmxlIHN0cmVhbVxuICAgKi9cbiAgYXN5bmMgdXBsb2FkRGF0YShpbnB1dDogc3RyaW5nIHwgUmVjb3JkW10gfCBSZWFkYWJsZSk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IHRoaXMuam9iRGF0YS5leGVjdXRlKGlucHV0KS5yZXN1bHQ7XG4gICAgdGhpcy5sb2dnZXIuZGVidWcoYFN1Y2Nlc3NmdWxseSB1cGxvYWRlZCBkYXRhIHRvIGpvYiAke3RoaXMuaWR9YCk7XG4gIH1cblxuICAvKipcbiAgICogQ2xvc2Ugb3BlbmVkIGpvYlxuICAgKlxuICAgKiBUaGlzIG1ldGhvZCB3aWxsIG5vdGlmeSB0aGUgb3JnICB0aGF0IHRoZSB1cGxvYWQgb2Ygam9iIGRhdGEgaXMgY29tcGxldGUgYW5kIGlzIHJlYWR5IGZvciBwcm9jZXNzaW5nLlxuICAgKi9cbiAgYXN5bmMgY2xvc2UoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0YXRlOiBKb2JJbmZvVjJbJ3N0YXRlJ10gPSAnVXBsb2FkQ29tcGxldGUnO1xuICAgICAgdGhpcy5qb2JJbmZvID0gYXdhaXQgdGhpcy5jcmVhdGVJbmdlc3RSZXF1ZXN0PEpvYkluZm9WMj4oe1xuICAgICAgICBtZXRob2Q6ICdQQVRDSCcsXG4gICAgICAgIHBhdGg6IGAvJHt0aGlzLmlkfWAsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgc3RhdGUgfSksXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uOyBjaGFyc2V0PXV0Zi04JyB9LFxuICAgICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIH0pO1xuICAgICAgdGhpcy5sb2dnZXIuZGVidWcoYFN1Y2Nlc3NmdWxseSBjbG9zZWQgam9iICR7dGhpcy5pZH1gKTtcbiAgICAgIHRoaXMuZW1pdCgnY2xvc2UnKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTZXQgdGhlIHN0YXR1cyB0byBhYm9ydFxuICAgKi9cbiAgYXN5bmMgYWJvcnQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0YXRlOiBKb2JJbmZvVjJbJ3N0YXRlJ10gPSAnQWJvcnRlZCc7XG4gICAgICB0aGlzLmpvYkluZm8gPSBhd2FpdCB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8Sm9iSW5mb1YyPih7XG4gICAgICAgIG1ldGhvZDogJ1BBVENIJyxcbiAgICAgICAgcGF0aDogYC8ke3RoaXMuaWR9YCxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBzdGF0ZSB9KSxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLTgnIH0sXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmxvZ2dlci5kZWJ1ZyhgU3VjY2Vzc2Z1bGx5IGFib3J0ZWQgam9iICR7dGhpcy5pZH1gKTtcbiAgICAgIHRoaXMuZW1pdCgnYWJvcnRlZCcpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFBvbGwgZm9yIHRoZSBzdGF0ZSBvZiB0aGUgcHJvY2Vzc2luZyBmb3IgdGhlIGpvYi5cbiAgICpcbiAgICogVGhpcyBtZXRob2Qgd2lsbCBvbmx5IHRocm93IGFmdGVyIGEgdGltZW91dC4gVG8gY2FwdHVyZSBhXG4gICAqIGpvYiBmYWlsdXJlIHdoaWxlIHBvbGxpbmcgeW91IG11c3Qgc2V0IGEgbGlzdGVuZXIgZm9yIHRoZVxuICAgKiBgZmFpbGVkYCBldmVudCBiZWZvcmUgY2FsbGluZyBpdDpcbiAgICpcbiAgICogam9iLm9uKCdmYWlsZWQnLCAoZXJyKSA9PiBjb25zb2xlLmVycm9yKGVycikpXG4gICAqIGF3YWl0IGpvYi5wb2xsKClcbiAgICpcbiAgICogQHBhcmFtIGludGVydmFsIFBvbGxpbmcgaW50ZXJ2YWwgaW4gbWlsbGlzZWNvbmRzXG4gICAqIEBwYXJhbSB0aW1lb3V0IFBvbGxpbmcgdGltZW91dCBpbiBtaWxsaXNlY29uZHNcbiAgICogQHJldHVybnMge1Byb21pc2U8dm9pZD59IEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdoZW4gdGhlIGpvYiBmaW5pc2hlcyBzdWNjZXNzZnVsbHlcbiAgICovXG4gIGFzeW5jIHBvbGwoXG4gICAgaW50ZXJ2YWw6IG51bWJlciA9IHRoaXMucG9sbGluZ09wdGlvbnMucG9sbEludGVydmFsLFxuICAgIHRpbWVvdXQ6IG51bWJlciA9IHRoaXMucG9sbGluZ09wdGlvbnMucG9sbFRpbWVvdXQsXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGpvYklkID0gdGhpcy5pZDtcbiAgICBjb25zdCBzdGFydFRpbWUgPSBEYXRlLm5vdygpO1xuICAgIGNvbnN0IGVuZFRpbWUgPSBzdGFydFRpbWUgKyB0aW1lb3V0O1xuXG4gICAgaWYgKHRpbWVvdXQgPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBKb2JQb2xsaW5nVGltZW91dEVycm9yKFxuICAgICAgICBgU2tpcHBpbmcgcG9sbGluZyBiZWNhdXNlIG9mIHRpbWVvdXQgPSAwbXMuIEpvYiBJZCA9ICR7am9iSWR9YCxcbiAgICAgICAgam9iSWQsXG4gICAgICApO1xuICAgIH1cblxuICAgIHRoaXMubG9nZ2VyLmRlYnVnKCdTdGFydCBwb2xsaW5nIGZvciBqb2Igc3RhdHVzJyk7XG4gICAgdGhpcy5sb2dnZXIuZGVidWcoXG4gICAgICBgUG9sbGluZyBvcHRpb25zOiB0aW1lb3V0OiR7dGltZW91dH1tcyB8IGludGVydmFsOiAke2ludGVydmFsfW1zLmAsXG4gICAgKTtcblxuICAgIHdoaWxlIChlbmRUaW1lID4gRGF0ZS5ub3coKSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5jaGVjaygpO1xuICAgICAgICBzd2l0Y2ggKHJlcy5zdGF0ZSkge1xuICAgICAgICAgIGNhc2UgJ09wZW4nOlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgICAnSm9iIGlzIHN0aWxsIG9wZW4uIE1ha2Ugc3VyZSBjbG9zZSB0aGUgam9iIGJ5IGBjbG9zZWAgbWV0aG9kIG9uIHRoZSBqb2IgaW5zdGFuY2UgYmVmb3JlIHBvbGxpbmcuJyxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgY2FzZSAnQWJvcnRlZCc6XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0pvYiBoYXMgYmVlbiBhYm9ydGVkJyk7XG4gICAgICAgICAgY2FzZSAnVXBsb2FkQ29tcGxldGUnOlxuICAgICAgICAgIGNhc2UgJ0luUHJvZ3Jlc3MnOlxuICAgICAgICAgICAgdGhpcy5lbWl0KCdpblByb2dyZXNzJywgcmVzKTtcbiAgICAgICAgICAgIGF3YWl0IGRlbGF5KGludGVydmFsKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ0ZhaWxlZCc6XG4gICAgICAgICAgICB0aGlzLmxvZ2dlci5kZWJ1ZyhyZXMpO1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgICBgSW5nZXN0IGpvYiBmYWlsZWQgdG8gY29tcGxldGUgZHVlIHRvOiAke3Jlcy5lcnJvck1lc3NhZ2V9YCxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgY2FzZSAnSm9iQ29tcGxldGUnOlxuICAgICAgICAgICAgdGhpcy5sb2dnZXIuZGVidWcoYEpvYiAke3RoaXMuaWR9IHdhcyBzdWNjZXNzZnVsbHkgcHJvY2Vzc2VkLmApO1xuICAgICAgICAgICAgdGhpcy5lbWl0KCdqb2JDb21wbGV0ZScsIHJlcyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHRpbWVvdXRFcnJvciA9IG5ldyBKb2JQb2xsaW5nVGltZW91dEVycm9yKFxuICAgICAgYFBvbGxpbmcgdGltZWQgb3V0IGFmdGVyICR7dGltZW91dH1tcy4gSm9iIElkID0gJHtqb2JJZH1gLFxuICAgICAgam9iSWQsXG4gICAgKTtcbiAgICB0aGlzLmVtaXQoJ2Vycm9yJywgdGltZW91dEVycm9yKTtcbiAgICB0aHJvdyB0aW1lb3V0RXJyb3I7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgdGhlIGxhdGVzdCBiYXRjaCBzdGF0dXMgaW4gc2VydmVyXG4gICAqL1xuICBhc3luYyBjaGVjaygpOiBQcm9taXNlPEpvYkluZm9WMj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBqb2JJbmZvID0gYXdhaXQgdGhpcy5jcmVhdGVJbmdlc3RSZXF1ZXN0PEpvYkluZm9WMj4oe1xuICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICBwYXRoOiBgLyR7dGhpcy5pZH1gLFxuICAgICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIH0pO1xuICAgICAgdGhpcy5qb2JJbmZvID0gam9iSW5mbztcbiAgICAgIHJldHVybiBqb2JJbmZvO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgLyoqIFJldHVybiBhbGwgcmVjb3JkIHJlc3VsdHNcbiAgICpcbiAgICogVGhpcyBtZXRob2Qgd2lsbCByZXR1cm4gc3VjY2Vzc2Z1bCwgZmFpbGVkIGFuZCB1bnByb2Nlc3NlZCByZWNvcmRzXG4gICAqXG4gICAqIEByZXR1cm5zIFByb21pc2U8SW5nZXN0Sm9iVjJSZXN1bHRzPlxuICAgKi9cbiAgcHVibGljIGFzeW5jIGdldEFsbFJlc3VsdHMoKTogUHJvbWlzZTxJbmdlc3RKb2JWMlJlc3VsdHM8Uz4+IHtcbiAgICBjb25zdCBbXG4gICAgICBzdWNjZXNzZnVsUmVzdWx0cyxcbiAgICAgIGZhaWxlZFJlc3VsdHMsXG4gICAgICB1bnByb2Nlc3NlZFJlY29yZHMsXG4gICAgXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgIHRoaXMuZ2V0U3VjY2Vzc2Z1bFJlc3VsdHMoKSxcbiAgICAgIHRoaXMuZ2V0RmFpbGVkUmVzdWx0cygpLFxuICAgICAgdGhpcy5nZXRVbnByb2Nlc3NlZFJlY29yZHMoKSxcbiAgICBdKTtcbiAgICByZXR1cm4geyBzdWNjZXNzZnVsUmVzdWx0cywgZmFpbGVkUmVzdWx0cywgdW5wcm9jZXNzZWRSZWNvcmRzIH07XG4gIH1cblxuICAvKiogUmV0dXJuIHN1Y2Nlc3NmdWwgcmVzdWx0c1xuICAgKlxuICAgKiBUaGUgb3JkZXIgb2YgcmVjb3JkcyByZXR1cm5lZCBpcyBub3QgZ3VhcmFudGVlZCB0byBtYXRjaCB0aGUgb3JkZXJpbmcgb2YgdGhlIHVwbG9hZGVkIGRhdGEuXG4gICAqXG4gICAqIEBwYXJhbSB7Ym9vbGVhbn0gcmF3IEdldCByZXN1bHRzIGFzIGEgQ1NWIHN0cmluZ1xuICAgKiBAcmV0dXJucyBQcm9taXNlPEluZ2VzdEpvYlYyU3VjY2Vzc2Z1bFJlc3VsdHM+XG4gICAqL1xuICBhc3luYyBnZXRTdWNjZXNzZnVsUmVzdWx0cyhyYXc/OiBmYWxzZSk6IFByb21pc2U8SW5nZXN0Sm9iVjJTdWNjZXNzZnVsUmVzdWx0czxTPj5cbiAgLyoqIFJldHVybiBzdWNjZXNzZnVsIHJlc3VsdHNcbiAgICpcbiAgICogVGhlIG9yZGVyIG9mIHJlY29yZHMgcmV0dXJuZWQgaXMgbm90IGd1YXJhbnRlZWQgdG8gbWF0Y2ggdGhlIG9yZGVyaW5nIG9mIHRoZSB1cGxvYWRlZCBkYXRhLlxuICAgKlxuICAgKiBAcGFyYW0ge2Jvb2xlYW59IHJhdyBHZXQgcmVzdWx0cyBhcyBhIENTViBzdHJpbmdcbiAgICogQHJldHVybnMgUHJvbWlzZTxzdHJpbmc+XG4gICAqL1xuICBhc3luYyBnZXRTdWNjZXNzZnVsUmVzdWx0cyhyYXc6IHRydWUpOiBQcm9taXNlPHN0cmluZz5cbiAgYXN5bmMgZ2V0U3VjY2Vzc2Z1bFJlc3VsdHMocmF3PzogYm9vbGVhbik6IFByb21pc2U8SW5nZXN0Sm9iVjJTdWNjZXNzZnVsUmVzdWx0czxTPiB8IHN0cmluZz4ge1xuICAgIGNvbnN0IHJlcU9wdHM6IEJ1bGtSZXF1ZXN0ID0ge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIHBhdGg6IGAvJHt0aGlzLmlkfS9zdWNjZXNzZnVsUmVzdWx0c2AsXG4gICAgfVxuXG4gICAgaWYgKHJhdykge1xuICAgICAgcmV0dXJuIHRoaXMuY3JlYXRlSW5nZXN0UmVxdWVzdDxzdHJpbmc+KHtcbiAgICAgICAgLi4ucmVxT3B0cyxcbiAgICAgICAgcmVzcG9uc2VUeXBlOiAndGV4dC9wbGFpbicsXG4gICAgICB9KVxuICAgIH1cblxuICAgIGlmICh0aGlzLmJ1bGtKb2JTdWNjZXNzZnVsUmVzdWx0cykge1xuICAgICAgcmV0dXJuIHRoaXMuYnVsa0pvYlN1Y2Nlc3NmdWxSZXN1bHRzO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8XG4gICAgICBJbmdlc3RKb2JWMlN1Y2Nlc3NmdWxSZXN1bHRzPFM+IHwgdW5kZWZpbmVkXG4gICAgPih7XG4gICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgcGF0aDogYC8ke3RoaXMuaWR9L3N1Y2Nlc3NmdWxSZXN1bHRzYCxcbiAgICAgIHJlc3BvbnNlVHlwZTogJ3RleHQvY3N2JyxcbiAgICB9KTtcblxuICAgIHRoaXMuYnVsa0pvYlN1Y2Nlc3NmdWxSZXN1bHRzID0gcmVzdWx0cyA/PyBbXTtcblxuICAgIHJldHVybiB0aGlzLmJ1bGtKb2JTdWNjZXNzZnVsUmVzdWx0cztcbiAgfVxuXG4gIC8qKiBSZXR1cm4gZmFpbGVkIHJlc3VsdHNcbiAgICpcbiAgICogVGhlIG9yZGVyIG9mIHJlY29yZHMgaW4gdGhlIHJlc3BvbnNlIGlzIG5vdCBndWFyYW50ZWVkIHRvIG1hdGNoIHRoZSBvcmRlcmluZyBvZiByZWNvcmRzIGluIHRoZSBvcmlnaW5hbCBqb2IgZGF0YS5cbiAgICpcbiAgICogQHBhcmFtIHtib29sZWFufSByYXcgR2V0IHJlc3VsdHMgYXMgYSBDU1Ygc3RyaW5nXG4gICAqIEByZXR1cm5zIFByb21pc2U8SW5nZXN0Sm9iVjJTdWNjZXNzZnVsUmVzdWx0cz5cbiAgICovXG4gIGFzeW5jIGdldEZhaWxlZFJlc3VsdHMocmF3PzogZmFsc2UpOiBQcm9taXNlPEluZ2VzdEpvYlYyRmFpbGVkUmVzdWx0czxTPj5cbiAgLyoqIFJldHVybiBmYWlsZWQgcmVzdWx0c1xuICAgKlxuICAgKiBUaGUgb3JkZXIgb2YgcmVjb3JkcyBpbiB0aGUgcmVzcG9uc2UgaXMgbm90IGd1YXJhbnRlZWQgdG8gbWF0Y2ggdGhlIG9yZGVyaW5nIG9mIHJlY29yZHMgaW4gdGhlIG9yaWdpbmFsIGpvYiBkYXRhLlxuICAgKlxuICAgKiBAcGFyYW0ge2Jvb2xlYW59IHJhdyBHZXQgcmVzdWx0cyBhcyBhIENTViBzdHJpbmdcbiAgICogQHJldHVybnMgUHJvbWlzZTxzdHJpbmc+XG4gICAqL1xuICBhc3luYyBnZXRGYWlsZWRSZXN1bHRzKHJhdzogdHJ1ZSk6IFByb21pc2U8c3RyaW5nPlxuICBhc3luYyBnZXRGYWlsZWRSZXN1bHRzKHJhdz86IGJvb2xlYW4pOiBQcm9taXNlPEluZ2VzdEpvYlYyRmFpbGVkUmVzdWx0czxTPiB8IHN0cmluZz4ge1xuICAgIGNvbnN0IHJlcU9wdHM6IEJ1bGtSZXF1ZXN0ID0ge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIHBhdGg6IGAvJHt0aGlzLmlkfS9mYWlsZWRSZXN1bHRzYCxcbiAgICB9XG5cbiAgICBpZiAocmF3KSB7XG4gICAgICByZXR1cm4gdGhpcy5jcmVhdGVJbmdlc3RSZXF1ZXN0PHN0cmluZz4oe1xuICAgICAgICAuLi5yZXFPcHRzLFxuICAgICAgICByZXNwb25zZVR5cGU6ICd0ZXh0L3BsYWluJyxcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgaWYgKHRoaXMuYnVsa0pvYkZhaWxlZFJlc3VsdHMpIHtcbiAgICAgIHJldHVybiB0aGlzLmJ1bGtKb2JGYWlsZWRSZXN1bHRzO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8XG4gICAgICBJbmdlc3RKb2JWMkZhaWxlZFJlc3VsdHM8Uz4gfCB1bmRlZmluZWRcbiAgICA+KHtcbiAgICAgIC4uLnJlcU9wdHMsXG4gICAgICByZXNwb25zZVR5cGU6ICd0ZXh0L2NzdicsXG4gICAgfSk7XG5cbiAgICB0aGlzLmJ1bGtKb2JGYWlsZWRSZXN1bHRzID0gcmVzdWx0cyA/PyBbXTtcblxuICAgIHJldHVybiB0aGlzLmJ1bGtKb2JGYWlsZWRSZXN1bHRzO1xuICB9XG5cbiAgLyoqIFJldHVybiB1bnByb2Nlc3NlZCByZXN1bHRzXG4gICAqXG4gICAqIFRoZSB1bnByb2Nlc3NlZCByZWNvcmRzIGVuZHBvaW50IHJldHVybnMgcmVjb3JkcyBhcyBhIENTVi5cbiAgICogSWYgdGhlIHJlcXVlc3QgaGVscGVyIGlzIGFibGUgdG8gcGFyc2UgaXQsIHlvdSBnZXQgdGhlIHJlY29yZHNcbiAgICogYXMgYW4gYXJyYXkgb2Ygb2JqZWN0cy5cbiAgICogSWYgdW5hYmxlIHRvIHBhcnNlIGl0IChiYWQgQ1NWKSwgeW91IGdldCB0aGUgcmF3IHJlc3BvbnNlIGFzIGEgc3RyaW5nLlxuICAgKlxuICAgKiBUaGUgb3JkZXIgb2YgcmVjb3JkcyBpbiB0aGUgcmVzcG9uc2UgaXMgbm90IGd1YXJhbnRlZWQgdG8gbWF0Y2ggdGhlIG9yZGVyaW5nIG9mIHJlY29yZHMgaW4gdGhlIG9yaWdpbmFsIGpvYiBkYXRhLlxuICAgKlxuICAgKiBAcGFyYW0ge2Jvb2xlYW59IHJhdyBHZXQgcmVzdWx0cyBhcyBhIENTViBzdHJpbmdcbiAgICogQHJldHVybnMgUHJvbWlzZTxJbmdlc3RKb2JWMlVucHJvY2Vzc2VkUmVjb3Jkcz5cbiAgICovXG4gIGFzeW5jIGdldFVucHJvY2Vzc2VkUmVjb3JkcyhyYXc/OiBmYWxzZSk6IFByb21pc2U8SW5nZXN0Sm9iVjJVbnByb2Nlc3NlZFJlY29yZHM8Uz4+XG4gICAgLyoqIFJldHVybiB1bnByb2Nlc3NlZCByZXN1bHRzXG4gICAqXG4gICAqIFRoZSB1bnByb2Nlc3NlZCByZWNvcmRzIGVuZHBvaW50IHJldHVybnMgcmVjb3JkcyBhcyBhIENTVi5cbiAgICogSWYgdGhlIHJlcXVlc3QgaGVscGVyIGlzIGFibGUgdG8gcGFyc2UgaXQsIHlvdSBnZXQgdGhlIHJlY29yZHNcbiAgICogYXMgYW4gYXJyYXkgb2Ygb2JqZWN0cy5cbiAgICogSWYgdW5hYmxlIHRvIHBhcnNlIGl0IChiYWQgQ1NWKSwgeW91IGdldCB0aGUgcmF3IHJlc3BvbnNlIGFzIGEgc3RyaW5nLlxuICAgKlxuICAgKiBUaGUgb3JkZXIgb2YgcmVjb3JkcyBpbiB0aGUgcmVzcG9uc2UgaXMgbm90IGd1YXJhbnRlZWQgdG8gbWF0Y2ggdGhlIG9yZGVyaW5nIG9mIHJlY29yZHMgaW4gdGhlIG9yaWdpbmFsIGpvYiBkYXRhLlxuICAgKlxuICAgKiBAcGFyYW0ge2Jvb2xlYW59IHJhdyBHZXQgcmVzdWx0cyBhcyBhIENTViBzdHJpbmdcbiAgICogQHJldHVybnMgUHJvbWlzZTxzdHJpbmc+XG4gICAqL1xuICBhc3luYyBnZXRVbnByb2Nlc3NlZFJlY29yZHMocmF3OiB0cnVlKTogUHJvbWlzZTxzdHJpbmc+XG4gIGFzeW5jIGdldFVucHJvY2Vzc2VkUmVjb3JkcyhyYXc/OiBib29sZWFuKTogUHJvbWlzZTxJbmdlc3RKb2JWMlVucHJvY2Vzc2VkUmVjb3JkczxTPj4ge1xuICAgIGNvbnN0IHJlcU9wdHM6IEJ1bGtSZXF1ZXN0ID0ge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIHBhdGg6IGAvJHt0aGlzLmlkfS91bnByb2Nlc3NlZHJlY29yZHNgLFxuICAgIH1cblxuICAgIGlmIChyYXcpIHtcbiAgICAgIHJldHVybiB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8c3RyaW5nPih7XG4gICAgICAgIC4uLnJlcU9wdHMsXG4gICAgICAgIHJlc3BvbnNlVHlwZTogJ3RleHQvcGxhaW4nLFxuICAgICAgfSlcbiAgICB9XG5cbiAgICBpZiAodGhpcy5idWxrSm9iVW5wcm9jZXNzZWRSZWNvcmRzKSB7XG4gICAgICByZXR1cm4gdGhpcy5idWxrSm9iVW5wcm9jZXNzZWRSZWNvcmRzO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCB0aGlzLmNyZWF0ZUluZ2VzdFJlcXVlc3Q8XG4gICAgICBJbmdlc3RKb2JWMlVucHJvY2Vzc2VkUmVjb3JkczxTPiB8IHVuZGVmaW5lZFxuICAgID4oe1xuICAgICAgLi4ucmVxT3B0cyxcbiAgICAgIHJlc3BvbnNlVHlwZTogJ3RleHQvY3N2JyxcbiAgICB9KTtcblxuICAgIHRoaXMuYnVsa0pvYlVucHJvY2Vzc2VkUmVjb3JkcyA9IHJlc3VsdHMgPz8gW107XG5cbiAgICByZXR1cm4gdGhpcy5idWxrSm9iVW5wcm9jZXNzZWRSZWNvcmRzO1xuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZXMgYW4gaW5nZXN0IGpvYi5cbiAgICovXG4gIGFzeW5jIGRlbGV0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy5jcmVhdGVJbmdlc3RSZXF1ZXN0PHZvaWQ+KHtcbiAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICBwYXRoOiBgLyR7dGhpcy5pZH1gLFxuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBjcmVhdGVJbmdlc3RSZXF1ZXN0PFQ+KHJlcXVlc3Q6IEJ1bGtSZXF1ZXN0KSB7XG4gICAgY29uc3QgeyBwYXRoLCByZXNwb25zZVR5cGUgfSA9IHJlcXVlc3Q7XG4gICAgY29uc3QgYmFzZVBhdGggPSBgL3NlcnZpY2VzL2RhdGEvdiR7dGhpcy5jb25uZWN0aW9uLnZlcnNpb259L2pvYnMvaW5nZXN0YDtcblxuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwoXG4gICAgICBwYXRoID8gYmFzZVBhdGggKyBwYXRoIDogYmFzZVBhdGgsXG4gICAgICB0aGlzLmNvbm5lY3Rpb24uaW5zdGFuY2VVcmwsXG4gICAgKS50b1N0cmluZygpO1xuXG4gICAgcmV0dXJuIG5ldyBCdWxrQXBpVjIodGhpcy5jb25uZWN0aW9uLCB7IHJlc3BvbnNlVHlwZSB9KS5yZXF1ZXN0PFQ+KHtcbiAgICAgIC4uLnJlcXVlc3QsXG4gICAgICB1cmwsXG4gICAgfSk7XG4gIH1cbn1cblxuY2xhc3MgSm9iRGF0YVYyPFMgZXh0ZW5kcyBTY2hlbWE+IGV4dGVuZHMgV3JpdGFibGUge1xuICByZWFkb25seSBqb2I6IEluZ2VzdEpvYlYyPFM+O1xuICByZWFkb25seSB1cGxvYWRTdHJlYW06IFNlcmlhbGl6YWJsZTtcbiAgcmVhZG9ubHkgZG93bmxvYWRTdHJlYW06IFBhcnNhYmxlO1xuICByZWFkb25seSBkYXRhU3RyZWFtOiBEdXBsZXg7XG4gIHJlc3VsdDogYW55O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3Iob3B0aW9uczogQ3JlYXRlSm9iRGF0YVYyT3B0aW9uczxTPikge1xuICAgIHN1cGVyKHsgb2JqZWN0TW9kZTogdHJ1ZSB9KTtcblxuICAgIGNvbnN0IGNyZWF0ZVJlcXVlc3QgPSBvcHRpb25zLmNyZWF0ZVJlcXVlc3Q7XG5cbiAgICB0aGlzLmpvYiA9IG9wdGlvbnMuam9iO1xuICAgIHRoaXMudXBsb2FkU3RyZWFtID0gbmV3IFNlcmlhbGl6YWJsZSgpO1xuICAgIHRoaXMuZG93bmxvYWRTdHJlYW0gPSBuZXcgUGFyc2FibGUoKTtcblxuICAgIGNvbnN0IGNvbnZlcnRlck9wdGlvbnMgPSB7IG51bGxWYWx1ZTogJyNOL0EnIH07XG4gICAgY29uc3QgdXBsb2FkRGF0YVN0cmVhbSA9IHRoaXMudXBsb2FkU3RyZWFtLnN0cmVhbSgnY3N2JywgY29udmVydGVyT3B0aW9ucyk7XG4gICAgY29uc3QgZG93bmxvYWREYXRhU3RyZWFtID0gdGhpcy5kb3dubG9hZFN0cmVhbS5zdHJlYW0oXG4gICAgICAnY3N2JyxcbiAgICAgIGNvbnZlcnRlck9wdGlvbnMsXG4gICAgKTtcblxuICAgIHRoaXMuZGF0YVN0cmVhbSA9IGNvbmNhdFN0cmVhbXNBc0R1cGxleChcbiAgICAgIHVwbG9hZERhdGFTdHJlYW0sXG4gICAgICBkb3dubG9hZERhdGFTdHJlYW0sXG4gICAgKTtcblxuICAgIHRoaXMub24oJ2ZpbmlzaCcsICgpID0+IHRoaXMudXBsb2FkU3RyZWFtLmVuZCgpKTtcblxuICAgIHVwbG9hZERhdGFTdHJlYW0ub25jZSgncmVhZGFibGUnLCAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICAvLyBwaXBlIHVwbG9hZCBkYXRhIHRvIGJhdGNoIEFQSSByZXF1ZXN0IHN0cmVhbVxuICAgICAgICBjb25zdCByZXEgPSBjcmVhdGVSZXF1ZXN0KHtcbiAgICAgICAgICBtZXRob2Q6ICdQVVQnLFxuICAgICAgICAgIHBhdGg6IGAvJHt0aGlzLmpvYi5pZH0vYmF0Y2hlc2AsXG4gICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICd0ZXh0L2NzdicsXG4gICAgICAgICAgfSxcbiAgICAgICAgICByZXNwb25zZVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgKGFzeW5jICgpID0+IHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgcmVxO1xuICAgICAgICAgICAgdGhpcy5lbWl0KCdyZXNwb25zZScsIHJlcyk7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2Vycm9yJywgZXJyKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pKCk7XG5cbiAgICAgICAgdXBsb2FkRGF0YVN0cmVhbS5waXBlKHJlcS5zdHJlYW0oKSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy5lbWl0KCdlcnJvcicsIGVycik7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBfd3JpdGUocmVjb3JkXzogUmVjb3JkLCBlbmM6IEJ1ZmZlckVuY29kaW5nLCBjYjogKCkgPT4gdm9pZCkge1xuICAgIGNvbnN0IHsgSWQsIHR5cGUsIGF0dHJpYnV0ZXMsIC4uLnJyZWMgfSA9IHJlY29yZF87XG4gICAgbGV0IHJlY29yZDtcbiAgICBzd2l0Y2ggKHRoaXMuam9iLmdldEluZm8oKS5vcGVyYXRpb24pIHtcbiAgICAgIGNhc2UgJ2luc2VydCc6XG4gICAgICAgIHJlY29yZCA9IHJyZWM7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnZGVsZXRlJzpcbiAgICAgIGNhc2UgJ2hhcmREZWxldGUnOlxuICAgICAgICByZWNvcmQgPSB7IElkIH07XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmVjb3JkID0geyBJZCwgLi4ucnJlYyB9O1xuICAgIH1cbiAgICB0aGlzLnVwbG9hZFN0cmVhbS53cml0ZShyZWNvcmQsIGVuYywgY2IpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgZHVwbGV4IHN0cmVhbSB3aGljaCBhY2NlcHRzIENTViBkYXRhIGlucHV0IGFuZCBiYXRjaCByZXN1bHQgb3V0cHV0XG4gICAqL1xuICBzdHJlYW0oKSB7XG4gICAgcmV0dXJuIHRoaXMuZGF0YVN0cmVhbTtcbiAgfVxuXG4gIC8qKlxuICAgKiBFeGVjdXRlIGJhdGNoIG9wZXJhdGlvblxuICAgKi9cbiAgZXhlY3V0ZShpbnB1dD86IHN0cmluZyB8IFJlY29yZFtdIHwgUmVhZGFibGUpIHtcbiAgICBpZiAodGhpcy5yZXN1bHQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignRGF0YSBjYW4gb25seSBiZSB1cGxvYWRlZCB0byBhIGpvYiBvbmNlLicpO1xuICAgIH1cblxuICAgIHRoaXMucmVzdWx0ID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5vbmNlKCdyZXNwb25zZScsICgpID0+IHJlc29sdmUoKSk7XG4gICAgICB0aGlzLm9uY2UoJ2Vycm9yJywgcmVqZWN0KTtcbiAgICB9KTtcblxuICAgIGlmIChpcy5ub2RlU3RyZWFtKGlucHV0KSkge1xuICAgICAgLy8gaWYgaW5wdXQgaGFzIHN0cmVhbS5SZWFkYWJsZSBpbnRlcmZhY2VcbiAgICAgIGlucHV0LnBpcGUodGhpcy5kYXRhU3RyZWFtKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgcmVjb3JkRGF0YSA9IHN0cnVjdHVyZWRDbG9uZShpbnB1dCk7XG5cbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHJlY29yZERhdGEpKSB7XG4gICAgICAgIGZvciAoY29uc3QgcmVjb3JkIG9mIHJlY29yZERhdGEpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhyZWNvcmQpKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHJlY29yZFtrZXldID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgICAgcmVjb3JkW2tleV0gPSBTdHJpbmcocmVjb3JkW2tleV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLndyaXRlKHJlY29yZCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5lbmQoKTtcbiAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHJlY29yZERhdGEgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHRoaXMuZGF0YVN0cmVhbS53cml0ZShyZWNvcmREYXRhLCAndXRmOCcpO1xuICAgICAgICB0aGlzLmRhdGFTdHJlYW0uZW5kKCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbn1cblxuZnVuY3Rpb24gZGVsYXkobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgbXMpKTtcbn1cblxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSovXG4vKlxuICogUmVnaXN0ZXIgaG9vayBpbiBjb25uZWN0aW9uIGluc3RhbnRpYXRpb24gZm9yIGR5bmFtaWNhbGx5IGFkZGluZyB0aGlzIEFQSSBtb2R1bGUgZmVhdHVyZXNcbiAqL1xucmVnaXN0ZXJNb2R1bGUoJ2J1bGsyJywgKGNvbm4pID0+IG5ldyBCdWxrVjIoY29ubikpO1xuXG5leHBvcnQgZGVmYXVsdCBCdWxrVjI7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVNBLFlBQVksUUFBUSxRQUFRO0FBQ3JDLFNBQTJCQyxRQUFRLFFBQVEsUUFBUTtBQUVuRCxTQUFTQyxZQUFZLEVBQUVDLFFBQVEsUUFBUSxrQkFBa0I7QUFDekQsT0FBT0MsT0FBTyxNQUFNLGFBQWE7QUFFakMsU0FBU0MsY0FBYyxRQUFRLFlBQVk7QUFFM0MsU0FBU0MsU0FBUyxRQUFnQixnQkFBZ0I7QUFDbEQsU0FBU0MscUJBQXFCLFFBQVEsZ0JBQWdCO0FBRXRELE9BQU9DLEVBQUUsTUFBTSxrQkFBa0I7QUFBQyxJQWdJNUJDLHNCQUFzQiwwQkFBQUMsTUFBQTtFQUcxQjtBQUNGO0FBQ0E7RUFDRSxTQUFBRCx1QkFBWUUsT0FBZSxFQUFFQyxLQUFhLEVBQUU7SUFBQSxJQUFBQyxLQUFBO0lBQUFDLGVBQUEsT0FBQUwsc0JBQUE7SUFDMUNJLEtBQUEsR0FBQUUsVUFBQSxPQUFBTixzQkFBQSxHQUFNRSxPQUFPO0lBQ2JFLEtBQUEsQ0FBS0csSUFBSSxHQUFHLG1CQUFtQjtJQUMvQkgsS0FBQSxDQUFLRCxLQUFLLEdBQUdBLEtBQUs7SUFBQyxPQUFBQyxLQUFBO0VBQ3JCO0VBQUNJLFNBQUEsQ0FBQVIsc0JBQUEsRUFBQUMsTUFBQTtFQUFBLE9BQUFRLFlBQUEsQ0FBQVQsc0JBQUE7QUFBQSxlQUFBVSxnQkFBQSxDQVZrQ0MsS0FBSztBQUFBLElBYXBDQyxTQUFTLDBCQUFBQyxRQUFBO0VBQUEsU0FBQUQsVUFBQTtJQUFBUCxlQUFBLE9BQUFPLFNBQUE7SUFBQSxPQUFBTixVQUFBLE9BQUFNLFNBQUEsRUFBQUUsU0FBQTtFQUFBO0VBQUFOLFNBQUEsQ0FBQUksU0FBQSxFQUFBQyxRQUFBO0VBQUEsT0FBQUosWUFBQSxDQUFBRyxTQUFBO0lBQUFHLEdBQUE7SUFBQUMsS0FBQSxFQUNiLFNBQUFDLHNCQUFzQkEsQ0FBQ0MsSUFBUyxFQUFFO01BQ2hDLE9BQ0VDLGNBQUEsQ0FBY0QsSUFBSSxDQUFDLElBQ25CRSxPQUFBLENBQU9GLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBSyxRQUFRLElBQzNCLFdBQVcsSUFBSUEsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUUxQjtFQUFDO0lBQUFILEdBQUE7SUFBQUMsS0FBQSxFQUVELFNBQUFLLGdCQUFnQkEsQ0FBQ0MsUUFBc0IsRUFBVztNQUFBLElBQUFDLFFBQUE7TUFDaEQsT0FDRUQsUUFBUSxDQUFDRSxVQUFVLEtBQUssR0FBRyxJQUMzQkMseUJBQUEsQ0FBQUYsUUFBQSxHQUFBRCxRQUFRLENBQUNKLElBQUksRUFBQVEsSUFBQSxDQUFBSCxRQUFBLEVBQVUsb0JBQW9CLENBQUM7SUFFaEQ7RUFBQztJQUFBUixHQUFBO0lBQUFDLEtBQUEsRUFFRCxTQUFBVyxVQUFVQSxDQUFDVCxJQUFTLEVBQUU7TUFDcEIsT0FBTztRQUNMVSxTQUFTLEVBQUVWLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ1UsU0FBUztRQUM1QjFCLE9BQU8sRUFBRWdCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ2hCO01BQ25CLENBQUM7SUFDSDtFQUFDO0FBQUEsRUFyQnVDUCxPQUFPO0FBd0JqRCxXQUFha0MsTUFBTTtFQWtCakIsU0FBQUEsT0FBWUMsVUFBeUIsRUFBRTtJQUFBekIsZUFBQSxPQUFBd0IsTUFBQTtJQWR2QztBQUNGO0FBQ0E7QUFDQTtBQUNBO0lBSkVFLGVBQUEsdUJBS3NCLElBQUk7SUFFMUI7QUFDRjtBQUNBO0FBQ0E7QUFDQTtJQUpFQSxlQUFBLHNCQUtxQixLQUFLO0lBR3hCLElBQUksQ0FBQ0QsVUFBVSxHQUFHQSxVQUFVO0lBQzVCLElBQUksQ0FBQ0UsTUFBTSxHQUFHLElBQUksQ0FBQ0YsVUFBVSxDQUFDRyxTQUFTLEdBQ25DcEMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDcUMsY0FBYyxDQUFDLElBQUksQ0FBQ0osVUFBVSxDQUFDRyxTQUFTLENBQUMsR0FDNURwQyxTQUFTLENBQUMsT0FBTyxDQUFDO0VBQ3hCOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBckJFLE9BQUFZLFlBQUEsQ0FBQW9CLE1BQUE7SUFBQWQsR0FBQTtJQUFBQyxLQUFBLEVBc0JBLFNBQU9tQixTQUFTQSxDQUFDQyxPQUE0QixFQUFrQjtNQUM3RCxPQUFPLElBQUlDLFdBQVcsQ0FBQyxJQUFJLENBQUNQLFVBQVUsRUFBRTtRQUN0Q1EsVUFBVSxFQUFFRixPQUFPO1FBQ25CRyxjQUFjLEVBQUU7TUFDbEIsQ0FBQyxDQUFDO0lBQ0o7O0lBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBTEU7SUFBQXhCLEdBQUE7SUFBQUMsS0FBQSxFQWNBLFNBQU93QixHQUFHQSxDQUFBLEVBR3dCO01BQUEsSUFGaENDLElBQXdCLEdBQUEzQixTQUFBLENBQUE0QixNQUFBLFFBQUE1QixTQUFBLFFBQUE2QixTQUFBLEdBQUE3QixTQUFBLE1BQUcsUUFBUTtNQUFBLElBQ25Dc0IsT0FBNkQsR0FBQXRCLFNBQUEsQ0FBQTRCLE1BQUEsT0FBQTVCLFNBQUEsTUFBQTZCLFNBQUE7TUFFN0QsSUFBSUYsSUFBSSxLQUFLLFFBQVEsRUFBRTtRQUNyQixPQUFPLElBQUlKLFdBQVcsQ0FBQyxJQUFJLENBQUNQLFVBQVUsRUFBRTtVQUN0Q2MsRUFBRSxFQUFFUixPQUFPLENBQUNRLEVBQUU7VUFDZEwsY0FBYyxFQUFFO1FBQ2xCLENBQUMsQ0FBQztNQUNKLENBQUMsTUFBTTtRQUNMLE9BQU8sSUFBSU0sVUFBVSxDQUFDLElBQUksQ0FBQ2YsVUFBVSxFQUFFO1VBQ3JDYyxFQUFFLEVBQUVSLE9BQU8sQ0FBQ1EsRUFBRTtVQUNkTCxjQUFjLEVBQUU7UUFDbEIsQ0FBQyxDQUFDO01BQ0o7SUFDRjs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBeEIsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQThCLHNCQUFBLEdBQUFDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBQyxRQUNFZCxPQUdHO1FBQUEsSUFBQWUsWUFBQSxFQUFBQyxXQUFBLEVBQUFDLEtBQUEsRUFBQUMsYUFBQSxFQUFBZCxHQUFBLEVBQUFlLEdBQUE7UUFBQSxPQUFBUCxtQkFBQSxDQUFBUSxJQUFBLFVBQUFDLFNBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBQyxJQUFBLEdBQUFELFNBQUEsQ0FBQUUsSUFBQTtZQUFBO2NBRUgsSUFBSSxDQUFDeEIsT0FBTyxDQUFDZ0IsV0FBVyxFQUFFaEIsT0FBTyxDQUFDZ0IsV0FBVyxHQUFHLElBQUksQ0FBQ0EsV0FBVztjQUNoRSxJQUFJLENBQUNoQixPQUFPLENBQUNlLFlBQVksRUFBRWYsT0FBTyxDQUFDZSxZQUFZLEdBQUcsSUFBSSxDQUFDQSxZQUFZO2NBRTNEQSxZQUFZLEdBQTJDZixPQUFPLENBQTlEZSxZQUFZLEVBQUVDLFdBQVcsR0FBOEJoQixPQUFPLENBQWhEZ0IsV0FBVyxFQUFFQyxLQUFLLEdBQXVCakIsT0FBTyxDQUFuQ2lCLEtBQUssRUFBS0MsYUFBYSxHQUFBTyx3QkFBQSxDQUFLekIsT0FBTyxFQUFBMEIsU0FBQTtjQUVoRXRCLEdBQUcsR0FBRyxJQUFJLENBQUNMLFNBQVMsQ0FBQ21CLGFBQWEsQ0FBQztjQUFBSSxTQUFBLENBQUFDLElBQUE7Y0FBQUQsU0FBQSxDQUFBRSxJQUFBO2NBQUEsT0FFakNwQixHQUFHLENBQUN1QixJQUFJLENBQUMsQ0FBQztZQUFBO2NBQUFMLFNBQUEsQ0FBQUUsSUFBQTtjQUFBLE9BQ1ZwQixHQUFHLENBQUN3QixVQUFVLENBQUNYLEtBQUssQ0FBQztZQUFBO2NBQUFLLFNBQUEsQ0FBQUUsSUFBQTtjQUFBLE9BQ3JCcEIsR0FBRyxDQUFDeUIsS0FBSyxDQUFDLENBQUM7WUFBQTtjQUFBUCxTQUFBLENBQUFFLElBQUE7Y0FBQSxPQUNYcEIsR0FBRyxDQUFDMEIsSUFBSSxDQUFDZixZQUFZLEVBQUVDLFdBQVcsQ0FBQztZQUFBO2NBQUFNLFNBQUEsQ0FBQUUsSUFBQTtjQUFBLE9BQzVCcEIsR0FBRyxDQUFDMkIsYUFBYSxDQUFDLENBQUM7WUFBQTtjQUFBLE9BQUFULFNBQUEsQ0FBQVUsTUFBQSxXQUFBVixTQUFBLENBQUFXLElBQUE7WUFBQTtjQUFBWCxTQUFBLENBQUFDLElBQUE7Y0FBQUQsU0FBQSxDQUFBWSxFQUFBLEdBQUFaLFNBQUE7Y0FFMUJILEdBQUcsR0FBQUcsU0FBQSxDQUFBWSxFQUFBO2NBQ1QsSUFBSSxDQUFDdEMsTUFBTSxDQUFDdUMsS0FBSyw2QkFBQUMsTUFBQSxDQUE2QmpCLEdBQUcsQ0FBQ3JELE9BQU8sQ0FBRSxDQUFDO2NBRTVELElBQUlxRCxHQUFHLENBQUNoRCxJQUFJLEtBQUssd0JBQXdCLEVBQUU7Z0JBQ3pDO2dCQUNBaUMsR0FBRyxDQUFDaUMsTUFBTSxDQUFDLENBQUMsQ0FBQ0MsS0FBSyxDQUFDLFVBQUNDLE9BQU87a0JBQUEsT0FBS0EsT0FBTztnQkFBQSxFQUFDO2NBQzFDO2NBQUMsTUFDS3BCLEdBQUc7WUFBQTtZQUFBO2NBQUEsT0FBQUcsU0FBQSxDQUFBa0IsSUFBQTtVQUFBO1FBQUEsR0FBQTFCLE9BQUE7TUFBQSxDQUVaO01BQUEsU0E1QksyQixxQkFBcUJBLENBQUFDLEVBQUE7UUFBQSxPQUFBaEMsc0JBQUEsQ0FBQWlDLEtBQUEsT0FBQWpFLFNBQUE7TUFBQTtNQUFBLE9BQXJCK0QscUJBQXFCO0lBQUE7SUE4QjNCO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBVEU7RUFBQTtJQUFBOUQsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQWdFLE1BQUEsR0FBQWpDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FVQSxTQUFBZ0MsU0FDRUMsSUFBWSxFQUNaOUMsT0FJQztRQUFBLElBQUErQyxRQUFBLEVBQUFDLFlBQUEsRUFBQUMsVUFBQSxFQUFBQyxrQkFBQSxFQUFBL0IsR0FBQTtRQUFBLE9BQUFQLG1CQUFBLENBQUFRLElBQUEsVUFBQStCLFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBN0IsSUFBQSxHQUFBNkIsU0FBQSxDQUFBNUIsSUFBQTtZQUFBO2NBRUt1QixRQUFRLEdBQUcsSUFBSXRDLFVBQVUsQ0FBQyxJQUFJLENBQUNmLFVBQVUsRUFBRTtnQkFDL0NRLFVBQVUsRUFBRTtrQkFDVm1ELEtBQUssRUFBRVAsSUFBSTtrQkFDWFEsU0FBUyxFQUFFdEQsT0FBTyxhQUFQQSxPQUFPLGVBQVBBLE9BQU8sQ0FBRXVELE9BQU8sR0FBRyxVQUFVLEdBQUcsT0FBTztrQkFDbERDLGVBQWUsRUFBRXhELE9BQU8sYUFBUEEsT0FBTyx1QkFBUEEsT0FBTyxDQUFFd0QsZUFBZTtrQkFDekNDLFVBQVUsRUFBRXpELE9BQU8sYUFBUEEsT0FBTyx1QkFBUEEsT0FBTyxDQUFFeUQ7Z0JBQ3ZCLENBQUM7Z0JBQ0R0RCxjQUFjLEVBQUU7Y0FDbEIsQ0FBQyxDQUFDO2NBRUk2QyxZQUFZLEdBQUcsSUFBSTFGLFFBQVEsQ0FBQyxDQUFDO2NBQzdCMkYsVUFBVSxHQUFHRCxZQUFZLENBQUNVLE1BQU0sQ0FBQyxLQUFLLENBQUM7Y0FBQU4sU0FBQSxDQUFBN0IsSUFBQTtjQUFBNkIsU0FBQSxDQUFBNUIsSUFBQTtjQUFBLE9BR3JDdUIsUUFBUSxDQUFDcEIsSUFBSSxDQUFDLENBQUM7WUFBQTtjQUFBeUIsU0FBQSxDQUFBNUIsSUFBQTtjQUFBLE9BQ2Z1QixRQUFRLENBQUNqQixJQUFJLENBQUM5QixPQUFPLGFBQVBBLE9BQU8sdUJBQVBBLE9BQU8sQ0FBRWUsWUFBWSxFQUFFZixPQUFPLGFBQVBBLE9BQU8sdUJBQVBBLE9BQU8sQ0FBRWdCLFdBQVcsQ0FBQztZQUFBO2NBQUFvQyxTQUFBLENBQUE1QixJQUFBO2NBQUEsT0FFL0J1QixRQUFRLENBQ3RDWSxNQUFNLENBQUMsQ0FBQyxDQUNSQyxJQUFJLENBQUMsVUFBQ0MsQ0FBQztnQkFBQSxPQUFLQSxDQUFDLENBQUNILE1BQU0sQ0FBQyxDQUFDO2NBQUEsRUFBQztZQUFBO2NBRnBCUixrQkFBa0IsR0FBQUUsU0FBQSxDQUFBbkIsSUFBQTtjQUd4QmlCLGtCQUFrQixDQUFDWSxJQUFJLENBQUNiLFVBQVUsQ0FBQztjQUFDRyxTQUFBLENBQUE1QixJQUFBO2NBQUE7WUFBQTtjQUFBNEIsU0FBQSxDQUFBN0IsSUFBQTtjQUFBNkIsU0FBQSxDQUFBbEIsRUFBQSxHQUFBa0IsU0FBQTtjQUU5QmpDLEdBQUcsR0FBQWlDLFNBQUEsQ0FBQWxCLEVBQUE7Y0FDVCxJQUFJLENBQUN0QyxNQUFNLENBQUN1QyxLQUFLLDhCQUFBQyxNQUFBLENBQThCakIsR0FBRyxDQUFDckQsT0FBTyxDQUFFLENBQUM7Y0FFN0QsSUFBSXFELEdBQUcsQ0FBQ2hELElBQUksS0FBSyx3QkFBd0IsRUFBRTtnQkFDekM7Z0JBQ0E0RSxRQUFRLENBQUNWLE1BQU0sQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxVQUFDQyxPQUFPO2tCQUFBLE9BQUtBLE9BQU87Z0JBQUEsRUFBQztjQUMvQztjQUFDLE1BRUtwQixHQUFHO1lBQUE7Y0FBQSxPQUFBaUMsU0FBQSxDQUFBcEIsTUFBQSxXQUVKZ0IsWUFBWTtZQUFBO1lBQUE7Y0FBQSxPQUFBSSxTQUFBLENBQUFaLElBQUE7VUFBQTtRQUFBLEdBQUFLLFFBQUE7TUFBQSxDQUNwQjtNQUFBLFNBekNLUSxLQUFLQSxDQUFBVSxHQUFBLEVBQUFDLEdBQUE7UUFBQSxPQUFBcEIsTUFBQSxDQUFBRCxLQUFBLE9BQUFqRSxTQUFBO01BQUE7TUFBQSxPQUFMMkUsS0FBSztJQUFBO0VBQUE7QUFBQTtBQTRDYixXQUFhNUMsVUFBVSwwQkFBQXdELGFBQUE7RUFVckIsU0FBQXhELFdBQ0V5RCxJQUFtQixFQUNuQmxFLE9BQTRELEVBQzVEO0lBQUEsSUFBQW1FLE1BQUE7SUFBQWxHLGVBQUEsT0FBQXdDLFVBQUE7SUFDQTBELE1BQUEsR0FBQWpHLFVBQUEsT0FBQXVDLFVBQUE7SUFDQTBELE1BQUEsQ0FBS3pFLFVBQVUsR0FBR3dFLElBQUk7SUFDdEJDLE1BQUEsQ0FBS3ZFLE1BQU0sR0FBR3VFLE1BQUEsQ0FBS3pFLFVBQVUsQ0FBQ0csU0FBUyxHQUNuQ3BDLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDcUMsY0FBYyxDQUFDcUUsTUFBQSxDQUFLekUsVUFBVSxDQUFDRyxTQUFTLENBQUMsR0FDdkVwQyxTQUFTLENBQUMsa0JBQWtCLENBQUM7SUFDakMsSUFBSSxJQUFJLElBQUl1QyxPQUFPLEVBQUU7TUFDbkJtRSxNQUFBLENBQUtDLEdBQUcsR0FBR3BFLE9BQU8sQ0FBQ1EsRUFBRTtJQUN2QixDQUFDLE1BQU07TUFDTDJELE1BQUEsQ0FBS2pFLFVBQVUsR0FBR0YsT0FBTyxDQUFDRSxVQUFVO0lBQ3RDO0lBQ0FpRSxNQUFBLENBQUtoRSxjQUFjLEdBQUdILE9BQU8sQ0FBQ0csY0FBYztJQUM1QztJQUNBZ0UsTUFBQSxDQUFLRSxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQUNsQyxLQUFLO01BQUEsT0FBTWdDLE1BQUEsQ0FBS2hDLEtBQUssR0FBR0EsS0FBSztJQUFBLENBQUMsQ0FBQztJQUFDLE9BQUFnQyxNQUFBO0VBQ3BEOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFKRS9GLFNBQUEsQ0FBQXFDLFVBQUEsRUFBQXdELGFBQUE7RUFBQSxPQUFBNUYsWUFBQSxDQUFBb0MsVUFBQTtJQUFBOUIsR0FBQTtJQUFBMkYsR0FBQSxFQUtBLFNBQUFBLElBQUEsRUFBd0I7TUFDdEIsT0FBTyxJQUFJLENBQUNDLE9BQU8sR0FBRyxJQUFJLENBQUNBLE9BQU8sQ0FBQy9ELEVBQUUsR0FBSSxJQUFJLENBQUM0RCxHQUFjO0lBQzlEOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFKRTtJQUFBekYsR0FBQTtJQUFBQyxLQUFBLEVBS0EsU0FBTzRGLE9BQU9BLENBQUEsRUFBbUI7TUFDL0IsSUFBSSxJQUFJLENBQUNELE9BQU8sRUFBRTtRQUNoQixPQUFPLElBQUksQ0FBQ0EsT0FBTztNQUNyQjtNQUVBLE1BQU0sSUFBSWhHLEtBQUssQ0FDYiw0REFDRixDQUFDO0lBQ0g7O0lBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUpFO0lBQUFJLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUE2RixLQUFBLEdBQUE5RCxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBS0EsU0FBQTZELFNBQUE7UUFBQSxPQUFBOUQsbUJBQUEsQ0FBQVEsSUFBQSxVQUFBdUQsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFyRCxJQUFBLEdBQUFxRCxTQUFBLENBQUFwRCxJQUFBO1lBQUE7Y0FBQSxJQUNPLElBQUksQ0FBQ3RCLFVBQVU7Z0JBQUEwRSxTQUFBLENBQUFwRCxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUNaLElBQUlqRCxLQUFLLENBQUMsdURBQXVELENBQUM7WUFBQTtjQUFBcUcsU0FBQSxDQUFBckQsSUFBQTtjQUFBcUQsU0FBQSxDQUFBcEQsSUFBQTtjQUFBLE9BR25ELElBQUksQ0FBQ3FELGtCQUFrQixDQUFpQjtnQkFDM0RDLE1BQU0sRUFBRSxNQUFNO2dCQUNkaEcsSUFBSSxFQUFFaUcsZUFBQSxDQUFlLElBQUksQ0FBQzdFLFVBQVUsQ0FBQztnQkFDckM4RSxPQUFPLEVBQUU7a0JBQ1AsY0FBYyxFQUFFO2dCQUNsQixDQUFDO2dCQUNEQyxZQUFZLEVBQUU7Y0FDaEIsQ0FBQyxDQUFDO1lBQUE7Y0FQRixJQUFJLENBQUNWLE9BQU8sR0FBQUssU0FBQSxDQUFBM0MsSUFBQTtjQVFaLElBQUksQ0FBQ3JDLE1BQU0sQ0FBQ3NGLEtBQUssNkJBQUE5QyxNQUFBLENBQTZCLElBQUksQ0FBQzVCLEVBQUUsQ0FBRSxDQUFDO2NBQ3hELElBQUksQ0FBQzJFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDWixPQUFPLENBQUM7Y0FBQ0ssU0FBQSxDQUFBcEQsSUFBQTtjQUFBO1lBQUE7Y0FBQW9ELFNBQUEsQ0FBQXJELElBQUE7Y0FBQXFELFNBQUEsQ0FBQTFDLEVBQUEsR0FBQTBDLFNBQUE7Y0FFaEMsSUFBSSxDQUFDTyxJQUFJLENBQUMsT0FBTyxFQUFBUCxTQUFBLENBQUExQyxFQUFLLENBQUM7Y0FBQyxNQUFBMEMsU0FBQSxDQUFBMUMsRUFBQTtZQUFBO2NBQUEsT0FBQTBDLFNBQUEsQ0FBQTVDLE1BQUEsV0FJbkIsSUFBSSxDQUFDdUMsT0FBTztZQUFBO1lBQUE7Y0FBQSxPQUFBSyxTQUFBLENBQUFwQyxJQUFBO1VBQUE7UUFBQSxHQUFBa0MsUUFBQTtNQUFBLENBQ3BCO01BQUEsU0FyQksvQyxJQUFJQSxDQUFBO1FBQUEsT0FBQThDLEtBQUEsQ0FBQTlCLEtBQUEsT0FBQWpFLFNBQUE7TUFBQTtNQUFBLE9BQUppRCxJQUFJO0lBQUE7SUF1QlY7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBTEU7RUFBQTtJQUFBaEQsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQXdHLE1BQUEsR0FBQXpFLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FNQSxTQUFBd0UsU0FBQTtRQUFBLElBQUFDLEtBQUE7UUFBQSxPQUFBMUUsbUJBQUEsQ0FBQVEsSUFBQSxVQUFBbUUsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUFqRSxJQUFBLEdBQUFpRSxTQUFBLENBQUFoRSxJQUFBO1lBQUE7Y0FBQWdFLFNBQUEsQ0FBQWpFLElBQUE7Y0FFVStELEtBQThCLEdBQUcsU0FBUztjQUFBRSxTQUFBLENBQUFoRSxJQUFBO2NBQUEsT0FDM0IsSUFBSSxDQUFDcUQsa0JBQWtCLENBQWlCO2dCQUMzREMsTUFBTSxFQUFFLE9BQU87Z0JBQ2ZXLElBQUksTUFBQXJELE1BQUEsQ0FBTSxJQUFJLENBQUM1QixFQUFFLENBQUU7Z0JBQ25CMUIsSUFBSSxFQUFFaUcsZUFBQSxDQUFlO2tCQUFFTyxLQUFLLEVBQUxBO2dCQUFNLENBQUMsQ0FBQztnQkFDL0JOLE9BQU8sRUFBRTtrQkFBRSxjQUFjLEVBQUU7Z0JBQWtDLENBQUM7Z0JBQzlEQyxZQUFZLEVBQUU7Y0FDaEIsQ0FBQyxDQUFDO1lBQUE7Y0FORixJQUFJLENBQUNWLE9BQU8sR0FBQWlCLFNBQUEsQ0FBQXZELElBQUE7Y0FPWixJQUFJLENBQUNyQyxNQUFNLENBQUNzRixLQUFLLDZCQUFBOUMsTUFBQSxDQUE2QixJQUFJLENBQUM1QixFQUFFLENBQUUsQ0FBQztjQUFDLE9BQUFnRixTQUFBLENBQUF4RCxNQUFBLFdBQ2xELElBQUksQ0FBQ3VDLE9BQU87WUFBQTtjQUFBaUIsU0FBQSxDQUFBakUsSUFBQTtjQUFBaUUsU0FBQSxDQUFBdEQsRUFBQSxHQUFBc0QsU0FBQTtjQUVuQixJQUFJLENBQUNMLElBQUksQ0FBQyxPQUFPLEVBQUFLLFNBQUEsQ0FBQXRELEVBQUssQ0FBQztjQUFDLE1BQUFzRCxTQUFBLENBQUF0RCxFQUFBO1lBQUE7WUFBQTtjQUFBLE9BQUFzRCxTQUFBLENBQUFoRCxJQUFBO1VBQUE7UUFBQSxHQUFBNkMsUUFBQTtNQUFBLENBRzNCO01BQUEsU0FoQktLLEtBQUtBLENBQUE7UUFBQSxPQUFBTixNQUFBLENBQUF6QyxLQUFBLE9BQUFqRSxTQUFBO01BQUE7TUFBQSxPQUFMZ0gsS0FBSztJQUFBO0lBa0JYO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBTkU7RUFBQTtJQUFBL0csR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQStHLEtBQUEsR0FBQWhGLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FPQSxTQUFBK0UsU0FBQTtRQUFBLElBQUFDLFNBQUEsRUFBQUMsU0FBQTtRQUFBLElBQUFDLFFBQUE7VUFBQUMsT0FBQTtVQUFBakksS0FBQTtVQUFBa0ksU0FBQTtVQUFBQyxPQUFBO1VBQUFDLEdBQUE7VUFBQUMsWUFBQTtVQUFBQyxNQUFBLEdBQUEzSCxTQUFBO1FBQUEsT0FBQWtDLG1CQUFBLENBQUFRLElBQUEsVUFBQWtGLFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBaEYsSUFBQSxHQUFBZ0YsU0FBQSxDQUFBL0UsSUFBQTtZQUFBO2NBQ0V1RSxRQUFnQixHQUFBTSxNQUFBLENBQUEvRixNQUFBLFFBQUErRixNQUFBLFFBQUE5RixTQUFBLEdBQUE4RixNQUFBLE1BQUcsSUFBSSxDQUFDbEcsY0FBYyxDQUFDWSxZQUFZO2NBQ25EaUYsT0FBZSxHQUFBSyxNQUFBLENBQUEvRixNQUFBLFFBQUErRixNQUFBLFFBQUE5RixTQUFBLEdBQUE4RixNQUFBLE1BQUcsSUFBSSxDQUFDbEcsY0FBYyxDQUFDYSxXQUFXO2NBRTNDakQsS0FBSyxHQUFHLElBQUksQ0FBQ3lDLEVBQUU7Y0FDZnlGLFNBQVMsR0FBR08sU0FBQSxDQUFTLENBQUM7Y0FDdEJOLE9BQU8sR0FBR0QsU0FBUyxHQUFHRCxPQUFPO2NBRW5DLElBQUksQ0FBQ3BHLE1BQU0sQ0FBQ3NGLEtBQUssQ0FBQyw4QkFBOEIsQ0FBQztjQUNqRCxJQUFJLENBQUN0RixNQUFNLENBQUNzRixLQUFLLENBQUF1Qix1QkFBQSxDQUFBWixTQUFBLCtCQUFBekQsTUFBQSxDQUNhNEQsT0FBTyxzQkFBQTFHLElBQUEsQ0FBQXVHLFNBQUEsRUFBa0JFLFFBQVEsUUFDL0QsQ0FBQztjQUFDLE1BRUVDLE9BQU8sS0FBSyxDQUFDO2dCQUFBTyxTQUFBLENBQUEvRSxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxNQUNULElBQUk1RCxzQkFBc0Isd0RBQUF3RSxNQUFBLENBQ3lCckUsS0FBSyxHQUM1REEsS0FDRixDQUFDO1lBQUE7Y0FBQSxNQUdJbUksT0FBTyxHQUFHTSxTQUFBLENBQVMsQ0FBQztnQkFBQUQsU0FBQSxDQUFBL0UsSUFBQTtnQkFBQTtjQUFBO2NBQUErRSxTQUFBLENBQUFoRixJQUFBO2NBQUFnRixTQUFBLENBQUEvRSxJQUFBO2NBQUEsT0FFTCxJQUFJLENBQUNrRixLQUFLLENBQUMsQ0FBQztZQUFBO2NBQXhCUCxHQUFHLEdBQUFJLFNBQUEsQ0FBQXRFLElBQUE7Y0FBQXNFLFNBQUEsQ0FBQXJFLEVBQUEsR0FDRGlFLEdBQUcsQ0FBQ2IsS0FBSztjQUFBaUIsU0FBQSxDQUFBL0UsSUFBQSxHQUFBK0UsU0FBQSxDQUFBckUsRUFBQSxLQUNWLFNBQVMsUUFBQXFFLFNBQUEsQ0FBQXJFLEVBQUEsS0FFVCxnQkFBZ0IsUUFBQXFFLFNBQUEsQ0FBQXJFLEVBQUEsS0FDaEIsWUFBWSxRQUFBcUUsU0FBQSxDQUFBckUsRUFBQSxLQUlaLFFBQVEsUUFBQXFFLFNBQUEsQ0FBQXJFLEVBQUEsS0FLUixhQUFhO2NBQUE7WUFBQTtjQUFBLE1BWFYsSUFBSTNELEtBQUssQ0FBQyxzQkFBc0IsQ0FBQztZQUFBO2NBR3ZDLElBQUksQ0FBQzRHLElBQUksQ0FBQyxZQUFZLEVBQUVnQixHQUFHLENBQUM7Y0FBQ0ksU0FBQSxDQUFBL0UsSUFBQTtjQUFBLE9BQ3ZCbUYsS0FBSyxDQUFDWixRQUFRLENBQUM7WUFBQTtjQUFBLE9BQUFRLFNBQUEsQ0FBQXZFLE1BQUE7WUFBQTtjQUdyQjtjQUNBO2NBQ0EsSUFBSSxDQUFDcEMsTUFBTSxDQUFDc0YsS0FBSyxDQUFDaUIsR0FBRyxDQUFDO2NBQUMsTUFDakIsSUFBSTVILEtBQUssQ0FBQyw4QkFBOEIsQ0FBQztZQUFBO2NBRS9DLElBQUksQ0FBQ3FCLE1BQU0sQ0FBQ3NGLEtBQUssUUFBQTlDLE1BQUEsQ0FBUSxJQUFJLENBQUM1QixFQUFFLGlDQUE4QixDQUFDO2NBQy9ELElBQUksQ0FBQzJFLElBQUksQ0FBQyxhQUFhLEVBQUVnQixHQUFHLENBQUM7Y0FBQyxPQUFBSSxTQUFBLENBQUF2RSxNQUFBO1lBQUE7Y0FBQXVFLFNBQUEsQ0FBQS9FLElBQUE7Y0FBQTtZQUFBO2NBQUErRSxTQUFBLENBQUFoRixJQUFBO2NBQUFnRixTQUFBLENBQUFLLEVBQUEsR0FBQUwsU0FBQTtjQUlsQyxJQUFJLENBQUNwQixJQUFJLENBQUMsT0FBTyxFQUFBb0IsU0FBQSxDQUFBSyxFQUFLLENBQUM7Y0FBQyxNQUFBTCxTQUFBLENBQUFLLEVBQUE7WUFBQTtjQUFBTCxTQUFBLENBQUEvRSxJQUFBO2NBQUE7WUFBQTtjQUt0QjRFLFlBQVksR0FBRyxJQUFJeEksc0JBQXNCLENBQUE2SSx1QkFBQSxDQUFBWCxTQUFBLDhCQUFBMUQsTUFBQSxDQUNsQjRELE9BQU8sb0JBQUExRyxJQUFBLENBQUF3RyxTQUFBLEVBQWdCL0gsS0FBSyxHQUN2REEsS0FDRixDQUFDO2NBQ0QsSUFBSSxDQUFDb0gsSUFBSSxDQUFDLE9BQU8sRUFBRWlCLFlBQVksQ0FBQztjQUFDLE1BQzNCQSxZQUFZO1lBQUE7WUFBQTtjQUFBLE9BQUFHLFNBQUEsQ0FBQS9ELElBQUE7VUFBQTtRQUFBLEdBQUFvRCxRQUFBO01BQUEsQ0FDbkI7TUFBQSxTQXJESzlELElBQUlBLENBQUE7UUFBQSxPQUFBNkQsS0FBQSxDQUFBaEQsS0FBQSxPQUFBakUsU0FBQTtNQUFBO01BQUEsT0FBSm9ELElBQUk7SUFBQTtJQXVEVjtBQUNGO0FBQ0E7QUFDQTtBQUNBO0lBSkU7RUFBQTtJQUFBbkQsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQWlJLE1BQUEsR0FBQWxHLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FLQSxTQUFBaUcsU0FBQTtRQUFBLElBQUF2QyxPQUFBO1FBQUEsT0FBQTNELG1CQUFBLENBQUFRLElBQUEsVUFBQTJGLFVBQUFDLFNBQUE7VUFBQSxrQkFBQUEsU0FBQSxDQUFBekYsSUFBQSxHQUFBeUYsU0FBQSxDQUFBeEYsSUFBQTtZQUFBO2NBQUF3RixTQUFBLENBQUF6RixJQUFBO2NBQUF5RixTQUFBLENBQUF4RixJQUFBO2NBQUEsT0FFMEIsSUFBSSxDQUFDcUQsa0JBQWtCLENBQWlCO2dCQUM1REMsTUFBTSxFQUFFLEtBQUs7Z0JBQ2JXLElBQUksTUFBQXJELE1BQUEsQ0FBTSxJQUFJLENBQUM1QixFQUFFLENBQUU7Z0JBQ25CeUUsWUFBWSxFQUFFO2NBQ2hCLENBQUMsQ0FBQztZQUFBO2NBSklWLE9BQU8sR0FBQXlDLFNBQUEsQ0FBQS9FLElBQUE7Y0FLYixJQUFJLENBQUNzQyxPQUFPLEdBQUdBLE9BQU87Y0FBQyxPQUFBeUMsU0FBQSxDQUFBaEYsTUFBQSxXQUNoQnVDLE9BQU87WUFBQTtjQUFBeUMsU0FBQSxDQUFBekYsSUFBQTtjQUFBeUYsU0FBQSxDQUFBOUUsRUFBQSxHQUFBOEUsU0FBQTtjQUVkLElBQUksQ0FBQzdCLElBQUksQ0FBQyxPQUFPLEVBQUE2QixTQUFBLENBQUE5RSxFQUFLLENBQUM7Y0FBQyxNQUFBOEUsU0FBQSxDQUFBOUUsRUFBQTtZQUFBO1lBQUE7Y0FBQSxPQUFBOEUsU0FBQSxDQUFBeEUsSUFBQTtVQUFBO1FBQUEsR0FBQXNFLFFBQUE7TUFBQSxDQUczQjtNQUFBLFNBYktKLEtBQUtBLENBQUE7UUFBQSxPQUFBRyxNQUFBLENBQUFsRSxLQUFBLE9BQUFqRSxTQUFBO01BQUE7TUFBQSxPQUFMZ0ksS0FBSztJQUFBO0lBZVg7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBTEU7RUFBQTtJQUFBL0gsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQXFJLE9BQUEsR0FBQXRHLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FNQSxTQUFBcUcsU0FBQTtRQUFBLElBQUFDLFlBQUEsRUFBQUMsZ0JBQUEsRUFBQUMsV0FBQSxFQUFBQyxVQUFBLEVBQUFDLFVBQUE7UUFBQSxPQUFBM0csbUJBQUEsQ0FBQVEsSUFBQSxVQUFBb0csVUFBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUFsRyxJQUFBLEdBQUFrRyxVQUFBLENBQUFqRyxJQUFBO1lBQUE7Y0FDUTJGLFlBQVksR0FBRyxJQUFJN0osUUFBUSxDQUFDLENBQUM7Y0FDN0I4SixnQkFBZ0IsR0FBR0QsWUFBWSxDQUFDekQsTUFBTSxDQUFDLEtBQUssQ0FBQztjQUU3QzJELFdBQVcsT0FBQWpGLE1BQUEsQ0FBTyxJQUFJLENBQUM1QixFQUFFO1lBQUE7Y0FBQSxNQUV4QixJQUFJLENBQUNrSCxPQUFPLEtBQUssTUFBTTtnQkFBQUQsVUFBQSxDQUFBakcsSUFBQTtnQkFBQTtjQUFBO2NBQ3RCK0YsVUFBVSxHQUFHLElBQUksQ0FBQzFDLGtCQUFrQixDQUFDO2dCQUN6Q0MsTUFBTSxFQUFFLEtBQUs7Z0JBQ2JXLElBQUksRUFBRSxJQUFJLENBQUNpQztnQkFDVDtnQkFBQSxFQUFBakIsdUJBQUEsQ0FBQWEsVUFBQSxNQUFBbEYsTUFBQSxDQUNLaUYsV0FBVyxnQkFBQS9ILElBQUEsQ0FBQWdJLFVBQUEsRUFBWSxJQUFJLENBQUNJLE9BQU8sSUFDdENMLFdBQVc7Z0JBQ2ZyQyxPQUFPLEVBQUU7a0JBQ1AyQyxNQUFNLEVBQUU7Z0JBQ1Y7Y0FDRixDQUFDLENBQUM7Y0FFRkosVUFBVSxDQUFDN0QsTUFBTSxDQUFDLENBQUMsQ0FBQ0ksSUFBSSxDQUFDc0QsZ0JBQWdCLENBQUM7Y0FBQ0ssVUFBQSxDQUFBakcsSUFBQTtjQUFBLE9BQ3JDK0YsVUFBVTtZQUFBO2NBQUFFLFVBQUEsQ0FBQWpHLElBQUE7Y0FBQTtZQUFBO2NBQUEsT0FBQWlHLFVBQUEsQ0FBQXpGLE1BQUEsV0FHWG1GLFlBQVk7WUFBQTtZQUFBO2NBQUEsT0FBQU0sVUFBQSxDQUFBakYsSUFBQTtVQUFBO1FBQUEsR0FBQTBFLFFBQUE7TUFBQSxDQUNwQjtNQUFBLFNBdkJZdkQsTUFBTUEsQ0FBQTtRQUFBLE9BQUFzRCxPQUFBLENBQUF0RSxLQUFBLE9BQUFqRSxTQUFBO01BQUE7TUFBQSxPQUFOaUYsTUFBTTtJQUFBO0lBeUJuQjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUFoRixHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBZ0osUUFBQSxHQUFBakgsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUFnSCxTQUFBO1FBQUEsT0FBQWpILG1CQUFBLENBQUFRLElBQUEsVUFBQTBHLFVBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBeEcsSUFBQSxHQUFBd0csVUFBQSxDQUFBdkcsSUFBQTtZQUFBO2NBQUEsT0FBQXVHLFVBQUEsQ0FBQS9GLE1BQUEsV0FDUyxJQUFJLENBQUM2QyxrQkFBa0IsQ0FBTztnQkFDbkNDLE1BQU0sRUFBRSxRQUFRO2dCQUNoQlcsSUFBSSxNQUFBckQsTUFBQSxDQUFNLElBQUksQ0FBQzVCLEVBQUU7Y0FDbkIsQ0FBQyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUF1SCxVQUFBLENBQUF2RixJQUFBO1VBQUE7UUFBQSxHQUFBcUYsUUFBQTtNQUFBLENBQ0g7TUFBQSxTQUxLeEYsT0FBTUEsQ0FBQTtRQUFBLE9BQUF1RixRQUFBLENBQUFqRixLQUFBLE9BQUFqRSxTQUFBO01BQUE7TUFBQSxPQUFOMkQsT0FBTTtJQUFBO0VBQUE7SUFBQTFELEdBQUE7SUFBQUMsS0FBQSxFQU9aLFNBQVFpRyxrQkFBa0JBLENBQUltRCxPQUFvQixFQUFFO01BQUEsSUFBQUMsTUFBQTtNQUNsRCxJQUFReEMsSUFBSSxHQUFtQnVDLE9BQU8sQ0FBOUJ2QyxJQUFJO1FBQUVSLFlBQVksR0FBSytDLE9BQU8sQ0FBeEIvQyxZQUFZO01BRTFCLElBQU1pRCxRQUFRLHFCQUFBOUYsTUFBQSxDQUFxQixJQUFJLENBQUMxQyxVQUFVLENBQUN5SSxPQUFPLGdCQUFhO01BRXZFLElBQU1DLEdBQUcsR0FBRyxJQUFBQyxJQUFBLENBQ1Y1QyxJQUFJLEdBQUd5QyxRQUFRLEdBQUd6QyxJQUFJLEdBQUd5QyxRQUFRLEVBQ2pDLElBQUksQ0FBQ3hJLFVBQVUsQ0FBQzRJLFdBQ2xCLENBQUMsQ0FBQ0MsUUFBUSxDQUFDLENBQUM7TUFFWixJQUFNQyxPQUFPLEdBQUcsSUFBSWhLLFNBQVMsQ0FBQyxJQUFJLENBQUNrQixVQUFVLEVBQUU7UUFBRXVGLFlBQVksRUFBWkE7TUFBYSxDQUFDLENBQUM7TUFFaEV1RCxPQUFPLENBQUNuRSxFQUFFLENBQUMsVUFBVSxFQUFFLFVBQUNuRixRQUFzQixFQUFLO1FBQ2pEK0ksTUFBSSxDQUFDUCxPQUFPLEdBQUd4SSxRQUFRLENBQUM4RixPQUFPLENBQUMsZ0JBQWdCLENBQUM7UUFDakRpRCxNQUFJLENBQUNySSxNQUFNLENBQUNzRixLQUFLLG9CQUFBOUMsTUFBQSxDQUFvQjZGLE1BQUksQ0FBQ1AsT0FBTyxDQUFFLENBQUM7TUFDdEQsQ0FBQyxDQUFDO01BRUYsT0FBT2MsT0FBTyxDQUFDUixPQUFPLENBQUFTLGFBQUEsQ0FBQUEsYUFBQSxLQUNqQlQsT0FBTztRQUNWSSxHQUFHLEVBQUhBO01BQUcsRUFDSixDQUFDO0lBQ0o7RUFBQztBQUFBLEVBelArQ2pMLFlBQVk7O0FBNFA5RDtBQUNBO0FBQ0E7QUFDQSxXQUFhOEMsV0FBVywwQkFBQXlJLGNBQUE7RUFhdEI7QUFDRjtBQUNBO0VBQ0UsU0FBQXpJLFlBQ0VpRSxJQUFtQixFQUNuQmxFLE9BQTRELEVBQzVEO0lBQUEsSUFBQTJJLE1BQUE7SUFBQTFLLGVBQUEsT0FBQWdDLFdBQUE7SUFDQTBJLE1BQUEsR0FBQXpLLFVBQUEsT0FBQStCLFdBQUE7SUFFQTBJLE1BQUEsQ0FBS2pKLFVBQVUsR0FBR3dFLElBQUk7SUFDdEJ5RSxNQUFBLENBQUsvSSxNQUFNLEdBQUcrSSxNQUFBLENBQUtqSixVQUFVLENBQUNHLFNBQVMsR0FDbkNwQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsQ0FBQ3FDLGNBQWMsQ0FBQzZJLE1BQUEsQ0FBS2pKLFVBQVUsQ0FBQ0csU0FBUyxDQUFDLEdBQ3hFcEMsU0FBUyxDQUFDLG1CQUFtQixDQUFDO0lBQ2xDa0wsTUFBQSxDQUFLeEksY0FBYyxHQUFHSCxPQUFPLENBQUNHLGNBQWM7SUFDNUMsSUFBSSxJQUFJLElBQUlILE9BQU8sRUFBRTtNQUNuQjJJLE1BQUEsQ0FBS3ZFLEdBQUcsR0FBR3BFLE9BQU8sQ0FBQ1EsRUFBRTtJQUN2QixDQUFDLE1BQU07TUFDTG1JLE1BQUEsQ0FBS3pJLFVBQVUsR0FBR0YsT0FBTyxDQUFDRSxVQUFVO0lBQ3RDO0lBQ0F5SSxNQUFBLENBQUtDLE9BQU8sR0FBRyxJQUFJQyxTQUFTLENBQUk7TUFDOUJDLGFBQWEsRUFBRSxTQUFmQSxhQUFhQSxDQUFHZCxPQUFPO1FBQUEsT0FBS1csTUFBQSxDQUFLSSxtQkFBbUIsQ0FBQ2YsT0FBTyxDQUFDO01BQUE7TUFDN0Q1SCxHQUFHLEVBQUF1STtJQUNMLENBQUMsQ0FBQztJQUNGO0lBQ0FBLE1BQUEsQ0FBS3RFLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBQ2xDLEtBQUs7TUFBQSxPQUFNd0csTUFBQSxDQUFLeEcsS0FBSyxHQUFHQSxLQUFLO0lBQUEsQ0FBQyxDQUFDO0lBQUMsT0FBQXdHLE1BQUE7RUFDcEQ7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUpFdkssU0FBQSxDQUFBNkIsV0FBQSxFQUFBeUksY0FBQTtFQUFBLE9BQUFySyxZQUFBLENBQUE0QixXQUFBO0lBQUF0QixHQUFBO0lBQUEyRixHQUFBLEVBS0EsU0FBQUEsSUFBQSxFQUF3QjtNQUN0QixPQUFPLElBQUksQ0FBQ0MsT0FBTyxHQUFHLElBQUksQ0FBQ0EsT0FBTyxDQUFDL0QsRUFBRSxHQUFJLElBQUksQ0FBQzRELEdBQWM7SUFDOUQ7O0lBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUpFO0lBQUF6RixHQUFBO0lBQUFDLEtBQUEsRUFLQSxTQUFPNEYsT0FBT0EsQ0FBQSxFQUFjO01BQzFCLElBQUksSUFBSSxDQUFDRCxPQUFPLEVBQUU7UUFDaEIsT0FBTyxJQUFJLENBQUNBLE9BQU87TUFDckI7TUFFQSxNQUFNLElBQUloRyxLQUFLLENBQ2IsNERBQ0YsQ0FBQztJQUNIOztJQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFKRTtJQUFBSSxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBb0ssTUFBQSxHQUFBckksaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUtBLFNBQUFvSSxTQUFBO1FBQUEsT0FBQXJJLG1CQUFBLENBQUFRLElBQUEsVUFBQThILFVBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBNUgsSUFBQSxHQUFBNEgsVUFBQSxDQUFBM0gsSUFBQTtZQUFBO2NBQUEsSUFDTyxJQUFJLENBQUN0QixVQUFVO2dCQUFBaUosVUFBQSxDQUFBM0gsSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDWixJQUFJakQsS0FBSyxDQUFDLHdEQUF3RCxDQUFDO1lBQUE7Y0FBQTRLLFVBQUEsQ0FBQTVILElBQUE7Y0FBQTRILFVBQUEsQ0FBQTNILElBQUE7Y0FBQSxPQUlwRCxJQUFJLENBQUN1SCxtQkFBbUIsQ0FBWTtnQkFDdkRqRSxNQUFNLEVBQUUsTUFBTTtnQkFDZGhHLElBQUksRUFBRWlHLGVBQUEsQ0FBZSxJQUFJLENBQUM3RSxVQUFVLENBQUM7Z0JBQ3JDOEUsT0FBTyxFQUFFO2tCQUNQLGNBQWMsRUFBRTtnQkFDbEIsQ0FBQztnQkFDREMsWUFBWSxFQUFFO2NBQ2hCLENBQUMsQ0FBQztZQUFBO2NBUEYsSUFBSSxDQUFDVixPQUFPLEdBQUE0RSxVQUFBLENBQUFsSCxJQUFBO2NBUVosSUFBSSxDQUFDckMsTUFBTSxDQUFDc0YsS0FBSyw2QkFBQTlDLE1BQUEsQ0FBNkIsSUFBSSxDQUFDNUIsRUFBRSxDQUFFLENBQUM7Y0FDeEQsSUFBSSxDQUFDMkUsSUFBSSxDQUFDLE1BQU0sQ0FBQztjQUFDZ0UsVUFBQSxDQUFBM0gsSUFBQTtjQUFBO1lBQUE7Y0FBQTJILFVBQUEsQ0FBQTVILElBQUE7Y0FBQTRILFVBQUEsQ0FBQWpILEVBQUEsR0FBQWlILFVBQUE7Y0FFbEIsSUFBSSxDQUFDaEUsSUFBSSxDQUFDLE9BQU8sRUFBQWdFLFVBQUEsQ0FBQWpILEVBQUssQ0FBQztjQUFDLE1BQUFpSCxVQUFBLENBQUFqSCxFQUFBO1lBQUE7Y0FBQSxPQUFBaUgsVUFBQSxDQUFBbkgsTUFBQSxXQUluQixJQUFJLENBQUN1QyxPQUFPO1lBQUE7WUFBQTtjQUFBLE9BQUE0RSxVQUFBLENBQUEzRyxJQUFBO1VBQUE7UUFBQSxHQUFBeUcsUUFBQTtNQUFBLENBQ3BCO01BQUEsU0F0Qkt0SCxJQUFJQSxDQUFBO1FBQUEsT0FBQXFILE1BQUEsQ0FBQXJHLEtBQUEsT0FBQWpFLFNBQUE7TUFBQTtNQUFBLE9BQUppRCxJQUFJO0lBQUE7SUF3QlY7QUFDRjtBQUNBO0FBQ0E7SUFIRTtFQUFBO0lBQUFoRCxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBd0ssV0FBQSxHQUFBekksaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUlBLFNBQUF3SSxVQUFpQnBJLEtBQW1DO1FBQUEsT0FBQUwsbUJBQUEsQ0FBQVEsSUFBQSxVQUFBa0ksV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUFoSSxJQUFBLEdBQUFnSSxVQUFBLENBQUEvSCxJQUFBO1lBQUE7Y0FBQStILFVBQUEsQ0FBQS9ILElBQUE7Y0FBQSxPQUM1QyxJQUFJLENBQUNvSCxPQUFPLENBQUNZLE9BQU8sQ0FBQ3ZJLEtBQUssQ0FBQyxDQUFDMEMsTUFBTTtZQUFBO2NBQ3hDLElBQUksQ0FBQy9ELE1BQU0sQ0FBQ3NGLEtBQUssc0NBQUE5QyxNQUFBLENBQXNDLElBQUksQ0FBQzVCLEVBQUUsQ0FBRSxDQUFDO1lBQUM7WUFBQTtjQUFBLE9BQUErSSxVQUFBLENBQUEvRyxJQUFBO1VBQUE7UUFBQSxHQUFBNkcsU0FBQTtNQUFBLENBQ25FO01BQUEsU0FIS3pILFVBQVVBLENBQUE2SCxHQUFBO1FBQUEsT0FBQUwsV0FBQSxDQUFBekcsS0FBQSxPQUFBakUsU0FBQTtNQUFBO01BQUEsT0FBVmtELFVBQVU7SUFBQTtJQUtoQjtBQUNGO0FBQ0E7QUFDQTtBQUNBO0lBSkU7RUFBQTtJQUFBakQsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQThLLE1BQUEsR0FBQS9JLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FLQSxTQUFBOEksVUFBQTtRQUFBLElBQUFyRSxLQUFBO1FBQUEsT0FBQTFFLG1CQUFBLENBQUFRLElBQUEsVUFBQXdJLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBdEksSUFBQSxHQUFBc0ksVUFBQSxDQUFBckksSUFBQTtZQUFBO2NBQUFxSSxVQUFBLENBQUF0SSxJQUFBO2NBRVUrRCxLQUF5QixHQUFHLGdCQUFnQjtjQUFBdUUsVUFBQSxDQUFBckksSUFBQTtjQUFBLE9BQzdCLElBQUksQ0FBQ3VILG1CQUFtQixDQUFZO2dCQUN2RGpFLE1BQU0sRUFBRSxPQUFPO2dCQUNmVyxJQUFJLE1BQUFyRCxNQUFBLENBQU0sSUFBSSxDQUFDNUIsRUFBRSxDQUFFO2dCQUNuQjFCLElBQUksRUFBRWlHLGVBQUEsQ0FBZTtrQkFBRU8sS0FBSyxFQUFMQTtnQkFBTSxDQUFDLENBQUM7Z0JBQy9CTixPQUFPLEVBQUU7a0JBQUUsY0FBYyxFQUFFO2dCQUFrQyxDQUFDO2dCQUM5REMsWUFBWSxFQUFFO2NBQ2hCLENBQUMsQ0FBQztZQUFBO2NBTkYsSUFBSSxDQUFDVixPQUFPLEdBQUFzRixVQUFBLENBQUE1SCxJQUFBO2NBT1osSUFBSSxDQUFDckMsTUFBTSxDQUFDc0YsS0FBSyw0QkFBQTlDLE1BQUEsQ0FBNEIsSUFBSSxDQUFDNUIsRUFBRSxDQUFFLENBQUM7Y0FDdkQsSUFBSSxDQUFDMkUsSUFBSSxDQUFDLE9BQU8sQ0FBQztjQUFDMEUsVUFBQSxDQUFBckksSUFBQTtjQUFBO1lBQUE7Y0FBQXFJLFVBQUEsQ0FBQXRJLElBQUE7Y0FBQXNJLFVBQUEsQ0FBQTNILEVBQUEsR0FBQTJILFVBQUE7Y0FFbkIsSUFBSSxDQUFDMUUsSUFBSSxDQUFDLE9BQU8sRUFBQTBFLFVBQUEsQ0FBQTNILEVBQUssQ0FBQztjQUFDLE1BQUEySCxVQUFBLENBQUEzSCxFQUFBO1lBQUE7WUFBQTtjQUFBLE9BQUEySCxVQUFBLENBQUFySCxJQUFBO1VBQUE7UUFBQSxHQUFBbUgsU0FBQTtNQUFBLENBRzNCO01BQUEsU0FoQks5SCxLQUFLQSxDQUFBO1FBQUEsT0FBQTZILE1BQUEsQ0FBQS9HLEtBQUEsT0FBQWpFLFNBQUE7TUFBQTtNQUFBLE9BQUxtRCxLQUFLO0lBQUE7SUFrQlg7QUFDRjtBQUNBO0lBRkU7RUFBQTtJQUFBbEQsR0FBQTtJQUFBQyxLQUFBO01BQUEsSUFBQWtMLE9BQUEsR0FBQW5KLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FHQSxTQUFBa0osVUFBQTtRQUFBLElBQUF6RSxLQUFBO1FBQUEsT0FBQTFFLG1CQUFBLENBQUFRLElBQUEsVUFBQTRJLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBMUksSUFBQSxHQUFBMEksVUFBQSxDQUFBekksSUFBQTtZQUFBO2NBQUF5SSxVQUFBLENBQUExSSxJQUFBO2NBRVUrRCxLQUF5QixHQUFHLFNBQVM7Y0FBQTJFLFVBQUEsQ0FBQXpJLElBQUE7Y0FBQSxPQUN0QixJQUFJLENBQUN1SCxtQkFBbUIsQ0FBWTtnQkFDdkRqRSxNQUFNLEVBQUUsT0FBTztnQkFDZlcsSUFBSSxNQUFBckQsTUFBQSxDQUFNLElBQUksQ0FBQzVCLEVBQUUsQ0FBRTtnQkFDbkIxQixJQUFJLEVBQUVpRyxlQUFBLENBQWU7a0JBQUVPLEtBQUssRUFBTEE7Z0JBQU0sQ0FBQyxDQUFDO2dCQUMvQk4sT0FBTyxFQUFFO2tCQUFFLGNBQWMsRUFBRTtnQkFBa0MsQ0FBQztnQkFDOURDLFlBQVksRUFBRTtjQUNoQixDQUFDLENBQUM7WUFBQTtjQU5GLElBQUksQ0FBQ1YsT0FBTyxHQUFBMEYsVUFBQSxDQUFBaEksSUFBQTtjQU9aLElBQUksQ0FBQ3JDLE1BQU0sQ0FBQ3NGLEtBQUssNkJBQUE5QyxNQUFBLENBQTZCLElBQUksQ0FBQzVCLEVBQUUsQ0FBRSxDQUFDO2NBQ3hELElBQUksQ0FBQzJFLElBQUksQ0FBQyxTQUFTLENBQUM7Y0FBQzhFLFVBQUEsQ0FBQXpJLElBQUE7Y0FBQTtZQUFBO2NBQUF5SSxVQUFBLENBQUExSSxJQUFBO2NBQUEwSSxVQUFBLENBQUEvSCxFQUFBLEdBQUErSCxVQUFBO2NBRXJCLElBQUksQ0FBQzlFLElBQUksQ0FBQyxPQUFPLEVBQUE4RSxVQUFBLENBQUEvSCxFQUFLLENBQUM7Y0FBQyxNQUFBK0gsVUFBQSxDQUFBL0gsRUFBQTtZQUFBO1lBQUE7Y0FBQSxPQUFBK0gsVUFBQSxDQUFBekgsSUFBQTtVQUFBO1FBQUEsR0FBQXVILFNBQUE7TUFBQSxDQUczQjtNQUFBLFNBaEJLckUsS0FBS0EsQ0FBQTtRQUFBLE9BQUFvRSxPQUFBLENBQUFuSCxLQUFBLE9BQUFqRSxTQUFBO01BQUE7TUFBQSxPQUFMZ0gsS0FBSztJQUFBO0lBa0JYO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFiRTtFQUFBO0lBQUEvRyxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBc0wsTUFBQSxHQUFBdkosaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQWNBLFNBQUFzSixVQUFBO1FBQUEsSUFBQUMsVUFBQSxFQUFBQyxVQUFBO1FBQUEsSUFBQXRFLFFBQUE7VUFBQUMsT0FBQTtVQUFBakksS0FBQTtVQUFBa0ksU0FBQTtVQUFBQyxPQUFBO1VBQUFDLEdBQUE7VUFBQUMsWUFBQTtVQUFBa0UsT0FBQSxHQUFBNUwsU0FBQTtRQUFBLE9BQUFrQyxtQkFBQSxDQUFBUSxJQUFBLFVBQUFtSixXQUFBQyxVQUFBO1VBQUEsa0JBQUFBLFVBQUEsQ0FBQWpKLElBQUEsR0FBQWlKLFVBQUEsQ0FBQWhKLElBQUE7WUFBQTtjQUNFdUUsUUFBZ0IsR0FBQXVFLE9BQUEsQ0FBQWhLLE1BQUEsUUFBQWdLLE9BQUEsUUFBQS9KLFNBQUEsR0FBQStKLE9BQUEsTUFBRyxJQUFJLENBQUNuSyxjQUFjLENBQUNZLFlBQVk7Y0FDbkRpRixPQUFlLEdBQUFzRSxPQUFBLENBQUFoSyxNQUFBLFFBQUFnSyxPQUFBLFFBQUEvSixTQUFBLEdBQUErSixPQUFBLE1BQUcsSUFBSSxDQUFDbkssY0FBYyxDQUFDYSxXQUFXO2NBRTNDakQsS0FBSyxHQUFHLElBQUksQ0FBQ3lDLEVBQUU7Y0FDZnlGLFNBQVMsR0FBR08sU0FBQSxDQUFTLENBQUM7Y0FDdEJOLE9BQU8sR0FBR0QsU0FBUyxHQUFHRCxPQUFPO2NBQUEsTUFFL0JBLE9BQU8sS0FBSyxDQUFDO2dCQUFBd0UsVUFBQSxDQUFBaEosSUFBQTtnQkFBQTtjQUFBO2NBQUEsTUFDVCxJQUFJNUQsc0JBQXNCLHdEQUFBd0UsTUFBQSxDQUN5QnJFLEtBQUssR0FDNURBLEtBQ0YsQ0FBQztZQUFBO2NBR0gsSUFBSSxDQUFDNkIsTUFBTSxDQUFDc0YsS0FBSyxDQUFDLDhCQUE4QixDQUFDO2NBQ2pELElBQUksQ0FBQ3RGLE1BQU0sQ0FBQ3NGLEtBQUssQ0FBQXVCLHVCQUFBLENBQUEyRCxVQUFBLCtCQUFBaEksTUFBQSxDQUNhNEQsT0FBTyxzQkFBQTFHLElBQUEsQ0FBQThLLFVBQUEsRUFBa0JyRSxRQUFRLFFBQy9ELENBQUM7WUFBQztjQUFBLE1BRUtHLE9BQU8sR0FBR00sU0FBQSxDQUFTLENBQUM7Z0JBQUFnRSxVQUFBLENBQUFoSixJQUFBO2dCQUFBO2NBQUE7Y0FBQWdKLFVBQUEsQ0FBQWpKLElBQUE7Y0FBQWlKLFVBQUEsQ0FBQWhKLElBQUE7Y0FBQSxPQUVMLElBQUksQ0FBQ2tGLEtBQUssQ0FBQyxDQUFDO1lBQUE7Y0FBeEJQLEdBQUcsR0FBQXFFLFVBQUEsQ0FBQXZJLElBQUE7Y0FBQXVJLFVBQUEsQ0FBQXRJLEVBQUEsR0FDRGlFLEdBQUcsQ0FBQ2IsS0FBSztjQUFBa0YsVUFBQSxDQUFBaEosSUFBQSxHQUFBZ0osVUFBQSxDQUFBdEksRUFBQSxLQUNWLE1BQU0sUUFBQXNJLFVBQUEsQ0FBQXRJLEVBQUEsS0FJTixTQUFTLFFBQUFzSSxVQUFBLENBQUF0SSxFQUFBLEtBRVQsZ0JBQWdCLFFBQUFzSSxVQUFBLENBQUF0SSxFQUFBLEtBQ2hCLFlBQVksUUFBQXNJLFVBQUEsQ0FBQXRJLEVBQUEsS0FJWixRQUFRLFFBQUFzSSxVQUFBLENBQUF0SSxFQUFBLEtBS1IsYUFBYTtjQUFBO1lBQUE7Y0FBQSxNQWZWLElBQUkzRCxLQUFLLENBQ2Isa0dBQ0YsQ0FBQztZQUFBO2NBQUEsTUFFSyxJQUFJQSxLQUFLLENBQUMsc0JBQXNCLENBQUM7WUFBQTtjQUd2QyxJQUFJLENBQUM0RyxJQUFJLENBQUMsWUFBWSxFQUFFZ0IsR0FBRyxDQUFDO2NBQUNxRSxVQUFBLENBQUFoSixJQUFBO2NBQUEsT0FDdkJtRixLQUFLLENBQUNaLFFBQVEsQ0FBQztZQUFBO2NBQUEsT0FBQXlFLFVBQUEsQ0FBQXhJLE1BQUE7WUFBQTtjQUdyQixJQUFJLENBQUNwQyxNQUFNLENBQUNzRixLQUFLLENBQUNpQixHQUFHLENBQUM7Y0FBQyxNQUNqQixJQUFJNUgsS0FBSywwQ0FBQTZELE1BQUEsQ0FDNEIrRCxHQUFHLENBQUNzRSxZQUFZLENBQzNELENBQUM7WUFBQTtjQUVELElBQUksQ0FBQzdLLE1BQU0sQ0FBQ3NGLEtBQUssUUFBQTlDLE1BQUEsQ0FBUSxJQUFJLENBQUM1QixFQUFFLGlDQUE4QixDQUFDO2NBQy9ELElBQUksQ0FBQzJFLElBQUksQ0FBQyxhQUFhLEVBQUVnQixHQUFHLENBQUM7Y0FBQyxPQUFBcUUsVUFBQSxDQUFBeEksTUFBQTtZQUFBO2NBQUF3SSxVQUFBLENBQUFoSixJQUFBO2NBQUE7WUFBQTtjQUFBZ0osVUFBQSxDQUFBakosSUFBQTtjQUFBaUosVUFBQSxDQUFBNUQsRUFBQSxHQUFBNEQsVUFBQTtjQUlsQyxJQUFJLENBQUNyRixJQUFJLENBQUMsT0FBTyxFQUFBcUYsVUFBQSxDQUFBNUQsRUFBSyxDQUFDO2NBQUMsTUFBQTRELFVBQUEsQ0FBQTVELEVBQUE7WUFBQTtjQUFBNEQsVUFBQSxDQUFBaEosSUFBQTtjQUFBO1lBQUE7Y0FLdEI0RSxZQUFZLEdBQUcsSUFBSXhJLHNCQUFzQixDQUFBNkksdUJBQUEsQ0FBQTRELFVBQUEsOEJBQUFqSSxNQUFBLENBQ2xCNEQsT0FBTyxvQkFBQTFHLElBQUEsQ0FBQStLLFVBQUEsRUFBZ0J0TSxLQUFLLEdBQ3ZEQSxLQUNGLENBQUM7Y0FDRCxJQUFJLENBQUNvSCxJQUFJLENBQUMsT0FBTyxFQUFFaUIsWUFBWSxDQUFDO2NBQUMsTUFDM0JBLFlBQVk7WUFBQTtZQUFBO2NBQUEsT0FBQW9FLFVBQUEsQ0FBQWhJLElBQUE7VUFBQTtRQUFBLEdBQUEySCxTQUFBO01BQUEsQ0FDbkI7TUFBQSxTQXpES3JJLElBQUlBLENBQUE7UUFBQSxPQUFBb0ksTUFBQSxDQUFBdkgsS0FBQSxPQUFBakUsU0FBQTtNQUFBO01BQUEsT0FBSm9ELElBQUk7SUFBQTtJQTJEVjtBQUNGO0FBQ0E7SUFGRTtFQUFBO0lBQUFuRCxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBOEwsT0FBQSxHQUFBL0osaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUdBLFNBQUE4SixVQUFBO1FBQUEsSUFBQXBHLE9BQUE7UUFBQSxPQUFBM0QsbUJBQUEsQ0FBQVEsSUFBQSxVQUFBd0osV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUF0SixJQUFBLEdBQUFzSixVQUFBLENBQUFySixJQUFBO1lBQUE7Y0FBQXFKLFVBQUEsQ0FBQXRKLElBQUE7Y0FBQXNKLFVBQUEsQ0FBQXJKLElBQUE7Y0FBQSxPQUUwQixJQUFJLENBQUN1SCxtQkFBbUIsQ0FBWTtnQkFDeERqRSxNQUFNLEVBQUUsS0FBSztnQkFDYlcsSUFBSSxNQUFBckQsTUFBQSxDQUFNLElBQUksQ0FBQzVCLEVBQUUsQ0FBRTtnQkFDbkJ5RSxZQUFZLEVBQUU7Y0FDaEIsQ0FBQyxDQUFDO1lBQUE7Y0FKSVYsT0FBTyxHQUFBc0csVUFBQSxDQUFBNUksSUFBQTtjQUtiLElBQUksQ0FBQ3NDLE9BQU8sR0FBR0EsT0FBTztjQUFDLE9BQUFzRyxVQUFBLENBQUE3SSxNQUFBLFdBQ2hCdUMsT0FBTztZQUFBO2NBQUFzRyxVQUFBLENBQUF0SixJQUFBO2NBQUFzSixVQUFBLENBQUEzSSxFQUFBLEdBQUEySSxVQUFBO2NBRWQsSUFBSSxDQUFDMUYsSUFBSSxDQUFDLE9BQU8sRUFBQTBGLFVBQUEsQ0FBQTNJLEVBQUssQ0FBQztjQUFDLE1BQUEySSxVQUFBLENBQUEzSSxFQUFBO1lBQUE7WUFBQTtjQUFBLE9BQUEySSxVQUFBLENBQUFySSxJQUFBO1VBQUE7UUFBQSxHQUFBbUksU0FBQTtNQUFBLENBRzNCO01BQUEsU0FiS2pFLEtBQUtBLENBQUE7UUFBQSxPQUFBZ0UsT0FBQSxDQUFBL0gsS0FBQSxPQUFBakUsU0FBQTtNQUFBO01BQUEsT0FBTGdJLEtBQUs7SUFBQTtJQWVYO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQUxFO0VBQUE7SUFBQS9ILEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFrTSxjQUFBLEdBQUFuSyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBTUEsU0FBQWtLLFVBQUE7UUFBQSxJQUFBQyxrQkFBQSxFQUFBQyxtQkFBQSxFQUFBQyxpQkFBQSxFQUFBQyxhQUFBLEVBQUFDLGtCQUFBO1FBQUEsT0FBQXhLLG1CQUFBLENBQUFRLElBQUEsVUFBQWlLLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBL0osSUFBQSxHQUFBK0osVUFBQSxDQUFBOUosSUFBQTtZQUFBO2NBQUE4SixVQUFBLENBQUE5SixJQUFBO2NBQUEsT0FLWStKLFFBQUEsQ0FBUUMsR0FBRyxDQUFDLENBQ3BCLElBQUksQ0FBQ0Msb0JBQW9CLENBQUMsQ0FBQyxFQUMzQixJQUFJLENBQUNDLGdCQUFnQixDQUFDLENBQUMsRUFDdkIsSUFBSSxDQUFDQyxxQkFBcUIsQ0FBQyxDQUFDLENBQzdCLENBQUM7WUFBQTtjQUFBWCxrQkFBQSxHQUFBTSxVQUFBLENBQUFySixJQUFBO2NBQUFnSixtQkFBQSxHQUFBVyxjQUFBLENBQUFaLGtCQUFBO2NBUEFFLGlCQUFpQixHQUFBRCxtQkFBQTtjQUNqQkUsYUFBYSxHQUFBRixtQkFBQTtjQUNiRyxrQkFBa0IsR0FBQUgsbUJBQUE7Y0FBQSxPQUFBSyxVQUFBLENBQUF0SixNQUFBLFdBTWI7Z0JBQUVrSixpQkFBaUIsRUFBakJBLGlCQUFpQjtnQkFBRUMsYUFBYSxFQUFiQSxhQUFhO2dCQUFFQyxrQkFBa0IsRUFBbEJBO2NBQW1CLENBQUM7WUFBQTtZQUFBO2NBQUEsT0FBQUUsVUFBQSxDQUFBOUksSUFBQTtVQUFBO1FBQUEsR0FBQXVJLFNBQUE7TUFBQSxDQUNoRTtNQUFBLFNBWFloSixhQUFhQSxDQUFBO1FBQUEsT0FBQStJLGNBQUEsQ0FBQW5JLEtBQUEsT0FBQWpFLFNBQUE7TUFBQTtNQUFBLE9BQWJxRCxhQUFhO0lBQUE7SUFhMUI7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFORTtFQUFBO0lBQUFwRCxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBaU4scUJBQUEsR0FBQWxMLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FnQkEsU0FBQWlMLFVBQTJCQyxHQUFhO1FBQUEsSUFBQUMsT0FBQSxFQUFBQyxPQUFBO1FBQUEsT0FBQXJMLG1CQUFBLENBQUFRLElBQUEsVUFBQThLLFdBQUFDLFVBQUE7VUFBQSxrQkFBQUEsVUFBQSxDQUFBNUssSUFBQSxHQUFBNEssVUFBQSxDQUFBM0ssSUFBQTtZQUFBO2NBQ2hDd0ssT0FBb0IsR0FBRztnQkFDM0JsSCxNQUFNLEVBQUUsS0FBSztnQkFDYlcsSUFBSSxNQUFBckQsTUFBQSxDQUFNLElBQUksQ0FBQzVCLEVBQUU7Y0FDbkIsQ0FBQztjQUFBLEtBRUd1TCxHQUFHO2dCQUFBSSxVQUFBLENBQUEzSyxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxPQUFBMkssVUFBQSxDQUFBbkssTUFBQSxXQUNFLElBQUksQ0FBQytHLG1CQUFtQixDQUFBTixhQUFBLENBQUFBLGFBQUEsS0FDMUJ1RCxPQUFPO2dCQUNWL0csWUFBWSxFQUFFO2NBQVksRUFDM0IsQ0FBQztZQUFBO2NBQUEsS0FHQSxJQUFJLENBQUNtSCx3QkFBd0I7Z0JBQUFELFVBQUEsQ0FBQTNLLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE9BQUEySyxVQUFBLENBQUFuSyxNQUFBLFdBQ3hCLElBQUksQ0FBQ29LLHdCQUF3QjtZQUFBO2NBQUFELFVBQUEsQ0FBQTNLLElBQUE7Y0FBQSxPQUdoQixJQUFJLENBQUN1SCxtQkFBbUIsQ0FFNUM7Z0JBQ0FqRSxNQUFNLEVBQUUsS0FBSztnQkFDYlcsSUFBSSxNQUFBckQsTUFBQSxDQUFNLElBQUksQ0FBQzVCLEVBQUUsdUJBQW9CO2dCQUNyQ3lFLFlBQVksRUFBRTtjQUNoQixDQUFDLENBQUM7WUFBQTtjQU5JZ0gsT0FBTyxHQUFBRSxVQUFBLENBQUFsSyxJQUFBO2NBUWIsSUFBSSxDQUFDbUssd0JBQXdCLEdBQUdILE9BQU8sYUFBUEEsT0FBTyxjQUFQQSxPQUFPLEdBQUksRUFBRTtjQUFDLE9BQUFFLFVBQUEsQ0FBQW5LLE1BQUEsV0FFdkMsSUFBSSxDQUFDb0ssd0JBQXdCO1lBQUE7WUFBQTtjQUFBLE9BQUFELFVBQUEsQ0FBQTNKLElBQUE7VUFBQTtRQUFBLEdBQUFzSixTQUFBO01BQUEsQ0FDckM7TUFBQSxTQTVCS0wsb0JBQW9CQSxDQUFBWSxHQUFBO1FBQUEsT0FBQVIscUJBQUEsQ0FBQWxKLEtBQUEsT0FBQWpFLFNBQUE7TUFBQTtNQUFBLE9BQXBCK00sb0JBQW9CO0lBQUE7SUE4QjFCO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBTkU7SUFBQTlNLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUEwTixpQkFBQSxHQUFBM0wsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQWdCQSxTQUFBMEwsVUFBdUJSLEdBQWE7UUFBQSxJQUFBQyxPQUFBLEVBQUFDLE9BQUE7UUFBQSxPQUFBckwsbUJBQUEsQ0FBQVEsSUFBQSxVQUFBb0wsV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUFsTCxJQUFBLEdBQUFrTCxVQUFBLENBQUFqTCxJQUFBO1lBQUE7Y0FDNUJ3SyxPQUFvQixHQUFHO2dCQUMzQmxILE1BQU0sRUFBRSxLQUFLO2dCQUNiVyxJQUFJLE1BQUFyRCxNQUFBLENBQU0sSUFBSSxDQUFDNUIsRUFBRTtjQUNuQixDQUFDO2NBQUEsS0FFR3VMLEdBQUc7Z0JBQUFVLFVBQUEsQ0FBQWpMLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE9BQUFpTCxVQUFBLENBQUF6SyxNQUFBLFdBQ0UsSUFBSSxDQUFDK0csbUJBQW1CLENBQUFOLGFBQUEsQ0FBQUEsYUFBQSxLQUMxQnVELE9BQU87Z0JBQ1YvRyxZQUFZLEVBQUU7Y0FBWSxFQUMzQixDQUFDO1lBQUE7Y0FBQSxLQUdBLElBQUksQ0FBQ3lILG9CQUFvQjtnQkFBQUQsVUFBQSxDQUFBakwsSUFBQTtnQkFBQTtjQUFBO2NBQUEsT0FBQWlMLFVBQUEsQ0FBQXpLLE1BQUEsV0FDcEIsSUFBSSxDQUFDMEssb0JBQW9CO1lBQUE7Y0FBQUQsVUFBQSxDQUFBakwsSUFBQTtjQUFBLE9BR1osSUFBSSxDQUFDdUgsbUJBQW1CLENBQUFOLGFBQUEsQ0FBQUEsYUFBQSxLQUd6Q3VELE9BQU87Z0JBQ1YvRyxZQUFZLEVBQUU7Y0FBVSxFQUN6QixDQUFDO1lBQUE7Y0FMSWdILE9BQU8sR0FBQVEsVUFBQSxDQUFBeEssSUFBQTtjQU9iLElBQUksQ0FBQ3lLLG9CQUFvQixHQUFHVCxPQUFPLGFBQVBBLE9BQU8sY0FBUEEsT0FBTyxHQUFJLEVBQUU7Y0FBQyxPQUFBUSxVQUFBLENBQUF6SyxNQUFBLFdBRW5DLElBQUksQ0FBQzBLLG9CQUFvQjtZQUFBO1lBQUE7Y0FBQSxPQUFBRCxVQUFBLENBQUFqSyxJQUFBO1VBQUE7UUFBQSxHQUFBK0osU0FBQTtNQUFBLENBQ2pDO01BQUEsU0EzQktiLGdCQUFnQkEsQ0FBQWlCLEdBQUE7UUFBQSxPQUFBTCxpQkFBQSxDQUFBM0osS0FBQSxPQUFBakUsU0FBQTtNQUFBO01BQUEsT0FBaEJnTixnQkFBZ0I7SUFBQTtJQTZCdEI7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBWEU7SUFBQS9NLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFnTyxzQkFBQSxHQUFBak0saUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQTBCQSxTQUFBZ00sVUFBNEJkLEdBQWE7UUFBQSxJQUFBQyxPQUFBLEVBQUFDLE9BQUE7UUFBQSxPQUFBckwsbUJBQUEsQ0FBQVEsSUFBQSxVQUFBMEwsV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUF4TCxJQUFBLEdBQUF3TCxVQUFBLENBQUF2TCxJQUFBO1lBQUE7Y0FDakN3SyxPQUFvQixHQUFHO2dCQUMzQmxILE1BQU0sRUFBRSxLQUFLO2dCQUNiVyxJQUFJLE1BQUFyRCxNQUFBLENBQU0sSUFBSSxDQUFDNUIsRUFBRTtjQUNuQixDQUFDO2NBQUEsS0FFR3VMLEdBQUc7Z0JBQUFnQixVQUFBLENBQUF2TCxJQUFBO2dCQUFBO2NBQUE7Y0FBQSxPQUFBdUwsVUFBQSxDQUFBL0ssTUFBQSxXQUNFLElBQUksQ0FBQytHLG1CQUFtQixDQUFBTixhQUFBLENBQUFBLGFBQUEsS0FDMUJ1RCxPQUFPO2dCQUNWL0csWUFBWSxFQUFFO2NBQVksRUFDM0IsQ0FBQztZQUFBO2NBQUEsS0FHQSxJQUFJLENBQUMrSCx5QkFBeUI7Z0JBQUFELFVBQUEsQ0FBQXZMLElBQUE7Z0JBQUE7Y0FBQTtjQUFBLE9BQUF1TCxVQUFBLENBQUEvSyxNQUFBLFdBQ3pCLElBQUksQ0FBQ2dMLHlCQUF5QjtZQUFBO2NBQUFELFVBQUEsQ0FBQXZMLElBQUE7Y0FBQSxPQUdqQixJQUFJLENBQUN1SCxtQkFBbUIsQ0FBQU4sYUFBQSxDQUFBQSxhQUFBLEtBR3pDdUQsT0FBTztnQkFDVi9HLFlBQVksRUFBRTtjQUFVLEVBQ3pCLENBQUM7WUFBQTtjQUxJZ0gsT0FBTyxHQUFBYyxVQUFBLENBQUE5SyxJQUFBO2NBT2IsSUFBSSxDQUFDK0sseUJBQXlCLEdBQUdmLE9BQU8sYUFBUEEsT0FBTyxjQUFQQSxPQUFPLEdBQUksRUFBRTtjQUFDLE9BQUFjLFVBQUEsQ0FBQS9LLE1BQUEsV0FFeEMsSUFBSSxDQUFDZ0wseUJBQXlCO1lBQUE7WUFBQTtjQUFBLE9BQUFELFVBQUEsQ0FBQXZLLElBQUE7VUFBQTtRQUFBLEdBQUFxSyxTQUFBO01BQUEsQ0FDdEM7TUFBQSxTQTNCS2xCLHFCQUFxQkEsQ0FBQXNCLEdBQUE7UUFBQSxPQUFBTCxzQkFBQSxDQUFBakssS0FBQSxPQUFBakUsU0FBQTtNQUFBO01BQUEsT0FBckJpTixxQkFBcUI7SUFBQTtJQTZCM0I7QUFDRjtBQUNBO0VBRkU7SUFBQWhOLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFzTyxRQUFBLEdBQUF2TSxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBR0EsU0FBQXNNLFVBQUE7UUFBQSxPQUFBdk0sbUJBQUEsQ0FBQVEsSUFBQSxVQUFBZ00sV0FBQUMsVUFBQTtVQUFBLGtCQUFBQSxVQUFBLENBQUE5TCxJQUFBLEdBQUE4TCxVQUFBLENBQUE3TCxJQUFBO1lBQUE7Y0FBQSxPQUFBNkwsVUFBQSxDQUFBckwsTUFBQSxXQUNTLElBQUksQ0FBQytHLG1CQUFtQixDQUFPO2dCQUNwQ2pFLE1BQU0sRUFBRSxRQUFRO2dCQUNoQlcsSUFBSSxNQUFBckQsTUFBQSxDQUFNLElBQUksQ0FBQzVCLEVBQUU7Y0FDbkIsQ0FBQyxDQUFDO1lBQUE7WUFBQTtjQUFBLE9BQUE2TSxVQUFBLENBQUE3SyxJQUFBO1VBQUE7UUFBQSxHQUFBMkssU0FBQTtNQUFBLENBQ0g7TUFBQSxTQUxLOUssT0FBTUEsQ0FBQTtRQUFBLE9BQUE2SyxRQUFBLENBQUF2SyxLQUFBLE9BQUFqRSxTQUFBO01BQUE7TUFBQSxPQUFOMkQsT0FBTTtJQUFBO0VBQUE7SUFBQTFELEdBQUE7SUFBQUMsS0FBQSxFQU9aLFNBQVFtSyxtQkFBbUJBLENBQUlmLE9BQW9CLEVBQUU7TUFDbkQsSUFBUXZDLElBQUksR0FBbUJ1QyxPQUFPLENBQTlCdkMsSUFBSTtRQUFFUixZQUFZLEdBQUsrQyxPQUFPLENBQXhCL0MsWUFBWTtNQUMxQixJQUFNaUQsUUFBUSxzQkFBQTlGLE1BQUEsQ0FBc0IsSUFBSSxDQUFDMUMsVUFBVSxDQUFDeUksT0FBTyxpQkFBYztNQUV6RSxJQUFNQyxHQUFHLEdBQUcsSUFBQUMsSUFBQSxDQUNWNUMsSUFBSSxHQUFHeUMsUUFBUSxHQUFHekMsSUFBSSxHQUFHeUMsUUFBUSxFQUNqQyxJQUFJLENBQUN4SSxVQUFVLENBQUM0SSxXQUNsQixDQUFDLENBQUNDLFFBQVEsQ0FBQyxDQUFDO01BRVosT0FBTyxJQUFJL0osU0FBUyxDQUFDLElBQUksQ0FBQ2tCLFVBQVUsRUFBRTtRQUFFdUYsWUFBWSxFQUFaQTtNQUFhLENBQUMsQ0FBQyxDQUFDK0MsT0FBTyxDQUFBUyxhQUFBLENBQUFBLGFBQUEsS0FDMURULE9BQU87UUFDVkksR0FBRyxFQUFIQTtNQUFHLEVBQ0osQ0FBQztJQUNKO0VBQUM7QUFBQSxFQXphZ0RqTCxZQUFZO0FBMGE5RCxJQUVLMEwsU0FBUywwQkFBQXlFLFNBQUE7RUFPYjtBQUNGO0FBQ0E7RUFDRSxTQUFBekUsVUFBWTdJLE9BQWtDLEVBQUU7SUFBQSxJQUFBdU4sTUFBQTtJQUFBdFAsZUFBQSxPQUFBNEssU0FBQTtJQUM5QzBFLE1BQUEsR0FBQXJQLFVBQUEsT0FBQTJLLFNBQUEsR0FBTTtNQUFFMkUsVUFBVSxFQUFFO0lBQUssQ0FBQztJQUUxQixJQUFNMUUsYUFBYSxHQUFHOUksT0FBTyxDQUFDOEksYUFBYTtJQUUzQ3lFLE1BQUEsQ0FBS25OLEdBQUcsR0FBR0osT0FBTyxDQUFDSSxHQUFHO0lBQ3RCbU4sTUFBQSxDQUFLRSxZQUFZLEdBQUcsSUFBSXBRLFlBQVksQ0FBQyxDQUFDO0lBQ3RDa1EsTUFBQSxDQUFLRyxjQUFjLEdBQUcsSUFBSXBRLFFBQVEsQ0FBQyxDQUFDO0lBRXBDLElBQU1xUSxnQkFBZ0IsR0FBRztNQUFFQyxTQUFTLEVBQUU7SUFBTyxDQUFDO0lBQzlDLElBQU1DLGdCQUFnQixHQUFHTixNQUFBLENBQUtFLFlBQVksQ0FBQy9KLE1BQU0sQ0FBQyxLQUFLLEVBQUVpSyxnQkFBZ0IsQ0FBQztJQUMxRSxJQUFNRyxrQkFBa0IsR0FBR1AsTUFBQSxDQUFLRyxjQUFjLENBQUNoSyxNQUFNLENBQ25ELEtBQUssRUFDTGlLLGdCQUNGLENBQUM7SUFFREosTUFBQSxDQUFLdEssVUFBVSxHQUFHdkYscUJBQXFCLENBQ3JDbVEsZ0JBQWdCLEVBQ2hCQyxrQkFDRixDQUFDO0lBRURQLE1BQUEsQ0FBS2xKLEVBQUUsQ0FBQyxRQUFRLEVBQUU7TUFBQSxPQUFNa0osTUFBQSxDQUFLRSxZQUFZLENBQUNNLEdBQUcsQ0FBQyxDQUFDO0lBQUEsRUFBQztJQUVoREYsZ0JBQWdCLENBQUNHLElBQUksQ0FBQyxVQUFVLEVBQUUsWUFBTTtNQUN0QyxJQUFJO1FBQ0Y7UUFDQSxJQUFNQyxHQUFHLEdBQUduRixhQUFhLENBQUM7VUFDeEJoRSxNQUFNLEVBQUUsS0FBSztVQUNiVyxJQUFJLE1BQUFyRCxNQUFBLENBQU1tTCxNQUFBLENBQUtuTixHQUFHLENBQUNJLEVBQUUsYUFBVTtVQUMvQndFLE9BQU8sRUFBRTtZQUNQLGNBQWMsRUFBRTtVQUNsQixDQUFDO1VBQ0RDLFlBQVksRUFBRTtRQUNoQixDQUFDLENBQUM7UUFFRnRFLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FBQyxTQUFBcU4sVUFBQTtVQUFBLElBQUEvSCxHQUFBO1VBQUEsT0FBQXZGLG1CQUFBLENBQUFRLElBQUEsVUFBQStNLFdBQUFDLFVBQUE7WUFBQSxrQkFBQUEsVUFBQSxDQUFBN00sSUFBQSxHQUFBNk0sVUFBQSxDQUFBNU0sSUFBQTtjQUFBO2dCQUFBNE0sVUFBQSxDQUFBN00sSUFBQTtnQkFBQTZNLFVBQUEsQ0FBQTVNLElBQUE7Z0JBQUEsT0FFcUJ5TSxHQUFHO2NBQUE7Z0JBQWY5SCxHQUFHLEdBQUFpSSxVQUFBLENBQUFuTSxJQUFBO2dCQUNUc0wsTUFBQSxDQUFLcEksSUFBSSxDQUFDLFVBQVUsRUFBRWdCLEdBQUcsQ0FBQztnQkFBQ2lJLFVBQUEsQ0FBQTVNLElBQUE7Z0JBQUE7Y0FBQTtnQkFBQTRNLFVBQUEsQ0FBQTdNLElBQUE7Z0JBQUE2TSxVQUFBLENBQUFsTSxFQUFBLEdBQUFrTSxVQUFBO2dCQUUzQmIsTUFBQSxDQUFLcEksSUFBSSxDQUFDLE9BQU8sRUFBQWlKLFVBQUEsQ0FBQWxNLEVBQUssQ0FBQztjQUFDO2NBQUE7Z0JBQUEsT0FBQWtNLFVBQUEsQ0FBQTVMLElBQUE7WUFBQTtVQUFBLEdBQUEwTCxTQUFBO1FBQUEsQ0FFM0IsR0FBRSxDQUFDO1FBRUpMLGdCQUFnQixDQUFDL0osSUFBSSxDQUFDbUssR0FBRyxDQUFDdkssTUFBTSxDQUFDLENBQUMsQ0FBQztNQUNyQyxDQUFDLENBQUMsT0FBT3ZDLEdBQUcsRUFBRTtRQUNab00sTUFBQSxDQUFLcEksSUFBSSxDQUFDLE9BQU8sRUFBRWhFLEdBQUcsQ0FBQztNQUN6QjtJQUNGLENBQUMsQ0FBQztJQUFDLE9BQUFvTSxNQUFBO0VBQ0w7RUFBQ25QLFNBQUEsQ0FBQXlLLFNBQUEsRUFBQXlFLFNBQUE7RUFBQSxPQUFBalAsWUFBQSxDQUFBd0ssU0FBQTtJQUFBbEssR0FBQTtJQUFBQyxLQUFBLEVBRUQsU0FBQXlQLE1BQU1BLENBQUNDLE9BQWUsRUFBRUMsR0FBbUIsRUFBRUMsRUFBYyxFQUFFO01BQzNELElBQVFDLEVBQUUsR0FBZ0NILE9BQU8sQ0FBekNHLEVBQUU7UUFBRXBPLElBQUksR0FBMEJpTyxPQUFPLENBQXJDak8sSUFBSTtRQUFFcU8sVUFBVSxHQUFjSixPQUFPLENBQS9CSSxVQUFVO1FBQUtDLElBQUksR0FBQWxOLHdCQUFBLENBQUs2TSxPQUFPLEVBQUFNLFVBQUE7TUFDakQsSUFBSUMsTUFBTTtNQUNWLFFBQVEsSUFBSSxDQUFDek8sR0FBRyxDQUFDb0UsT0FBTyxDQUFDLENBQUMsQ0FBQ2xCLFNBQVM7UUFDbEMsS0FBSyxRQUFRO1VBQ1h1TCxNQUFNLEdBQUdGLElBQUk7VUFDYjtRQUNGLEtBQUssUUFBUTtRQUNiLEtBQUssWUFBWTtVQUNmRSxNQUFNLEdBQUc7WUFBRUosRUFBRSxFQUFGQTtVQUFHLENBQUM7VUFDZjtRQUNGO1VBQ0VJLE1BQU0sR0FBQXBHLGFBQUE7WUFBS2dHLEVBQUUsRUFBRkE7VUFBRSxHQUFLRSxJQUFJLENBQUU7TUFDNUI7TUFDQSxJQUFJLENBQUNsQixZQUFZLENBQUNxQixLQUFLLENBQUNELE1BQU0sRUFBRU4sR0FBRyxFQUFFQyxFQUFFLENBQUM7SUFDMUM7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQTdQLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUE4RSxNQUFNQSxDQUFBLEVBQUc7TUFDUCxPQUFPLElBQUksQ0FBQ1QsVUFBVTtJQUN4Qjs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBdEUsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQTRLLE9BQU9BLENBQUN2SSxLQUFvQyxFQUFFO01BQUEsSUFBQThOLE1BQUE7TUFDNUMsSUFBSSxJQUFJLENBQUNwTCxNQUFNLEVBQUU7UUFDZixNQUFNLElBQUlwRixLQUFLLENBQUMsMENBQTBDLENBQUM7TUFDN0Q7TUFFQSxJQUFJLENBQUNvRixNQUFNLEdBQUcsSUFBQTRILFFBQUEsQ0FBa0IsVUFBQ3lELE9BQU8sRUFBRUMsTUFBTSxFQUFLO1FBQ25ERixNQUFJLENBQUNmLElBQUksQ0FBQyxVQUFVLEVBQUU7VUFBQSxPQUFNZ0IsT0FBTyxDQUFDLENBQUM7UUFBQSxFQUFDO1FBQ3RDRCxNQUFJLENBQUNmLElBQUksQ0FBQyxPQUFPLEVBQUVpQixNQUFNLENBQUM7TUFDNUIsQ0FBQyxDQUFDO01BRUYsSUFBSXRSLEVBQUUsQ0FBQ3VSLFVBQVUsQ0FBQ2pPLEtBQUssQ0FBQyxFQUFFO1FBQ3hCO1FBQ0FBLEtBQUssQ0FBQzZDLElBQUksQ0FBQyxJQUFJLENBQUNiLFVBQVUsQ0FBQztNQUM3QixDQUFDLE1BQU07UUFDTCxJQUFNa00sVUFBVSxHQUFHQyxlQUFlLENBQUNuTyxLQUFLLENBQUM7UUFFekMsSUFBSWxDLGNBQUEsQ0FBY29RLFVBQVUsQ0FBQyxFQUFFO1VBQUEsSUFBQUUsU0FBQSxHQUFBQywwQkFBQSxDQUNSSCxVQUFVO1lBQUFJLEtBQUE7VUFBQTtZQUEvQixLQUFBRixTQUFBLENBQUF4TCxDQUFBLE1BQUEwTCxLQUFBLEdBQUFGLFNBQUEsQ0FBQUcsQ0FBQSxJQUFBQyxJQUFBLEdBQWlDO2NBQUEsSUFBdEJaLE1BQU0sR0FBQVUsS0FBQSxDQUFBM1EsS0FBQTtjQUNmLFNBQUE4USxFQUFBLE1BQUFDLFlBQUEsR0FBa0JDLGFBQUEsQ0FBWWYsTUFBTSxDQUFDLEVBQUFhLEVBQUEsR0FBQUMsWUFBQSxDQUFBclAsTUFBQSxFQUFBb1AsRUFBQSxJQUFFO2dCQUFsQyxJQUFNL1EsR0FBRyxHQUFBZ1IsWUFBQSxDQUFBRCxFQUFBO2dCQUNaLElBQUksT0FBT2IsTUFBTSxDQUFDbFEsR0FBRyxDQUFDLEtBQUssU0FBUyxFQUFFO2tCQUNwQ2tRLE1BQU0sQ0FBQ2xRLEdBQUcsQ0FBQyxHQUFHa1IsTUFBTSxDQUFDaEIsTUFBTSxDQUFDbFEsR0FBRyxDQUFDLENBQUM7Z0JBQ25DO2NBQ0Y7Y0FDQSxJQUFJLENBQUNtUSxLQUFLLENBQUNELE1BQU0sQ0FBQztZQUNwQjtVQUFDLFNBQUExTixHQUFBO1lBQUFrTyxTQUFBLENBQUFTLENBQUEsQ0FBQTNPLEdBQUE7VUFBQTtZQUFBa08sU0FBQSxDQUFBVSxDQUFBO1VBQUE7VUFDRCxJQUFJLENBQUNoQyxHQUFHLENBQUMsQ0FBQztRQUNaLENBQUMsTUFBTSxJQUFJLE9BQU9vQixVQUFVLEtBQUssUUFBUSxFQUFFO1VBQ3pDLElBQUksQ0FBQ2xNLFVBQVUsQ0FBQzZMLEtBQUssQ0FBQ0ssVUFBVSxFQUFFLE1BQU0sQ0FBQztVQUN6QyxJQUFJLENBQUNsTSxVQUFVLENBQUM4SyxHQUFHLENBQUMsQ0FBQztRQUN2QjtNQUNGO01BRUEsT0FBTyxJQUFJO0lBQ2I7RUFBQztBQUFBLEVBekh1QzNRLFFBQVE7QUE0SGxELFNBQVN1SixLQUFLQSxDQUFDcUosRUFBVSxFQUFpQjtFQUN4QyxPQUFPLElBQUF6RSxRQUFBLENBQVksVUFBQ3lELE9BQU87SUFBQSxPQUFLaUIsV0FBQSxDQUFXakIsT0FBTyxFQUFFZ0IsRUFBRSxDQUFDO0VBQUEsRUFBQztBQUMxRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBeFMsY0FBYyxDQUFDLE9BQU8sRUFBRSxVQUFDMEcsSUFBSTtFQUFBLE9BQUssSUFBSXpFLE1BQU0sQ0FBQ3lFLElBQUksQ0FBQztBQUFBLEVBQUM7QUFFbkQsZUFBZXpFLE1BQU0iLCJpZ25vcmVMaXN0IjpbXX0=