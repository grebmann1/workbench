import _typeof from "@babel/runtime-corejs3/helpers/typeof";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
/**
 * @file Manages Salesforce Apex REST endpoint calls
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { registerModule } from '../jsforce';
/**
 * API class for Apex REST endpoint call
 */
export var Apex = /*#__PURE__*/function () {
  /**
   *
   */
  function Apex(conn) {
    _classCallCheck(this, Apex);
    /**
     * Synonym of Apex#delete()
     */
    _defineProperty(this, "del", this.delete);
    this._conn = conn;
  }

  /* @private */
  return _createClass(Apex, [{
    key: "_baseUrl",
    value: function _baseUrl() {
      return "".concat(this._conn.instanceUrl, "/services/apexrest");
    }

    /**
     * @private
     */
  }, {
    key: "_createRequestParams",
    value: function _createRequestParams(method, path, body) {
      var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
      var headers = _typeof(options.headers) === 'object' ? options.headers : {};
      if (!/^(GET|DELETE)$/i.test(method)) {
        headers['content-type'] = 'application/json';
      }
      var params = {
        method: method,
        url: this._baseUrl() + path,
        headers: headers
      };
      if (body) {
        params.body = _JSON$stringify(body);
      }
      return params;
    }

    /**
     * Call Apex REST service in GET request
     */
  }, {
    key: "get",
    value: function get(path, options) {
      return this._conn.request(this._createRequestParams('GET', path, undefined, options));
    }

    /**
     * Call Apex REST service in POST request
     */
  }, {
    key: "post",
    value: function post(path, body, options) {
      var params = this._createRequestParams('POST', path, body, options);
      return this._conn.request(params);
    }

    /**
     * Call Apex REST service in PUT request
     */
  }, {
    key: "put",
    value: function put(path, body, options) {
      var params = this._createRequestParams('PUT', path, body, options);
      return this._conn.request(params);
    }

    /**
     * Call Apex REST service in PATCH request
     */
  }, {
    key: "patch",
    value: function patch(path, body, options) {
      var params = this._createRequestParams('PATCH', path, body, options);
      return this._conn.request(params);
    }

    /**
     * Call Apex REST service in DELETE request
     */
  }, {
    key: "delete",
    value: function _delete(path, options) {
      return this._conn.request(this._createRequestParams('DELETE', path, undefined, options));
    }
  }]);
}();

/*--------------------------------------------*/
/*
 * Register hook in connection instantiation for dynamically adding this API module features
 */
registerModule('apex', function (conn) {
  return new Apex(conn);
});
export default Apex;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJyZWdpc3Rlck1vZHVsZSIsIkFwZXgiLCJjb25uIiwiX2NsYXNzQ2FsbENoZWNrIiwiX2RlZmluZVByb3BlcnR5IiwiZGVsZXRlIiwiX2Nvbm4iLCJfY3JlYXRlQ2xhc3MiLCJrZXkiLCJ2YWx1ZSIsIl9iYXNlVXJsIiwiY29uY2F0IiwiaW5zdGFuY2VVcmwiLCJfY3JlYXRlUmVxdWVzdFBhcmFtcyIsIm1ldGhvZCIsInBhdGgiLCJib2R5Iiwib3B0aW9ucyIsImFyZ3VtZW50cyIsImxlbmd0aCIsInVuZGVmaW5lZCIsImhlYWRlcnMiLCJfdHlwZW9mIiwidGVzdCIsInBhcmFtcyIsInVybCIsIl9KU09OJHN0cmluZ2lmeSIsImdldCIsInJlcXVlc3QiLCJwb3N0IiwicHV0IiwicGF0Y2giXSwic291cmNlcyI6WyIuLi8uLi9zcmMvYXBpL2FwZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAZmlsZSBNYW5hZ2VzIFNhbGVzZm9yY2UgQXBleCBSRVNUIGVuZHBvaW50IGNhbGxzXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgcmVnaXN0ZXJNb2R1bGUgfSBmcm9tICcuLi9qc2ZvcmNlJztcbmltcG9ydCBDb25uZWN0aW9uIGZyb20gJy4uL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHsgSHR0cFJlcXVlc3QsIEh0dHBNZXRob2RzLCBTY2hlbWEgfSBmcm9tICcuLi90eXBlcyc7XG5cbi8qKlxuICogQVBJIGNsYXNzIGZvciBBcGV4IFJFU1QgZW5kcG9pbnQgY2FsbFxuICovXG5leHBvcnQgY2xhc3MgQXBleDxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPikge1xuICAgIHRoaXMuX2Nvbm4gPSBjb25uO1xuICB9XG5cbiAgLyogQHByaXZhdGUgKi9cbiAgX2Jhc2VVcmwoKSB7XG4gICAgcmV0dXJuIGAke3RoaXMuX2Nvbm4uaW5zdGFuY2VVcmx9L3NlcnZpY2VzL2FwZXhyZXN0YDtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2NyZWF0ZVJlcXVlc3RQYXJhbXMoXG4gICAgbWV0aG9kOiBIdHRwTWV0aG9kcyxcbiAgICBwYXRoOiBzdHJpbmcsXG4gICAgYm9keT86IE9iamVjdCxcbiAgICBvcHRpb25zOiB7IGhlYWRlcnM/OiBIdHRwUmVxdWVzdFsnaGVhZGVycyddIH0gPSB7fSxcbiAgKTogSHR0cFJlcXVlc3Qge1xuICAgIGNvbnN0IGhlYWRlcnM6IEh0dHBSZXF1ZXN0WydoZWFkZXJzJ10gPVxuICAgICAgdHlwZW9mIG9wdGlvbnMuaGVhZGVycyA9PT0gJ29iamVjdCcgPyBvcHRpb25zLmhlYWRlcnMgOiB7fTtcbiAgICBpZiAoIS9eKEdFVHxERUxFVEUpJC9pLnRlc3QobWV0aG9kKSkge1xuICAgICAgaGVhZGVyc1snY29udGVudC10eXBlJ10gPSAnYXBwbGljYXRpb24vanNvbic7XG4gICAgfVxuICAgIGNvbnN0IHBhcmFtczogSHR0cFJlcXVlc3QgPSB7XG4gICAgICBtZXRob2QsXG4gICAgICB1cmw6IHRoaXMuX2Jhc2VVcmwoKSArIHBhdGgsXG4gICAgICBoZWFkZXJzLFxuICAgIH07XG4gICAgaWYgKGJvZHkpIHtcbiAgICAgIHBhcmFtcy5ib2R5ID0gSlNPTi5zdHJpbmdpZnkoYm9keSk7XG4gICAgfVxuICAgIHJldHVybiBwYXJhbXM7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBBcGV4IFJFU1Qgc2VydmljZSBpbiBHRVQgcmVxdWVzdFxuICAgKi9cbiAgZ2V0PFIgPSB1bmtub3duPihwYXRoOiBzdHJpbmcsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICByZXR1cm4gdGhpcy5fY29ubi5yZXF1ZXN0PFI+KFxuICAgICAgdGhpcy5fY3JlYXRlUmVxdWVzdFBhcmFtcygnR0VUJywgcGF0aCwgdW5kZWZpbmVkLCBvcHRpb25zKSxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgQXBleCBSRVNUIHNlcnZpY2UgaW4gUE9TVCByZXF1ZXN0XG4gICAqL1xuICBwb3N0PFIgPSB1bmtub3duPihwYXRoOiBzdHJpbmcsIGJvZHk/OiBPYmplY3QsIG9wdGlvbnM/OiBPYmplY3QpIHtcbiAgICBjb25zdCBwYXJhbXMgPSB0aGlzLl9jcmVhdGVSZXF1ZXN0UGFyYW1zKCdQT1NUJywgcGF0aCwgYm9keSwgb3B0aW9ucyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSPihwYXJhbXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgQXBleCBSRVNUIHNlcnZpY2UgaW4gUFVUIHJlcXVlc3RcbiAgICovXG4gIHB1dDxSID0gdW5rbm93bj4ocGF0aDogc3RyaW5nLCBib2R5PzogT2JqZWN0LCBvcHRpb25zPzogT2JqZWN0KSB7XG4gICAgY29uc3QgcGFyYW1zID0gdGhpcy5fY3JlYXRlUmVxdWVzdFBhcmFtcygnUFVUJywgcGF0aCwgYm9keSwgb3B0aW9ucyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSPihwYXJhbXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgQXBleCBSRVNUIHNlcnZpY2UgaW4gUEFUQ0ggcmVxdWVzdFxuICAgKi9cbiAgcGF0Y2g8UiA9IHVua25vd24+KHBhdGg6IHN0cmluZywgYm9keT86IE9iamVjdCwgb3B0aW9ucz86IE9iamVjdCkge1xuICAgIGNvbnN0IHBhcmFtcyA9IHRoaXMuX2NyZWF0ZVJlcXVlc3RQYXJhbXMoJ1BBVENIJywgcGF0aCwgYm9keSwgb3B0aW9ucyk7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSPihwYXJhbXMpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgQXBleCBSRVNUIHNlcnZpY2UgaW4gREVMRVRFIHJlcXVlc3RcbiAgICovXG4gIGRlbGV0ZTxSID0gdW5rbm93bj4ocGF0aDogc3RyaW5nLCBvcHRpb25zPzogT2JqZWN0KSB7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm4ucmVxdWVzdDxSPihcbiAgICAgIHRoaXMuX2NyZWF0ZVJlcXVlc3RQYXJhbXMoJ0RFTEVURScsIHBhdGgsIHVuZGVmaW5lZCwgb3B0aW9ucyksXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5vbnltIG9mIEFwZXgjZGVsZXRlKClcbiAgICovXG4gIGRlbCA9IHRoaXMuZGVsZXRlO1xufVxuXG4vKi0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tKi9cbi8qXG4gKiBSZWdpc3RlciBob29rIGluIGNvbm5lY3Rpb24gaW5zdGFudGlhdGlvbiBmb3IgZHluYW1pY2FsbHkgYWRkaW5nIHRoaXMgQVBJIG1vZHVsZSBmZWF0dXJlc1xuICovXG5yZWdpc3Rlck1vZHVsZSgnYXBleCcsIChjb25uKSA9PiBuZXcgQXBleChjb25uKSk7XG5cbmV4cG9ydCBkZWZhdWx0IEFwZXg7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLGNBQWMsUUFBUSxZQUFZO0FBSTNDO0FBQ0E7QUFDQTtBQUNBLFdBQWFDLElBQUk7RUFHZjtBQUNGO0FBQ0E7RUFDRSxTQUFBQSxLQUFZQyxJQUFtQixFQUFFO0lBQUFDLGVBQUEsT0FBQUYsSUFBQTtJQTRFakM7QUFDRjtBQUNBO0lBRkVHLGVBQUEsY0FHTSxJQUFJLENBQUNDLE1BQU07SUE5RWYsSUFBSSxDQUFDQyxLQUFLLEdBQUdKLElBQUk7RUFDbkI7O0VBRUE7RUFBQSxPQUFBSyxZQUFBLENBQUFOLElBQUE7SUFBQU8sR0FBQTtJQUFBQyxLQUFBLEVBQ0EsU0FBQUMsUUFBUUEsQ0FBQSxFQUFHO01BQ1QsVUFBQUMsTUFBQSxDQUFVLElBQUksQ0FBQ0wsS0FBSyxDQUFDTSxXQUFXO0lBQ2xDOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFKLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUFJLG9CQUFvQkEsQ0FDbEJDLE1BQW1CLEVBQ25CQyxJQUFZLEVBQ1pDLElBQWEsRUFFQTtNQUFBLElBRGJDLE9BQTZDLEdBQUFDLFNBQUEsQ0FBQUMsTUFBQSxRQUFBRCxTQUFBLFFBQUFFLFNBQUEsR0FBQUYsU0FBQSxNQUFHLENBQUMsQ0FBQztNQUVsRCxJQUFNRyxPQUErQixHQUNuQ0MsT0FBQSxDQUFPTCxPQUFPLENBQUNJLE9BQU8sTUFBSyxRQUFRLEdBQUdKLE9BQU8sQ0FBQ0ksT0FBTyxHQUFHLENBQUMsQ0FBQztNQUM1RCxJQUFJLENBQUMsaUJBQWlCLENBQUNFLElBQUksQ0FBQ1QsTUFBTSxDQUFDLEVBQUU7UUFDbkNPLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRyxrQkFBa0I7TUFDOUM7TUFDQSxJQUFNRyxNQUFtQixHQUFHO1FBQzFCVixNQUFNLEVBQU5BLE1BQU07UUFDTlcsR0FBRyxFQUFFLElBQUksQ0FBQ2YsUUFBUSxDQUFDLENBQUMsR0FBR0ssSUFBSTtRQUMzQk0sT0FBTyxFQUFQQTtNQUNGLENBQUM7TUFDRCxJQUFJTCxJQUFJLEVBQUU7UUFDUlEsTUFBTSxDQUFDUixJQUFJLEdBQUdVLGVBQUEsQ0FBZVYsSUFBSSxDQUFDO01BQ3BDO01BQ0EsT0FBT1EsTUFBTTtJQUNmOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFoQixHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBa0IsR0FBR0EsQ0FBY1osSUFBWSxFQUFFRSxPQUFnQixFQUFFO01BQy9DLE9BQU8sSUFBSSxDQUFDWCxLQUFLLENBQUNzQixPQUFPLENBQ3ZCLElBQUksQ0FBQ2Ysb0JBQW9CLENBQUMsS0FBSyxFQUFFRSxJQUFJLEVBQUVLLFNBQVMsRUFBRUgsT0FBTyxDQUMzRCxDQUFDO0lBQ0g7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQVQsR0FBQTtJQUFBQyxLQUFBLEVBR0EsU0FBQW9CLElBQUlBLENBQWNkLElBQVksRUFBRUMsSUFBYSxFQUFFQyxPQUFnQixFQUFFO01BQy9ELElBQU1PLE1BQU0sR0FBRyxJQUFJLENBQUNYLG9CQUFvQixDQUFDLE1BQU0sRUFBRUUsSUFBSSxFQUFFQyxJQUFJLEVBQUVDLE9BQU8sQ0FBQztNQUNyRSxPQUFPLElBQUksQ0FBQ1gsS0FBSyxDQUFDc0IsT0FBTyxDQUFJSixNQUFNLENBQUM7SUFDdEM7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQWhCLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUFxQixHQUFHQSxDQUFjZixJQUFZLEVBQUVDLElBQWEsRUFBRUMsT0FBZ0IsRUFBRTtNQUM5RCxJQUFNTyxNQUFNLEdBQUcsSUFBSSxDQUFDWCxvQkFBb0IsQ0FBQyxLQUFLLEVBQUVFLElBQUksRUFBRUMsSUFBSSxFQUFFQyxPQUFPLENBQUM7TUFDcEUsT0FBTyxJQUFJLENBQUNYLEtBQUssQ0FBQ3NCLE9BQU8sQ0FBSUosTUFBTSxDQUFDO0lBQ3RDOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFoQixHQUFBO0lBQUFDLEtBQUEsRUFHQSxTQUFBc0IsS0FBS0EsQ0FBY2hCLElBQVksRUFBRUMsSUFBYSxFQUFFQyxPQUFnQixFQUFFO01BQ2hFLElBQU1PLE1BQU0sR0FBRyxJQUFJLENBQUNYLG9CQUFvQixDQUFDLE9BQU8sRUFBRUUsSUFBSSxFQUFFQyxJQUFJLEVBQUVDLE9BQU8sQ0FBQztNQUN0RSxPQUFPLElBQUksQ0FBQ1gsS0FBSyxDQUFDc0IsT0FBTyxDQUFJSixNQUFNLENBQUM7SUFDdEM7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQWhCLEdBQUE7SUFBQUMsS0FBQSxFQUdBLFNBQUFKLE9BQU1BLENBQWNVLElBQVksRUFBRUUsT0FBZ0IsRUFBRTtNQUNsRCxPQUFPLElBQUksQ0FBQ1gsS0FBSyxDQUFDc0IsT0FBTyxDQUN2QixJQUFJLENBQUNmLG9CQUFvQixDQUFDLFFBQVEsRUFBRUUsSUFBSSxFQUFFSyxTQUFTLEVBQUVILE9BQU8sQ0FDOUQsQ0FBQztJQUNIO0VBQUM7QUFBQTs7QUFRSDtBQUNBO0FBQ0E7QUFDQTtBQUNBakIsY0FBYyxDQUFDLE1BQU0sRUFBRSxVQUFDRSxJQUFJO0VBQUEsT0FBSyxJQUFJRCxJQUFJLENBQUNDLElBQUksQ0FBQztBQUFBLEVBQUM7QUFFaEQsZUFBZUQsSUFBSSIsImlnbm9yZUxpc3QiOltdfQ==