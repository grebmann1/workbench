import "core-js/modules/es.array.push.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.to-string.js";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
var _excluded = ["url", "body"];
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof _Symbol && _getIteratorMethod(r) || r["@@iterator"]; if (!t) { if (_Array$isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { var _context9; if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = _sliceInstanceProperty(_context9 = {}.toString.call(r)).call(_context9, 8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? _Array$from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import "core-js/modules/web.dom-exception.constructor.js";
import "core-js/modules/web.dom-exception.stack.js";
import "core-js/modules/web.dom-exception.to-string-tag.js";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _includesInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/includes";
import _keysInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/keys";
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context7, _context8; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context7 = ownKeys(Object(t), !0)).call(_context7, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context8 = ownKeys(Object(t))).call(_context8, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
import { Readable } from 'stream';
import { fetch, errors, Response, ProxyAgent } from 'undici';
import { createHttpRequestHandlerStreams, executeWithTimeout, isRedirect, performRedirectRequest } from './request-helper';
import { getLogger } from './util/logger';
import is from '@sindresorhus/is';
/**
 *
 */
var defaults = {};

/**
 *
 */
export function setDefaults(defaults_) {
  defaults = defaults_;
}

/**
 *
 */
function startFetchRequest(_x, _x2, _x3, _x4, _x5) {
  return _startFetchRequest.apply(this, arguments);
}
/**
 *
 */
function _startFetchRequest() {
  _startFetchRequest = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(request, options, input, output, emitter) {
    var _options$retry$status, _options$retry, _options$retry$maxRet, _options$retry2, _options$retry$minTim, _options$retry3, _options$retry$timeou, _options$retry4, _options$retry$errorC, _options$retry5, _options$retry$method, _options$retry6, _options$timeout, _context5;
    var counter,
      logger,
      httpProxy,
      followRedirect,
      agent,
      url,
      body,
      rrequest,
      controller,
      retryCount,
      retry420Count,
      retryOpts,
      shouldRetryRequest,
      _fetchWithRetries,
      res,
      fetchTimeout,
      throwableError,
      headers,
      _iterator,
      _step,
      headerName,
      response,
      _args2 = arguments;
    return _regeneratorRuntime.wrap(function _callee2$(_context6) {
      while (1) switch (_context6.prev = _context6.next) {
        case 0:
          counter = _args2.length > 5 && _args2[5] !== undefined ? _args2[5] : 0;
          logger = getLogger('fetch');
          httpProxy = options.httpProxy, followRedirect = options.followRedirect;
          agent = httpProxy ? new ProxyAgent(httpProxy) : undefined;
          url = request.url, body = request.body, rrequest = _objectWithoutProperties(request, _excluded);
          controller = new AbortController();
          retryCount = 0;
          retry420Count = 0;
          retryOpts = {
            statusCodes: (_options$retry$status = (_options$retry = options.retry) === null || _options$retry === void 0 ? void 0 : _options$retry.statusCodes) !== null && _options$retry$status !== void 0 ? _options$retry$status : [420, 429, 500, 502, 503, 504],
            maxRetries: (_options$retry$maxRet = (_options$retry2 = options.retry) === null || _options$retry2 === void 0 ? void 0 : _options$retry2.maxRetries) !== null && _options$retry$maxRet !== void 0 ? _options$retry$maxRet : 5,
            minTimeout: (_options$retry$minTim = (_options$retry3 = options.retry) === null || _options$retry3 === void 0 ? void 0 : _options$retry3.minTimeout) !== null && _options$retry$minTim !== void 0 ? _options$retry$minTim : 500,
            timeoutFactor: (_options$retry$timeou = (_options$retry4 = options.retry) === null || _options$retry4 === void 0 ? void 0 : _options$retry4.timeoutFactor) !== null && _options$retry$timeou !== void 0 ? _options$retry$timeou : 2,
            errorCodes: (_options$retry$errorC = (_options$retry5 = options.retry) === null || _options$retry5 === void 0 ? void 0 : _options$retry5.errorCodes) !== null && _options$retry$errorC !== void 0 ? _options$retry$errorC : ['ECONNRESET', 'ECONNREFUSED', 'ENOTFOUND', 'ENETDOWN', 'ENETUNREACH', 'EHOSTDOWN', 'UND_ERR_SOCKET', 'ETIMEDOUT', 'EPIPE'],
            methods: (_options$retry$method = (_options$retry6 = options.retry) === null || _options$retry6 === void 0 ? void 0 : _options$retry6.methods) !== null && _options$retry$method !== void 0 ? _options$retry$method : ['GET', 'PUT', 'HEAD', 'OPTIONS', 'DELETE']
          };
          shouldRetryRequest = function shouldRetryRequest(maxRetry, resOrErr) {
            var _context;
            if (!_includesInstanceProperty(_context = retryOpts.methods).call(_context, request.method)) return false;
            if (resOrErr instanceof Response) {
              var _context2;
              // REST API status codes: https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/errorcodes.htm
              //
              // Deleted/expired scratch orgs return 420 and causes a long delay on all requests due to the retry with exponential backoff.
              // We still want to retry on 420 (Metadata API requests sometimes return it) so here we'll limit to a maximum of 2 retries.
              if (resOrErr.status === 420) {
                return retry420Count < 2;
              } else if (_includesInstanceProperty(_context2 = retryOpts.statusCodes).call(_context2, resOrErr.status)) {
                if (maxRetry === retryCount) {
                  return false;
                } else {
                  return true;
                }
              }
              return false;
            } else {
              var _context3;
              if (maxRetry === retryCount) return false;

              // If the error is not a TypeError, then it's not an operational error and thus we cannot retry.
              if (!(resOrErr instanceof TypeError)) return false;
              if (is.nodeStream(body) && Readable.isDisturbed(body)) {
                logger.debug('Body of type stream was read, unable to retry request.');
                return false;
              }
              var err = resOrErr;
              var causativeError = err.cause instanceof errors.SocketError ? err.cause.cause : err.cause;
              return !!(causativeError && 'code' in causativeError && causativeError.code && retryOpts !== null && retryOpts !== void 0 && _includesInstanceProperty(_context3 = retryOpts.errorCodes).call(_context3, causativeError.code));
            }
          };
          _fetchWithRetries = /*#__PURE__*/function () {
            var _ref = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
              var maxRetry,
                fetchOpts,
                _res,
                error,
                _args = arguments;
              return _regeneratorRuntime.wrap(function _callee$(_context4) {
                while (1) switch (_context4.prev = _context4.next) {
                  case 0:
                    maxRetry = _args.length > 0 && _args[0] !== undefined ? _args[0] : retryOpts === null || retryOpts === void 0 ? void 0 : retryOpts.maxRetries;
                    fetchOpts = _objectSpread(_objectSpread(_objectSpread({}, rrequest), input && /^(post|put|patch)$/i.test(request.method) ? {
                      body: input
                    } : {}), {}, {
                      duplex: 'half',
                      redirect: 'manual',
                      signal: controller.signal,
                      dispatcher: agent
                    });
                    _context4.prev = 2;
                    _context4.next = 5;
                    return fetch(url, fetchOpts);
                  case 5:
                    _res = _context4.sent;
                    if (!shouldRetryRequest(retryOpts.maxRetries, _res)) {
                      _context4.next = 17;
                      break;
                    }
                    logger.debug("retrying for the ".concat(retryCount + 1, " time"));
                    logger.debug('reason: statusCode match');
                    _context4.next = 11;
                    return sleep(retryCount === 0 ? retryOpts.minTimeout : retryOpts.minTimeout * Math.pow(retryOpts.timeoutFactor, retryCount));
                  case 11:
                    // NOTE: this event is only used by tests and will be removed at any time.
                    // jsforce may switch to node's fetch which doesn't emit this event on retries.
                    emitter.emit('retry', retryCount);
                    retryCount++;
                    if (_res.status === 420) {
                      retry420Count++;
                    }
                    _context4.next = 16;
                    return _fetchWithRetries(maxRetry);
                  case 16:
                    return _context4.abrupt("return", _context4.sent);
                  case 17:
                    return _context4.abrupt("return", _res);
                  case 20:
                    _context4.prev = 20;
                    _context4.t0 = _context4["catch"](2);
                    logger.debug('Request failed');
                    error = _context4.t0; // request was canceled by consumer (AbortController), skip retry and rethrow.
                    if (!(error.name === 'AbortError')) {
                      _context4.next = 26;
                      break;
                    }
                    throw error;
                  case 26:
                    if (!shouldRetryRequest(retryOpts.maxRetries, error)) {
                      _context4.next = 34;
                      break;
                    }
                    logger.debug("retrying for the ".concat(retryCount + 1, " time"));
                    logger.debug("Error: ".concat(_context4.t0.message));
                    _context4.next = 31;
                    return sleep(retryCount === 0 ? retryOpts.minTimeout : retryOpts.minTimeout * Math.pow(retryOpts.timeoutFactor, retryCount));
                  case 31:
                    // NOTE: this event is only used by tests and will be removed at any time.
                    // jsforce may switch to node's fetch which doesn't emit this event on retries.
                    emitter.emit('retry', retryCount);
                    retryCount++;
                    return _context4.abrupt("return", _fetchWithRetries(maxRetry));
                  case 34:
                    logger.debug('Skipping retry...');
                    throw _context4.t0;
                  case 36:
                  case "end":
                    return _context4.stop();
                }
              }, _callee, null, [[2, 20]]);
            }));
            return function fetchWithRetries() {
              return _ref.apply(this, arguments);
            };
          }();
          // Timeout after 30 minutes without a response
          //
          // default timeout is 0 and jsforce consumers can't set this when calling `Connection` methods so we set a long default at the fetch wrapper level.
          fetchTimeout = (_options$timeout = options.timeout) !== null && _options$timeout !== void 0 ? _options$timeout : 1800000;
          _context6.prev = 12;
          _context6.next = 15;
          return executeWithTimeout(_fetchWithRetries, fetchTimeout, function () {
            return controller.abort();
          });
        case 15:
          res = _context6.sent;
          _context6.next = 23;
          break;
        case 18:
          _context6.prev = 18;
          _context6.t0 = _context6["catch"](12);
          if (_context6.t0 instanceof DOMException && _context6.t0.name === 'AbortError') {
            throwableError = new DOMException(_context6.t0.message + ' Request was aborted due to timeout of 30 minutes.', _context6.t0.name);
          } else {
            throwableError = _context6.t0;
          }
          emitter.emit('error', throwableError);
          return _context6.abrupt("return");
        case 23:
          headers = {};
          _iterator = _createForOfIteratorHelper(_keysInstanceProperty(_context5 = res.headers).call(_context5));
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              headerName = _step.value;
              headers[headerName.toLowerCase()] = res.headers.get(headerName);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
          response = {
            statusCode: res.status,
            headers: headers
          };
          if (!(followRedirect && isRedirect(response.statusCode))) {
            _context6.next = 30;
            break;
          }
          try {
            performRedirectRequest(request, response, followRedirect, counter, function (req) {
              return startFetchRequest(req, options, undefined, output, emitter, counter + 1);
            });
          } catch (err) {
            emitter.emit('error', err);
          }
          return _context6.abrupt("return");
        case 30:
          emitter.emit('response', response);
          if (res.body) {
            Readable.fromWeb(res.body).pipe(output);
          } else {
            output.end();
          }
        case 32:
        case "end":
          return _context6.stop();
      }
    }, _callee2, null, [[12, 18]]);
  }));
  return _startFetchRequest.apply(this, arguments);
}
export default function request(req) {
  var options_ = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var options = _objectSpread(_objectSpread({}, defaults), options_);
  var _createHttpRequestHan = createHttpRequestHandlerStreams(req, options),
    input = _createHttpRequestHan.input,
    output = _createHttpRequestHan.output,
    stream = _createHttpRequestHan.stream;
  startFetchRequest(req, options, input, output, stream);
  return stream;
}
var sleep = function sleep(ms) {
  return new _Promise(function (r) {
    return _setTimeout(r, ms);
  });
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJSZWFkYWJsZSIsImZldGNoIiwiZXJyb3JzIiwiUmVzcG9uc2UiLCJQcm94eUFnZW50IiwiY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyIsImV4ZWN1dGVXaXRoVGltZW91dCIsImlzUmVkaXJlY3QiLCJwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0IiwiZ2V0TG9nZ2VyIiwiaXMiLCJkZWZhdWx0cyIsInNldERlZmF1bHRzIiwiZGVmYXVsdHNfIiwic3RhcnRGZXRjaFJlcXVlc3QiLCJfeCIsIl94MiIsIl94MyIsIl94NCIsIl94NSIsIl9zdGFydEZldGNoUmVxdWVzdCIsImFwcGx5IiwiYXJndW1lbnRzIiwiX2FzeW5jVG9HZW5lcmF0b3IiLCJfcmVnZW5lcmF0b3JSdW50aW1lIiwibWFyayIsIl9jYWxsZWUyIiwicmVxdWVzdCIsIm9wdGlvbnMiLCJpbnB1dCIsIm91dHB1dCIsImVtaXR0ZXIiLCJfb3B0aW9ucyRyZXRyeSRzdGF0dXMiLCJfb3B0aW9ucyRyZXRyeSIsIl9vcHRpb25zJHJldHJ5JG1heFJldCIsIl9vcHRpb25zJHJldHJ5MiIsIl9vcHRpb25zJHJldHJ5JG1pblRpbSIsIl9vcHRpb25zJHJldHJ5MyIsIl9vcHRpb25zJHJldHJ5JHRpbWVvdSIsIl9vcHRpb25zJHJldHJ5NCIsIl9vcHRpb25zJHJldHJ5JGVycm9yQyIsIl9vcHRpb25zJHJldHJ5NSIsIl9vcHRpb25zJHJldHJ5JG1ldGhvZCIsIl9vcHRpb25zJHJldHJ5NiIsIl9vcHRpb25zJHRpbWVvdXQiLCJfY29udGV4dDUiLCJjb3VudGVyIiwibG9nZ2VyIiwiaHR0cFByb3h5IiwiZm9sbG93UmVkaXJlY3QiLCJhZ2VudCIsInVybCIsImJvZHkiLCJycmVxdWVzdCIsImNvbnRyb2xsZXIiLCJyZXRyeUNvdW50IiwicmV0cnk0MjBDb3VudCIsInJldHJ5T3B0cyIsInNob3VsZFJldHJ5UmVxdWVzdCIsIl9mZXRjaFdpdGhSZXRyaWVzIiwicmVzIiwiZmV0Y2hUaW1lb3V0IiwidGhyb3dhYmxlRXJyb3IiLCJoZWFkZXJzIiwiX2l0ZXJhdG9yIiwiX3N0ZXAiLCJoZWFkZXJOYW1lIiwicmVzcG9uc2UiLCJfYXJnczIiLCJ3cmFwIiwiX2NhbGxlZTIkIiwiX2NvbnRleHQ2IiwicHJldiIsIm5leHQiLCJsZW5ndGgiLCJ1bmRlZmluZWQiLCJfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMiLCJfZXhjbHVkZWQiLCJBYm9ydENvbnRyb2xsZXIiLCJzdGF0dXNDb2RlcyIsInJldHJ5IiwibWF4UmV0cmllcyIsIm1pblRpbWVvdXQiLCJ0aW1lb3V0RmFjdG9yIiwiZXJyb3JDb2RlcyIsIm1ldGhvZHMiLCJtYXhSZXRyeSIsInJlc09yRXJyIiwiX2NvbnRleHQiLCJfaW5jbHVkZXNJbnN0YW5jZVByb3BlcnR5IiwiY2FsbCIsIm1ldGhvZCIsIl9jb250ZXh0MiIsInN0YXR1cyIsIl9jb250ZXh0MyIsIlR5cGVFcnJvciIsIm5vZGVTdHJlYW0iLCJpc0Rpc3R1cmJlZCIsImRlYnVnIiwiZXJyIiwiY2F1c2F0aXZlRXJyb3IiLCJjYXVzZSIsIlNvY2tldEVycm9yIiwiY29kZSIsImZldGNoV2l0aFJldHJpZXMiLCJfcmVmIiwiX2NhbGxlZSIsImZldGNoT3B0cyIsIl9yZXMiLCJlcnJvciIsIl9hcmdzIiwiX2NhbGxlZSQiLCJfY29udGV4dDQiLCJfb2JqZWN0U3ByZWFkIiwidGVzdCIsImR1cGxleCIsInJlZGlyZWN0Iiwic2lnbmFsIiwiZGlzcGF0Y2hlciIsInNlbnQiLCJjb25jYXQiLCJzbGVlcCIsIk1hdGgiLCJwb3ciLCJlbWl0IiwiYWJydXB0IiwidDAiLCJuYW1lIiwibWVzc2FnZSIsInN0b3AiLCJ0aW1lb3V0IiwiYWJvcnQiLCJET01FeGNlcHRpb24iLCJfY3JlYXRlRm9yT2ZJdGVyYXRvckhlbHBlciIsIl9rZXlzSW5zdGFuY2VQcm9wZXJ0eSIsInMiLCJuIiwiZG9uZSIsInZhbHVlIiwidG9Mb3dlckNhc2UiLCJnZXQiLCJlIiwiZiIsInN0YXR1c0NvZGUiLCJyZXEiLCJmcm9tV2ViIiwicGlwZSIsImVuZCIsIm9wdGlvbnNfIiwiX2NyZWF0ZUh0dHBSZXF1ZXN0SGFuIiwic3RyZWFtIiwibXMiLCJfUHJvbWlzZSIsInIiLCJfc2V0VGltZW91dCJdLCJzb3VyY2VzIjpbIi4uL3NyYy9yZXF1ZXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gJ2V2ZW50cyc7XG5pbXBvcnQgeyBEdXBsZXgsIFJlYWRhYmxlLCBXcml0YWJsZSB9IGZyb20gJ3N0cmVhbSc7XG5pbXBvcnQge2ZldGNoLCBlcnJvcnMsIFJlc3BvbnNlLCBSZXF1ZXN0SW5pdCwgUHJveHlBZ2VudH0gZnJvbSAndW5kaWNpJztcbmltcG9ydCB7XG4gIGNyZWF0ZUh0dHBSZXF1ZXN0SGFuZGxlclN0cmVhbXMsXG4gIGV4ZWN1dGVXaXRoVGltZW91dCxcbiAgaXNSZWRpcmVjdCxcbiAgcGVyZm9ybVJlZGlyZWN0UmVxdWVzdCxcbn0gZnJvbSAnLi9yZXF1ZXN0LWhlbHBlcic7XG5pbXBvcnQgeyBIdHRwUmVxdWVzdCwgSHR0cFJlcXVlc3RPcHRpb25zIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBnZXRMb2dnZXIgfSBmcm9tICcuL3V0aWwvbG9nZ2VyJztcbmltcG9ydCBpcyBmcm9tICdAc2luZHJlc29yaHVzL2lzJztcblxudHlwZSBDb2RlZEVycm9yID0ge1xuICBjb2RlPzogc3RyaW5nO1xufVxuXG4vKipcbiAqXG4gKi9cbmxldCBkZWZhdWx0czogSHR0cFJlcXVlc3RPcHRpb25zID0ge307XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldERlZmF1bHRzKGRlZmF1bHRzXzogSHR0cFJlcXVlc3RPcHRpb25zKSB7XG4gIGRlZmF1bHRzID0gZGVmYXVsdHNfO1xufVxuXG4vKipcbiAqXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0RmV0Y2hSZXF1ZXN0KFxuICByZXF1ZXN0OiBIdHRwUmVxdWVzdCxcbiAgb3B0aW9uczogSHR0cFJlcXVlc3RPcHRpb25zLFxuICBpbnB1dDogUmVhZGFibGUgfCB1bmRlZmluZWQsXG4gIG91dHB1dDogV3JpdGFibGUsXG4gIGVtaXR0ZXI6IEV2ZW50RW1pdHRlcixcbiAgY291bnRlcjogbnVtYmVyID0gMCxcbikge1xuICBjb25zdCBsb2dnZXIgPSBnZXRMb2dnZXIoJ2ZldGNoJyk7XG4gIGNvbnN0IHsgaHR0cFByb3h5LCBmb2xsb3dSZWRpcmVjdCB9ID0gb3B0aW9ucztcbiAgY29uc3QgYWdlbnQgPSBodHRwUHJveHkgPyBuZXcgUHJveHlBZ2VudChodHRwUHJveHkpIDogdW5kZWZpbmVkO1xuICBjb25zdCB7IHVybCwgYm9keSwgLi4ucnJlcXVlc3QgfSA9IHJlcXVlc3Q7XG4gIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cbiAgbGV0IHJldHJ5Q291bnQgPSAwO1xuICBsZXQgcmV0cnk0MjBDb3VudCA9IDA7XG5cbiAgY29uc3QgcmV0cnlPcHRzOiBSZXF1aXJlZDxIdHRwUmVxdWVzdE9wdGlvbnNbJ3JldHJ5J10+ID0ge1xuICAgIHN0YXR1c0NvZGVzOiBvcHRpb25zLnJldHJ5Py5zdGF0dXNDb2RlcyA/PyBbNDIwLCA0MjksIDUwMCwgNTAyLCA1MDMsIDUwNF0sXG4gICAgbWF4UmV0cmllczogb3B0aW9ucy5yZXRyeT8ubWF4UmV0cmllcyA/PyA1LFxuICAgIG1pblRpbWVvdXQ6IG9wdGlvbnMucmV0cnk/Lm1pblRpbWVvdXQgPz8gNTAwLFxuICAgIHRpbWVvdXRGYWN0b3I6IG9wdGlvbnMucmV0cnk/LnRpbWVvdXRGYWN0b3IgPz8gMixcbiAgICBlcnJvckNvZGVzOiBvcHRpb25zLnJldHJ5Py5lcnJvckNvZGVzID8/IFtcbiAgICAgICdFQ09OTlJFU0VUJyxcbiAgICAgICdFQ09OTlJFRlVTRUQnLFxuICAgICAgJ0VOT1RGT1VORCcsXG4gICAgICAnRU5FVERPV04nLFxuICAgICAgJ0VORVRVTlJFQUNIJyxcbiAgICAgICdFSE9TVERPV04nLFxuICAgICAgJ1VORF9FUlJfU09DS0VUJyxcbiAgICAgICdFVElNRURPVVQnLFxuICAgICAgJ0VQSVBFJyxcbiAgICBdLFxuICAgIG1ldGhvZHM6IG9wdGlvbnMucmV0cnk/Lm1ldGhvZHMgPz8gW1xuICAgICAgJ0dFVCcsXG4gICAgICAnUFVUJyxcbiAgICAgICdIRUFEJyxcbiAgICAgICdPUFRJT05TJyxcbiAgICAgICdERUxFVEUnLFxuICAgIF0sXG4gIH07XG5cbiAgY29uc3Qgc2hvdWxkUmV0cnlSZXF1ZXN0ID0gKFxuICAgIG1heFJldHJ5OiBudW1iZXIsXG4gICAgcmVzT3JFcnI6IFJlc3BvbnNlIHwgRXJyb3IsXG4gICk6IGJvb2xlYW4gPT4ge1xuICAgIGlmICghcmV0cnlPcHRzLm1ldGhvZHMuaW5jbHVkZXMocmVxdWVzdC5tZXRob2QpKSByZXR1cm4gZmFsc2U7XG5cbiAgICBpZiAocmVzT3JFcnIgaW5zdGFuY2VvZiBSZXNwb25zZSkge1xuICAgICAgLy8gUkVTVCBBUEkgc3RhdHVzIGNvZGVzOiBodHRwczovL2RldmVsb3Blci5zYWxlc2ZvcmNlLmNvbS9kb2NzL2F0bGFzLmVuLXVzLmFwaV9yZXN0Lm1ldGEvYXBpX3Jlc3QvZXJyb3Jjb2Rlcy5odG1cbiAgICAgIC8vXG4gICAgICAvLyBEZWxldGVkL2V4cGlyZWQgc2NyYXRjaCBvcmdzIHJldHVybiA0MjAgYW5kIGNhdXNlcyBhIGxvbmcgZGVsYXkgb24gYWxsIHJlcXVlc3RzIGR1ZSB0byB0aGUgcmV0cnkgd2l0aCBleHBvbmVudGlhbCBiYWNrb2ZmLlxuICAgICAgLy8gV2Ugc3RpbGwgd2FudCB0byByZXRyeSBvbiA0MjAgKE1ldGFkYXRhIEFQSSByZXF1ZXN0cyBzb21ldGltZXMgcmV0dXJuIGl0KSBzbyBoZXJlIHdlJ2xsIGxpbWl0IHRvIGEgbWF4aW11bSBvZiAyIHJldHJpZXMuXG4gICAgICBpZiAocmVzT3JFcnIuc3RhdHVzID09PSA0MjApIHtcbiAgICAgICAgcmV0dXJuIHJldHJ5NDIwQ291bnQgPCAyO1xuICAgICAgfSBlbHNlIGlmIChyZXRyeU9wdHMuc3RhdHVzQ29kZXMuaW5jbHVkZXMocmVzT3JFcnIuc3RhdHVzKSkge1xuICAgICAgICBpZiAobWF4UmV0cnkgPT09IHJldHJ5Q291bnQpIHtcbiAgICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAobWF4UmV0cnkgPT09IHJldHJ5Q291bnQpIHJldHVybiBmYWxzZTtcblxuICAgICAgLy8gSWYgdGhlIGVycm9yIGlzIG5vdCBhIFR5cGVFcnJvciwgdGhlbiBpdCdzIG5vdCBhbiBvcGVyYXRpb25hbCBlcnJvciBhbmQgdGh1cyB3ZSBjYW5ub3QgcmV0cnkuXG4gICAgICBpZiAoIShyZXNPckVyciBpbnN0YW5jZW9mIFR5cGVFcnJvcikpIHJldHVybiBmYWxzZTtcblxuICAgICAgaWYgKGlzLm5vZGVTdHJlYW0oYm9keSkgJiYgUmVhZGFibGUuaXNEaXN0dXJiZWQoYm9keSkpIHtcbiAgICAgICAgbG9nZ2VyLmRlYnVnKCdCb2R5IG9mIHR5cGUgc3RyZWFtIHdhcyByZWFkLCB1bmFibGUgdG8gcmV0cnkgcmVxdWVzdC4nKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBlcnI6IFR5cGVFcnJvciA9IHJlc09yRXJyO1xuICAgICAgY29uc3QgY2F1c2F0aXZlRXJyb3I6IENvZGVkRXJyb3IgPSAoZXJyLmNhdXNlIGluc3RhbmNlb2YgZXJyb3JzLlNvY2tldEVycm9yID8gZXJyLmNhdXNlLmNhdXNlIDogZXJyLmNhdXNlKSBhcyBDb2RlZEVycm9yO1xuICAgICAgcmV0dXJuICEhKGNhdXNhdGl2ZUVycm9yICYmICdjb2RlJyBpbiBjYXVzYXRpdmVFcnJvciAmJiBjYXVzYXRpdmVFcnJvci5jb2RlICYmIHJldHJ5T3B0cz8uZXJyb3JDb2Rlcy5pbmNsdWRlcyhjYXVzYXRpdmVFcnJvci5jb2RlKSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGZldGNoV2l0aFJldHJpZXMgPSBhc3luYyAoXG4gICAgbWF4UmV0cnkgPSByZXRyeU9wdHM/Lm1heFJldHJpZXMsXG4gICk6IFByb21pc2U8UmVzcG9uc2U+ID0+IHtcbiAgICBjb25zdCBmZXRjaE9wdHM6IFJlcXVlc3RJbml0ID0ge1xuICAgICAgLi4ucnJlcXVlc3QsXG4gICAgICAuLi4oaW5wdXQgJiYgL14ocG9zdHxwdXR8cGF0Y2gpJC9pLnRlc3QocmVxdWVzdC5tZXRob2QpXG4gICAgICAgID8geyBib2R5OiBpbnB1dCB9XG4gICAgICAgIDoge30pLFxuICAgICAgZHVwbGV4OiAnaGFsZicsXG4gICAgICByZWRpcmVjdDogJ21hbnVhbCcsXG4gICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgZGlzcGF0Y2hlcjogYWdlbnQsXG4gICAgfTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIGZldGNoT3B0cyk7XG4gICAgICBpZiAoc2hvdWxkUmV0cnlSZXF1ZXN0KHJldHJ5T3B0cy5tYXhSZXRyaWVzLCByZXMpKSB7XG4gICAgICAgIGxvZ2dlci5kZWJ1ZyhgcmV0cnlpbmcgZm9yIHRoZSAke3JldHJ5Q291bnQgKyAxfSB0aW1lYCk7XG4gICAgICAgIGxvZ2dlci5kZWJ1ZygncmVhc29uOiBzdGF0dXNDb2RlIG1hdGNoJyk7XG5cbiAgICAgICAgYXdhaXQgc2xlZXAoXG4gICAgICAgICAgcmV0cnlDb3VudCA9PT0gMFxuICAgICAgICAgICAgPyByZXRyeU9wdHMubWluVGltZW91dFxuICAgICAgICAgICAgOiByZXRyeU9wdHMubWluVGltZW91dCAqIHJldHJ5T3B0cy50aW1lb3V0RmFjdG9yICoqIHJldHJ5Q291bnQsXG4gICAgICAgICk7XG5cbiAgICAgICAgLy8gTk9URTogdGhpcyBldmVudCBpcyBvbmx5IHVzZWQgYnkgdGVzdHMgYW5kIHdpbGwgYmUgcmVtb3ZlZCBhdCBhbnkgdGltZS5cbiAgICAgICAgLy8ganNmb3JjZSBtYXkgc3dpdGNoIHRvIG5vZGUncyBmZXRjaCB3aGljaCBkb2Vzbid0IGVtaXQgdGhpcyBldmVudCBvbiByZXRyaWVzLlxuICAgICAgICBlbWl0dGVyLmVtaXQoJ3JldHJ5JywgcmV0cnlDb3VudCk7XG4gICAgICAgIHJldHJ5Q291bnQrKztcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT09IDQyMCkge1xuICAgICAgICAgIHJldHJ5NDIwQ291bnQrKztcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBhd2FpdCBmZXRjaFdpdGhSZXRyaWVzKG1heFJldHJ5KTtcbiAgICAgIH1cbiAgICAgIC8vIHNob3VsZCB3ZSB0aHJvdyBoZXJlIGlmIHRoZSBtYXhSZXRyeSBhbHJlYWR5IGhhcHBlbmVkIGFuZCBzdGlsbCBnb3QgdGhlIHNhbWUgc3RhdHVzQ29kZT9cbiAgICAgIHJldHVybiByZXM7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBsb2dnZXIuZGVidWcoJ1JlcXVlc3QgZmFpbGVkJyk7XG4gICAgICBjb25zdCBlcnJvciA9IGVyciBhcyBFcnJvciB8IFR5cGVFcnJvcjtcblxuICAgICAgLy8gcmVxdWVzdCB3YXMgY2FuY2VsZWQgYnkgY29uc3VtZXIgKEFib3J0Q29udHJvbGxlciksIHNraXAgcmV0cnkgYW5kIHJldGhyb3cuXG4gICAgICBpZiAoZXJyb3IubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSB7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgICAgfVxuXG4gICAgICBpZiAoc2hvdWxkUmV0cnlSZXF1ZXN0KHJldHJ5T3B0cy5tYXhSZXRyaWVzLCBlcnJvcikpIHtcbiAgICAgICAgbG9nZ2VyLmRlYnVnKGByZXRyeWluZyBmb3IgdGhlICR7cmV0cnlDb3VudCArIDF9IHRpbWVgKTtcbiAgICAgICAgbG9nZ2VyLmRlYnVnKGBFcnJvcjogJHsoZXJyIGFzIEVycm9yKS5tZXNzYWdlfWApO1xuXG4gICAgICAgIGF3YWl0IHNsZWVwKFxuICAgICAgICAgIHJldHJ5Q291bnQgPT09IDBcbiAgICAgICAgICAgID8gcmV0cnlPcHRzLm1pblRpbWVvdXRcbiAgICAgICAgICAgIDogcmV0cnlPcHRzLm1pblRpbWVvdXQgKiByZXRyeU9wdHMudGltZW91dEZhY3RvciAqKiByZXRyeUNvdW50LFxuICAgICAgICApO1xuXG4gICAgICAgIC8vIE5PVEU6IHRoaXMgZXZlbnQgaXMgb25seSB1c2VkIGJ5IHRlc3RzIGFuZCB3aWxsIGJlIHJlbW92ZWQgYXQgYW55IHRpbWUuXG4gICAgICAgIC8vIGpzZm9yY2UgbWF5IHN3aXRjaCB0byBub2RlJ3MgZmV0Y2ggd2hpY2ggZG9lc24ndCBlbWl0IHRoaXMgZXZlbnQgb24gcmV0cmllcy5cbiAgICAgICAgZW1pdHRlci5lbWl0KCdyZXRyeScsIHJldHJ5Q291bnQpO1xuICAgICAgICByZXRyeUNvdW50Kys7XG5cbiAgICAgICAgcmV0dXJuIGZldGNoV2l0aFJldHJpZXMobWF4UmV0cnkpO1xuICAgICAgfVxuXG4gICAgICBsb2dnZXIuZGVidWcoJ1NraXBwaW5nIHJldHJ5Li4uJyk7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9O1xuXG4gIGxldCByZXM6IFJlc3BvbnNlO1xuXG4gIC8vIFRpbWVvdXQgYWZ0ZXIgMzAgbWludXRlcyB3aXRob3V0IGEgcmVzcG9uc2VcbiAgLy9cbiAgLy8gZGVmYXVsdCB0aW1lb3V0IGlzIDAgYW5kIGpzZm9yY2UgY29uc3VtZXJzIGNhbid0IHNldCB0aGlzIHdoZW4gY2FsbGluZyBgQ29ubmVjdGlvbmAgbWV0aG9kcyBzbyB3ZSBzZXQgYSBsb25nIGRlZmF1bHQgYXQgdGhlIGZldGNoIHdyYXBwZXIgbGV2ZWwuXG4gIGNvbnN0IGZldGNoVGltZW91dCA9IG9wdGlvbnMudGltZW91dCA/PyAxXzgwMF8wMDA7XG5cbiAgdHJ5IHtcbiAgICByZXMgPSBhd2FpdCBleGVjdXRlV2l0aFRpbWVvdXQoZmV0Y2hXaXRoUmV0cmllcywgZmV0Y2hUaW1lb3V0LCAoKSA9PlxuICAgICAgY29udHJvbGxlci5hYm9ydCgpLFxuICAgICk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGxldCB0aHJvd2FibGVFcnJvcjogRXJyb3I7XG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIERPTUV4Y2VwdGlvbiAmJiBlcnIubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSB7XG4gICAgICB0aHJvd2FibGVFcnJvciA9IG5ldyBET01FeGNlcHRpb24oKGVyciBhcyBFcnJvcikubWVzc2FnZSArICcgUmVxdWVzdCB3YXMgYWJvcnRlZCBkdWUgdG8gdGltZW91dCBvZiAzMCBtaW51dGVzLicsIChlcnIgYXMgRXJyb3IpLm5hbWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvd2FibGVFcnJvciA9IGVyciBhcyBFcnJvcjtcbiAgICB9XG4gICAgZW1pdHRlci5lbWl0KCdlcnJvcicsIHRocm93YWJsZUVycm9yKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgaGVhZGVyczogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHt9O1xuICBmb3IgKGNvbnN0IGhlYWRlck5hbWUgb2YgcmVzLmhlYWRlcnMua2V5cygpKSB7XG4gICAgaGVhZGVyc1toZWFkZXJOYW1lLnRvTG93ZXJDYXNlKCldID0gcmVzLmhlYWRlcnMuZ2V0KGhlYWRlck5hbWUpO1xuICB9XG4gIGNvbnN0IHJlc3BvbnNlID0ge1xuICAgIHN0YXR1c0NvZGU6IHJlcy5zdGF0dXMsXG4gICAgaGVhZGVycyxcbiAgfTtcbiAgaWYgKGZvbGxvd1JlZGlyZWN0ICYmIGlzUmVkaXJlY3QocmVzcG9uc2Uuc3RhdHVzQ29kZSkpIHtcbiAgICB0cnkge1xuICAgICAgcGVyZm9ybVJlZGlyZWN0UmVxdWVzdChcbiAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGZvbGxvd1JlZGlyZWN0LFxuICAgICAgICBjb3VudGVyLFxuICAgICAgICAocmVxKSA9PlxuICAgICAgICAgIHN0YXJ0RmV0Y2hSZXF1ZXN0KFxuICAgICAgICAgICAgcmVxLFxuICAgICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgICAgIG91dHB1dCxcbiAgICAgICAgICAgIGVtaXR0ZXIsXG4gICAgICAgICAgICBjb3VudGVyICsgMSxcbiAgICAgICAgICApLFxuICAgICAgKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGVtaXR0ZXIuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cbiAgZW1pdHRlci5lbWl0KCdyZXNwb25zZScsIHJlc3BvbnNlKTtcbiAgaWYgKHJlcy5ib2R5KSB7XG4gICAgUmVhZGFibGUuZnJvbVdlYihyZXMuYm9keSkucGlwZShvdXRwdXQpO1xuICB9IGVsc2Uge1xuICAgIG91dHB1dC5lbmQoKTtcbiAgfVxufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHJlcXVlc3QoXG4gIHJlcTogSHR0cFJlcXVlc3QsXG4gIG9wdGlvbnNfOiBIdHRwUmVxdWVzdE9wdGlvbnMgPSB7fSxcbik6IER1cGxleCB7XG4gIGNvbnN0IG9wdGlvbnMgPSB7IC4uLmRlZmF1bHRzLCAuLi5vcHRpb25zXyB9O1xuICBjb25zdCB7IGlucHV0LCBvdXRwdXQsIHN0cmVhbSB9ID0gY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyhcbiAgICByZXEsXG4gICAgb3B0aW9ucyxcbiAgKTtcbiAgc3RhcnRGZXRjaFJlcXVlc3QocmVxLCBvcHRpb25zLCBpbnB1dCwgb3V0cHV0LCBzdHJlYW0pO1xuICByZXR1cm4gc3RyZWFtO1xufVxuXG5jb25zdCBzbGVlcCA9IChtczogbnVtYmVyKSA9PiBuZXcgUHJvbWlzZSgocikgPT4gc2V0VGltZW91dChyLCBtcykpO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsU0FBaUJBLFFBQVEsUUFBa0IsUUFBUTtBQUNuRCxTQUFRQyxLQUFLLEVBQUVDLE1BQU0sRUFBRUMsUUFBUSxFQUFlQyxVQUFVLFFBQU8sUUFBUTtBQUN2RSxTQUNFQywrQkFBK0IsRUFDL0JDLGtCQUFrQixFQUNsQkMsVUFBVSxFQUNWQyxzQkFBc0IsUUFDakIsa0JBQWtCO0FBRXpCLFNBQVNDLFNBQVMsUUFBUSxlQUFlO0FBQ3pDLE9BQU9DLEVBQUUsTUFBTSxrQkFBa0I7QUFNakM7QUFDQTtBQUNBO0FBQ0EsSUFBSUMsUUFBNEIsR0FBRyxDQUFDLENBQUM7O0FBRXJDO0FBQ0E7QUFDQTtBQUNBLE9BQU8sU0FBU0MsV0FBV0EsQ0FBQ0MsU0FBNkIsRUFBRTtFQUN6REYsUUFBUSxHQUFHRSxTQUFTO0FBQ3RCOztBQUVBO0FBQ0E7QUFDQTtBQUZBLFNBR2VDLGlCQUFpQkEsQ0FBQUMsRUFBQSxFQUFBQyxHQUFBLEVBQUFDLEdBQUEsRUFBQUMsR0FBQSxFQUFBQyxHQUFBO0VBQUEsT0FBQUMsa0JBQUEsQ0FBQUMsS0FBQSxPQUFBQyxTQUFBO0FBQUE7QUFpTmhDO0FBQ0E7QUFDQTtBQUZBLFNBQUFGLG1CQUFBO0VBQUFBLGtCQUFBLEdBQUFHLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FqTkEsU0FBQUMsU0FDRUMsT0FBb0IsRUFDcEJDLE9BQTJCLEVBQzNCQyxLQUEyQixFQUMzQkMsTUFBZ0IsRUFDaEJDLE9BQXFCO0lBQUEsSUFBQUMscUJBQUEsRUFBQUMsY0FBQSxFQUFBQyxxQkFBQSxFQUFBQyxlQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGVBQUEsRUFBQUMscUJBQUEsRUFBQUMsZUFBQSxFQUFBQyxxQkFBQSxFQUFBQyxlQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGVBQUEsRUFBQUMsZ0JBQUEsRUFBQUMsU0FBQTtJQUFBLElBQUFDLE9BQUE7TUFBQUMsTUFBQTtNQUFBQyxTQUFBO01BQUFDLGNBQUE7TUFBQUMsS0FBQTtNQUFBQyxHQUFBO01BQUFDLElBQUE7TUFBQUMsUUFBQTtNQUFBQyxVQUFBO01BQUFDLFVBQUE7TUFBQUMsYUFBQTtNQUFBQyxTQUFBO01BQUFDLGtCQUFBO01BQUFDLGlCQUFBO01BQUFDLEdBQUE7TUFBQUMsWUFBQTtNQUFBQyxjQUFBO01BQUFDLE9BQUE7TUFBQUMsU0FBQTtNQUFBQyxLQUFBO01BQUFDLFVBQUE7TUFBQUMsUUFBQTtNQUFBQyxNQUFBLEdBQUE5QyxTQUFBO0lBQUEsT0FBQUUsbUJBQUEsQ0FBQTZDLElBQUEsVUFBQUMsVUFBQUMsU0FBQTtNQUFBLGtCQUFBQSxTQUFBLENBQUFDLElBQUEsR0FBQUQsU0FBQSxDQUFBRSxJQUFBO1FBQUE7VUFDckIzQixPQUFlLEdBQUFzQixNQUFBLENBQUFNLE1BQUEsUUFBQU4sTUFBQSxRQUFBTyxTQUFBLEdBQUFQLE1BQUEsTUFBRyxDQUFDO1VBRWJyQixNQUFNLEdBQUd0QyxTQUFTLENBQUMsT0FBTyxDQUFDO1VBQ3pCdUMsU0FBUyxHQUFxQnBCLE9BQU8sQ0FBckNvQixTQUFTLEVBQUVDLGNBQWMsR0FBS3JCLE9BQU8sQ0FBMUJxQixjQUFjO1VBQzNCQyxLQUFLLEdBQUdGLFNBQVMsR0FBRyxJQUFJNUMsVUFBVSxDQUFDNEMsU0FBUyxDQUFDLEdBQUcyQixTQUFTO1VBQ3ZEeEIsR0FBRyxHQUF3QnhCLE9BQU8sQ0FBbEN3QixHQUFHLEVBQUVDLElBQUksR0FBa0J6QixPQUFPLENBQTdCeUIsSUFBSSxFQUFLQyxRQUFRLEdBQUF1Qix3QkFBQSxDQUFLakQsT0FBTyxFQUFBa0QsU0FBQTtVQUNwQ3ZCLFVBQVUsR0FBRyxJQUFJd0IsZUFBZSxDQUFDLENBQUM7VUFFcEN2QixVQUFVLEdBQUcsQ0FBQztVQUNkQyxhQUFhLEdBQUcsQ0FBQztVQUVmQyxTQUFnRCxHQUFHO1lBQ3ZEc0IsV0FBVyxHQUFBL0MscUJBQUEsSUFBQUMsY0FBQSxHQUFFTCxPQUFPLENBQUNvRCxLQUFLLGNBQUEvQyxjQUFBLHVCQUFiQSxjQUFBLENBQWU4QyxXQUFXLGNBQUEvQyxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7WUFDekVpRCxVQUFVLEdBQUEvQyxxQkFBQSxJQUFBQyxlQUFBLEdBQUVQLE9BQU8sQ0FBQ29ELEtBQUssY0FBQTdDLGVBQUEsdUJBQWJBLGVBQUEsQ0FBZThDLFVBQVUsY0FBQS9DLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQztZQUMxQ2dELFVBQVUsR0FBQTlDLHFCQUFBLElBQUFDLGVBQUEsR0FBRVQsT0FBTyxDQUFDb0QsS0FBSyxjQUFBM0MsZUFBQSx1QkFBYkEsZUFBQSxDQUFlNkMsVUFBVSxjQUFBOUMscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxHQUFHO1lBQzVDK0MsYUFBYSxHQUFBN0MscUJBQUEsSUFBQUMsZUFBQSxHQUFFWCxPQUFPLENBQUNvRCxLQUFLLGNBQUF6QyxlQUFBLHVCQUFiQSxlQUFBLENBQWU0QyxhQUFhLGNBQUE3QyxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUM7WUFDaEQ4QyxVQUFVLEdBQUE1QyxxQkFBQSxJQUFBQyxlQUFBLEdBQUViLE9BQU8sQ0FBQ29ELEtBQUssY0FBQXZDLGVBQUEsdUJBQWJBLGVBQUEsQ0FBZTJDLFVBQVUsY0FBQTVDLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FDdkMsWUFBWSxFQUNaLGNBQWMsRUFDZCxXQUFXLEVBQ1gsVUFBVSxFQUNWLGFBQWEsRUFDYixXQUFXLEVBQ1gsZ0JBQWdCLEVBQ2hCLFdBQVcsRUFDWCxPQUFPLENBQ1I7WUFDRDZDLE9BQU8sR0FBQTNDLHFCQUFBLElBQUFDLGVBQUEsR0FBRWYsT0FBTyxDQUFDb0QsS0FBSyxjQUFBckMsZUFBQSx1QkFBYkEsZUFBQSxDQUFlMEMsT0FBTyxjQUFBM0MscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxDQUNqQyxLQUFLLEVBQ0wsS0FBSyxFQUNMLE1BQU0sRUFDTixTQUFTLEVBQ1QsUUFBUTtVQUVaLENBQUM7VUFFS2dCLGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBa0JBLENBQ3RCNEIsUUFBZ0IsRUFDaEJDLFFBQTBCLEVBQ2Q7WUFBQSxJQUFBQyxRQUFBO1lBQ1osSUFBSSxDQUFDQyx5QkFBQSxDQUFBRCxRQUFBLEdBQUEvQixTQUFTLENBQUM0QixPQUFPLEVBQUFLLElBQUEsQ0FBQUYsUUFBQSxFQUFVN0QsT0FBTyxDQUFDZ0UsTUFBTSxDQUFDLEVBQUUsT0FBTyxLQUFLO1lBRTdELElBQUlKLFFBQVEsWUFBWXBGLFFBQVEsRUFBRTtjQUFBLElBQUF5RixTQUFBO2NBQ2hDO2NBQ0E7Y0FDQTtjQUNBO2NBQ0EsSUFBSUwsUUFBUSxDQUFDTSxNQUFNLEtBQUssR0FBRyxFQUFFO2dCQUMzQixPQUFPckMsYUFBYSxHQUFHLENBQUM7Y0FDMUIsQ0FBQyxNQUFNLElBQUlpQyx5QkFBQSxDQUFBRyxTQUFBLEdBQUFuQyxTQUFTLENBQUNzQixXQUFXLEVBQUFXLElBQUEsQ0FBQUUsU0FBQSxFQUFVTCxRQUFRLENBQUNNLE1BQU0sQ0FBQyxFQUFFO2dCQUMxRCxJQUFJUCxRQUFRLEtBQUsvQixVQUFVLEVBQUU7a0JBQzNCLE9BQU8sS0FBSztnQkFDZCxDQUFDLE1BQU07a0JBQ0wsT0FBTyxJQUFJO2dCQUNiO2NBQ0Y7Y0FDQSxPQUFPLEtBQUs7WUFDZCxDQUFDLE1BQU07Y0FBQSxJQUFBdUMsU0FBQTtjQUNMLElBQUlSLFFBQVEsS0FBSy9CLFVBQVUsRUFBRSxPQUFPLEtBQUs7O2NBRXpDO2NBQ0EsSUFBSSxFQUFFZ0MsUUFBUSxZQUFZUSxTQUFTLENBQUMsRUFBRSxPQUFPLEtBQUs7Y0FFbEQsSUFBSXJGLEVBQUUsQ0FBQ3NGLFVBQVUsQ0FBQzVDLElBQUksQ0FBQyxJQUFJcEQsUUFBUSxDQUFDaUcsV0FBVyxDQUFDN0MsSUFBSSxDQUFDLEVBQUU7Z0JBQ3JETCxNQUFNLENBQUNtRCxLQUFLLENBQUMsd0RBQXdELENBQUM7Z0JBQ3RFLE9BQU8sS0FBSztjQUNkO2NBRUEsSUFBTUMsR0FBYyxHQUFHWixRQUFRO2NBQy9CLElBQU1hLGNBQTBCLEdBQUlELEdBQUcsQ0FBQ0UsS0FBSyxZQUFZbkcsTUFBTSxDQUFDb0csV0FBVyxHQUFHSCxHQUFHLENBQUNFLEtBQUssQ0FBQ0EsS0FBSyxHQUFHRixHQUFHLENBQUNFLEtBQW9CO2NBQ3hILE9BQU8sQ0FBQyxFQUFFRCxjQUFjLElBQUksTUFBTSxJQUFJQSxjQUFjLElBQUlBLGNBQWMsQ0FBQ0csSUFBSSxJQUFJOUMsU0FBUyxhQUFUQSxTQUFTLGVBQVRnQyx5QkFBQSxDQUFBSyxTQUFBLEdBQUFyQyxTQUFTLENBQUUyQixVQUFVLEVBQUFNLElBQUEsQ0FBQUksU0FBQSxFQUFVTSxjQUFjLENBQUNHLElBQUksQ0FBQyxDQUFDO1lBQ3JJO1VBQ0YsQ0FBQztVQUVLQyxpQkFBZ0I7WUFBQSxJQUFBQyxJQUFBLEdBQUFsRixpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBQUcsU0FBQWlGLFFBQUE7Y0FBQSxJQUFBcEIsUUFBQTtnQkFBQXFCLFNBQUE7Z0JBQUFDLElBQUE7Z0JBQUFDLEtBQUE7Z0JBQUFDLEtBQUEsR0FBQXhGLFNBQUE7Y0FBQSxPQUFBRSxtQkFBQSxDQUFBNkMsSUFBQSxVQUFBMEMsU0FBQUMsU0FBQTtnQkFBQSxrQkFBQUEsU0FBQSxDQUFBeEMsSUFBQSxHQUFBd0MsU0FBQSxDQUFBdkMsSUFBQTtrQkFBQTtvQkFDdkJhLFFBQVEsR0FBQXdCLEtBQUEsQ0FBQXBDLE1BQUEsUUFBQW9DLEtBQUEsUUFBQW5DLFNBQUEsR0FBQW1DLEtBQUEsTUFBR3JELFNBQVMsYUFBVEEsU0FBUyx1QkFBVEEsU0FBUyxDQUFFd0IsVUFBVTtvQkFFMUIwQixTQUFzQixHQUFBTSxhQUFBLENBQUFBLGFBQUEsQ0FBQUEsYUFBQSxLQUN2QjVELFFBQVEsR0FDUHhCLEtBQUssSUFBSSxxQkFBcUIsQ0FBQ3FGLElBQUksQ0FBQ3ZGLE9BQU8sQ0FBQ2dFLE1BQU0sQ0FBQyxHQUNuRDtzQkFBRXZDLElBQUksRUFBRXZCO29CQUFNLENBQUMsR0FDZixDQUFDLENBQUM7c0JBQ05zRixNQUFNLEVBQUUsTUFBTTtzQkFDZEMsUUFBUSxFQUFFLFFBQVE7c0JBQ2xCQyxNQUFNLEVBQUUvRCxVQUFVLENBQUMrRCxNQUFNO3NCQUN6QkMsVUFBVSxFQUFFcEU7b0JBQUs7b0JBQUE4RCxTQUFBLENBQUF4QyxJQUFBO29CQUFBd0MsU0FBQSxDQUFBdkMsSUFBQTtvQkFBQSxPQUlDeEUsS0FBSyxDQUFDa0QsR0FBRyxFQUFFd0QsU0FBUyxDQUFDO2tCQUFBO29CQUFqQy9DLElBQUcsR0FBQW9ELFNBQUEsQ0FBQU8sSUFBQTtvQkFBQSxLQUNMN0Qsa0JBQWtCLENBQUNELFNBQVMsQ0FBQ3dCLFVBQVUsRUFBRXJCLElBQUcsQ0FBQztzQkFBQW9ELFNBQUEsQ0FBQXZDLElBQUE7c0JBQUE7b0JBQUE7b0JBQy9DMUIsTUFBTSxDQUFDbUQsS0FBSyxxQkFBQXNCLE1BQUEsQ0FBcUJqRSxVQUFVLEdBQUcsQ0FBQyxVQUFPLENBQUM7b0JBQ3ZEUixNQUFNLENBQUNtRCxLQUFLLENBQUMsMEJBQTBCLENBQUM7b0JBQUNjLFNBQUEsQ0FBQXZDLElBQUE7b0JBQUEsT0FFbkNnRCxLQUFLLENBQ1RsRSxVQUFVLEtBQUssQ0FBQyxHQUNaRSxTQUFTLENBQUN5QixVQUFVLEdBQ3BCekIsU0FBUyxDQUFDeUIsVUFBVSxHQUFBd0MsSUFBQSxDQUFBQyxHQUFBLENBQUdsRSxTQUFTLENBQUMwQixhQUFhLEVBQUk1QixVQUFVLENBQ2xFLENBQUM7a0JBQUE7b0JBRUQ7b0JBQ0E7b0JBQ0F4QixPQUFPLENBQUM2RixJQUFJLENBQUMsT0FBTyxFQUFFckUsVUFBVSxDQUFDO29CQUNqQ0EsVUFBVSxFQUFFO29CQUNaLElBQUlLLElBQUcsQ0FBQ2lDLE1BQU0sS0FBSyxHQUFHLEVBQUU7c0JBQ3RCckMsYUFBYSxFQUFFO29CQUNqQjtvQkFBQ3dELFNBQUEsQ0FBQXZDLElBQUE7b0JBQUEsT0FFWStCLGlCQUFnQixDQUFDbEIsUUFBUSxDQUFDO2tCQUFBO29CQUFBLE9BQUEwQixTQUFBLENBQUFhLE1BQUEsV0FBQWIsU0FBQSxDQUFBTyxJQUFBO2tCQUFBO29CQUFBLE9BQUFQLFNBQUEsQ0FBQWEsTUFBQSxXQUdsQ2pFLElBQUc7a0JBQUE7b0JBQUFvRCxTQUFBLENBQUF4QyxJQUFBO29CQUFBd0MsU0FBQSxDQUFBYyxFQUFBLEdBQUFkLFNBQUE7b0JBRVZqRSxNQUFNLENBQUNtRCxLQUFLLENBQUMsZ0JBQWdCLENBQUM7b0JBQ3hCVyxLQUFLLEdBQUFHLFNBQUEsQ0FBQWMsRUFBQSxFQUVYO29CQUFBLE1BQ0lqQixLQUFLLENBQUNrQixJQUFJLEtBQUssWUFBWTtzQkFBQWYsU0FBQSxDQUFBdkMsSUFBQTtzQkFBQTtvQkFBQTtvQkFBQSxNQUN2Qm9DLEtBQUs7a0JBQUE7b0JBQUEsS0FHVG5ELGtCQUFrQixDQUFDRCxTQUFTLENBQUN3QixVQUFVLEVBQUU0QixLQUFLLENBQUM7c0JBQUFHLFNBQUEsQ0FBQXZDLElBQUE7c0JBQUE7b0JBQUE7b0JBQ2pEMUIsTUFBTSxDQUFDbUQsS0FBSyxxQkFBQXNCLE1BQUEsQ0FBcUJqRSxVQUFVLEdBQUcsQ0FBQyxVQUFPLENBQUM7b0JBQ3ZEUixNQUFNLENBQUNtRCxLQUFLLFdBQUFzQixNQUFBLENBQVdSLFNBQUEsQ0FBQWMsRUFBQSxDQUFlRSxPQUFPLENBQUUsQ0FBQztvQkFBQ2hCLFNBQUEsQ0FBQXZDLElBQUE7b0JBQUEsT0FFM0NnRCxLQUFLLENBQ1RsRSxVQUFVLEtBQUssQ0FBQyxHQUNaRSxTQUFTLENBQUN5QixVQUFVLEdBQ3BCekIsU0FBUyxDQUFDeUIsVUFBVSxHQUFBd0MsSUFBQSxDQUFBQyxHQUFBLENBQUdsRSxTQUFTLENBQUMwQixhQUFhLEVBQUk1QixVQUFVLENBQ2xFLENBQUM7a0JBQUE7b0JBRUQ7b0JBQ0E7b0JBQ0F4QixPQUFPLENBQUM2RixJQUFJLENBQUMsT0FBTyxFQUFFckUsVUFBVSxDQUFDO29CQUNqQ0EsVUFBVSxFQUFFO29CQUFDLE9BQUF5RCxTQUFBLENBQUFhLE1BQUEsV0FFTnJCLGlCQUFnQixDQUFDbEIsUUFBUSxDQUFDO2tCQUFBO29CQUduQ3ZDLE1BQU0sQ0FBQ21ELEtBQUssQ0FBQyxtQkFBbUIsQ0FBQztvQkFBQyxNQUFBYyxTQUFBLENBQUFjLEVBQUE7a0JBQUE7a0JBQUE7b0JBQUEsT0FBQWQsU0FBQSxDQUFBaUIsSUFBQTtnQkFBQTtjQUFBLEdBQUF2QixPQUFBO1lBQUEsQ0FHckM7WUFBQSxnQkFwRUtGLGdCQUFnQkEsQ0FBQTtjQUFBLE9BQUFDLElBQUEsQ0FBQXBGLEtBQUEsT0FBQUMsU0FBQTtZQUFBO1VBQUE7VUF3RXRCO1VBQ0E7VUFDQTtVQUNNdUMsWUFBWSxJQUFBakIsZ0JBQUEsR0FBR2hCLE9BQU8sQ0FBQ3NHLE9BQU8sY0FBQXRGLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUksT0FBUztVQUFBMkIsU0FBQSxDQUFBQyxJQUFBO1VBQUFELFNBQUEsQ0FBQUUsSUFBQTtVQUFBLE9BR25DbkUsa0JBQWtCLENBQUNrRyxpQkFBZ0IsRUFBRTNDLFlBQVksRUFBRTtZQUFBLE9BQzdEUCxVQUFVLENBQUM2RSxLQUFLLENBQUMsQ0FBQztVQUFBLENBQ3BCLENBQUM7UUFBQTtVQUZEdkUsR0FBRyxHQUFBVyxTQUFBLENBQUFnRCxJQUFBO1VBQUFoRCxTQUFBLENBQUFFLElBQUE7VUFBQTtRQUFBO1VBQUFGLFNBQUEsQ0FBQUMsSUFBQTtVQUFBRCxTQUFBLENBQUF1RCxFQUFBLEdBQUF2RCxTQUFBO1VBS0gsSUFBSUEsU0FBQSxDQUFBdUQsRUFBQSxZQUFlTSxZQUFZLElBQUk3RCxTQUFBLENBQUF1RCxFQUFBLENBQUlDLElBQUksS0FBSyxZQUFZLEVBQUU7WUFDNURqRSxjQUFjLEdBQUcsSUFBSXNFLFlBQVksQ0FBQzdELFNBQUEsQ0FBQXVELEVBQUEsQ0FBZUUsT0FBTyxHQUFHLG9EQUFvRCxFQUFFekQsU0FBQSxDQUFBdUQsRUFBQSxDQUFlQyxJQUFJLENBQUM7VUFDdkksQ0FBQyxNQUFNO1lBQ0xqRSxjQUFjLEdBQUFTLFNBQUEsQ0FBQXVELEVBQWU7VUFDL0I7VUFDQS9GLE9BQU8sQ0FBQzZGLElBQUksQ0FBQyxPQUFPLEVBQUU5RCxjQUFjLENBQUM7VUFBQyxPQUFBUyxTQUFBLENBQUFzRCxNQUFBO1FBQUE7VUFHbEM5RCxPQUErQixHQUFHLENBQUMsQ0FBQztVQUFBQyxTQUFBLEdBQUFxRSwwQkFBQSxDQUNqQkMscUJBQUEsQ0FBQXpGLFNBQUEsR0FBQWUsR0FBRyxDQUFDRyxPQUFPLEVBQUEyQixJQUFBLENBQUE3QyxTQUFNLENBQUM7VUFBQTtZQUEzQyxLQUFBbUIsU0FBQSxDQUFBdUUsQ0FBQSxNQUFBdEUsS0FBQSxHQUFBRCxTQUFBLENBQUF3RSxDQUFBLElBQUFDLElBQUEsR0FBNkM7Y0FBbEN2RSxVQUFVLEdBQUFELEtBQUEsQ0FBQXlFLEtBQUE7Y0FDbkIzRSxPQUFPLENBQUNHLFVBQVUsQ0FBQ3lFLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRy9FLEdBQUcsQ0FBQ0csT0FBTyxDQUFDNkUsR0FBRyxDQUFDMUUsVUFBVSxDQUFDO1lBQ2pFO1VBQUMsU0FBQWlDLEdBQUE7WUFBQW5DLFNBQUEsQ0FBQTZFLENBQUEsQ0FBQTFDLEdBQUE7VUFBQTtZQUFBbkMsU0FBQSxDQUFBOEUsQ0FBQTtVQUFBO1VBQ0szRSxRQUFRLEdBQUc7WUFDZjRFLFVBQVUsRUFBRW5GLEdBQUcsQ0FBQ2lDLE1BQU07WUFDdEI5QixPQUFPLEVBQVBBO1VBQ0YsQ0FBQztVQUFBLE1BQ0dkLGNBQWMsSUFBSTFDLFVBQVUsQ0FBQzRELFFBQVEsQ0FBQzRFLFVBQVUsQ0FBQztZQUFBeEUsU0FBQSxDQUFBRSxJQUFBO1lBQUE7VUFBQTtVQUNuRCxJQUFJO1lBQ0ZqRSxzQkFBc0IsQ0FDcEJtQixPQUFPLEVBQ1B3QyxRQUFRLEVBQ1JsQixjQUFjLEVBQ2RILE9BQU8sRUFDUCxVQUFDa0csR0FBRztjQUFBLE9BQ0ZsSSxpQkFBaUIsQ0FDZmtJLEdBQUcsRUFDSHBILE9BQU8sRUFDUCtDLFNBQVMsRUFDVDdDLE1BQU0sRUFDTkMsT0FBTyxFQUNQZSxPQUFPLEdBQUcsQ0FDWixDQUFDO1lBQUEsQ0FDTCxDQUFDO1VBQ0gsQ0FBQyxDQUFDLE9BQU9xRCxHQUFHLEVBQUU7WUFDWnBFLE9BQU8sQ0FBQzZGLElBQUksQ0FBQyxPQUFPLEVBQUV6QixHQUFHLENBQUM7VUFDNUI7VUFBQyxPQUFBNUIsU0FBQSxDQUFBc0QsTUFBQTtRQUFBO1VBR0g5RixPQUFPLENBQUM2RixJQUFJLENBQUMsVUFBVSxFQUFFekQsUUFBUSxDQUFDO1VBQ2xDLElBQUlQLEdBQUcsQ0FBQ1IsSUFBSSxFQUFFO1lBQ1pwRCxRQUFRLENBQUNpSixPQUFPLENBQUNyRixHQUFHLENBQUNSLElBQUksQ0FBQyxDQUFDOEYsSUFBSSxDQUFDcEgsTUFBTSxDQUFDO1VBQ3pDLENBQUMsTUFBTTtZQUNMQSxNQUFNLENBQUNxSCxHQUFHLENBQUMsQ0FBQztVQUNkO1FBQUM7UUFBQTtVQUFBLE9BQUE1RSxTQUFBLENBQUEwRCxJQUFBO01BQUE7SUFBQSxHQUFBdkcsUUFBQTtFQUFBLENBQ0Y7RUFBQSxPQUFBTixrQkFBQSxDQUFBQyxLQUFBLE9BQUFDLFNBQUE7QUFBQTtBQUtELGVBQWUsU0FBU0ssT0FBT0EsQ0FDN0JxSCxHQUFnQixFQUVSO0VBQUEsSUFEUkksUUFBNEIsR0FBQTlILFNBQUEsQ0FBQW9ELE1BQUEsUUFBQXBELFNBQUEsUUFBQXFELFNBQUEsR0FBQXJELFNBQUEsTUFBRyxDQUFDLENBQUM7RUFFakMsSUFBTU0sT0FBTyxHQUFBcUYsYUFBQSxDQUFBQSxhQUFBLEtBQVF0RyxRQUFRLEdBQUt5SSxRQUFRLENBQUU7RUFDNUMsSUFBQUMscUJBQUEsR0FBa0NoSiwrQkFBK0IsQ0FDL0QySSxHQUFHLEVBQ0hwSCxPQUNGLENBQUM7SUFIT0MsS0FBSyxHQUFBd0gscUJBQUEsQ0FBTHhILEtBQUs7SUFBRUMsTUFBTSxHQUFBdUgscUJBQUEsQ0FBTnZILE1BQU07SUFBRXdILE1BQU0sR0FBQUQscUJBQUEsQ0FBTkMsTUFBTTtFQUk3QnhJLGlCQUFpQixDQUFDa0ksR0FBRyxFQUFFcEgsT0FBTyxFQUFFQyxLQUFLLEVBQUVDLE1BQU0sRUFBRXdILE1BQU0sQ0FBQztFQUN0RCxPQUFPQSxNQUFNO0FBQ2Y7QUFFQSxJQUFNN0IsS0FBSyxHQUFHLFNBQVJBLEtBQUtBLENBQUk4QixFQUFVO0VBQUEsT0FBSyxJQUFBQyxRQUFBLENBQVksVUFBQ0MsQ0FBQztJQUFBLE9BQUtDLFdBQUEsQ0FBV0QsQ0FBQyxFQUFFRixFQUFFLENBQUM7RUFBQSxFQUFDO0FBQUEiLCJpZ25vcmVMaXN0IjpbXX0=