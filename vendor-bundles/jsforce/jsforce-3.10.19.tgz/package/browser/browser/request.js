import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.regexp.to-string.js";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _sliceInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/slice";
import _Array$from from "@babel/runtime-corejs3/core-js-stable/array/from";
import _Symbol from "@babel/runtime-corejs3/core-js-stable/symbol";
import _getIteratorMethod from "@babel/runtime-corejs3/core-js/get-iterator-method";
import _Array$isArray from "@babel/runtime-corejs3/core-js-stable/array/is-array";
import _objectWithoutProperties from "@babel/runtime-corejs3/helpers/objectWithoutProperties";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
var _excluded = ["url", "body"];
import _keysInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/keys";
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof _Symbol && _getIteratorMethod(r) || r["@@iterator"]; if (!t) { if (_Array$isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { var _context7; if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = _sliceInstanceProperty(_context7 = {}.toString.call(r)).call(_context7, 8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? _Array$from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.promise.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.test.js";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context5, _context6; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context5 = ownKeys(Object(t), !0)).call(_context5, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context6 = ownKeys(Object(t))).call(_context6, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
import { createHttpRequestHandlerStreams, executeWithTimeout, isRedirect, performRedirectRequest } from '../request-helper';
import { readAll } from '../util/stream';
/**
 * As the request streming is not yet supported on major browsers,
 * it is set to false for now.
 */
var supportsReadableStream = false;

/*
(async () => {
  try {
    if (
      typeof fetch === 'function' &&
      typeof Request === 'function' &&
      typeof ReadableStream === 'function'
    ) {
      // this feature detection requires dummy POST request
      const req = new Request('data:text/plain,', {
        method: 'POST',
        body: new ReadableStream(),
      });
      // if it has content-type header it doesn't regard body as stream
      if (req.headers.has('Content-Type')) {
        return false;
      }
      await (await fetch(req)).text();
      return true;
    }
  } catch (e) {
    // error might occur in env with CSP without connect-src data:
    return false;
  }
  return false;
})();
*/

/**
 *
 */
function toWhatwgReadableStream(ins) {
  return new ReadableStream({
    start: function start(controller) {
      ins.on('data', function (chunk) {
        return controller.enqueue(chunk);
      });
      ins.on('end', function () {
        return controller.close();
      });
    }
  });
}

/**
 *
 */
function readWhatwgReadableStream(_x, _x2) {
  return _readWhatwgReadableStream.apply(this, arguments);
}
/**
 *
 */
function _readWhatwgReadableStream() {
  _readWhatwgReadableStream = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2(rs, outs) {
    var reader, readAndWrite, _readAndWrite;
    return _regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          _readAndWrite = function _readAndWrite3() {
            _readAndWrite = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee() {
              var _yield$reader$read, done, value;
              return _regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return reader.read();
                  case 2:
                    _yield$reader$read = _context.sent;
                    done = _yield$reader$read.done;
                    value = _yield$reader$read.value;
                    if (!done) {
                      _context.next = 8;
                      break;
                    }
                    outs.end();
                    return _context.abrupt("return", false);
                  case 8:
                    outs.write(value);
                    return _context.abrupt("return", true);
                  case 10:
                  case "end":
                    return _context.stop();
                }
              }, _callee);
            }));
            return _readAndWrite.apply(this, arguments);
          };
          readAndWrite = function _readAndWrite2() {
            return _readAndWrite.apply(this, arguments);
          };
          reader = rs.getReader();
        case 3:
          _context2.next = 5;
          return readAndWrite();
        case 5:
          if (!_context2.sent) {
            _context2.next = 9;
            break;
          }
          ;
          _context2.next = 3;
          break;
        case 9:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
  return _readWhatwgReadableStream.apply(this, arguments);
}
function startFetchRequest(_x3, _x4, _x5, _x6, _x7) {
  return _startFetchRequest.apply(this, arguments);
}
/**
 *
 */
function _startFetchRequest() {
  _startFetchRequest = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee3(request, options, input, output, emitter) {
    var _context3;
    var counter,
      followRedirect,
      url,
      reqBody,
      rreq,
      body,
      controller,
      res,
      headers,
      _iterator,
      _step,
      headerName,
      response,
      _args3 = arguments;
    return _regeneratorRuntime.wrap(function _callee3$(_context4) {
      while (1) switch (_context4.prev = _context4.next) {
        case 0:
          counter = _args3.length > 5 && _args3[5] !== undefined ? _args3[5] : 0;
          followRedirect = options.followRedirect;
          url = request.url, reqBody = request.body, rreq = _objectWithoutProperties(request, _excluded);
          if (!(input && /^(post|put|patch)$/i.test(request.method))) {
            _context4.next = 14;
            break;
          }
          if (!supportsReadableStream) {
            _context4.next = 8;
            break;
          }
          _context4.t1 = toWhatwgReadableStream(input);
          _context4.next = 11;
          break;
        case 8:
          _context4.next = 10;
          return readAll(input);
        case 10:
          _context4.t1 = _context4.sent;
        case 11:
          _context4.t0 = _context4.t1;
          _context4.next = 15;
          break;
        case 14:
          _context4.t0 = undefined;
        case 15:
          body = _context4.t0;
          controller = typeof AbortController !== 'undefined' ? new AbortController() : undefined;
          _context4.next = 19;
          return executeWithTimeout(function () {
            return fetch(url, _objectSpread(_objectSpread(_objectSpread(_objectSpread({}, rreq), body ? {
              body: body
            } : {}), {}, {
              redirect: 'manual'
            }, controller ? {
              signal: controller.signal
            } : {}), {
              allowHTTP1ForStreamingUpload: true
            }));
          }, options.timeout, function () {
            return controller === null || controller === void 0 ? void 0 : controller.abort();
          });
        case 19:
          res = _context4.sent;
          headers = {}; // @ts-expect-error no .keys()?
          _iterator = _createForOfIteratorHelper(_keysInstanceProperty(_context3 = res.headers).call(_context3));
          try {
            for (_iterator.s(); !(_step = _iterator.n()).done;) {
              headerName = _step.value;
              headers[headerName.toLowerCase()] = res.headers.get(headerName);
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
          response = {
            statusCode: res.status,
            headers: headers
          };
          if (!(followRedirect && isRedirect(response.statusCode))) {
            _context4.next = 27;
            break;
          }
          try {
            performRedirectRequest(request, response, followRedirect, counter, function (req) {
              return startFetchRequest(req, options, undefined, output, emitter, counter + 1);
            });
          } catch (err) {
            emitter.emit('error', err);
          }
          return _context4.abrupt("return");
        case 27:
          emitter.emit('response', response);
          if (res.body) {
            readWhatwgReadableStream(res.body, output);
          } else {
            output.end();
          }
        case 29:
        case "end":
          return _context4.stop();
      }
    }, _callee3);
  }));
  return _startFetchRequest.apply(this, arguments);
}
var defaults = {};

/**
 *
 */
export function setDefaults(defaults_) {
  defaults = defaults_;
}

/**
 *
 */
export default function request(req) {
  var options_ = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var options = _objectSpread(_objectSpread({}, defaults), options_);
  var _createHttpRequestHan = createHttpRequestHandlerStreams(req, options),
    input = _createHttpRequestHan.input,
    output = _createHttpRequestHan.output,
    stream = _createHttpRequestHan.stream;
  startFetchRequest(req, options, input, output, stream);
  return stream;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJjcmVhdGVIdHRwUmVxdWVzdEhhbmRsZXJTdHJlYW1zIiwiZXhlY3V0ZVdpdGhUaW1lb3V0IiwiaXNSZWRpcmVjdCIsInBlcmZvcm1SZWRpcmVjdFJlcXVlc3QiLCJyZWFkQWxsIiwic3VwcG9ydHNSZWFkYWJsZVN0cmVhbSIsInRvV2hhdHdnUmVhZGFibGVTdHJlYW0iLCJpbnMiLCJSZWFkYWJsZVN0cmVhbSIsInN0YXJ0IiwiY29udHJvbGxlciIsIm9uIiwiY2h1bmsiLCJlbnF1ZXVlIiwiY2xvc2UiLCJyZWFkV2hhdHdnUmVhZGFibGVTdHJlYW0iLCJfeCIsIl94MiIsIl9yZWFkV2hhdHdnUmVhZGFibGVTdHJlYW0iLCJhcHBseSIsImFyZ3VtZW50cyIsIl9hc3luY1RvR2VuZXJhdG9yIiwiX3JlZ2VuZXJhdG9yUnVudGltZSIsIm1hcmsiLCJfY2FsbGVlMiIsInJzIiwib3V0cyIsInJlYWRlciIsInJlYWRBbmRXcml0ZSIsIl9yZWFkQW5kV3JpdGUiLCJ3cmFwIiwiX2NhbGxlZTIkIiwiX2NvbnRleHQyIiwicHJldiIsIm5leHQiLCJfcmVhZEFuZFdyaXRlMyIsIl9jYWxsZWUiLCJfeWllbGQkcmVhZGVyJHJlYWQiLCJkb25lIiwidmFsdWUiLCJfY2FsbGVlJCIsIl9jb250ZXh0IiwicmVhZCIsInNlbnQiLCJlbmQiLCJhYnJ1cHQiLCJ3cml0ZSIsInN0b3AiLCJfcmVhZEFuZFdyaXRlMiIsImdldFJlYWRlciIsInN0YXJ0RmV0Y2hSZXF1ZXN0IiwiX3gzIiwiX3g0IiwiX3g1IiwiX3g2IiwiX3g3IiwiX3N0YXJ0RmV0Y2hSZXF1ZXN0IiwiX2NhbGxlZTMiLCJyZXF1ZXN0Iiwib3B0aW9ucyIsImlucHV0Iiwib3V0cHV0IiwiZW1pdHRlciIsIl9jb250ZXh0MyIsImNvdW50ZXIiLCJmb2xsb3dSZWRpcmVjdCIsInVybCIsInJlcUJvZHkiLCJycmVxIiwiYm9keSIsInJlcyIsImhlYWRlcnMiLCJfaXRlcmF0b3IiLCJfc3RlcCIsImhlYWRlck5hbWUiLCJyZXNwb25zZSIsIl9hcmdzMyIsIl9jYWxsZWUzJCIsIl9jb250ZXh0NCIsImxlbmd0aCIsInVuZGVmaW5lZCIsIl9vYmplY3RXaXRob3V0UHJvcGVydGllcyIsIl9leGNsdWRlZCIsInRlc3QiLCJtZXRob2QiLCJ0MSIsInQwIiwiQWJvcnRDb250cm9sbGVyIiwiZmV0Y2giLCJfb2JqZWN0U3ByZWFkIiwicmVkaXJlY3QiLCJzaWduYWwiLCJhbGxvd0hUVFAxRm9yU3RyZWFtaW5nVXBsb2FkIiwidGltZW91dCIsImFib3J0IiwiX2NyZWF0ZUZvck9mSXRlcmF0b3JIZWxwZXIiLCJfa2V5c0luc3RhbmNlUHJvcGVydHkiLCJjYWxsIiwicyIsIm4iLCJ0b0xvd2VyQ2FzZSIsImdldCIsImVyciIsImUiLCJmIiwic3RhdHVzQ29kZSIsInN0YXR1cyIsInJlcSIsImVtaXQiLCJkZWZhdWx0cyIsInNldERlZmF1bHRzIiwiZGVmYXVsdHNfIiwib3B0aW9uc18iLCJfY3JlYXRlSHR0cFJlcXVlc3RIYW4iLCJzdHJlYW0iXSwic291cmNlcyI6WyIuLi8uLi9zcmMvYnJvd3Nlci9yZXF1ZXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gJ2V2ZW50cyc7XG5pbXBvcnQgeyBSZWFkYWJsZSwgV3JpdGFibGUgfSBmcm9tICdzdHJlYW0nO1xuaW1wb3J0IHtcbiAgY3JlYXRlSHR0cFJlcXVlc3RIYW5kbGVyU3RyZWFtcyxcbiAgZXhlY3V0ZVdpdGhUaW1lb3V0LFxuICBpc1JlZGlyZWN0LFxuICBwZXJmb3JtUmVkaXJlY3RSZXF1ZXN0LFxufSBmcm9tICcuLi9yZXF1ZXN0LWhlbHBlcic7XG5pbXBvcnQgeyByZWFkQWxsIH0gZnJvbSAnLi4vdXRpbC9zdHJlYW0nO1xuaW1wb3J0IHsgSHR0cFJlcXVlc3QsIEh0dHBSZXF1ZXN0T3B0aW9ucyB9IGZyb20gJy4uL3R5cGVzJztcblxuLyoqXG4gKiBBcyB0aGUgcmVxdWVzdCBzdHJlbWluZyBpcyBub3QgeWV0IHN1cHBvcnRlZCBvbiBtYWpvciBicm93c2VycyxcbiAqIGl0IGlzIHNldCB0byBmYWxzZSBmb3Igbm93LlxuICovXG5jb25zdCBzdXBwb3J0c1JlYWRhYmxlU3RyZWFtID0gZmFsc2U7XG5cbi8qXG4oYXN5bmMgKCkgPT4ge1xuICB0cnkge1xuICAgIGlmIChcbiAgICAgIHR5cGVvZiBmZXRjaCA9PT0gJ2Z1bmN0aW9uJyAmJlxuICAgICAgdHlwZW9mIFJlcXVlc3QgPT09ICdmdW5jdGlvbicgJiZcbiAgICAgIHR5cGVvZiBSZWFkYWJsZVN0cmVhbSA9PT0gJ2Z1bmN0aW9uJ1xuICAgICkge1xuICAgICAgLy8gdGhpcyBmZWF0dXJlIGRldGVjdGlvbiByZXF1aXJlcyBkdW1teSBQT1NUIHJlcXVlc3RcbiAgICAgIGNvbnN0IHJlcSA9IG5ldyBSZXF1ZXN0KCdkYXRhOnRleHQvcGxhaW4sJywge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgYm9keTogbmV3IFJlYWRhYmxlU3RyZWFtKCksXG4gICAgICB9KTtcbiAgICAgIC8vIGlmIGl0IGhhcyBjb250ZW50LXR5cGUgaGVhZGVyIGl0IGRvZXNuJ3QgcmVnYXJkIGJvZHkgYXMgc3RyZWFtXG4gICAgICBpZiAocmVxLmhlYWRlcnMuaGFzKCdDb250ZW50LVR5cGUnKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBhd2FpdCAoYXdhaXQgZmV0Y2gocmVxKSkudGV4dCgpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9IGNhdGNoIChlKSB7XG4gICAgLy8gZXJyb3IgbWlnaHQgb2NjdXIgaW4gZW52IHdpdGggQ1NQIHdpdGhvdXQgY29ubmVjdC1zcmMgZGF0YTpcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufSkoKTtcbiovXG5cbi8qKlxuICpcbiAqL1xuZnVuY3Rpb24gdG9XaGF0d2dSZWFkYWJsZVN0cmVhbShpbnM6IFJlYWRhYmxlKTogUmVhZGFibGVTdHJlYW0ge1xuICByZXR1cm4gbmV3IFJlYWRhYmxlU3RyZWFtKHtcbiAgICBzdGFydChjb250cm9sbGVyKSB7XG4gICAgICBpbnMub24oJ2RhdGEnLCAoY2h1bmspID0+IGNvbnRyb2xsZXIuZW5xdWV1ZShjaHVuaykpO1xuICAgICAgaW5zLm9uKCdlbmQnLCAoKSA9PiBjb250cm9sbGVyLmNsb3NlKCkpO1xuICAgIH0sXG4gIH0pO1xufVxuXG4vKipcbiAqXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIHJlYWRXaGF0d2dSZWFkYWJsZVN0cmVhbShyczogUmVhZGFibGVTdHJlYW0sIG91dHM6IFdyaXRhYmxlKSB7XG4gIGNvbnN0IHJlYWRlciA9IHJzLmdldFJlYWRlcigpO1xuICBhc3luYyBmdW5jdGlvbiByZWFkQW5kV3JpdGUoKSB7XG4gICAgY29uc3QgeyBkb25lLCB2YWx1ZSB9ID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcbiAgICBpZiAoZG9uZSkge1xuICAgICAgb3V0cy5lbmQoKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgb3V0cy53cml0ZSh2YWx1ZSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgd2hpbGUgKGF3YWl0IHJlYWRBbmRXcml0ZSgpKTtcbn1cblxuLyoqXG4gKlxuICovXG5hc3luYyBmdW5jdGlvbiBzdGFydEZldGNoUmVxdWVzdChcbiAgcmVxdWVzdDogSHR0cFJlcXVlc3QsXG4gIG9wdGlvbnM6IEh0dHBSZXF1ZXN0T3B0aW9ucyxcbiAgaW5wdXQ6IFJlYWRhYmxlIHwgdW5kZWZpbmVkLFxuICBvdXRwdXQ6IFdyaXRhYmxlLFxuICBlbWl0dGVyOiBFdmVudEVtaXR0ZXIsXG4gIGNvdW50ZXI6IG51bWJlciA9IDAsXG4pIHtcbiAgY29uc3QgeyBmb2xsb3dSZWRpcmVjdCB9ID0gb3B0aW9ucztcbiAgY29uc3QgeyB1cmwsIGJvZHk6IHJlcUJvZHksIC4uLnJyZXEgfSA9IHJlcXVlc3Q7XG4gIGNvbnN0IGJvZHkgPVxuICAgIGlucHV0ICYmIC9eKHBvc3R8cHV0fHBhdGNoKSQvaS50ZXN0KHJlcXVlc3QubWV0aG9kKVxuICAgICAgPyBzdXBwb3J0c1JlYWRhYmxlU3RyZWFtXG4gICAgICAgID8gdG9XaGF0d2dSZWFkYWJsZVN0cmVhbShpbnB1dClcbiAgICAgICAgOiBhd2FpdCByZWFkQWxsKGlucHV0KVxuICAgICAgOiB1bmRlZmluZWQ7XG4gIGNvbnN0IGNvbnRyb2xsZXIgPVxuICAgIHR5cGVvZiBBYm9ydENvbnRyb2xsZXIgIT09ICd1bmRlZmluZWQnID8gbmV3IEFib3J0Q29udHJvbGxlcigpIDogdW5kZWZpbmVkO1xuICBjb25zdCByZXMgPSBhd2FpdCBleGVjdXRlV2l0aFRpbWVvdXQoXG4gICAgKCkgPT5cbiAgICAgIGZldGNoKHVybCwge1xuICAgICAgICAuLi5ycmVxLFxuICAgICAgICAuLi4oYm9keSA/IHsgYm9keSB9IDoge30pLFxuICAgICAgICByZWRpcmVjdDogJ21hbnVhbCcsXG4gICAgICAgIC4uLihjb250cm9sbGVyID8geyBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsIH0gOiB7fSksXG4gICAgICAgIC4uLih7IGFsbG93SFRUUDFGb3JTdHJlYW1pbmdVcGxvYWQ6IHRydWUgfSBhcyBhbnkpLCAvLyBDaHJvbWUgYWxsb3dzIHJlcXVlc3Qgc3RyZWFtIG9ubHkgaW4gSFRUUDIvUVVJQyB1bmxlc3MgdGhpcyBvcHQtaW4gZmxhZ1xuICAgICAgfSksXG4gICAgb3B0aW9ucy50aW1lb3V0LFxuICAgICgpID0+IGNvbnRyb2xsZXI/LmFib3J0KCksXG4gICk7XG4gIGNvbnN0IGhlYWRlcnM6IHsgW2tleTogc3RyaW5nXTogYW55IH0gPSB7fTtcbiAgLy8gQHRzLWV4cGVjdC1lcnJvciBubyAua2V5cygpP1xuICBmb3IgKGNvbnN0IGhlYWRlck5hbWUgb2YgcmVzLmhlYWRlcnMua2V5cygpKSB7XG4gICAgaGVhZGVyc1toZWFkZXJOYW1lLnRvTG93ZXJDYXNlKCldID0gcmVzLmhlYWRlcnMuZ2V0KGhlYWRlck5hbWUpO1xuICB9XG4gIGNvbnN0IHJlc3BvbnNlID0ge1xuICAgIHN0YXR1c0NvZGU6IHJlcy5zdGF0dXMsXG4gICAgaGVhZGVycyxcbiAgfTtcbiAgaWYgKGZvbGxvd1JlZGlyZWN0ICYmIGlzUmVkaXJlY3QocmVzcG9uc2Uuc3RhdHVzQ29kZSkpIHtcbiAgICB0cnkge1xuICAgICAgcGVyZm9ybVJlZGlyZWN0UmVxdWVzdChcbiAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgcmVzcG9uc2UsXG4gICAgICAgIGZvbGxvd1JlZGlyZWN0LFxuICAgICAgICBjb3VudGVyLFxuICAgICAgICAocmVxKSA9PlxuICAgICAgICAgIHN0YXJ0RmV0Y2hSZXF1ZXN0KFxuICAgICAgICAgICAgcmVxLFxuICAgICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgICAgIG91dHB1dCxcbiAgICAgICAgICAgIGVtaXR0ZXIsXG4gICAgICAgICAgICBjb3VudGVyICsgMSxcbiAgICAgICAgICApLFxuICAgICAgKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGVtaXR0ZXIuZW1pdCgnZXJyb3InLCBlcnIpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cbiAgZW1pdHRlci5lbWl0KCdyZXNwb25zZScsIHJlc3BvbnNlKTtcbiAgaWYgKHJlcy5ib2R5KSB7XG4gICAgcmVhZFdoYXR3Z1JlYWRhYmxlU3RyZWFtKHJlcy5ib2R5LCBvdXRwdXQpO1xuICB9IGVsc2Uge1xuICAgIG91dHB1dC5lbmQoKTtcbiAgfVxufVxuXG4vKipcbiAqXG4gKi9cbmxldCBkZWZhdWx0czogSHR0cFJlcXVlc3RPcHRpb25zID0ge307XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldERlZmF1bHRzKGRlZmF1bHRzXzogSHR0cFJlcXVlc3RPcHRpb25zKSB7XG4gIGRlZmF1bHRzID0gZGVmYXVsdHNfO1xufVxuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHJlcXVlc3QoXG4gIHJlcTogSHR0cFJlcXVlc3QsXG4gIG9wdGlvbnNfOiBIdHRwUmVxdWVzdE9wdGlvbnMgPSB7fSxcbikge1xuICBjb25zdCBvcHRpb25zID0geyAuLi5kZWZhdWx0cywgLi4ub3B0aW9uc18gfTtcbiAgY29uc3QgeyBpbnB1dCwgb3V0cHV0LCBzdHJlYW0gfSA9IGNyZWF0ZUh0dHBSZXF1ZXN0SGFuZGxlclN0cmVhbXMoXG4gICAgcmVxLFxuICAgIG9wdGlvbnMsXG4gICk7XG4gIHN0YXJ0RmV0Y2hSZXF1ZXN0KHJlcSwgb3B0aW9ucywgaW5wdXQsIG91dHB1dCwgc3RyZWFtKTtcbiAgcmV0dXJuIHN0cmVhbTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFQSxTQUNFQSwrQkFBK0IsRUFDL0JDLGtCQUFrQixFQUNsQkMsVUFBVSxFQUNWQyxzQkFBc0IsUUFDakIsbUJBQW1CO0FBQzFCLFNBQVNDLE9BQU8sUUFBUSxnQkFBZ0I7QUFHeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNQyxzQkFBc0IsR0FBRyxLQUFLOztBQUVwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsU0FBU0Msc0JBQXNCQSxDQUFDQyxHQUFhLEVBQWtCO0VBQzdELE9BQU8sSUFBSUMsY0FBYyxDQUFDO0lBQ3hCQyxLQUFLLFdBQUxBLEtBQUtBLENBQUNDLFVBQVUsRUFBRTtNQUNoQkgsR0FBRyxDQUFDSSxFQUFFLENBQUMsTUFBTSxFQUFFLFVBQUNDLEtBQUs7UUFBQSxPQUFLRixVQUFVLENBQUNHLE9BQU8sQ0FBQ0QsS0FBSyxDQUFDO01BQUEsRUFBQztNQUNwREwsR0FBRyxDQUFDSSxFQUFFLENBQUMsS0FBSyxFQUFFO1FBQUEsT0FBTUQsVUFBVSxDQUFDSSxLQUFLLENBQUMsQ0FBQztNQUFBLEVBQUM7SUFDekM7RUFDRixDQUFDLENBQUM7QUFDSjs7QUFFQTtBQUNBO0FBQ0E7QUFGQSxTQUdlQyx3QkFBd0JBLENBQUFDLEVBQUEsRUFBQUMsR0FBQTtFQUFBLE9BQUFDLHlCQUFBLENBQUFDLEtBQUEsT0FBQUMsU0FBQTtBQUFBO0FBY3ZDO0FBQ0E7QUFDQTtBQUZBLFNBQUFGLDBCQUFBO0VBQUFBLHlCQUFBLEdBQUFHLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FkQSxTQUFBQyxTQUF3Q0MsRUFBa0IsRUFBRUMsSUFBYztJQUFBLElBQUFDLE1BQUEsRUFFekRDLFlBQVksRUFBQUMsYUFBQTtJQUFBLE9BQUFQLG1CQUFBLENBQUFRLElBQUEsVUFBQUMsVUFBQUMsU0FBQTtNQUFBLGtCQUFBQSxTQUFBLENBQUFDLElBQUEsR0FBQUQsU0FBQSxDQUFBRSxJQUFBO1FBQUE7VUFBQUwsYUFBQSxZQUFBTSxlQUFBO1lBQUFOLGFBQUEsR0FBQVIsaUJBQUEsY0FBQUMsbUJBQUEsQ0FBQUMsSUFBQSxDQUEzQixTQUFBYSxRQUFBO2NBQUEsSUFBQUMsa0JBQUEsRUFBQUMsSUFBQSxFQUFBQyxLQUFBO2NBQUEsT0FBQWpCLG1CQUFBLENBQUFRLElBQUEsVUFBQVUsU0FBQUMsUUFBQTtnQkFBQSxrQkFBQUEsUUFBQSxDQUFBUixJQUFBLEdBQUFRLFFBQUEsQ0FBQVAsSUFBQTtrQkFBQTtvQkFBQU8sUUFBQSxDQUFBUCxJQUFBO29CQUFBLE9BQ2dDUCxNQUFNLENBQUNlLElBQUksQ0FBQyxDQUFDO2tCQUFBO29CQUFBTCxrQkFBQSxHQUFBSSxRQUFBLENBQUFFLElBQUE7b0JBQW5DTCxJQUFJLEdBQUFELGtCQUFBLENBQUpDLElBQUk7b0JBQUVDLEtBQUssR0FBQUYsa0JBQUEsQ0FBTEUsS0FBSztvQkFBQSxLQUNmRCxJQUFJO3NCQUFBRyxRQUFBLENBQUFQLElBQUE7c0JBQUE7b0JBQUE7b0JBQ05SLElBQUksQ0FBQ2tCLEdBQUcsQ0FBQyxDQUFDO29CQUFDLE9BQUFILFFBQUEsQ0FBQUksTUFBQSxXQUNKLEtBQUs7a0JBQUE7b0JBRWRuQixJQUFJLENBQUNvQixLQUFLLENBQUNQLEtBQUssQ0FBQztvQkFBQyxPQUFBRSxRQUFBLENBQUFJLE1BQUEsV0FDWCxJQUFJO2tCQUFBO2tCQUFBO29CQUFBLE9BQUFKLFFBQUEsQ0FBQU0sSUFBQTtnQkFBQTtjQUFBLEdBQUFYLE9BQUE7WUFBQSxDQUNaO1lBQUEsT0FBQVAsYUFBQSxDQUFBVixLQUFBLE9BQUFDLFNBQUE7VUFBQTtVQVJjUSxZQUFZLFlBQUFvQixlQUFBO1lBQUEsT0FBQW5CLGFBQUEsQ0FBQVYsS0FBQSxPQUFBQyxTQUFBO1VBQUE7VUFEckJPLE1BQU0sR0FBR0YsRUFBRSxDQUFDd0IsU0FBUyxDQUFDLENBQUM7UUFBQTtVQUFBakIsU0FBQSxDQUFBRSxJQUFBO1VBQUEsT0FVaEJOLFlBQVksQ0FBQyxDQUFDO1FBQUE7VUFBQSxLQUFBSSxTQUFBLENBQUFXLElBQUE7WUFBQVgsU0FBQSxDQUFBRSxJQUFBO1lBQUE7VUFBQTtVQUFDO1VBQUNGLFNBQUEsQ0FBQUUsSUFBQTtVQUFBO1FBQUE7UUFBQTtVQUFBLE9BQUFGLFNBQUEsQ0FBQWUsSUFBQTtNQUFBO0lBQUEsR0FBQXZCLFFBQUE7RUFBQSxDQUM5QjtFQUFBLE9BQUFOLHlCQUFBLENBQUFDLEtBQUEsT0FBQUMsU0FBQTtBQUFBO0FBQUEsU0FLYzhCLGlCQUFpQkEsQ0FBQUMsR0FBQSxFQUFBQyxHQUFBLEVBQUFDLEdBQUEsRUFBQUMsR0FBQSxFQUFBQyxHQUFBO0VBQUEsT0FBQUMsa0JBQUEsQ0FBQXJDLEtBQUEsT0FBQUMsU0FBQTtBQUFBO0FBcUVoQztBQUNBO0FBQ0E7QUFGQSxTQUFBb0MsbUJBQUE7RUFBQUEsa0JBQUEsR0FBQW5DLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FyRUEsU0FBQWtDLFNBQ0VDLE9BQW9CLEVBQ3BCQyxPQUEyQixFQUMzQkMsS0FBMkIsRUFDM0JDLE1BQWdCLEVBQ2hCQyxPQUFxQjtJQUFBLElBQUFDLFNBQUE7SUFBQSxJQUFBQyxPQUFBO01BQUFDLGNBQUE7TUFBQUMsR0FBQTtNQUFBQyxPQUFBO01BQUFDLElBQUE7TUFBQUMsSUFBQTtNQUFBM0QsVUFBQTtNQUFBNEQsR0FBQTtNQUFBQyxPQUFBO01BQUFDLFNBQUE7TUFBQUMsS0FBQTtNQUFBQyxVQUFBO01BQUFDLFFBQUE7TUFBQUMsTUFBQSxHQUFBeEQsU0FBQTtJQUFBLE9BQUFFLG1CQUFBLENBQUFRLElBQUEsVUFBQStDLFVBQUFDLFNBQUE7TUFBQSxrQkFBQUEsU0FBQSxDQUFBN0MsSUFBQSxHQUFBNkMsU0FBQSxDQUFBNUMsSUFBQTtRQUFBO1VBQ3JCOEIsT0FBZSxHQUFBWSxNQUFBLENBQUFHLE1BQUEsUUFBQUgsTUFBQSxRQUFBSSxTQUFBLEdBQUFKLE1BQUEsTUFBRyxDQUFDO1VBRVhYLGNBQWMsR0FBS04sT0FBTyxDQUExQk0sY0FBYztVQUNkQyxHQUFHLEdBQTZCUixPQUFPLENBQXZDUSxHQUFHLEVBQVFDLE9BQU8sR0FBY1QsT0FBTyxDQUFsQ1csSUFBSSxFQUFjRCxJQUFJLEdBQUFhLHdCQUFBLENBQUt2QixPQUFPLEVBQUF3QixTQUFBO1VBQUEsTUFFN0N0QixLQUFLLElBQUkscUJBQXFCLENBQUN1QixJQUFJLENBQUN6QixPQUFPLENBQUMwQixNQUFNLENBQUM7WUFBQU4sU0FBQSxDQUFBNUMsSUFBQTtZQUFBO1VBQUE7VUFBQSxLQUMvQzdCLHNCQUFzQjtZQUFBeUUsU0FBQSxDQUFBNUMsSUFBQTtZQUFBO1VBQUE7VUFBQTRDLFNBQUEsQ0FBQU8sRUFBQSxHQUNwQi9FLHNCQUFzQixDQUFDc0QsS0FBSyxDQUFDO1VBQUFrQixTQUFBLENBQUE1QyxJQUFBO1VBQUE7UUFBQTtVQUFBNEMsU0FBQSxDQUFBNUMsSUFBQTtVQUFBLE9BQ3ZCOUIsT0FBTyxDQUFDd0QsS0FBSyxDQUFDO1FBQUE7VUFBQWtCLFNBQUEsQ0FBQU8sRUFBQSxHQUFBUCxTQUFBLENBQUFuQyxJQUFBO1FBQUE7VUFBQW1DLFNBQUEsQ0FBQVEsRUFBQSxHQUFBUixTQUFBLENBQUFPLEVBQUE7VUFBQVAsU0FBQSxDQUFBNUMsSUFBQTtVQUFBO1FBQUE7VUFBQTRDLFNBQUEsQ0FBQVEsRUFBQSxHQUN0Qk4sU0FBUztRQUFBO1VBTFRYLElBQUksR0FBQVMsU0FBQSxDQUFBUSxFQUFBO1VBTUo1RSxVQUFVLEdBQ2QsT0FBTzZFLGVBQWUsS0FBSyxXQUFXLEdBQUcsSUFBSUEsZUFBZSxDQUFDLENBQUMsR0FBR1AsU0FBUztVQUFBRixTQUFBLENBQUE1QyxJQUFBO1VBQUEsT0FDMURqQyxrQkFBa0IsQ0FDbEM7WUFBQSxPQUNFdUYsS0FBSyxDQUFDdEIsR0FBRyxFQUFBdUIsYUFBQSxDQUFBQSxhQUFBLENBQUFBLGFBQUEsQ0FBQUEsYUFBQSxLQUNKckIsSUFBSSxHQUNIQyxJQUFJLEdBQUc7Y0FBRUEsSUFBSSxFQUFKQTtZQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Y0FDeEJxQixRQUFRLEVBQUU7WUFBUSxHQUNkaEYsVUFBVSxHQUFHO2NBQUVpRixNQUFNLEVBQUVqRixVQUFVLENBQUNpRjtZQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsR0FDL0M7Y0FBRUMsNEJBQTRCLEVBQUU7WUFBSyxDQUFDLENBQzNDLENBQUM7VUFBQSxHQUNKakMsT0FBTyxDQUFDa0MsT0FBTyxFQUNmO1lBQUEsT0FBTW5GLFVBQVUsYUFBVkEsVUFBVSx1QkFBVkEsVUFBVSxDQUFFb0YsS0FBSyxDQUFDLENBQUM7VUFBQSxDQUMzQixDQUFDO1FBQUE7VUFYS3hCLEdBQUcsR0FBQVEsU0FBQSxDQUFBbkMsSUFBQTtVQVlINEIsT0FBK0IsR0FBRyxDQUFDLENBQUMsRUFDMUM7VUFBQUMsU0FBQSxHQUFBdUIsMEJBQUEsQ0FDeUJDLHFCQUFBLENBQUFqQyxTQUFBLEdBQUFPLEdBQUcsQ0FBQ0MsT0FBTyxFQUFBMEIsSUFBQSxDQUFBbEMsU0FBTSxDQUFDO1VBQUE7WUFBM0MsS0FBQVMsU0FBQSxDQUFBMEIsQ0FBQSxNQUFBekIsS0FBQSxHQUFBRCxTQUFBLENBQUEyQixDQUFBLElBQUE3RCxJQUFBLEdBQTZDO2NBQWxDb0MsVUFBVSxHQUFBRCxLQUFBLENBQUFsQyxLQUFBO2NBQ25CZ0MsT0FBTyxDQUFDRyxVQUFVLENBQUMwQixXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUc5QixHQUFHLENBQUNDLE9BQU8sQ0FBQzhCLEdBQUcsQ0FBQzNCLFVBQVUsQ0FBQztZQUNqRTtVQUFDLFNBQUE0QixHQUFBO1lBQUE5QixTQUFBLENBQUErQixDQUFBLENBQUFELEdBQUE7VUFBQTtZQUFBOUIsU0FBQSxDQUFBZ0MsQ0FBQTtVQUFBO1VBQ0s3QixRQUFRLEdBQUc7WUFDZjhCLFVBQVUsRUFBRW5DLEdBQUcsQ0FBQ29DLE1BQU07WUFDdEJuQyxPQUFPLEVBQVBBO1VBQ0YsQ0FBQztVQUFBLE1BQ0dOLGNBQWMsSUFBSS9ELFVBQVUsQ0FBQ3lFLFFBQVEsQ0FBQzhCLFVBQVUsQ0FBQztZQUFBM0IsU0FBQSxDQUFBNUMsSUFBQTtZQUFBO1VBQUE7VUFDbkQsSUFBSTtZQUNGL0Isc0JBQXNCLENBQ3BCdUQsT0FBTyxFQUNQaUIsUUFBUSxFQUNSVixjQUFjLEVBQ2RELE9BQU8sRUFDUCxVQUFDMkMsR0FBRztjQUFBLE9BQ0Z6RCxpQkFBaUIsQ0FDZnlELEdBQUcsRUFDSGhELE9BQU8sRUFDUHFCLFNBQVMsRUFDVG5CLE1BQU0sRUFDTkMsT0FBTyxFQUNQRSxPQUFPLEdBQUcsQ0FDWixDQUFDO1lBQUEsQ0FDTCxDQUFDO1VBQ0gsQ0FBQyxDQUFDLE9BQU9zQyxHQUFHLEVBQUU7WUFDWnhDLE9BQU8sQ0FBQzhDLElBQUksQ0FBQyxPQUFPLEVBQUVOLEdBQUcsQ0FBQztVQUM1QjtVQUFDLE9BQUF4QixTQUFBLENBQUFqQyxNQUFBO1FBQUE7VUFHSGlCLE9BQU8sQ0FBQzhDLElBQUksQ0FBQyxVQUFVLEVBQUVqQyxRQUFRLENBQUM7VUFDbEMsSUFBSUwsR0FBRyxDQUFDRCxJQUFJLEVBQUU7WUFDWnRELHdCQUF3QixDQUFDdUQsR0FBRyxDQUFDRCxJQUFJLEVBQUVSLE1BQU0sQ0FBQztVQUM1QyxDQUFDLE1BQU07WUFDTEEsTUFBTSxDQUFDakIsR0FBRyxDQUFDLENBQUM7VUFDZDtRQUFDO1FBQUE7VUFBQSxPQUFBa0MsU0FBQSxDQUFBL0IsSUFBQTtNQUFBO0lBQUEsR0FBQVUsUUFBQTtFQUFBLENBQ0Y7RUFBQSxPQUFBRCxrQkFBQSxDQUFBckMsS0FBQSxPQUFBQyxTQUFBO0FBQUE7QUFLRCxJQUFJeUYsUUFBNEIsR0FBRyxDQUFDLENBQUM7O0FBRXJDO0FBQ0E7QUFDQTtBQUNBLE9BQU8sU0FBU0MsV0FBV0EsQ0FBQ0MsU0FBNkIsRUFBRTtFQUN6REYsUUFBUSxHQUFHRSxTQUFTO0FBQ3RCOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsU0FBU3JELE9BQU9BLENBQzdCaUQsR0FBZ0IsRUFFaEI7RUFBQSxJQURBSyxRQUE0QixHQUFBNUYsU0FBQSxDQUFBMkQsTUFBQSxRQUFBM0QsU0FBQSxRQUFBNEQsU0FBQSxHQUFBNUQsU0FBQSxNQUFHLENBQUMsQ0FBQztFQUVqQyxJQUFNdUMsT0FBTyxHQUFBOEIsYUFBQSxDQUFBQSxhQUFBLEtBQVFvQixRQUFRLEdBQUtHLFFBQVEsQ0FBRTtFQUM1QyxJQUFBQyxxQkFBQSxHQUFrQ2pILCtCQUErQixDQUMvRDJHLEdBQUcsRUFDSGhELE9BQ0YsQ0FBQztJQUhPQyxLQUFLLEdBQUFxRCxxQkFBQSxDQUFMckQsS0FBSztJQUFFQyxNQUFNLEdBQUFvRCxxQkFBQSxDQUFOcEQsTUFBTTtJQUFFcUQsTUFBTSxHQUFBRCxxQkFBQSxDQUFOQyxNQUFNO0VBSTdCaEUsaUJBQWlCLENBQUN5RCxHQUFHLEVBQUVoRCxPQUFPLEVBQUVDLEtBQUssRUFBRUMsTUFBTSxFQUFFcUQsTUFBTSxDQUFDO0VBQ3RELE9BQU9BLE1BQU07QUFDZiIsImlnbm9yZUxpc3QiOltdfQ==