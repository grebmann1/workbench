import _Reflect$construct from "@babel/runtime-corejs3/core-js-stable/reflect/construct";
import _Object$keys from "@babel/runtime-corejs3/core-js-stable/object/keys";
import _Object$getOwnPropertySymbols from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-symbols";
import _filterInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/filter";
import _Object$getOwnPropertyDescriptor from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptor";
import _forEachInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/for-each";
import _Object$getOwnPropertyDescriptors from "@babel/runtime-corejs3/core-js-stable/object/get-own-property-descriptors";
import _Object$defineProperties from "@babel/runtime-corejs3/core-js-stable/object/define-properties";
import _Object$defineProperty from "@babel/runtime-corejs3/core-js-stable/object/define-property";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _possibleConstructorReturn from "@babel/runtime-corejs3/helpers/possibleConstructorReturn";
import _getPrototypeOf from "@babel/runtime-corejs3/helpers/getPrototypeOf";
import _inherits from "@babel/runtime-corejs3/helpers/inherits";
import _slicedToArray from "@babel/runtime-corejs3/helpers/slicedToArray";
function ownKeys(e, r) { var t = _Object$keys(e); if (_Object$getOwnPropertySymbols) { var o = _Object$getOwnPropertySymbols(e); r && (o = _filterInstanceProperty(o).call(o, function (r) { return _Object$getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var _context5, _context6; var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? _forEachInstanceProperty(_context5 = ownKeys(Object(t), !0)).call(_context5, function (r) { _defineProperty(e, r, t[r]); }) : _Object$getOwnPropertyDescriptors ? _Object$defineProperties(e, _Object$getOwnPropertyDescriptors(t)) : _forEachInstanceProperty(_context6 = ownKeys(Object(t))).call(_context6, function (r) { _Object$defineProperty(e, r, _Object$getOwnPropertyDescriptor(t, r)); }); } return e; }
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? _Reflect$construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(_Reflect$construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
import "core-js/modules/es.error.cause.js";
import "core-js/modules/es.array.join.js";
import "core-js/modules/es.number.constructor.js";
import "core-js/modules/es.object.keys.js";
import "core-js/modules/es.array.push.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.regexp.constructor.js";
import "core-js/modules/es.regexp.dot-all.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.regexp.sticky.js";
import "core-js/modules/es.regexp.to-string.js";
import "core-js/modules/es.string.match.js";
import "core-js/modules/es.string.search.js";
import _concatInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/concat";
import _Object$fromEntries from "@babel/runtime-corejs3/core-js-stable/object/from-entries";
import _URLSearchParams from "@babel/runtime-corejs3/core-js-stable/url-search-params";
import _setTimeout from "@babel/runtime-corejs3/core-js-stable/set-timeout";
import _JSON$stringify from "@babel/runtime-corejs3/core-js-stable/json/stringify";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _setInterval from "@babel/runtime-corejs3/core-js-stable/set-interval";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
import _reverseInstanceProperty from "@babel/runtime-corejs3/core-js-stable/instance/reverse";
/**
 * @file Browser client connection management class
 * @author Shinichi Tomita <shinichi.tomita@gmail.com>
 */
import { EventEmitter } from 'events';
import Connection from '../connection';
import OAuth2 from '../oauth2';

/**
 * @private
 */
function popupWin(url, w, h) {
  var _context, _context2, _context3;
  var left = screen.width / 2 - w / 2;
  var top = screen.height / 2 - h / 2;
  return window.open(url, undefined, _concatInstanceProperty(_context = _concatInstanceProperty(_context2 = _concatInstanceProperty(_context3 = "location=yes,toolbar=no,status=no,menubar=no,width=".concat(w, ",height=")).call(_context3, h, ",top=")).call(_context2, top, ",left=")).call(_context, left));
}

/**
 * @private
 */
function handleCallbackResponse() {
  var res = checkCallbackResponse();
  var state = localStorage.getItem('jsforce_state');
  if (res && state && res.body.get('state') === state) {
    localStorage.removeItem('jsforce_state');
    var _state$split = state.split('.'),
      _state$split2 = _slicedToArray(_state$split, 2),
      prefix = _state$split2[0],
      promptType = _state$split2[1];
    var cli = new BrowserClient(prefix);
    if (res.success) {
      cli._storeTokens(_Object$fromEntries(res.body));
      location.hash = '';
    } else {
      cli._storeError(res.body);
    }
    if (promptType === 'popup') {
      window.close();
    }
    return true;
  }
}

/**
 * @private
 */
function checkCallbackResponse() {
  var params;
  if (window.location.hash) {
    params = new _URLSearchParams(window.location.hash.substring(1));
    if (params.get('access_token')) {
      return {
        success: true,
        body: params
      };
    }
  } else if (window.location.search) {
    params = new _URLSearchParams(window.location.search.substring(1));
    if (params.get('error')) {
      return {
        success: false,
        body: params
      };
    }
  }
}

/**
 *
 */

/**
 *
 */
var DEFAULT_POPUP_WIN_WIDTH = 912;
var DEFAULT_POPUP_WIN_HEIGHT = 513;

/** @private **/
var clientIdx = 0;

/**
 *
 */
export var BrowserClient = /*#__PURE__*/function (_EventEmitter) {
  /**
   *
   */
  function BrowserClient(prefix) {
    var _this;
    _classCallCheck(this, BrowserClient);
    _this = _callSuper(this, BrowserClient);
    _this._prefix = prefix || 'jsforce' + clientIdx++;
    return _this;
  }
  _inherits(BrowserClient, _EventEmitter);
  return _createClass(BrowserClient, [{
    key: "connection",
    get: function get() {
      if (!this._connection) {
        this._connection = new Connection(this._config);
      }
      return this._connection;
    }

    /**
     *
     */
  }, {
    key: "init",
    value: function init(config) {
      var _this2 = this;
      if (handleCallbackResponse()) {
        return;
      }
      this._config = config;
      var tokens = this._getTokens();
      if (tokens) {
        this.connection._establish(tokens);
        _setTimeout(function () {
          _this2.emit('connect', _this2.connection);
        }, 10);
      }
    }

    /**
     *
     */
  }, {
    key: "login",
    value: function login() {
      var _this$_config,
        _size$width,
        _size$height,
        _this3 = this;
      var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
      var scope = options.scope,
        size = options.size;
      var oauth2 = new OAuth2((_this$_config = this._config) !== null && _this$_config !== void 0 ? _this$_config : {});
      var rand = Math.random().toString(36).substring(2);
      var state = [this._prefix, 'popup', rand].join('.');
      localStorage.setItem('jsforce_state', state);
      var authzUrl = oauth2.getAuthorizationUrl(_objectSpread({
        response_type: 'token',
        prompt: 'login consent',
        state: state + "#".concat(_JSON$stringify({
          loginUrl: oauth2.loginUrl,
          redirectUri: oauth2.redirectUri
        }))
      }, scope ? {
        scope: scope
      } : {}));
      var pw = popupWin(authzUrl, (_size$width = size === null || size === void 0 ? void 0 : size.width) !== null && _size$width !== void 0 ? _size$width : DEFAULT_POPUP_WIN_WIDTH, (_size$height = size === null || size === void 0 ? void 0 : size.height) !== null && _size$height !== void 0 ? _size$height : DEFAULT_POPUP_WIN_HEIGHT);
      return new _Promise(function (resolve, reject) {
        if (!pw) {
          var _state = [_this3._prefix, 'redirect', rand].join('.');
          localStorage.setItem('jsforce_state', _state);
          var _authzUrl = oauth2.getAuthorizationUrl(_objectSpread({
            response_type: 'token',
            prompt: 'consent',
            state: _state + "#".concat(_JSON$stringify({
              loginUrl: oauth2.loginUrl,
              redirectUri: oauth2.redirectUri
            }))
          }, scope ? {
            scope: scope
          } : {}));
          location.href = _authzUrl;
          return;
        }
        _this3._removeTokens();
        var pid = _setInterval(function () {
          try {
            if (!pw || pw.closed) {
              clearInterval(pid);
              var tokens = _this3._getTokens();
              if (tokens) {
                _this3.connection._establish(tokens);
                _this3.emit('connect', _this3.connection);
                resolve({
                  status: 'connect'
                });
              } else {
                var err = _this3._getError();
                if (err) {
                  reject(new Error(err.error + ': ' + err.error_description));
                } else {
                  resolve({
                    status: 'cancel'
                  });
                }
              }
            }
          } catch (e) {
            //
            console.log('custom error', e);
          }
        }, 1000);
      });
    }

    /**
     *
     */
  }, {
    key: "isLoggedIn",
    value: function isLoggedIn() {
      return !!this.connection.accessToken;
    }

    /**
     *
     */
  }, {
    key: "logout",
    value: function logout() {
      this.connection.logout();
      this._removeTokens();
      this.emit('disconnect');
    }

    /**
     * @private
     */
  }, {
    key: "_getTokens",
    value: function _getTokens() {
      var regexp = new RegExp('(^|;\\s*)' + this._prefix + '_loggedin=true(;|$)');
      if (document.cookie.match(regexp)) {
        var issuedAt = Number(localStorage.getItem(this._prefix + '_issued_at'));
        // 2 hours
        if (_Date$now() < issuedAt + 2 * 60 * 60 * 1000) {
          var userInfo;
          var idUrl = localStorage.getItem(this._prefix + '_id');
          if (idUrl) {
            var _context4;
            var _idUrl$split$reverse = _reverseInstanceProperty(_context4 = idUrl.split('/')).call(_context4),
              _idUrl$split$reverse2 = _slicedToArray(_idUrl$split$reverse, 2),
              id = _idUrl$split$reverse2[0],
              organizationId = _idUrl$split$reverse2[1];
            userInfo = {
              id: id,
              organizationId: organizationId,
              url: idUrl
            };
          }
          return {
            accessToken: localStorage.getItem(this._prefix + '_access_token'),
            instanceUrl: localStorage.getItem(this._prefix + '_instance_url'),
            refreshToken: localStorage.getItem(this._prefix + '_refresh_token'),
            userInfo: userInfo
          };
        }
      }
      return null;
    }

    /**
     * @private
     */
  }, {
    key: "_storeTokens",
    value: function _storeTokens(params) {
      localStorage.setItem(this._prefix + '_access_token', params.access_token);
      localStorage.setItem(this._prefix + '_instance_url', params.instance_url);
      localStorage.setItem(this._prefix + '_issued_at', params.issued_at);
      localStorage.setItem(this._prefix + '_id', params.id);
      if (params.refresh_token) {
        localStorage.setItem(this._prefix + '_refresh_token', params.refresh_token);
      }
      document.cookie = this._prefix + '_loggedin=true;';
    }

    /**
     * @private
     */
  }, {
    key: "_removeTokens",
    value: function _removeTokens() {
      localStorage.removeItem(this._prefix + '_access_token');
      localStorage.removeItem(this._prefix + '_instance_url');
      localStorage.removeItem(this._prefix + '_issued_at');
      localStorage.removeItem(this._prefix + '_id');
      document.cookie = this._prefix + '_loggedin=';
    }

    /**
     * @private
     */
  }, {
    key: "_getError",
    value: function _getError() {
      try {
        var _localStorage$getItem;
        var err = JSON.parse((_localStorage$getItem = localStorage.getItem(this._prefix + '_error')) !== null && _localStorage$getItem !== void 0 ? _localStorage$getItem : '');
        localStorage.removeItem(this._prefix + '_error');
        return err;
      } catch (e) {
        //
      }
    }

    /**
     * @private
     */
  }, {
    key: "_storeError",
    value: function _storeError(err) {
      localStorage.setItem(this._prefix + '_error', _JSON$stringify(err));
    }
  }]);
}(EventEmitter);

/**
 *
 */
var client = new BrowserClient();
export default client;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJFdmVudEVtaXR0ZXIiLCJDb25uZWN0aW9uIiwiT0F1dGgyIiwicG9wdXBXaW4iLCJ1cmwiLCJ3IiwiaCIsIl9jb250ZXh0IiwiX2NvbnRleHQyIiwiX2NvbnRleHQzIiwibGVmdCIsInNjcmVlbiIsIndpZHRoIiwidG9wIiwiaGVpZ2h0Iiwid2luZG93Iiwib3BlbiIsInVuZGVmaW5lZCIsIl9jb25jYXRJbnN0YW5jZVByb3BlcnR5IiwiY29uY2F0IiwiY2FsbCIsImhhbmRsZUNhbGxiYWNrUmVzcG9uc2UiLCJyZXMiLCJjaGVja0NhbGxiYWNrUmVzcG9uc2UiLCJzdGF0ZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJib2R5IiwiZ2V0IiwicmVtb3ZlSXRlbSIsIl9zdGF0ZSRzcGxpdCIsInNwbGl0IiwiX3N0YXRlJHNwbGl0MiIsIl9zbGljZWRUb0FycmF5IiwicHJlZml4IiwicHJvbXB0VHlwZSIsImNsaSIsIkJyb3dzZXJDbGllbnQiLCJzdWNjZXNzIiwiX3N0b3JlVG9rZW5zIiwiX09iamVjdCRmcm9tRW50cmllcyIsImxvY2F0aW9uIiwiaGFzaCIsIl9zdG9yZUVycm9yIiwiY2xvc2UiLCJwYXJhbXMiLCJfVVJMU2VhcmNoUGFyYW1zIiwic3Vic3RyaW5nIiwic2VhcmNoIiwiREVGQVVMVF9QT1BVUF9XSU5fV0lEVEgiLCJERUZBVUxUX1BPUFVQX1dJTl9IRUlHSFQiLCJjbGllbnRJZHgiLCJfRXZlbnRFbWl0dGVyIiwiX3RoaXMiLCJfY2xhc3NDYWxsQ2hlY2siLCJfY2FsbFN1cGVyIiwiX3ByZWZpeCIsIl9pbmhlcml0cyIsIl9jcmVhdGVDbGFzcyIsImtleSIsIl9jb25uZWN0aW9uIiwiX2NvbmZpZyIsInZhbHVlIiwiaW5pdCIsImNvbmZpZyIsIl90aGlzMiIsInRva2VucyIsIl9nZXRUb2tlbnMiLCJjb25uZWN0aW9uIiwiX2VzdGFibGlzaCIsIl9zZXRUaW1lb3V0IiwiZW1pdCIsImxvZ2luIiwiX3RoaXMkX2NvbmZpZyIsIl9zaXplJHdpZHRoIiwiX3NpemUkaGVpZ2h0IiwiX3RoaXMzIiwib3B0aW9ucyIsImFyZ3VtZW50cyIsImxlbmd0aCIsInNjb3BlIiwic2l6ZSIsIm9hdXRoMiIsInJhbmQiLCJNYXRoIiwicmFuZG9tIiwidG9TdHJpbmciLCJqb2luIiwic2V0SXRlbSIsImF1dGh6VXJsIiwiZ2V0QXV0aG9yaXphdGlvblVybCIsIl9vYmplY3RTcHJlYWQiLCJyZXNwb25zZV90eXBlIiwicHJvbXB0IiwiX0pTT04kc3RyaW5naWZ5IiwibG9naW5VcmwiLCJyZWRpcmVjdFVyaSIsInB3IiwiX1Byb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwiaHJlZiIsIl9yZW1vdmVUb2tlbnMiLCJwaWQiLCJfc2V0SW50ZXJ2YWwiLCJjbG9zZWQiLCJjbGVhckludGVydmFsIiwic3RhdHVzIiwiZXJyIiwiX2dldEVycm9yIiwiRXJyb3IiLCJlcnJvciIsImVycm9yX2Rlc2NyaXB0aW9uIiwiZSIsImNvbnNvbGUiLCJsb2ciLCJpc0xvZ2dlZEluIiwiYWNjZXNzVG9rZW4iLCJsb2dvdXQiLCJyZWdleHAiLCJSZWdFeHAiLCJkb2N1bWVudCIsImNvb2tpZSIsIm1hdGNoIiwiaXNzdWVkQXQiLCJOdW1iZXIiLCJfRGF0ZSRub3ciLCJ1c2VySW5mbyIsImlkVXJsIiwiX2NvbnRleHQ0IiwiX2lkVXJsJHNwbGl0JHJldmVyc2UiLCJfcmV2ZXJzZUluc3RhbmNlUHJvcGVydHkiLCJfaWRVcmwkc3BsaXQkcmV2ZXJzZTIiLCJpZCIsIm9yZ2FuaXphdGlvbklkIiwiaW5zdGFuY2VVcmwiLCJyZWZyZXNoVG9rZW4iLCJhY2Nlc3NfdG9rZW4iLCJpbnN0YW5jZV91cmwiLCJpc3N1ZWRfYXQiLCJyZWZyZXNoX3Rva2VuIiwiX2xvY2FsU3RvcmFnZSRnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwiY2xpZW50Il0sInNvdXJjZXMiOlsiLi4vLi4vc3JjL2Jyb3dzZXIvY2xpZW50LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGZpbGUgQnJvd3NlciBjbGllbnQgY29ubmVjdGlvbiBtYW5hZ2VtZW50IGNsYXNzXG4gKiBAYXV0aG9yIFNoaW5pY2hpIFRvbWl0YSA8c2hpbmljaGkudG9taXRhQGdtYWlsLmNvbT5cbiAqL1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJztcbmltcG9ydCBDb25uZWN0aW9uLCB7IENvbm5lY3Rpb25Db25maWcgfSBmcm9tICcuLi9jb25uZWN0aW9uJztcbmltcG9ydCBPQXV0aDIsIHsgVG9rZW5SZXNwb25zZSB9IGZyb20gJy4uL29hdXRoMic7XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gcG9wdXBXaW4odXJsOiBzdHJpbmcsIHc6IG51bWJlciwgaDogbnVtYmVyKSB7XG4gIGNvbnN0IGxlZnQgPSBzY3JlZW4ud2lkdGggLyAyIC0gdyAvIDI7XG4gIGNvbnN0IHRvcCA9IHNjcmVlbi5oZWlnaHQgLyAyIC0gaCAvIDI7XG4gIHJldHVybiB3aW5kb3cub3BlbihcbiAgICB1cmwsXG4gICAgdW5kZWZpbmVkLFxuICAgIGBsb2NhdGlvbj15ZXMsdG9vbGJhcj1ubyxzdGF0dXM9bm8sbWVudWJhcj1ubyx3aWR0aD0ke3d9LGhlaWdodD0ke2h9LHRvcD0ke3RvcH0sbGVmdD0ke2xlZnR9YCxcbiAgKTtcbn1cblxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBoYW5kbGVDYWxsYmFja1Jlc3BvbnNlKCkge1xuICBjb25zdCByZXMgPSBjaGVja0NhbGxiYWNrUmVzcG9uc2UoKTtcbiAgY29uc3Qgc3RhdGUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnanNmb3JjZV9zdGF0ZScpO1xuICBpZiAocmVzICYmIHN0YXRlICYmIHJlcy5ib2R5LmdldCgnc3RhdGUnKSA9PT0gc3RhdGUpIHtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnanNmb3JjZV9zdGF0ZScpO1xuICAgIGNvbnN0IFtwcmVmaXgsIHByb21wdFR5cGVdID0gc3RhdGUuc3BsaXQoJy4nKTtcbiAgICBjb25zdCBjbGkgPSBuZXcgQnJvd3NlckNsaWVudChwcmVmaXgpO1xuICAgIGlmIChyZXMuc3VjY2Vzcykge1xuICAgICAgY2xpLl9zdG9yZVRva2VucyhPYmplY3QuZnJvbUVudHJpZXMocmVzLmJvZHkpIGFzIFRva2VuUmVzcG9uc2UpO1xuICAgICAgbG9jYXRpb24uaGFzaCA9ICcnO1xuICAgIH0gZWxzZSB7XG4gICAgICBjbGkuX3N0b3JlRXJyb3IocmVzLmJvZHkpO1xuICAgIH1cbiAgICBpZiAocHJvbXB0VHlwZSA9PT0gJ3BvcHVwJykge1xuICAgICAgd2luZG93LmNsb3NlKCk7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gY2hlY2tDYWxsYmFja1Jlc3BvbnNlKCkge1xuICBsZXQgcGFyYW1zO1xuICBpZiAod2luZG93LmxvY2F0aW9uLmhhc2gpIHtcbiAgICBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHdpbmRvdy5sb2NhdGlvbi5oYXNoLnN1YnN0cmluZygxKSk7XG4gICAgaWYgKHBhcmFtcy5nZXQoJ2FjY2Vzc190b2tlbicpKSB7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBib2R5OiBwYXJhbXMgfTtcbiAgICB9XG4gIH0gZWxzZSBpZiAod2luZG93LmxvY2F0aW9uLnNlYXJjaCkge1xuICAgIHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMod2luZG93LmxvY2F0aW9uLnNlYXJjaC5zdWJzdHJpbmcoMSkpO1xuICAgIGlmIChwYXJhbXMuZ2V0KCdlcnJvcicpKSB7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgYm9keTogcGFyYW1zIH07XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IHR5cGUgTG9naW5PcHRpb25zID0ge1xuICBzY29wZT86IHN0cmluZztcbiAgc2l6ZT86IHsgd2lkdGg6IG51bWJlcjsgaGVpZ2h0OiBudW1iZXIgfTtcbn07XG5cbi8qKlxuICpcbiAqL1xuY29uc3QgREVGQVVMVF9QT1BVUF9XSU5fV0lEVEggPSA5MTI7XG5jb25zdCBERUZBVUxUX1BPUFVQX1dJTl9IRUlHSFQgPSA1MTM7XG5cbi8qKiBAcHJpdmF0ZSAqKi9cbmxldCBjbGllbnRJZHggPSAwO1xuXG4vKipcbiAqXG4gKi9cbmV4cG9ydCBjbGFzcyBCcm93c2VyQ2xpZW50IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgX3ByZWZpeDogc3RyaW5nO1xuICBfY29uZmlnOiBDb25uZWN0aW9uQ29uZmlnIHwgdW5kZWZpbmVkO1xuICBfY29ubmVjdGlvbjogQ29ubmVjdGlvbiB8IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICpcbiAgICovXG4gIGNvbnN0cnVjdG9yKHByZWZpeD86IHN0cmluZykge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5fcHJlZml4ID0gcHJlZml4IHx8ICdqc2ZvcmNlJyArIGNsaWVudElkeCsrO1xuICB9XG5cbiAgZ2V0IGNvbm5lY3Rpb24oKTogQ29ubmVjdGlvbiB7XG4gICAgaWYgKCF0aGlzLl9jb25uZWN0aW9uKSB7XG4gICAgICB0aGlzLl9jb25uZWN0aW9uID0gbmV3IENvbm5lY3Rpb24odGhpcy5fY29uZmlnKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm5lY3Rpb247XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGluaXQoY29uZmlnOiBDb25uZWN0aW9uQ29uZmlnKSB7XG4gICAgaWYgKGhhbmRsZUNhbGxiYWNrUmVzcG9uc2UoKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLl9jb25maWcgPSBjb25maWc7XG4gICAgY29uc3QgdG9rZW5zID0gdGhpcy5fZ2V0VG9rZW5zKCk7XG4gICAgaWYgKHRva2Vucykge1xuICAgICAgdGhpcy5jb25uZWN0aW9uLl9lc3RhYmxpc2godG9rZW5zKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLmVtaXQoJ2Nvbm5lY3QnLCB0aGlzLmNvbm5lY3Rpb24pO1xuICAgICAgfSwgMTApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgbG9naW4ob3B0aW9uczogTG9naW5PcHRpb25zID0ge30pIHtcbiAgICBjb25zdCB7IHNjb3BlLCBzaXplIH0gPSBvcHRpb25zO1xuICAgIGNvbnN0IG9hdXRoMiA9IG5ldyBPQXV0aDIodGhpcy5fY29uZmlnID8/IHt9KTtcbiAgICBjb25zdCByYW5kID0gTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyaW5nKDIpO1xuICAgIGNvbnN0IHN0YXRlID0gW3RoaXMuX3ByZWZpeCwgJ3BvcHVwJywgcmFuZF0uam9pbignLicpO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdqc2ZvcmNlX3N0YXRlJywgc3RhdGUpO1xuICAgIGNvbnN0IGF1dGh6VXJsID0gb2F1dGgyLmdldEF1dGhvcml6YXRpb25Vcmwoe1xuICAgICAgcmVzcG9uc2VfdHlwZTogJ3Rva2VuJyxcbiAgICAgIHByb21wdDonbG9naW4gY29uc2VudCcsXG4gICAgICBzdGF0ZTogc3RhdGUgK2AjJHtKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIGxvZ2luVXJsOm9hdXRoMi5sb2dpblVybCxcbiAgICAgICAgcmVkaXJlY3RVcmk6b2F1dGgyLnJlZGlyZWN0VXJpXG4gICAgfSl9YCxcbiAgICAgIC4uLihzY29wZSA/IHsgc2NvcGUgfSA6IHt9KSxcbiAgICB9KTtcbiAgICBjb25zdCBwdyA9IHBvcHVwV2luKFxuICAgICAgYXV0aHpVcmwsXG4gICAgICBzaXplPy53aWR0aCA/PyBERUZBVUxUX1BPUFVQX1dJTl9XSURUSCxcbiAgICAgIHNpemU/LmhlaWdodCA/PyBERUZBVUxUX1BPUFVQX1dJTl9IRUlHSFQsXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFByb21pc2U8eyBzdGF0dXM6IHN0cmluZyB9PigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBpZiAoIXB3KSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gW3RoaXMuX3ByZWZpeCwgJ3JlZGlyZWN0JywgcmFuZF0uam9pbignLicpO1xuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnanNmb3JjZV9zdGF0ZScsIHN0YXRlKTtcbiAgICAgICAgY29uc3QgYXV0aHpVcmwgPSBvYXV0aDIuZ2V0QXV0aG9yaXphdGlvblVybCh7XG4gICAgICAgICAgcmVzcG9uc2VfdHlwZTogJ3Rva2VuJyxcbiAgICAgICAgICBwcm9tcHQ6J2NvbnNlbnQnLFxuICAgICAgICAgICAgc3RhdGU6IHN0YXRlICtgIyR7SlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICBsb2dpblVybDpvYXV0aDIubG9naW5VcmwsXG4gICAgICAgICAgICAgIHJlZGlyZWN0VXJpOm9hdXRoMi5yZWRpcmVjdFVyaVxuICAgICAgICAgIH0pfWAsXG4gICAgICAgICAgLi4uKHNjb3BlID8geyBzY29wZSB9IDoge30pLFxuICAgICAgICB9KTtcbiAgICAgICAgbG9jYXRpb24uaHJlZiA9IGF1dGh6VXJsO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB0aGlzLl9yZW1vdmVUb2tlbnMoKTtcbiAgICAgIGNvbnN0IHBpZCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAoIXB3IHx8IHB3LmNsb3NlZCkge1xuICAgICAgICAgICAgY2xlYXJJbnRlcnZhbChwaWQpO1xuICAgICAgICAgICAgY29uc3QgdG9rZW5zID0gdGhpcy5fZ2V0VG9rZW5zKCk7XG4gICAgICAgICAgICBpZiAodG9rZW5zKSB7XG4gICAgICAgICAgICAgIHRoaXMuY29ubmVjdGlvbi5fZXN0YWJsaXNoKHRva2Vucyk7XG4gICAgICAgICAgICAgIHRoaXMuZW1pdCgnY29ubmVjdCcsIHRoaXMuY29ubmVjdGlvbik7XG4gICAgICAgICAgICAgIHJlc29sdmUoeyBzdGF0dXM6ICdjb25uZWN0JyB9KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGNvbnN0IGVyciA9IHRoaXMuX2dldEVycm9yKCk7XG4gICAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICByZWplY3QobmV3IEVycm9yKGVyci5lcnJvciArICc6ICcgKyBlcnIuZXJyb3JfZGVzY3JpcHRpb24pKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHsgc3RhdHVzOiAnY2FuY2VsJyB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIC8vXG4gICAgICAgICAgY29uc29sZS5sb2coJ2N1c3RvbSBlcnJvcicsIGUpO1xuICAgICAgICB9XG4gICAgICB9LCAxMDAwKTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKi9cbiAgaXNMb2dnZWRJbigpIHtcbiAgICByZXR1cm4gISF0aGlzLmNvbm5lY3Rpb24uYWNjZXNzVG9rZW47XG4gIH1cblxuICAvKipcbiAgICpcbiAgICovXG4gIGxvZ291dCgpIHtcbiAgICB0aGlzLmNvbm5lY3Rpb24ubG9nb3V0KCk7XG4gICAgdGhpcy5fcmVtb3ZlVG9rZW5zKCk7XG4gICAgdGhpcy5lbWl0KCdkaXNjb25uZWN0Jyk7XG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9nZXRUb2tlbnMoKSB7XG4gICAgY29uc3QgcmVnZXhwID0gbmV3IFJlZ0V4cChcbiAgICAgICcoXnw7XFxcXHMqKScgKyB0aGlzLl9wcmVmaXggKyAnX2xvZ2dlZGluPXRydWUoO3wkKScsXG4gICAgKTtcbiAgICBpZiAoZG9jdW1lbnQuY29va2llLm1hdGNoKHJlZ2V4cCkpIHtcbiAgICAgIGNvbnN0IGlzc3VlZEF0ID0gTnVtYmVyKFxuICAgICAgICBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2lzc3VlZF9hdCcpLFxuICAgICAgKTtcbiAgICAgIC8vIDIgaG91cnNcbiAgICAgIGlmIChEYXRlLm5vdygpIDwgaXNzdWVkQXQgKyAyICogNjAgKiA2MCAqIDEwMDApIHtcbiAgICAgICAgbGV0IHVzZXJJbmZvO1xuICAgICAgICBjb25zdCBpZFVybCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfaWQnKTtcbiAgICAgICAgaWYgKGlkVXJsKSB7XG4gICAgICAgICAgY29uc3QgW2lkLCBvcmdhbml6YXRpb25JZF0gPSBpZFVybC5zcGxpdCgnLycpLnJldmVyc2UoKTtcbiAgICAgICAgICB1c2VySW5mbyA9IHsgaWQsIG9yZ2FuaXphdGlvbklkLCB1cmw6IGlkVXJsIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBhY2Nlc3NUb2tlbjogbG9jYWxTdG9yYWdlLmdldEl0ZW0odGhpcy5fcHJlZml4ICsgJ19hY2Nlc3NfdG9rZW4nKSxcbiAgICAgICAgICBpbnN0YW5jZVVybDogbG9jYWxTdG9yYWdlLmdldEl0ZW0odGhpcy5fcHJlZml4ICsgJ19pbnN0YW5jZV91cmwnKSxcbiAgICAgICAgICByZWZyZXNoVG9rZW46IGxvY2FsU3RvcmFnZS5nZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfcmVmcmVzaF90b2tlbicpLFxuICAgICAgICAgIHVzZXJJbmZvLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX3N0b3JlVG9rZW5zKHBhcmFtczogVG9rZW5SZXNwb25zZSkge1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfYWNjZXNzX3Rva2VuJywgcGFyYW1zLmFjY2Vzc190b2tlbik7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0odGhpcy5fcHJlZml4ICsgJ19pbnN0YW5jZV91cmwnLCBwYXJhbXMuaW5zdGFuY2VfdXJsKTtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2lzc3VlZF9hdCcsIHBhcmFtcy5pc3N1ZWRfYXQpO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfaWQnLCBwYXJhbXMuaWQpO1xuICAgIGlmKHBhcmFtcy5yZWZyZXNoX3Rva2VuKXtcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKHRoaXMuX3ByZWZpeCArICdfcmVmcmVzaF90b2tlbicsIHBhcmFtcy5yZWZyZXNoX3Rva2VuKTtcbiAgICB9XG4gICAgZG9jdW1lbnQuY29va2llID0gdGhpcy5fcHJlZml4ICsgJ19sb2dnZWRpbj10cnVlOyc7XG4gIH1cblxuICAvKipcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9yZW1vdmVUb2tlbnMoKSB7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0odGhpcy5fcHJlZml4ICsgJ19hY2Nlc3NfdG9rZW4nKTtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSh0aGlzLl9wcmVmaXggKyAnX2luc3RhbmNlX3VybCcpO1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKHRoaXMuX3ByZWZpeCArICdfaXNzdWVkX2F0Jyk7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0odGhpcy5fcHJlZml4ICsgJ19pZCcpO1xuICAgIGRvY3VtZW50LmNvb2tpZSA9IHRoaXMuX3ByZWZpeCArICdfbG9nZ2VkaW49JztcbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2dldEVycm9yKCkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBlcnIgPSBKU09OLnBhcnNlKFxuICAgICAgICBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2Vycm9yJykgPz8gJycsXG4gICAgICApO1xuICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0odGhpcy5fcHJlZml4ICsgJ19lcnJvcicpO1xuICAgICAgcmV0dXJuIGVycjtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvL1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX3N0b3JlRXJyb3IoZXJyOiBhbnkpIHtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aGlzLl9wcmVmaXggKyAnX2Vycm9yJywgSlNPTi5zdHJpbmdpZnkoZXJyKSk7XG4gIH1cbn1cblxuLyoqXG4gKlxuICovXG5jb25zdCBjbGllbnQgPSBuZXcgQnJvd3NlckNsaWVudCgpO1xuXG5leHBvcnQgZGVmYXVsdCBjbGllbnQ7XG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0EsWUFBWSxRQUFRLFFBQVE7QUFDckMsT0FBT0MsVUFBVSxNQUE0QixlQUFlO0FBQzVELE9BQU9DLE1BQU0sTUFBeUIsV0FBVzs7QUFFakQ7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsUUFBUUEsQ0FBQ0MsR0FBVyxFQUFFQyxDQUFTLEVBQUVDLENBQVMsRUFBRTtFQUFBLElBQUFDLFFBQUEsRUFBQUMsU0FBQSxFQUFBQyxTQUFBO0VBQ25ELElBQU1DLElBQUksR0FBR0MsTUFBTSxDQUFDQyxLQUFLLEdBQUcsQ0FBQyxHQUFHUCxDQUFDLEdBQUcsQ0FBQztFQUNyQyxJQUFNUSxHQUFHLEdBQUdGLE1BQU0sQ0FBQ0csTUFBTSxHQUFHLENBQUMsR0FBR1IsQ0FBQyxHQUFHLENBQUM7RUFDckMsT0FBT1MsTUFBTSxDQUFDQyxJQUFJLENBQ2hCWixHQUFHLEVBQ0hhLFNBQVMsRUFBQUMsdUJBQUEsQ0FBQVgsUUFBQSxHQUFBVyx1QkFBQSxDQUFBVixTQUFBLEdBQUFVLHVCQUFBLENBQUFULFNBQUEseURBQUFVLE1BQUEsQ0FDNkNkLENBQUMsZUFBQWUsSUFBQSxDQUFBWCxTQUFBLEVBQVdILENBQUMsWUFBQWMsSUFBQSxDQUFBWixTQUFBLEVBQVFLLEdBQUcsYUFBQU8sSUFBQSxDQUFBYixRQUFBLEVBQVNHLElBQUksQ0FDN0YsQ0FBQztBQUNIOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVNXLHNCQUFzQkEsQ0FBQSxFQUFHO0VBQ2hDLElBQU1DLEdBQUcsR0FBR0MscUJBQXFCLENBQUMsQ0FBQztFQUNuQyxJQUFNQyxLQUFLLEdBQUdDLFlBQVksQ0FBQ0MsT0FBTyxDQUFDLGVBQWUsQ0FBQztFQUNuRCxJQUFJSixHQUFHLElBQUlFLEtBQUssSUFBSUYsR0FBRyxDQUFDSyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBS0osS0FBSyxFQUFFO0lBQ25EQyxZQUFZLENBQUNJLFVBQVUsQ0FBQyxlQUFlLENBQUM7SUFDeEMsSUFBQUMsWUFBQSxHQUE2Qk4sS0FBSyxDQUFDTyxLQUFLLENBQUMsR0FBRyxDQUFDO01BQUFDLGFBQUEsR0FBQUMsY0FBQSxDQUFBSCxZQUFBO01BQXRDSSxNQUFNLEdBQUFGLGFBQUE7TUFBRUcsVUFBVSxHQUFBSCxhQUFBO0lBQ3pCLElBQU1JLEdBQUcsR0FBRyxJQUFJQyxhQUFhLENBQUNILE1BQU0sQ0FBQztJQUNyQyxJQUFJWixHQUFHLENBQUNnQixPQUFPLEVBQUU7TUFDZkYsR0FBRyxDQUFDRyxZQUFZLENBQUNDLG1CQUFBLENBQW1CbEIsR0FBRyxDQUFDSyxJQUFJLENBQWtCLENBQUM7TUFDL0RjLFFBQVEsQ0FBQ0MsSUFBSSxHQUFHLEVBQUU7SUFDcEIsQ0FBQyxNQUFNO01BQ0xOLEdBQUcsQ0FBQ08sV0FBVyxDQUFDckIsR0FBRyxDQUFDSyxJQUFJLENBQUM7SUFDM0I7SUFDQSxJQUFJUSxVQUFVLEtBQUssT0FBTyxFQUFFO01BQzFCcEIsTUFBTSxDQUFDNkIsS0FBSyxDQUFDLENBQUM7SUFDaEI7SUFDQSxPQUFPLElBQUk7RUFDYjtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBLFNBQVNyQixxQkFBcUJBLENBQUEsRUFBRztFQUMvQixJQUFJc0IsTUFBTTtFQUNWLElBQUk5QixNQUFNLENBQUMwQixRQUFRLENBQUNDLElBQUksRUFBRTtJQUN4QkcsTUFBTSxHQUFHLElBQUFDLGdCQUFBLENBQW9CL0IsTUFBTSxDQUFDMEIsUUFBUSxDQUFDQyxJQUFJLENBQUNLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMvRCxJQUFJRixNQUFNLENBQUNqQixHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUU7TUFDOUIsT0FBTztRQUFFVSxPQUFPLEVBQUUsSUFBSTtRQUFFWCxJQUFJLEVBQUVrQjtNQUFPLENBQUM7SUFDeEM7RUFDRixDQUFDLE1BQU0sSUFBSTlCLE1BQU0sQ0FBQzBCLFFBQVEsQ0FBQ08sTUFBTSxFQUFFO0lBQ2pDSCxNQUFNLEdBQUcsSUFBQUMsZ0JBQUEsQ0FBb0IvQixNQUFNLENBQUMwQixRQUFRLENBQUNPLE1BQU0sQ0FBQ0QsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2pFLElBQUlGLE1BQU0sQ0FBQ2pCLEdBQUcsQ0FBQyxPQUFPLENBQUMsRUFBRTtNQUN2QixPQUFPO1FBQUVVLE9BQU8sRUFBRSxLQUFLO1FBQUVYLElBQUksRUFBRWtCO01BQU8sQ0FBQztJQUN6QztFQUNGO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBOztBQU1BO0FBQ0E7QUFDQTtBQUNBLElBQU1JLHVCQUF1QixHQUFHLEdBQUc7QUFDbkMsSUFBTUMsd0JBQXdCLEdBQUcsR0FBRzs7QUFFcEM7QUFDQSxJQUFJQyxTQUFTLEdBQUcsQ0FBQzs7QUFFakI7QUFDQTtBQUNBO0FBQ0EsV0FBYWQsYUFBYSwwQkFBQWUsYUFBQTtFQUt4QjtBQUNGO0FBQ0E7RUFDRSxTQUFBZixjQUFZSCxNQUFlLEVBQUU7SUFBQSxJQUFBbUIsS0FBQTtJQUFBQyxlQUFBLE9BQUFqQixhQUFBO0lBQzNCZ0IsS0FBQSxHQUFBRSxVQUFBLE9BQUFsQixhQUFBO0lBQ0FnQixLQUFBLENBQUtHLE9BQU8sR0FBR3RCLE1BQU0sSUFBSSxTQUFTLEdBQUdpQixTQUFTLEVBQUU7SUFBQyxPQUFBRSxLQUFBO0VBQ25EO0VBQUNJLFNBQUEsQ0FBQXBCLGFBQUEsRUFBQWUsYUFBQTtFQUFBLE9BQUFNLFlBQUEsQ0FBQXJCLGFBQUE7SUFBQXNCLEdBQUE7SUFBQS9CLEdBQUEsRUFFRCxTQUFBQSxJQUFBLEVBQTZCO01BQzNCLElBQUksQ0FBQyxJQUFJLENBQUNnQyxXQUFXLEVBQUU7UUFDckIsSUFBSSxDQUFDQSxXQUFXLEdBQUcsSUFBSTNELFVBQVUsQ0FBQyxJQUFJLENBQUM0RCxPQUFPLENBQUM7TUFDakQ7TUFDQSxPQUFPLElBQUksQ0FBQ0QsV0FBVztJQUN6Qjs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBRCxHQUFBO0lBQUFHLEtBQUEsRUFHQSxTQUFBQyxJQUFJQSxDQUFDQyxNQUF3QixFQUFFO01BQUEsSUFBQUMsTUFBQTtNQUM3QixJQUFJNUMsc0JBQXNCLENBQUMsQ0FBQyxFQUFFO1FBQzVCO01BQ0Y7TUFDQSxJQUFJLENBQUN3QyxPQUFPLEdBQUdHLE1BQU07TUFDckIsSUFBTUUsTUFBTSxHQUFHLElBQUksQ0FBQ0MsVUFBVSxDQUFDLENBQUM7TUFDaEMsSUFBSUQsTUFBTSxFQUFFO1FBQ1YsSUFBSSxDQUFDRSxVQUFVLENBQUNDLFVBQVUsQ0FBQ0gsTUFBTSxDQUFDO1FBQ2xDSSxXQUFBLENBQVcsWUFBTTtVQUNmTCxNQUFJLENBQUNNLElBQUksQ0FBQyxTQUFTLEVBQUVOLE1BQUksQ0FBQ0csVUFBVSxDQUFDO1FBQ3ZDLENBQUMsRUFBRSxFQUFFLENBQUM7TUFDUjtJQUNGOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFULEdBQUE7SUFBQUcsS0FBQSxFQUdBLFNBQUFVLEtBQUtBLENBQUEsRUFBNkI7TUFBQSxJQUFBQyxhQUFBO1FBQUFDLFdBQUE7UUFBQUMsWUFBQTtRQUFBQyxNQUFBO01BQUEsSUFBNUJDLE9BQXFCLEdBQUFDLFNBQUEsQ0FBQUMsTUFBQSxRQUFBRCxTQUFBLFFBQUE3RCxTQUFBLEdBQUE2RCxTQUFBLE1BQUcsQ0FBQyxDQUFDO01BQzlCLElBQVFFLEtBQUssR0FBV0gsT0FBTyxDQUF2QkcsS0FBSztRQUFFQyxJQUFJLEdBQUtKLE9BQU8sQ0FBaEJJLElBQUk7TUFDbkIsSUFBTUMsTUFBTSxHQUFHLElBQUloRixNQUFNLEVBQUF1RSxhQUFBLEdBQUMsSUFBSSxDQUFDWixPQUFPLGNBQUFZLGFBQUEsY0FBQUEsYUFBQSxHQUFJLENBQUMsQ0FBQyxDQUFDO01BQzdDLElBQU1VLElBQUksR0FBR0MsSUFBSSxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUN2QyxTQUFTLENBQUMsQ0FBQyxDQUFDO01BQ3BELElBQU12QixLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUNnQyxPQUFPLEVBQUUsT0FBTyxFQUFFMkIsSUFBSSxDQUFDLENBQUNJLElBQUksQ0FBQyxHQUFHLENBQUM7TUFDckQ5RCxZQUFZLENBQUMrRCxPQUFPLENBQUMsZUFBZSxFQUFFaEUsS0FBSyxDQUFDO01BQzVDLElBQU1pRSxRQUFRLEdBQUdQLE1BQU0sQ0FBQ1EsbUJBQW1CLENBQUFDLGFBQUE7UUFDekNDLGFBQWEsRUFBRSxPQUFPO1FBQ3RCQyxNQUFNLEVBQUMsZUFBZTtRQUN0QnJFLEtBQUssRUFBRUEsS0FBSyxPQUFBTCxNQUFBLENBQU0yRSxlQUFBLENBQWU7VUFDL0JDLFFBQVEsRUFBQ2IsTUFBTSxDQUFDYSxRQUFRO1VBQ3hCQyxXQUFXLEVBQUNkLE1BQU0sQ0FBQ2M7UUFDdkIsQ0FBQyxDQUFDO01BQUUsR0FDRWhCLEtBQUssR0FBRztRQUFFQSxLQUFLLEVBQUxBO01BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUMzQixDQUFDO01BQ0YsSUFBTWlCLEVBQUUsR0FBRzlGLFFBQVEsQ0FDakJzRixRQUFRLEdBQUFmLFdBQUEsR0FDUk8sSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUVyRSxLQUFLLGNBQUE4RCxXQUFBLGNBQUFBLFdBQUEsR0FBSXpCLHVCQUF1QixHQUFBMEIsWUFBQSxHQUN0Q00sSUFBSSxhQUFKQSxJQUFJLHVCQUFKQSxJQUFJLENBQUVuRSxNQUFNLGNBQUE2RCxZQUFBLGNBQUFBLFlBQUEsR0FBSXpCLHdCQUNsQixDQUFDO01BQ0QsT0FBTyxJQUFBZ0QsUUFBQSxDQUFnQyxVQUFDQyxPQUFPLEVBQUVDLE1BQU0sRUFBSztRQUMxRCxJQUFJLENBQUNILEVBQUUsRUFBRTtVQUNQLElBQU16RSxNQUFLLEdBQUcsQ0FBQ29ELE1BQUksQ0FBQ3BCLE9BQU8sRUFBRSxVQUFVLEVBQUUyQixJQUFJLENBQUMsQ0FBQ0ksSUFBSSxDQUFDLEdBQUcsQ0FBQztVQUN4RDlELFlBQVksQ0FBQytELE9BQU8sQ0FBQyxlQUFlLEVBQUVoRSxNQUFLLENBQUM7VUFDNUMsSUFBTWlFLFNBQVEsR0FBR1AsTUFBTSxDQUFDUSxtQkFBbUIsQ0FBQUMsYUFBQTtZQUN6Q0MsYUFBYSxFQUFFLE9BQU87WUFDdEJDLE1BQU0sRUFBQyxTQUFTO1lBQ2RyRSxLQUFLLEVBQUVBLE1BQUssT0FBQUwsTUFBQSxDQUFNMkUsZUFBQSxDQUFlO2NBQy9CQyxRQUFRLEVBQUNiLE1BQU0sQ0FBQ2EsUUFBUTtjQUN4QkMsV0FBVyxFQUFDZCxNQUFNLENBQUNjO1lBQ3ZCLENBQUMsQ0FBQztVQUFFLEdBQ0FoQixLQUFLLEdBQUc7WUFBRUEsS0FBSyxFQUFMQTtVQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FDM0IsQ0FBQztVQUNGdkMsUUFBUSxDQUFDNEQsSUFBSSxHQUFHWixTQUFRO1VBQ3hCO1FBQ0Y7UUFDQWIsTUFBSSxDQUFDMEIsYUFBYSxDQUFDLENBQUM7UUFDcEIsSUFBTUMsR0FBRyxHQUFHQyxZQUFBLENBQVksWUFBTTtVQUM1QixJQUFJO1lBQ0YsSUFBSSxDQUFDUCxFQUFFLElBQUlBLEVBQUUsQ0FBQ1EsTUFBTSxFQUFFO2NBQ3BCQyxhQUFhLENBQUNILEdBQUcsQ0FBQztjQUNsQixJQUFNckMsTUFBTSxHQUFHVSxNQUFJLENBQUNULFVBQVUsQ0FBQyxDQUFDO2NBQ2hDLElBQUlELE1BQU0sRUFBRTtnQkFDVlUsTUFBSSxDQUFDUixVQUFVLENBQUNDLFVBQVUsQ0FBQ0gsTUFBTSxDQUFDO2dCQUNsQ1UsTUFBSSxDQUFDTCxJQUFJLENBQUMsU0FBUyxFQUFFSyxNQUFJLENBQUNSLFVBQVUsQ0FBQztnQkFDckMrQixPQUFPLENBQUM7a0JBQUVRLE1BQU0sRUFBRTtnQkFBVSxDQUFDLENBQUM7Y0FDaEMsQ0FBQyxNQUFNO2dCQUNMLElBQU1DLEdBQUcsR0FBR2hDLE1BQUksQ0FBQ2lDLFNBQVMsQ0FBQyxDQUFDO2dCQUM1QixJQUFJRCxHQUFHLEVBQUU7a0JBQ1BSLE1BQU0sQ0FBQyxJQUFJVSxLQUFLLENBQUNGLEdBQUcsQ0FBQ0csS0FBSyxHQUFHLElBQUksR0FBR0gsR0FBRyxDQUFDSSxpQkFBaUIsQ0FBQyxDQUFDO2dCQUM3RCxDQUFDLE1BQU07a0JBQ0xiLE9BQU8sQ0FBQztvQkFBRVEsTUFBTSxFQUFFO2tCQUFTLENBQUMsQ0FBQztnQkFDL0I7Y0FDRjtZQUNGO1VBQ0YsQ0FBQyxDQUFDLE9BQU9NLENBQUMsRUFBRTtZQUNWO1lBQ0FDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLGNBQWMsRUFBRUYsQ0FBQyxDQUFDO1VBQ2hDO1FBQ0YsQ0FBQyxFQUFFLElBQUksQ0FBQztNQUNWLENBQUMsQ0FBQztJQUNKOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUF0RCxHQUFBO0lBQUFHLEtBQUEsRUFHQSxTQUFBc0QsVUFBVUEsQ0FBQSxFQUFHO01BQ1gsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDaEQsVUFBVSxDQUFDaUQsV0FBVztJQUN0Qzs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBMUQsR0FBQTtJQUFBRyxLQUFBLEVBR0EsU0FBQXdELE1BQU1BLENBQUEsRUFBRztNQUNQLElBQUksQ0FBQ2xELFVBQVUsQ0FBQ2tELE1BQU0sQ0FBQyxDQUFDO01BQ3hCLElBQUksQ0FBQ2hCLGFBQWEsQ0FBQyxDQUFDO01BQ3BCLElBQUksQ0FBQy9CLElBQUksQ0FBQyxZQUFZLENBQUM7SUFDekI7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQVosR0FBQTtJQUFBRyxLQUFBLEVBR0EsU0FBQUssVUFBVUEsQ0FBQSxFQUFHO01BQ1gsSUFBTW9ELE1BQU0sR0FBRyxJQUFJQyxNQUFNLENBQ3ZCLFdBQVcsR0FBRyxJQUFJLENBQUNoRSxPQUFPLEdBQUcscUJBQy9CLENBQUM7TUFDRCxJQUFJaUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FBQ0osTUFBTSxDQUFDLEVBQUU7UUFDakMsSUFBTUssUUFBUSxHQUFHQyxNQUFNLENBQ3JCcEcsWUFBWSxDQUFDQyxPQUFPLENBQUMsSUFBSSxDQUFDOEIsT0FBTyxHQUFHLFlBQVksQ0FDbEQsQ0FBQztRQUNEO1FBQ0EsSUFBSXNFLFNBQUEsQ0FBUyxDQUFDLEdBQUdGLFFBQVEsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxJQUFJLEVBQUU7VUFDOUMsSUFBSUcsUUFBUTtVQUNaLElBQU1DLEtBQUssR0FBR3ZHLFlBQVksQ0FBQ0MsT0FBTyxDQUFDLElBQUksQ0FBQzhCLE9BQU8sR0FBRyxLQUFLLENBQUM7VUFDeEQsSUFBSXdFLEtBQUssRUFBRTtZQUFBLElBQUFDLFNBQUE7WUFDVCxJQUFBQyxvQkFBQSxHQUE2QkMsd0JBQUEsQ0FBQUYsU0FBQSxHQUFBRCxLQUFLLENBQUNqRyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUFYLElBQUEsQ0FBQTZHLFNBQVMsQ0FBQztjQUFBRyxxQkFBQSxHQUFBbkcsY0FBQSxDQUFBaUcsb0JBQUE7Y0FBaERHLEVBQUUsR0FBQUQscUJBQUE7Y0FBRUUsY0FBYyxHQUFBRixxQkFBQTtZQUN6QkwsUUFBUSxHQUFHO2NBQUVNLEVBQUUsRUFBRkEsRUFBRTtjQUFFQyxjQUFjLEVBQWRBLGNBQWM7Y0FBRWxJLEdBQUcsRUFBRTRIO1lBQU0sQ0FBQztVQUMvQztVQUNBLE9BQU87WUFDTFgsV0FBVyxFQUFFNUYsWUFBWSxDQUFDQyxPQUFPLENBQUMsSUFBSSxDQUFDOEIsT0FBTyxHQUFHLGVBQWUsQ0FBQztZQUNqRStFLFdBQVcsRUFBRTlHLFlBQVksQ0FBQ0MsT0FBTyxDQUFDLElBQUksQ0FBQzhCLE9BQU8sR0FBRyxlQUFlLENBQUM7WUFDakVnRixZQUFZLEVBQUUvRyxZQUFZLENBQUNDLE9BQU8sQ0FBQyxJQUFJLENBQUM4QixPQUFPLEdBQUcsZ0JBQWdCLENBQUM7WUFDbkV1RSxRQUFRLEVBQVJBO1VBQ0YsQ0FBQztRQUNIO01BQ0Y7TUFDQSxPQUFPLElBQUk7SUFDYjs7SUFFQTtBQUNGO0FBQ0E7RUFGRTtJQUFBcEUsR0FBQTtJQUFBRyxLQUFBLEVBR0EsU0FBQXZCLFlBQVlBLENBQUNNLE1BQXFCLEVBQUU7TUFDbENwQixZQUFZLENBQUMrRCxPQUFPLENBQUMsSUFBSSxDQUFDaEMsT0FBTyxHQUFHLGVBQWUsRUFBRVgsTUFBTSxDQUFDNEYsWUFBWSxDQUFDO01BQ3pFaEgsWUFBWSxDQUFDK0QsT0FBTyxDQUFDLElBQUksQ0FBQ2hDLE9BQU8sR0FBRyxlQUFlLEVBQUVYLE1BQU0sQ0FBQzZGLFlBQVksQ0FBQztNQUN6RWpILFlBQVksQ0FBQytELE9BQU8sQ0FBQyxJQUFJLENBQUNoQyxPQUFPLEdBQUcsWUFBWSxFQUFFWCxNQUFNLENBQUM4RixTQUFTLENBQUM7TUFDbkVsSCxZQUFZLENBQUMrRCxPQUFPLENBQUMsSUFBSSxDQUFDaEMsT0FBTyxHQUFHLEtBQUssRUFBRVgsTUFBTSxDQUFDd0YsRUFBRSxDQUFDO01BQ3JELElBQUd4RixNQUFNLENBQUMrRixhQUFhLEVBQUM7UUFDdEJuSCxZQUFZLENBQUMrRCxPQUFPLENBQUMsSUFBSSxDQUFDaEMsT0FBTyxHQUFHLGdCQUFnQixFQUFFWCxNQUFNLENBQUMrRixhQUFhLENBQUM7TUFDN0U7TUFDQW5CLFFBQVEsQ0FBQ0MsTUFBTSxHQUFHLElBQUksQ0FBQ2xFLE9BQU8sR0FBRyxpQkFBaUI7SUFDcEQ7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQUcsR0FBQTtJQUFBRyxLQUFBLEVBR0EsU0FBQXdDLGFBQWFBLENBQUEsRUFBRztNQUNkN0UsWUFBWSxDQUFDSSxVQUFVLENBQUMsSUFBSSxDQUFDMkIsT0FBTyxHQUFHLGVBQWUsQ0FBQztNQUN2RC9CLFlBQVksQ0FBQ0ksVUFBVSxDQUFDLElBQUksQ0FBQzJCLE9BQU8sR0FBRyxlQUFlLENBQUM7TUFDdkQvQixZQUFZLENBQUNJLFVBQVUsQ0FBQyxJQUFJLENBQUMyQixPQUFPLEdBQUcsWUFBWSxDQUFDO01BQ3BEL0IsWUFBWSxDQUFDSSxVQUFVLENBQUMsSUFBSSxDQUFDMkIsT0FBTyxHQUFHLEtBQUssQ0FBQztNQUM3Q2lFLFFBQVEsQ0FBQ0MsTUFBTSxHQUFHLElBQUksQ0FBQ2xFLE9BQU8sR0FBRyxZQUFZO0lBQy9DOztJQUVBO0FBQ0Y7QUFDQTtFQUZFO0lBQUFHLEdBQUE7SUFBQUcsS0FBQSxFQUdBLFNBQUErQyxTQUFTQSxDQUFBLEVBQUc7TUFDVixJQUFJO1FBQUEsSUFBQWdDLHFCQUFBO1FBQ0YsSUFBTWpDLEdBQUcsR0FBR2tDLElBQUksQ0FBQ0MsS0FBSyxFQUFBRixxQkFBQSxHQUNwQnBILFlBQVksQ0FBQ0MsT0FBTyxDQUFDLElBQUksQ0FBQzhCLE9BQU8sR0FBRyxRQUFRLENBQUMsY0FBQXFGLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFDbkQsQ0FBQztRQUNEcEgsWUFBWSxDQUFDSSxVQUFVLENBQUMsSUFBSSxDQUFDMkIsT0FBTyxHQUFHLFFBQVEsQ0FBQztRQUNoRCxPQUFPb0QsR0FBRztNQUNaLENBQUMsQ0FBQyxPQUFPSyxDQUFDLEVBQUU7UUFDVjtNQUFBO0lBRUo7O0lBRUE7QUFDRjtBQUNBO0VBRkU7SUFBQXRELEdBQUE7SUFBQUcsS0FBQSxFQUdBLFNBQUFuQixXQUFXQSxDQUFDaUUsR0FBUSxFQUFFO01BQ3BCbkYsWUFBWSxDQUFDK0QsT0FBTyxDQUFDLElBQUksQ0FBQ2hDLE9BQU8sR0FBRyxRQUFRLEVBQUVzQyxlQUFBLENBQWVjLEdBQUcsQ0FBQyxDQUFDO0lBQ3BFO0VBQUM7QUFBQSxFQWxNZ0M1RyxZQUFZOztBQXFNL0M7QUFDQTtBQUNBO0FBQ0EsSUFBTWdKLE1BQU0sR0FBRyxJQUFJM0csYUFBYSxDQUFDLENBQUM7QUFFbEMsZUFBZTJHLE1BQU0iLCJpZ25vcmVMaXN0IjpbXX0=