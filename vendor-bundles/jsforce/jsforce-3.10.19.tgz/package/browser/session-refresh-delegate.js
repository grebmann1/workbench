import _asyncToGenerator from "@babel/runtime-corejs3/helpers/asyncToGenerator";
import _classCallCheck from "@babel/runtime-corejs3/helpers/classCallCheck";
import _createClass from "@babel/runtime-corejs3/helpers/createClass";
import _defineProperty from "@babel/runtime-corejs3/helpers/defineProperty";
import _regeneratorRuntime from "@babel/runtime-corejs3/regenerator";
import "core-js/modules/es.error.cause.js";
import _Promise from "@babel/runtime-corejs3/core-js-stable/promise";
import _Date$now from "@babel/runtime-corejs3/core-js-stable/date/now";
/**
 *
 */
import { getLogger } from './util/logger';

/**
 *
 */

/**
 *
 */
export var SessionRefreshDelegate = /*#__PURE__*/function () {
  function SessionRefreshDelegate(conn, refreshFn) {
    _classCallCheck(this, SessionRefreshDelegate);
    _defineProperty(this, "_lastRefreshedAt", undefined);
    _defineProperty(this, "_refreshPromise", undefined);
    this._conn = conn;
    this._logger = conn._logLevel ? SessionRefreshDelegate._logger.createInstance(conn._logLevel) : SessionRefreshDelegate._logger;
    this._refreshFn = refreshFn;
  }

  /**
   * Refresh access token
   * @private
   */
  return _createClass(SessionRefreshDelegate, [{
    key: "refresh",
    value: (function () {
      var _refresh = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee(since) {
        var _this = this;
        return _regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              if (!(this._lastRefreshedAt && this._lastRefreshedAt > since)) {
                _context.next = 2;
                break;
              }
              return _context.abrupt("return");
            case 2:
              if (!this._refreshPromise) {
                _context.next = 6;
                break;
              }
              _context.next = 5;
              return this._refreshPromise;
            case 5:
              return _context.abrupt("return");
            case 6:
              _context.prev = 6;
              this._logger.info('<refresh token>');
              this._refreshPromise = new _Promise(function (resolve, reject) {
                _this._refreshFn(_this._conn, function (err, accessToken, res) {
                  if (!err) {
                    _this._logger.debug('Connection refresh completed.');
                    _this._conn.accessToken = accessToken;
                    _this._conn.emit('refresh', accessToken, res);
                    resolve();
                  } else if (err.message === 'defaultRefreshFn') {
                    _this._logger.debug('Connection refresh failed.');
                    _this._conn.emit('sessionExpired', null, res);
                    reject(new Error('SessionId has expired'));
                  } else {
                    reject(err);
                  }
                });
              });
              _context.next = 11;
              return this._refreshPromise;
            case 11:
              this._logger.info('<refresh complete>');
              _context.next = 17;
              break;
            case 14:
              _context.prev = 14;
              _context.t0 = _context["catch"](6);
              throw new Error("Unable to refresh session due to: ".concat(_context.t0.message));
            case 17:
              _context.prev = 17;
              this._refreshPromise = undefined;
              this._lastRefreshedAt = _Date$now();
              return _context.finish(17);
            case 21:
            case "end":
              return _context.stop();
          }
        }, _callee, this, [[6, 14, 17, 21]]);
      }));
      function refresh(_x) {
        return _refresh.apply(this, arguments);
      }
      return refresh;
    }())
  }, {
    key: "isRefreshing",
    value: function isRefreshing() {
      return !!this._refreshPromise;
    }
  }, {
    key: "waitRefresh",
    value: function () {
      var _waitRefresh = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime.mark(function _callee2() {
        return _regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              return _context2.abrupt("return", this._refreshPromise);
            case 1:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
      function waitRefresh() {
        return _waitRefresh.apply(this, arguments);
      }
      return waitRefresh;
    }()
  }]);
}();
_defineProperty(SessionRefreshDelegate, "_logger", getLogger('session-refresh-delegate'));
export default SessionRefreshDelegate;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJnZXRMb2dnZXIiLCJTZXNzaW9uUmVmcmVzaERlbGVnYXRlIiwiY29ubiIsInJlZnJlc2hGbiIsIl9jbGFzc0NhbGxDaGVjayIsIl9kZWZpbmVQcm9wZXJ0eSIsInVuZGVmaW5lZCIsIl9jb25uIiwiX2xvZ2dlciIsIl9sb2dMZXZlbCIsImNyZWF0ZUluc3RhbmNlIiwiX3JlZnJlc2hGbiIsIl9jcmVhdGVDbGFzcyIsImtleSIsInZhbHVlIiwiX3JlZnJlc2giLCJfYXN5bmNUb0dlbmVyYXRvciIsIl9yZWdlbmVyYXRvclJ1bnRpbWUiLCJtYXJrIiwiX2NhbGxlZSIsInNpbmNlIiwiX3RoaXMiLCJ3cmFwIiwiX2NhbGxlZSQiLCJfY29udGV4dCIsInByZXYiLCJuZXh0IiwiX2xhc3RSZWZyZXNoZWRBdCIsImFicnVwdCIsIl9yZWZyZXNoUHJvbWlzZSIsImluZm8iLCJfUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJlcnIiLCJhY2Nlc3NUb2tlbiIsInJlcyIsImRlYnVnIiwiZW1pdCIsIm1lc3NhZ2UiLCJFcnJvciIsInQwIiwiY29uY2F0IiwiX0RhdGUkbm93IiwiZmluaXNoIiwic3RvcCIsInJlZnJlc2giLCJfeCIsImFwcGx5IiwiYXJndW1lbnRzIiwiaXNSZWZyZXNoaW5nIiwiX3dhaXRSZWZyZXNoIiwiX2NhbGxlZTIiLCJfY2FsbGVlMiQiLCJfY29udGV4dDIiLCJ3YWl0UmVmcmVzaCJdLCJzb3VyY2VzIjpbIi4uL3NyYy9zZXNzaW9uLXJlZnJlc2gtZGVsZWdhdGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKlxuICovXG5pbXBvcnQgeyBnZXRMb2dnZXIsIExvZ2dlciB9IGZyb20gJy4vdXRpbC9sb2dnZXInO1xuaW1wb3J0IHsgQ2FsbGJhY2ssIFNjaGVtYSB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IENvbm5lY3Rpb24gZnJvbSAnLi9jb25uZWN0aW9uJztcbmltcG9ydCB7IFRva2VuUmVzcG9uc2UgfSBmcm9tICcuL29hdXRoMic7XG5cbi8qKlxuICpcbiAqL1xuZXhwb3J0IHR5cGUgU2Vzc2lvblJlZnJlc2hGdW5jPFMgZXh0ZW5kcyBTY2hlbWE+ID0gKFxuICBjb25uOiBDb25uZWN0aW9uPFM+LFxuICBjYWxsYmFjazogQ2FsbGJhY2s8c3RyaW5nLCBUb2tlblJlc3BvbnNlPixcbikgPT4gdm9pZDtcblxuLyoqXG4gKlxuICovXG5leHBvcnQgY2xhc3MgU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZTxTIGV4dGVuZHMgU2NoZW1hPiB7XG4gIHN0YXRpYyBfbG9nZ2VyOiBMb2dnZXIgPSBnZXRMb2dnZXIoJ3Nlc3Npb24tcmVmcmVzaC1kZWxlZ2F0ZScpO1xuXG4gIHByaXZhdGUgX3JlZnJlc2hGbjogU2Vzc2lvblJlZnJlc2hGdW5jPFM+O1xuICBwcml2YXRlIF9jb25uOiBDb25uZWN0aW9uPFM+O1xuICBwcml2YXRlIF9sb2dnZXI6IExvZ2dlcjtcbiAgcHJpdmF0ZSBfbGFzdFJlZnJlc2hlZEF0OiBudW1iZXIgfCB2b2lkID0gdW5kZWZpbmVkO1xuICBwcml2YXRlIF9yZWZyZXNoUHJvbWlzZTogUHJvbWlzZTx2b2lkPiB8IHZvaWQgPSB1bmRlZmluZWQ7XG5cbiAgY29uc3RydWN0b3IoY29ubjogQ29ubmVjdGlvbjxTPiwgcmVmcmVzaEZuOiBTZXNzaW9uUmVmcmVzaEZ1bmM8Uz4pIHtcbiAgICB0aGlzLl9jb25uID0gY29ubjtcbiAgICB0aGlzLl9sb2dnZXIgPSBjb25uLl9sb2dMZXZlbFxuICAgICAgPyBTZXNzaW9uUmVmcmVzaERlbGVnYXRlLl9sb2dnZXIuY3JlYXRlSW5zdGFuY2UoY29ubi5fbG9nTGV2ZWwpXG4gICAgICA6IFNlc3Npb25SZWZyZXNoRGVsZWdhdGUuX2xvZ2dlcjtcbiAgICB0aGlzLl9yZWZyZXNoRm4gPSByZWZyZXNoRm47XG4gIH1cblxuICAvKipcbiAgICogUmVmcmVzaCBhY2Nlc3MgdG9rZW5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIGFzeW5jIHJlZnJlc2goc2luY2U6IG51bWJlcikge1xuICAgIC8vIENhbGxiYWNrIGltbWVkaWF0ZWx5IFdoZW4gcmVmcmVzaGVkIGFmdGVyIGRlc2lnbmF0ZWQgdGltZVxuICAgIGlmICh0aGlzLl9sYXN0UmVmcmVzaGVkQXQgJiYgdGhpcy5fbGFzdFJlZnJlc2hlZEF0ID4gc2luY2UpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHRoaXMuX3JlZnJlc2hQcm9taXNlKSB7XG4gICAgICBhd2FpdCB0aGlzLl9yZWZyZXNoUHJvbWlzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuX2xvZ2dlci5pbmZvKCc8cmVmcmVzaCB0b2tlbj4nKTtcbiAgICAgIHRoaXMuX3JlZnJlc2hQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICB0aGlzLl9yZWZyZXNoRm4odGhpcy5fY29ubiwgKGVyciwgYWNjZXNzVG9rZW4sIHJlcykgPT4ge1xuICAgICAgICAgIGlmICghZXJyKSB7XG4gICAgICAgICAgICB0aGlzLl9sb2dnZXIuZGVidWcoJ0Nvbm5lY3Rpb24gcmVmcmVzaCBjb21wbGV0ZWQuJyk7XG4gICAgICAgICAgICB0aGlzLl9jb25uLmFjY2Vzc1Rva2VuID0gYWNjZXNzVG9rZW47XG4gICAgICAgICAgICB0aGlzLl9jb25uLmVtaXQoJ3JlZnJlc2gnLCBhY2Nlc3NUb2tlbiwgcmVzKTtcbiAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICB9IGVsc2UgaWYoZXJyLm1lc3NhZ2UgPT09ICdkZWZhdWx0UmVmcmVzaEZuJyl7XG4gICAgICAgICAgICB0aGlzLl9sb2dnZXIuZGVidWcoJ0Nvbm5lY3Rpb24gcmVmcmVzaCBmYWlsZWQuJyk7XG4gICAgICAgICAgICB0aGlzLl9jb25uLmVtaXQoJ3Nlc3Npb25FeHBpcmVkJywgbnVsbCxyZXMpO1xuICAgICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcignU2Vzc2lvbklkIGhhcyBleHBpcmVkJykpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgICBhd2FpdCB0aGlzLl9yZWZyZXNoUHJvbWlzZTtcbiAgICAgIHRoaXMuX2xvZ2dlci5pbmZvKCc8cmVmcmVzaCBjb21wbGV0ZT4nKTtcbiAgICB9IGNhdGNoKGVycikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmFibGUgdG8gcmVmcmVzaCBzZXNzaW9uIGR1ZSB0bzogJHsoZXJyIGFzIEVycm9yKS5tZXNzYWdlfWApXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMuX3JlZnJlc2hQcm9taXNlID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy5fbGFzdFJlZnJlc2hlZEF0ID0gRGF0ZS5ub3coKTtcbiAgICB9XG4gIH1cblxuICBpc1JlZnJlc2hpbmcoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuICEhdGhpcy5fcmVmcmVzaFByb21pc2U7XG4gIH1cblxuICBhc3luYyB3YWl0UmVmcmVzaCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVmcmVzaFByb21pc2U7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgU2Vzc2lvblJlZnJlc2hEZWxlZ2F0ZTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQSxTQUFTLFFBQWdCLGVBQWU7O0FBS2pEO0FBQ0E7QUFDQTs7QUFNQTtBQUNBO0FBQ0E7QUFDQSxXQUFhQyxzQkFBc0I7RUFTakMsU0FBQUEsdUJBQVlDLElBQW1CLEVBQUVDLFNBQWdDLEVBQUU7SUFBQUMsZUFBQSxPQUFBSCxzQkFBQTtJQUFBSSxlQUFBLDJCQUh6QkMsU0FBUztJQUFBRCxlQUFBLDBCQUNIQyxTQUFTO0lBR3ZELElBQUksQ0FBQ0MsS0FBSyxHQUFHTCxJQUFJO0lBQ2pCLElBQUksQ0FBQ00sT0FBTyxHQUFHTixJQUFJLENBQUNPLFNBQVMsR0FDekJSLHNCQUFzQixDQUFDTyxPQUFPLENBQUNFLGNBQWMsQ0FBQ1IsSUFBSSxDQUFDTyxTQUFTLENBQUMsR0FDN0RSLHNCQUFzQixDQUFDTyxPQUFPO0lBQ2xDLElBQUksQ0FBQ0csVUFBVSxHQUFHUixTQUFTO0VBQzdCOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBSEUsT0FBQVMsWUFBQSxDQUFBWCxzQkFBQTtJQUFBWSxHQUFBO0lBQUFDLEtBQUE7TUFBQSxJQUFBQyxRQUFBLEdBQUFDLGlCQUFBLGNBQUFDLG1CQUFBLENBQUFDLElBQUEsQ0FJQSxTQUFBQyxRQUFjQyxLQUFhO1FBQUEsSUFBQUMsS0FBQTtRQUFBLE9BQUFKLG1CQUFBLENBQUFLLElBQUEsVUFBQUMsU0FBQUMsUUFBQTtVQUFBLGtCQUFBQSxRQUFBLENBQUFDLElBQUEsR0FBQUQsUUFBQSxDQUFBRSxJQUFBO1lBQUE7Y0FBQSxNQUVyQixJQUFJLENBQUNDLGdCQUFnQixJQUFJLElBQUksQ0FBQ0EsZ0JBQWdCLEdBQUdQLEtBQUs7Z0JBQUFJLFFBQUEsQ0FBQUUsSUFBQTtnQkFBQTtjQUFBO2NBQUEsT0FBQUYsUUFBQSxDQUFBSSxNQUFBO1lBQUE7Y0FBQSxLQUd0RCxJQUFJLENBQUNDLGVBQWU7Z0JBQUFMLFFBQUEsQ0FBQUUsSUFBQTtnQkFBQTtjQUFBO2NBQUFGLFFBQUEsQ0FBQUUsSUFBQTtjQUFBLE9BQ2hCLElBQUksQ0FBQ0csZUFBZTtZQUFBO2NBQUEsT0FBQUwsUUFBQSxDQUFBSSxNQUFBO1lBQUE7Y0FBQUosUUFBQSxDQUFBQyxJQUFBO2NBSTFCLElBQUksQ0FBQ2pCLE9BQU8sQ0FBQ3NCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztjQUNwQyxJQUFJLENBQUNELGVBQWUsR0FBRyxJQUFBRSxRQUFBLENBQVksVUFBQ0MsT0FBTyxFQUFFQyxNQUFNLEVBQUs7Z0JBQ3REWixLQUFJLENBQUNWLFVBQVUsQ0FBQ1UsS0FBSSxDQUFDZCxLQUFLLEVBQUUsVUFBQzJCLEdBQUcsRUFBRUMsV0FBVyxFQUFFQyxHQUFHLEVBQUs7a0JBQ3JELElBQUksQ0FBQ0YsR0FBRyxFQUFFO29CQUNSYixLQUFJLENBQUNiLE9BQU8sQ0FBQzZCLEtBQUssQ0FBQywrQkFBK0IsQ0FBQztvQkFDbkRoQixLQUFJLENBQUNkLEtBQUssQ0FBQzRCLFdBQVcsR0FBR0EsV0FBVztvQkFDcENkLEtBQUksQ0FBQ2QsS0FBSyxDQUFDK0IsSUFBSSxDQUFDLFNBQVMsRUFBRUgsV0FBVyxFQUFFQyxHQUFHLENBQUM7b0JBQzVDSixPQUFPLENBQUMsQ0FBQztrQkFDWCxDQUFDLE1BQU0sSUFBR0UsR0FBRyxDQUFDSyxPQUFPLEtBQUssa0JBQWtCLEVBQUM7b0JBQzNDbEIsS0FBSSxDQUFDYixPQUFPLENBQUM2QixLQUFLLENBQUMsNEJBQTRCLENBQUM7b0JBQ2hEaEIsS0FBSSxDQUFDZCxLQUFLLENBQUMrQixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxFQUFDRixHQUFHLENBQUM7b0JBQzNDSCxNQUFNLENBQUMsSUFBSU8sS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUM7a0JBQzVDLENBQUMsTUFBTTtvQkFDTFAsTUFBTSxDQUFDQyxHQUFHLENBQUM7a0JBQ2I7Z0JBQ0YsQ0FBQyxDQUFDO2NBQ0osQ0FBQyxDQUFDO2NBQUNWLFFBQUEsQ0FBQUUsSUFBQTtjQUFBLE9BQ0csSUFBSSxDQUFDRyxlQUFlO1lBQUE7Y0FDMUIsSUFBSSxDQUFDckIsT0FBTyxDQUFDc0IsSUFBSSxDQUFDLG9CQUFvQixDQUFDO2NBQUNOLFFBQUEsQ0FBQUUsSUFBQTtjQUFBO1lBQUE7Y0FBQUYsUUFBQSxDQUFBQyxJQUFBO2NBQUFELFFBQUEsQ0FBQWlCLEVBQUEsR0FBQWpCLFFBQUE7Y0FBQSxNQUVsQyxJQUFJZ0IsS0FBSyxzQ0FBQUUsTUFBQSxDQUFzQ2xCLFFBQUEsQ0FBQWlCLEVBQUEsQ0FBZUYsT0FBTyxDQUFFLENBQUM7WUFBQTtjQUFBZixRQUFBLENBQUFDLElBQUE7Y0FFOUUsSUFBSSxDQUFDSSxlQUFlLEdBQUd2QixTQUFTO2NBQ2hDLElBQUksQ0FBQ3FCLGdCQUFnQixHQUFHZ0IsU0FBQSxDQUFTLENBQUM7Y0FBQyxPQUFBbkIsUUFBQSxDQUFBb0IsTUFBQTtZQUFBO1lBQUE7Y0FBQSxPQUFBcEIsUUFBQSxDQUFBcUIsSUFBQTtVQUFBO1FBQUEsR0FBQTFCLE9BQUE7TUFBQSxDQUV0QztNQUFBLFNBbkNLMkIsT0FBT0EsQ0FBQUMsRUFBQTtRQUFBLE9BQUFoQyxRQUFBLENBQUFpQyxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVBILE9BQU87SUFBQTtFQUFBO0lBQUFqQyxHQUFBO0lBQUFDLEtBQUEsRUFxQ2IsU0FBQW9DLFlBQVlBLENBQUEsRUFBWTtNQUN0QixPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUNyQixlQUFlO0lBQy9CO0VBQUM7SUFBQWhCLEdBQUE7SUFBQUMsS0FBQTtNQUFBLElBQUFxQyxZQUFBLEdBQUFuQyxpQkFBQSxjQUFBQyxtQkFBQSxDQUFBQyxJQUFBLENBRUQsU0FBQWtDLFNBQUE7UUFBQSxPQUFBbkMsbUJBQUEsQ0FBQUssSUFBQSxVQUFBK0IsVUFBQUMsU0FBQTtVQUFBLGtCQUFBQSxTQUFBLENBQUE3QixJQUFBLEdBQUE2QixTQUFBLENBQUE1QixJQUFBO1lBQUE7Y0FBQSxPQUFBNEIsU0FBQSxDQUFBMUIsTUFBQSxXQUNTLElBQUksQ0FBQ0MsZUFBZTtZQUFBO1lBQUE7Y0FBQSxPQUFBeUIsU0FBQSxDQUFBVCxJQUFBO1VBQUE7UUFBQSxHQUFBTyxRQUFBO01BQUEsQ0FDNUI7TUFBQSxTQUZLRyxXQUFXQSxDQUFBO1FBQUEsT0FBQUosWUFBQSxDQUFBSCxLQUFBLE9BQUFDLFNBQUE7TUFBQTtNQUFBLE9BQVhNLFdBQVc7SUFBQTtFQUFBO0FBQUE7QUFHbEJsRCxlQUFBLENBakVZSixzQkFBc0IsYUFDUkQsU0FBUyxDQUFDLDBCQUEwQixDQUFDO0FBa0VoRSxlQUFlQyxzQkFBc0IiLCJpZ25vcmVMaXN0IjpbXX0=